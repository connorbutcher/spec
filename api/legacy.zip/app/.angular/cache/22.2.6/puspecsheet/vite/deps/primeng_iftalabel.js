import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ua as ɵɵdefineComponent, Xi as ɵɵProvidersFeature, _o as ɵɵgetInheritedFactory, ca as ɵɵclassMap, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable } from "./core-BenYQOr3.js";
import { U as InjectionToken, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeuix/styles/dist/iftalabel/index.mjs
var style = "\n    .p-iftalabel {\n        display: block;\n        position: relative;\n    }\n\n    .p-iftalabel label {\n        position: absolute;\n        pointer-events: none;\n        top: dt('iftalabel.top');\n        transition-property: all;\n        transition-timing-function: ease;\n        line-height: 1;\n        font-size: dt('iftalabel.font.size');\n        font-weight: dt('iftalabel.font.weight');\n        inset-inline-start: dt('iftalabel.position.x');\n        color: dt('iftalabel.color');\n        transition-duration: dt('iftalabel.transition.duration');\n    }\n\n    .p-iftalabel .p-inputtext,\n    .p-iftalabel .p-textarea,\n    .p-iftalabel .p-select-label,\n    .p-iftalabel .p-multiselect-label,\n    .p-iftalabel .p-multiselect-label:has(.p-chip),\n    .p-iftalabel .p-autocomplete-input-multiple,\n    .p-iftalabel .p-inputtags,\n    .p-iftalabel .p-cascadeselect-label,\n    .p-iftalabel .p-treeselect-label {\n        padding-block-start: dt('iftalabel.input.padding.top');\n        padding-block-end: dt('iftalabel.input.padding.bottom');\n    }\n\n    .p-iftalabel:has(.p-invalid) label {\n        color: dt('iftalabel.invalid.color');\n    }\n\n    .p-iftalabel:has(input:focus) label,\n    .p-iftalabel:has(input:-webkit-autofill) label,\n    .p-iftalabel:has(textarea:focus) label,\n    .p-iftalabel:has(.p-inputwrapper-focus) label {\n        color: dt('iftalabel.focus.color');\n    }\n\n    .p-iftalabel .p-inputicon {\n        margin-top: calc((dt('iftalabel.input.padding.top') - dt('iftalabel.input.padding.bottom') - dt('icon.size')) / 2);\n    }\n";
// node_modules/primeng/fesm2022/primeng-iftalabel.mjs
var classes = { root: "p-iftalabel" };
var IftaLabelStyle = class IftaLabelStyle extends BaseStyle {
	name = "iftalabel";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵIftaLabelStyle_BaseFactory = void 0;
		return function IftaLabelStyle_Factory(__ngFactoryType__) {
			return (ɵIftaLabelStyle_BaseFactory || (ɵIftaLabelStyle_BaseFactory = ɵɵgetInheritedFactory(IftaLabelStyle)))(__ngFactoryType__ || IftaLabelStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: IftaLabelStyle,
		factory: IftaLabelStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(IftaLabelStyle, [{ type: Injectable }], null, null);
})();
var IftaLabelClasses;
(function(IftaLabelClasses) {
	IftaLabelClasses["root"] = "p-iftalabel";
})(IftaLabelClasses || (IftaLabelClasses = {}));
var IFTALABEL_INSTANCE = new InjectionToken("IFTALABEL_INSTANCE");
var IftaLabel = class IftaLabel extends BaseComponent {
	componentName = "IftaLabel";
	_componentStyle = inject(IftaLabelStyle);
	$pcIftaLabel = inject(IFTALABEL_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵIftaLabel_BaseFactory = void 0;
		return function IftaLabel_Factory(__ngFactoryType__) {
			return (ɵIftaLabel_BaseFactory || (ɵIftaLabel_BaseFactory = ɵɵgetInheritedFactory(IftaLabel)))(__ngFactoryType__ || IftaLabel);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: IftaLabel,
			selectors: [["p-iftalabel"], ["p-ifta-label"]],
			hostVars: 2,
			hostBindings: function IftaLabel_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassMap(ctx.cx("root"));
			},
			features: [
				ɵɵProvidersFeature([
					IftaLabelStyle,
					{
						provide: IFTALABEL_INSTANCE,
						useExisting: IftaLabel
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: IftaLabel
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function IftaLabel_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(IftaLabel, [{
		type: Component,
		args: [{
			selector: "p-iftalabel, p-ifta-label",
			standalone: true,
			imports: [],
			template: `<ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				IftaLabelStyle,
				{
					provide: IFTALABEL_INSTANCE,
					useExisting: IftaLabel
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: IftaLabel
				}
			],
			hostDirectives: [Bind],
			host: { "[class]": "cx('root')" }
		}]
	}], null, null);
})();
var IftaLabelModule = class IftaLabelModule {
	static ɵfac = function IftaLabelModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || IftaLabelModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: IftaLabelModule,
		imports: [IftaLabel, SharedModule],
		exports: [IftaLabel, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [SharedModule, SharedModule] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(IftaLabelModule, [{
		type: NgModule,
		args: [{
			imports: [IftaLabel, SharedModule],
			exports: [IftaLabel, SharedModule]
		}]
	}], null, null);
})();
export { IftaLabel, IftaLabelClasses, IftaLabelModule, IftaLabelStyle };
