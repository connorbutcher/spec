import { U as InjectionToken, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Os as ɵɵstyleProp, Ps as ɵɵtextInterpolate, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ca as ɵɵclassMap, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, xn as Injectable } from "./core-BenYQOr3.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { S as p, b as l } from "./dist-BRhwYpCB.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/primeng/fesm2022/primeng-badge.mjs
var style$1 = `
    
    .p-badge {
        display: inline-flex;
        border-radius: dt('badge.border.radius');
        align-items: center;
        justify-content: center;
        padding: dt('badge.padding');
        background: dt('badge.primary.background');
        color: dt('badge.primary.color');
        font-size: dt('badge.font.size');
        font-weight: dt('badge.font.weight');
        min-width: dt('badge.min.width');
        height: dt('badge.height');
    }

    .p-badge-dot {
        width: dt('badge.dot.size');
        min-width: dt('badge.dot.size');
        height: dt('badge.dot.size');
        border-radius: 50%;
        padding: 0;
    }

    .p-badge-circle {
        padding: 0;
        border-radius: 50%;
    }

    .p-badge-secondary {
        background: dt('badge.secondary.background');
        color: dt('badge.secondary.color');
    }

    .p-badge-success {
        background: dt('badge.success.background');
        color: dt('badge.success.color');
    }

    .p-badge-info {
        background: dt('badge.info.background');
        color: dt('badge.info.color');
    }

    .p-badge-warn {
        background: dt('badge.warn.background');
        color: dt('badge.warn.color');
    }

    .p-badge-danger {
        background: dt('badge.danger.background');
        color: dt('badge.danger.color');
    }

    .p-badge-contrast {
        background: dt('badge.contrast.background');
        color: dt('badge.contrast.color');
    }

    .p-badge-sm {
        font-size: dt('badge.sm.font.size');
        min-width: dt('badge.sm.min.width');
        height: dt('badge.sm.height');
    }

    .p-badge-lg {
        font-size: dt('badge.lg.font.size');
        min-width: dt('badge.lg.min.width');
        height: dt('badge.lg.height');
    }

    .p-badge-xl {
        font-size: dt('badge.xl.font.size');
        min-width: dt('badge.xl.min.width');
        height: dt('badge.xl.height');
    }

`;
var classes = { root: ({ instance }) => {
	const value = instance.value();
	const size = instance.size();
	const badgeSize = instance.badgeSize();
	const severity = instance.severity();
	return ["p-badge p-component", {
		"p-badge-circle": l(value) && String(value).length === 1,
		"p-badge-dot": p(value),
		"p-badge-sm": size === "small" || badgeSize === "small",
		"p-badge-lg": size === "large" || badgeSize === "large",
		"p-badge-xl": size === "xlarge" || badgeSize === "xlarge",
		"p-badge-info": severity === "info",
		"p-badge-success": severity === "success",
		"p-badge-warn": severity === "warn",
		"p-badge-danger": severity === "danger",
		"p-badge-secondary": severity === "secondary",
		"p-badge-contrast": severity === "contrast"
	}];
} };
var BadgeStyle = class BadgeStyle extends BaseStyle {
	name = "badge";
	style = style$1;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵBadgeStyle_BaseFactory = void 0;
		return function BadgeStyle_Factory(__ngFactoryType__) {
			return (ɵBadgeStyle_BaseFactory || (ɵBadgeStyle_BaseFactory = ɵɵgetInheritedFactory(BadgeStyle)))(__ngFactoryType__ || BadgeStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: BadgeStyle,
		factory: BadgeStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BadgeStyle, [{ type: Injectable }], null, null);
})();
var BadgeClasses;
(function(BadgeClasses) {
	BadgeClasses["root"] = "p-badge";
})(BadgeClasses || (BadgeClasses = {}));
var BADGE_INSTANCE = new InjectionToken("BADGE_INSTANCE");
var Badge = class Badge extends BaseComponent {
	componentName = "Badge";
	$pcBadge = inject(BADGE_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	badgeSize = input(...ngDevMode ? [void 0, { debugName: "badgeSize" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	severity = input(...ngDevMode ? [void 0, { debugName: "severity" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	badgeDisabled = input(false, {
		...ngDevMode ? { debugName: "badgeDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	_componentStyle = inject(BadgeStyle);
	displayStyle = computed(() => this.badgeDisabled() ? "none" : null, ...ngDevMode ? [{ debugName: "displayStyle" }] : /* istanbul ignore next */ []);
	dataP = computed(() => {
		const value = this.value();
		const severity = this.severity();
		const size = this.size();
		return this.cn({
			circle: value != null && String(value).length === 1,
			empty: value == null,
			disabled: this.badgeDisabled(),
			[severity]: severity,
			[size]: size
		});
	}, ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵBadge_BaseFactory = void 0;
		return function Badge_Factory(__ngFactoryType__) {
			return (ɵBadge_BaseFactory || (ɵBadge_BaseFactory = ɵɵgetInheritedFactory(Badge)))(__ngFactoryType__ || Badge);
		};
	})();
	static ɵcmp = /*@__PURE__*/ ɵɵdefineComponent({
		type: Badge,
		selectors: [["p-badge"]],
		hostVars: 5,
		hostBindings: function Badge_HostBindings(rf, ctx) {
			if (rf & 2) {
				ɵɵattribute("data-p", ctx.dataP());
				ɵɵclassMap(ctx.cx("root"));
				ɵɵstyleProp("display", ctx.displayStyle());
			}
		},
		inputs: {
			badgeSize: [1, "badgeSize"],
			size: [1, "size"],
			severity: [1, "severity"],
			value: [1, "value"],
			badgeDisabled: [1, "badgeDisabled"]
		},
		features: [
			ɵɵProvidersFeature([
				BadgeStyle,
				{
					provide: BADGE_INSTANCE,
					useExisting: Badge
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Badge
				}
			]),
			ɵɵHostDirectivesFeature([Bind]),
			ɵɵInheritDefinitionFeature
		],
		decls: 1,
		vars: 1,
		template: function Badge_Template(rf, ctx) {
			if (rf & 1) ɵɵtext(0);
			if (rf & 2) ɵɵtextInterpolate(ctx.value());
		},
		dependencies: [SharedModule],
		encapsulation: 2
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Badge, [{
		type: Component,
		args: [{
			selector: "p-badge",
			template: `{{ value() }}`,
			standalone: true,
			imports: [SharedModule],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				BadgeStyle,
				{
					provide: BADGE_INSTANCE,
					useExisting: Badge
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Badge
				}
			],
			host: {
				"[class]": "cx('root')",
				"[style.display]": "displayStyle()",
				"[attr.data-p]": "dataP()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		badgeSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "badgeSize",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		severity: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "severity",
				required: false
			}]
		}],
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		badgeDisabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "badgeDisabled",
				required: false
			}]
		}]
	});
})();
var BadgeModule = class BadgeModule {
	static ɵfac = function BadgeModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || BadgeModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: BadgeModule,
		imports: [Badge, SharedModule],
		exports: [Badge, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Badge,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BadgeModule, [{
		type: NgModule,
		args: [{
			imports: [Badge, SharedModule],
			exports: [Badge, SharedModule]
		}]
	}], null, null);
})();
export { BadgeStyle as i, BadgeClasses as n, BadgeModule as r, Badge as t };
