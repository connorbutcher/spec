import { U as InjectionToken, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, p as linkedSignal, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Ps as ɵɵtextInterpolate, Ro as ɵɵlistener, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, go as ɵɵgetCurrentView, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { t as TimesCircle } from "./primeicons-angular-times-circle-CpbZ0TQ8.js";
import { SharedModule, TranslationKeys } from "./primeng_api.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeuix/styles/dist/chip/index.mjs
var style = "\n    .p-chip {\n        display: inline-flex;\n        align-items: center;\n        background: dt('chip.background');\n        color: dt('chip.color');\n        border-radius: dt('chip.border.radius');\n        padding-block: dt('chip.padding.y');\n        padding-inline: dt('chip.padding.x');\n        gap: dt('chip.gap');\n    }\n    \n    .p-chip.p-focus {\n        background: dt('chip.focus.background');\n    }\n\n    .p-chip-icon {\n        color: dt('chip.icon.color');\n        font-size: dt('chip.icon.size');\n        width: dt('chip.icon.size');\n        height: dt('chip.icon.size');\n        flex-shrink: 0;\n    }\n\n    .p-chip-image {\n        border-radius: 50%;\n        width: dt('chip.image.width');\n        height: dt('chip.image.height');\n        margin-inline-start: calc(-1 * dt('chip.padding.y'));\n        flex-shrink: 0;\n    }\n\n    .p-chip-label {\n        font-weight: dt('chip.label.font.weight');\n        font-size: dt('chip.label.font.size');\n    }\n\n    .p-chip:has(.p-chip-remove-icon) {\n        padding-inline-end: dt('chip.padding.y');\n    }\n\n    .p-chip:has(.p-chip-image) {\n        padding-block-start: calc(dt('chip.padding.y') / 2);\n        padding-block-end: calc(dt('chip.padding.y') / 2);\n    }\n\n    .p-chip-remove-icon {\n        cursor: pointer;\n        font-size: dt('chip.remove.icon.size');\n        width: dt('chip.remove.icon.size');\n        height: dt('chip.remove.icon.size');\n        color: dt('chip.remove.icon.color');\n        border-radius: 50%;\n        transition:\n            outline-color dt('chip.transition.duration'),\n            box-shadow dt('chip.transition.duration');\n        outline-color: transparent;\n    }\n\n    .p-chip-remove-icon:focus-visible {\n        box-shadow: dt('chip.remove.icon.focus.ring.shadow');\n        outline: dt('chip.remove.icon.focus.ring.width') dt('chip.remove.icon.focus.ring.style') dt('chip.remove.icon.focus.ring.color');\n        outline-offset: dt('chip.remove.icon.focus.ring.offset');\n    }\n";
// node_modules/primeng/fesm2022/primeng-chip.mjs
var inlineStyles = { root: ({ instance }) => ({ display: !instance.visible() ? "none" : null }) };
var classes = {
	root: ({ instance }) => ["p-chip p-component", { "p-disabled": instance.disabled() }],
	image: "p-chip-image",
	icon: "p-chip-icon",
	label: "p-chip-label",
	removeIcon: "p-chip-remove-icon"
};
var ChipStyle = class ChipStyle extends BaseStyle {
	name = "chip";
	style = style;
	classes = classes;
	inlineStyles = inlineStyles;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵChipStyle_BaseFactory = void 0;
		return function ChipStyle_Factory(__ngFactoryType__) {
			return (ɵChipStyle_BaseFactory || (ɵChipStyle_BaseFactory = ɵɵgetInheritedFactory(ChipStyle)))(__ngFactoryType__ || ChipStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: ChipStyle,
		factory: ChipStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChipStyle, [{ type: Injectable }], null, null);
})();
var ChipClasses;
(function(ChipClasses) {
	ChipClasses["root"] = "p-chip";
	ChipClasses["image"] = "p-chip-image";
	ChipClasses["icon"] = "p-chip-icon";
	ChipClasses["label"] = "p-chip-label";
	ChipClasses["removeIcon"] = "p-chip-remove-icon";
})(ChipClasses || (ChipClasses = {}));
var CHIP_INSTANCE = new InjectionToken("CHIP_INSTANCE");
var Chip = class Chip extends BaseComponent {
	componentName = "Chip";
	$pcChip = inject(CHIP_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	image = input(...ngDevMode ? [void 0, { debugName: "image" }] : /* istanbul ignore next */ []);
	alt = input(...ngDevMode ? [void 0, { debugName: "alt" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	removable = input(false, {
		...ngDevMode ? { debugName: "removable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	removeIcon = input(...ngDevMode ? [void 0, { debugName: "removeIcon" }] : /* istanbul ignore next */ []);
	chipProps = input(...ngDevMode ? [void 0, { debugName: "chipProps" }] : /* istanbul ignore next */ []);
	onRemove = output();
	onImageError = output();
	removeIconTemplate = contentChild("removeicon", {
		...ngDevMode ? { debugName: "removeIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	visible = linkedSignal({
		...ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {},
		source: () => JSON.stringify([
			this._label(),
			this._icon(),
			this._image()
		]),
		computation: () => true
	});
	_componentStyle = inject(ChipStyle);
	_label = computed(() => this.chipProps()?.label ?? this.label(), ...ngDevMode ? [{ debugName: "_label" }] : /* istanbul ignore next */ []);
	_icon = computed(() => this.chipProps()?.icon ?? this.icon(), ...ngDevMode ? [{ debugName: "_icon" }] : /* istanbul ignore next */ []);
	_image = computed(() => this.chipProps()?.image ?? this.image(), ...ngDevMode ? [{ debugName: "_image" }] : /* istanbul ignore next */ []);
	_alt = computed(() => this.chipProps()?.alt ?? this.alt(), ...ngDevMode ? [{ debugName: "_alt" }] : /* istanbul ignore next */ []);
	_removable = computed(() => this.chipProps()?.removable ?? this.removable(), ...ngDevMode ? [{ debugName: "_removable" }] : /* istanbul ignore next */ []);
	_removeIcon = computed(() => this.chipProps()?.removeIcon ?? this.removeIcon(), ...ngDevMode ? [{ debugName: "_removeIcon" }] : /* istanbul ignore next */ []);
	removeAriaLabel = computed(() => this.translate(TranslationKeys.ARIA, "removeLabel"), ...ngDevMode ? [{ debugName: "removeAriaLabel" }] : /* istanbul ignore next */ []);
	removeIconTabindex = computed(() => this.disabled() ? -1 : 0, ...ngDevMode ? [{ debugName: "removeIconTabindex" }] : /* istanbul ignore next */ []);
	dataP = computed(() => this.cn({ removable: this._removable() }), ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	close(event) {
		this.visible.set(false);
		this.onRemove.emit(event);
	}
	onKeydown(event) {
		if (event.key === "Enter" || event.key === "Backspace") this.close(event);
	}
	imageError(event) {
		this.onImageError.emit(event);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵChip_BaseFactory = void 0;
		return function Chip_Factory(__ngFactoryType__) {
			return (ɵChip_BaseFactory || (ɵChip_BaseFactory = ɵɵgetInheritedFactory(Chip)))(__ngFactoryType__ || Chip);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["removeicon"];
		const _c1 = ["*"];
		function Chip_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "img", 2);
				ɵɵlistener("error", function Chip_Conditional_1_Template_img_error_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.imageError($event));
				});
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("image"));
				ɵɵproperty("pBind", ctx_r1.ptm("image"))("src", ctx_r1._image())("alt", ctx_r1._alt());
			}
		}
		function Chip_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 3);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("icon"), ctx_r1._icon()));
				ɵɵproperty("pBind", ctx_r1.ptm("icon"));
			}
		}
		function Chip_Conditional_3_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "div", 3);
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("label"));
				ɵɵproperty("pBind", ctx_r1.ptm("label"));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1._label());
			}
		}
		function Chip_Conditional_4_Conditional_0_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r3 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "span", 6);
				ɵɵlistener("click", function Chip_Conditional_4_Conditional_0_Conditional_0_Template_span_click_0_listener($event) {
					ɵɵrestoreView(_r3);
					const ctx_r1 = ɵɵnextContext(3);
					return ɵɵresetView(ctx_r1.close($event));
				})("keydown", function Chip_Conditional_4_Conditional_0_Conditional_0_Template_span_keydown_0_listener($event) {
					ɵɵrestoreView(_r3);
					const ctx_r1 = ɵɵnextContext(3);
					return ɵɵresetView(ctx_r1.onKeydown($event));
				});
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("removeIcon"), ctx_r1._removeIcon()));
				ɵɵproperty("pBind", ctx_r1.ptm("removeIcon"));
				ɵɵattribute("tabindex", ctx_r1.removeIconTabindex())("aria-label", ctx_r1.removeAriaLabel());
			}
		}
		function Chip_Conditional_4_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r4 = ɵɵgetCurrentView();
				ɵɵnamespaceSVG();
				ɵɵelementStart(0, "svg", 7);
				ɵɵlistener("click", function Chip_Conditional_4_Conditional_0_Conditional_1_Template_svg_click_0_listener($event) {
					ɵɵrestoreView(_r4);
					const ctx_r1 = ɵɵnextContext(3);
					return ɵɵresetView(ctx_r1.close($event));
				})("keydown", function Chip_Conditional_4_Conditional_0_Conditional_1_Template_svg_keydown_0_listener($event) {
					ɵɵrestoreView(_r4);
					const ctx_r1 = ɵɵnextContext(3);
					return ɵɵresetView(ctx_r1.onKeydown($event));
				});
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("removeIcon"));
				ɵɵproperty("pBind", ctx_r1.ptm("removeIcon"));
				ɵɵattribute("tabindex", ctx_r1.removeIconTabindex())("aria-label", ctx_r1.removeAriaLabel());
			}
		}
		function Chip_Conditional_4_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Chip_Conditional_4_Conditional_0_Conditional_0_Template, 1, 5, "span", 4)(1, Chip_Conditional_4_Conditional_0_Conditional_1_Template, 1, 5, "svg", 5);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵconditional(ctx_r1._removeIcon() ? 0 : 1);
			}
		}
		function Chip_Conditional_4_Conditional_1_1_ng_template_0_Template(rf, ctx) {}
		function Chip_Conditional_4_Conditional_1_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Chip_Conditional_4_Conditional_1_1_ng_template_0_Template, 0, 0, "ng-template");
		}
		function Chip_Conditional_4_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r5 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "span", 6);
				ɵɵlistener("click", function Chip_Conditional_4_Conditional_1_Template_span_click_0_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.close($event));
				})("keydown", function Chip_Conditional_4_Conditional_1_Template_span_keydown_0_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.onKeydown($event));
				});
				ɵɵtemplate(1, Chip_Conditional_4_Conditional_1_1_Template, 1, 0, null, 8);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("removeIcon"));
				ɵɵproperty("pBind", ctx_r1.ptm("removeIcon"));
				ɵɵattribute("tabindex", ctx_r1.removeIconTabindex())("aria-label", ctx_r1.removeAriaLabel());
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.removeIconTemplate());
			}
		}
		function Chip_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Chip_Conditional_4_Conditional_0_Template, 2, 1)(1, Chip_Conditional_4_Conditional_1_Template, 2, 6, "span", 4);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵconditional(!ctx_r1.removeIconTemplate() ? 0 : 1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Chip,
			selectors: [["p-chip"]],
			contentQueries: function Chip_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.removeIconTemplate, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 6,
			hostBindings: function Chip_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("aria-label", ctx._label())("data-p", ctx.dataP());
					ɵɵstyleMap(ctx.sx("root"));
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				label: [1, "label"],
				icon: [1, "icon"],
				image: [1, "image"],
				alt: [1, "alt"],
				disabled: [1, "disabled"],
				removable: [1, "removable"],
				removeIcon: [1, "removeIcon"],
				chipProps: [1, "chipProps"]
			},
			outputs: {
				onRemove: "onRemove",
				onImageError: "onImageError"
			},
			features: [
				ɵɵProvidersFeature([
					ChipStyle,
					{
						provide: CHIP_INSTANCE,
						useExisting: Chip
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Chip
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c1,
			decls: 5,
			vars: 3,
			consts: [
				[
					3,
					"pBind",
					"class",
					"src",
					"alt"
				],
				[
					3,
					"pBind",
					"class"
				],
				[
					3,
					"error",
					"pBind",
					"src",
					"alt"
				],
				[3, "pBind"],
				[
					"role",
					"button",
					3,
					"pBind",
					"class"
				],
				[
					"data-p-icon",
					"times-circle",
					"role",
					"button",
					3,
					"pBind",
					"class"
				],
				[
					"role",
					"button",
					3,
					"click",
					"keydown",
					"pBind"
				],
				[
					"data-p-icon",
					"times-circle",
					"role",
					"button",
					3,
					"click",
					"keydown",
					"pBind"
				],
				[4, "ngTemplateOutlet"]
			],
			template: function Chip_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
					ɵɵconditionalCreate(1, Chip_Conditional_1_Template, 1, 5, "img", 0)(2, Chip_Conditional_2_Template, 1, 3, "span", 1);
					ɵɵconditionalCreate(3, Chip_Conditional_3_Template, 2, 4, "div", 1);
					ɵɵconditionalCreate(4, Chip_Conditional_4_Template, 2, 1);
				}
				if (rf & 2) {
					ɵɵadvance();
					ɵɵconditional(ctx._image() ? 1 : ctx._icon() ? 2 : -1);
					ɵɵadvance(2);
					ɵɵconditional(ctx._label() ? 3 : -1);
					ɵɵadvance();
					ɵɵconditional(ctx._removable() ? 4 : -1);
				}
			},
			dependencies: [
				NgTemplateOutlet,
				SharedModule,
				Bind,
				TimesCircle
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Chip, [{
		type: Component,
		args: [{
			selector: "p-chip",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				SharedModule,
				Bind,
				TimesCircle
			],
			template: `
        <ng-content />
        @if (_image()) {
            <img [pBind]="ptm('image')" [class]="cx('image')" [src]="_image()" (error)="imageError($event)" [alt]="_alt()" />
        } @else if (_icon()) {
            <span [pBind]="ptm('icon')" [class]="cn(cx('icon'), _icon())"></span>
        }
        @if (_label()) {
            <div [pBind]="ptm('label')" [class]="cx('label')">{{ _label() }}</div>
        }
        @if (_removable()) {
            @if (!removeIconTemplate()) {
                @if (_removeIcon()) {
                    <span
                        [pBind]="ptm('removeIcon')"
                        [class]="cn(cx('removeIcon'), _removeIcon())"
                        (click)="close($event)"
                        (keydown)="onKeydown($event)"
                        [attr.tabindex]="removeIconTabindex()"
                        [attr.aria-label]="removeAriaLabel()"
                        role="button"
                    ></span>
                } @else {
                    <svg
                        [pBind]="ptm('removeIcon')"
                        data-p-icon="times-circle"
                        [class]="cx('removeIcon')"
                        (click)="close($event)"
                        (keydown)="onKeydown($event)"
                        [attr.tabindex]="removeIconTabindex()"
                        [attr.aria-label]="removeAriaLabel()"
                        role="button"
                    />
                }
            } @else {
                <span [pBind]="ptm('removeIcon')" [attr.tabindex]="removeIconTabindex()" [class]="cx('removeIcon')" (click)="close($event)" (keydown)="onKeydown($event)" [attr.aria-label]="removeAriaLabel()" role="button">
                    <ng-template *ngTemplateOutlet="removeIconTemplate()"></ng-template>
                </span>
            }
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				ChipStyle,
				{
					provide: CHIP_INSTANCE,
					useExisting: Chip
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Chip
				}
			],
			host: {
				"[class]": "cx('root')",
				"[style]": "sx('root')",
				"[attr.aria-label]": "_label()",
				"[attr.data-p]": "dataP()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		label: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		icon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		image: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "image",
				required: false
			}]
		}],
		alt: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "alt",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		removable: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "removable",
				required: false
			}]
		}],
		removeIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "removeIcon",
				required: false
			}]
		}],
		chipProps: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "chipProps",
				required: false
			}]
		}],
		onRemove: [{
			type: Output,
			args: ["onRemove"]
		}],
		onImageError: [{
			type: Output,
			args: ["onImageError"]
		}],
		removeIconTemplate: [{
			type: ContentChild,
			args: ["removeicon", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var ChipModule = class ChipModule {
	static ɵfac = function ChipModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ChipModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: ChipModule,
		imports: [Chip, SharedModule],
		exports: [Chip, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Chip,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChipModule, [{
		type: NgModule,
		args: [{
			imports: [Chip, SharedModule],
			exports: [Chip, SharedModule]
		}]
	}], null, null);
})();
export { ChipStyle as i, ChipClasses as n, ChipModule as r, Chip as t };
