import "./primeng_bind.js";
export { t as Badge, n as BadgeClasses, r as BadgeModule, i as BadgeStyle } from "./primeng-badge-DVBRASwf.js";
