import "./primeng_bind.js";
export { t as Tooltip, n as TooltipClasses, r as TooltipModule, i as TooltipStyle } from "./primeng-tooltip-DhgMe6wA.js";
