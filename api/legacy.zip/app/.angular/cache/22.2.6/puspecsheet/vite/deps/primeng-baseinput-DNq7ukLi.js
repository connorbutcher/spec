import { c as computed, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ji as ɵɵInheritDefinitionFeature, O as booleanAttribute, Sn as Input, Wa as ɵɵdefineDirective, X as input, _o as ɵɵgetInheritedFactory, un as Directive } from "./core-BenYQOr3.js";
import { t as BaseEditableHolder } from "./primeng-baseeditableholder-joFSbzas.js";
import { t as Fluid } from "./primeng-fluid-DG0dbSem.js";
// node_modules/primeng/fesm2022/primeng-baseinput.mjs
var BaseInput = class BaseInput extends BaseEditableHolder {
	pcFluid = inject(Fluid, {
		optional: true,
		host: true,
		skipSelf: true
	});
	fluid = input(void 0, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	inputSize = input(...ngDevMode ? [void 0, { debugName: "inputSize" }] : /* istanbul ignore next */ []);
	pattern = input(...ngDevMode ? [void 0, { debugName: "pattern" }] : /* istanbul ignore next */ []);
	min = input(...ngDevMode ? [void 0, { debugName: "min" }] : /* istanbul ignore next */ []);
	max = input(...ngDevMode ? [void 0, { debugName: "max" }] : /* istanbul ignore next */ []);
	step = input(...ngDevMode ? [void 0, { debugName: "step" }] : /* istanbul ignore next */ []);
	minlength = input(...ngDevMode ? [void 0, { debugName: "minlength" }] : /* istanbul ignore next */ []);
	maxlength = input(...ngDevMode ? [void 0, { debugName: "maxlength" }] : /* istanbul ignore next */ []);
	$variant = computed(() => this.variant() || this.config.inputVariant() || void 0, ...ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []);
	$pattern = computed(() => {
		const v = this.pattern();
		return typeof v === "string" && v.length > 0 ? v : void 0;
	}, ...ngDevMode ? [{ debugName: "$pattern" }] : /* istanbul ignore next */ []);
	get hasFluid() {
		return this.fluid() ?? !!this.pcFluid;
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵBaseInput_BaseFactory = void 0;
		return function BaseInput_Factory(__ngFactoryType__) {
			return (ɵBaseInput_BaseFactory || (ɵBaseInput_BaseFactory = ɵɵgetInheritedFactory(BaseInput)))(__ngFactoryType__ || BaseInput);
		};
	})();
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: BaseInput,
		inputs: {
			fluid: [1, "fluid"],
			variant: [1, "variant"],
			size: [1, "size"],
			inputSize: [1, "inputSize"],
			pattern: [1, "pattern"],
			min: [1, "min"],
			max: [1, "max"],
			step: [1, "step"],
			minlength: [1, "minlength"],
			maxlength: [1, "maxlength"]
		},
		features: [ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BaseInput, [{
		type: Directive,
		args: [{ standalone: true }]
	}], null, {
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		variant: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		inputSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inputSize",
				required: false
			}]
		}],
		pattern: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pattern",
				required: false
			}]
		}],
		min: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "min",
				required: false
			}]
		}],
		max: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "max",
				required: false
			}]
		}],
		step: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "step",
				required: false
			}]
		}],
		minlength: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "minlength",
				required: false
			}]
		}],
		maxlength: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "maxlength",
				required: false
			}]
		}]
	});
})();
export { BaseInput as t };
