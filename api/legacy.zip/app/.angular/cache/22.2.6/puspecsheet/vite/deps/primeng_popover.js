import { U as InjectionToken, Ui as signal, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet, u as isPlatformBrowser } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, O as booleanAttribute, Ro as ɵɵlistener, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, go as ɵɵgetCurrentView, gs as ɵɵresolveDocument, ha as ɵɵcontentQuerySignal, hn as HostListener, i as ContentChild, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, rt as numberAttribute, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import "./dist-BRhwYpCB.js";
import { OverlayService, SharedModule } from "./primeng_api.js";
import { a as getEventTarget, n as PARENT_INSTANCE, r as ConnectedOverlayScrollHandler, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { n as MotionDirective, r as MotionModule } from "./primeng-motion-BhkauyGA.js";
import { G as fe, K as ft, Q as nt, at as se, dt as z, k as M, s as zindexutils_default, y as Ct } from "./primeng-utils-CHKSviI4.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeuix/styles/dist/popover/index.mjs
var style = "\n    .p-popover {\n        margin-block-start: dt('popover.gutter');\n        background: dt('popover.background');\n        color: dt('popover.color');\n        border: 1px solid dt('popover.border.color');\n        border-radius: dt('popover.border.radius');\n        box-shadow: dt('popover.shadow');\n        will-change: transform;\n    }\n\n    .p-popover-content {\n        padding: dt('popover.content.padding');\n    }\n\n    .p-popover-flipped {\n        margin-block-start: calc(dt('popover.gutter') * -1);\n        margin-block-end: dt('popover.gutter');\n    }\n\n    .p-popover:after,\n    .p-popover:before {\n        bottom: 100%;\n        left: calc(dt('popover.arrow.offset') + dt('popover.arrow.left', '0px'));\n        content: ' ';\n        height: 0;\n        width: 0;\n        position: absolute;\n        pointer-events: none;\n    }\n\n    .p-popover:after {\n        border-width: calc(dt('popover.gutter') - 2px);\n        margin-left: calc(-1 * (dt('popover.gutter') - 2px));\n        border-style: solid;\n        border-color: transparent;\n        border-bottom-color: dt('popover.background');\n    }\n\n    .p-popover:before {\n        border-width: dt('popover.gutter');\n        margin-left: calc(-1 * dt('popover.gutter'));\n        border-style: solid;\n        border-color: transparent;\n        border-bottom-color: dt('popover.border.color');\n    }\n\n    .p-popover-flipped:after,\n    .p-popover-flipped:before {\n        bottom: auto;\n        top: 100%;\n    }\n\n    .p-popover.p-popover-flipped:after {\n        border-bottom-color: transparent;\n        border-top-color: dt('popover.background');\n    }\n\n    .p-popover.p-popover-flipped:before {\n        border-bottom-color: transparent;\n        border-top-color: dt('popover.border.color');\n    }\n";
// node_modules/primeng/fesm2022/primeng-popover.mjs
var inlineStyles = { root: ({ instance }) => {
	return {
		position: "absolute",
		...instance.style()
	};
} };
var classes = {
	root: "p-popover p-component",
	content: "p-popover-content"
};
var PopoverStyle = class PopoverStyle extends BaseStyle {
	name = "popover";
	style = style;
	classes = classes;
	inlineStyles = inlineStyles;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵPopoverStyle_BaseFactory = void 0;
		return function PopoverStyle_Factory(__ngFactoryType__) {
			return (ɵPopoverStyle_BaseFactory || (ɵPopoverStyle_BaseFactory = ɵɵgetInheritedFactory(PopoverStyle)))(__ngFactoryType__ || PopoverStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: PopoverStyle,
		factory: PopoverStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PopoverStyle, [{ type: Injectable }], null, null);
})();
var POPOVER_INSTANCE = new InjectionToken("POPOVER_INSTANCE");
var Popover = class Popover extends BaseComponent {
	componentName = "Popover";
	$pcPopover = inject(POPOVER_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	dismissable = input(true, {
		...ngDevMode ? { debugName: "dismissable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	style = input(...ngDevMode ? [void 0, { debugName: "style" }] : /* istanbul ignore next */ []);
	styleClass = input(...ngDevMode ? [void 0, { debugName: "styleClass" }] : /* istanbul ignore next */ []);
	appendTo = input("body", ...ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []);
	autoZIndex = input(true, {
		...ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	ariaCloseLabel = input(...ngDevMode ? [void 0, { debugName: "ariaCloseLabel" }] : /* istanbul ignore next */ []);
	baseZIndex = input(0, {
		...ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	focusOnShow = input(true, {
		...ngDevMode ? { debugName: "focusOnShow" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	motionOptions = input(void 0, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	computedMotionOptions = computed(() => ({
		...this.ptm("motion"),
		...this.motionOptions()
	}), ...ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []);
	onShow = output();
	onHide = output();
	$appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []);
	container;
	overlayVisible = signal(false, ...ngDevMode ? [{ debugName: "overlayVisible" }] : /* istanbul ignore next */ []);
	render = signal(false, ...ngDevMode ? [{ debugName: "render" }] : /* istanbul ignore next */ []);
	selfClick = false;
	documentClickListener;
	target = null;
	willHide;
	scrollHandler;
	documentResizeListener;
	contentTemplate = contentChild("content", {
		...ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	onCloseClickCallback = this.onCloseClick.bind(this);
	contentTemplateContext = computed(() => ({ closeCallback: this.onCloseClickCallback }), ...ngDevMode ? [{ debugName: "contentTemplateContext" }] : /* istanbul ignore next */ []);
	destroyCallback;
	overlayEventListener;
	overlaySubscription;
	_componentStyle = inject(PopoverStyle);
	overlayService = inject(OverlayService);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptm("host"));
	}
	bindDocumentClickListener() {
		if (isPlatformBrowser(this.platformId)) {
			if (!this.documentClickListener) {
				let documentEvent = se() ? "touchstart" : "click";
				const documentTarget = this.el ? this.el.nativeElement.ownerDocument : this.document;
				this.documentClickListener = this.renderer.listen(documentTarget, documentEvent, (event) => {
					if (!this.dismissable()) return;
					const node = getEventTarget(event, this.container);
					const targetNode = getEventTarget(event, this.target);
					if (!this.container?.contains(node) && this.target !== targetNode && !this.target?.contains(targetNode) && !this.selfClick) this.hide();
					this.selfClick = false;
				});
			}
		}
	}
	unbindDocumentClickListener() {
		if (this.documentClickListener) {
			this.documentClickListener();
			this.documentClickListener = null;
			this.selfClick = false;
		}
	}
	toggle(event, target) {
		if (this.overlayVisible()) {
			if (this.hasTargetChanged(event, target)) this.destroyCallback = () => {
				this.show(null, target || event.currentTarget || event.target);
			};
			this.hide();
		} else this.show(event, target);
	}
	show(event, target) {
		if (target && event) event.stopPropagation();
		if (this.container && !this.overlayVisible()) this.container = null;
		this.target = target || event.currentTarget || event.target;
		this.overlayVisible.set(true);
		this.render.set(true);
	}
	onOverlayClick(event) {
		this.overlayService.add({
			originalEvent: event,
			target: this.el.nativeElement
		});
		this.selfClick = true;
	}
	onContentClick(event) {
		const targetElement = event.target;
		this.selfClick = event.offsetX < targetElement.clientWidth && event.offsetY < targetElement.clientHeight;
	}
	hasTargetChanged(event, target) {
		return this.target != null && this.target !== (target || event.currentTarget || event.target);
	}
	appendOverlay() {
		if (this.$appendTo() && this.$appendTo() !== "self") {
			if (this.$appendTo() === "body") Ct(this.$overlayParent(this.document.body, this.container), this.container);
			else Ct(this.$overlayParent(this.$appendTo(), this.container), this.container);
		}
	}
	restoreAppend() {
		if (this.container && this.$appendTo() && this.$appendTo() !== "self") Ct(this.el.nativeElement, this.container);
	}
	setZIndex() {
		if (this.autoZIndex()) zindexutils_default.set("overlay", this.container, this.baseZIndex() + this.config.zIndex.overlay);
	}
	align() {
		if (this.target && this.container) {
			z(this.container, this.target, false);
			const containerOffset = ft(this.container);
			const targetOffset = ft(this.target);
			const containerLeft = containerOffset.left;
			const containerTop = containerOffset.top;
			const targetLeft = targetOffset.left;
			const targetTop = targetOffset.top;
			const borderRadius = this.document.defaultView?.getComputedStyle(this.container).getPropertyValue("border-radius");
			let arrowLeft = 0;
			if (containerLeft < targetLeft) arrowLeft = targetLeft - containerLeft - parseFloat(borderRadius) * 2;
			this.container.style.setProperty(this.$styleScope.resolvers.$dt("popover.arrow.left").name, `${arrowLeft}px`);
			if (containerTop < targetTop) {
				this.container.setAttribute("data-p-popover-flipped", "true");
				if (!this.$unstyled()) M(this.container, this.pcn("p-popover-flipped"));
			}
		}
	}
	onAnimationStart(event) {
		this.container = event.element;
		this.$markInstance(this.container);
		this.appendOverlay();
		this.align();
		this.setZIndex();
		this.bindDocumentClickListener();
		this.bindDocumentResizeListener();
		this.bindScrollListener();
		if (this.focusOnShow()) this.focus();
		this.overlayEventListener = (e) => {
			if (this.container && this.container.contains(e.target)) this.selfClick = true;
		};
		this.overlaySubscription = this.overlayService.clickObservable.subscribe(this.overlayEventListener);
		this.onShow.emit(null);
	}
	onAnimationEnd() {
		if (!this.overlayVisible()) {
			if (this.destroyCallback) {
				this.destroyCallback();
				this.destroyCallback = null;
			}
			if (this.overlaySubscription) this.overlaySubscription.unsubscribe();
			if (this.autoZIndex()) zindexutils_default.clear(this.container);
			this.onContainerDestroy();
			this.onHide.emit({});
			this.render.set(false);
			this.container = null;
		}
	}
	focus() {
		const focusable = nt(this.container, "[autofocus]");
		if (focusable) setTimeout(() => focusable.focus(), 5);
	}
	hide() {
		this.overlayVisible.set(false);
	}
	onCloseClick(event) {
		this.hide();
		event.preventDefault();
	}
	onEscapeKeydown(_event) {
		this.hide();
	}
	onWindowResize() {
		if (this.overlayVisible() && !fe()) this.hide();
	}
	bindDocumentResizeListener() {
		if (isPlatformBrowser(this.platformId)) {
			if (!this.documentResizeListener) {
				const window = this.document.defaultView;
				this.documentResizeListener = this.renderer.listen(window, "resize", this.onWindowResize.bind(this));
			}
		}
	}
	unbindDocumentResizeListener() {
		if (this.documentResizeListener) {
			this.documentResizeListener();
			this.documentResizeListener = null;
		}
	}
	bindScrollListener() {
		if (isPlatformBrowser(this.platformId)) {
			if (!this.scrollHandler) this.scrollHandler = new ConnectedOverlayScrollHandler(this.target, () => {
				if (this.overlayVisible()) this.hide();
			});
			this.scrollHandler.bindScrollListener();
		}
	}
	unbindScrollListener() {
		if (this.scrollHandler) this.scrollHandler.unbindScrollListener();
	}
	onContainerDestroy() {
		if (!this.cd.destroyed) this.target = null;
		this.unbindDocumentClickListener();
		this.unbindDocumentResizeListener();
		this.unbindScrollListener();
	}
	onDestroy() {
		if (this.scrollHandler) {
			this.scrollHandler.destroy();
			this.scrollHandler = null;
		}
		if (this.container && this.autoZIndex()) zindexutils_default.clear(this.container);
		if (!this.cd.destroyed) this.target = null;
		this.destroyCallback = null;
		if (this.container) {
			this.restoreAppend();
			this.onContainerDestroy();
		}
		if (this.overlaySubscription) this.overlaySubscription.unsubscribe();
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵPopover_BaseFactory = void 0;
		return function Popover_Factory(__ngFactoryType__) {
			return (ɵPopover_BaseFactory || (ɵPopover_BaseFactory = ɵɵgetInheritedFactory(Popover)))(__ngFactoryType__ || Popover);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["content"];
		const _c1 = ["*"];
		function Popover_Conditional_0_Conditional_3_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Popover_Conditional_0_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Popover_Conditional_0_Conditional_3_ng_container_0_Template, 1, 0, "ng-container", 3);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.contentTemplate())("ngTemplateOutletContext", ctx_r1.contentTemplateContext());
			}
		}
		function Popover_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "div", 1);
				ɵɵlistener("click", function Popover_Conditional_0_Template_div_click_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onOverlayClick($event));
				})("pMotionOnEnter", function Popover_Conditional_0_Template_div_pMotionOnEnter_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onAnimationStart($event));
				})("pMotionOnAfterLeave", function Popover_Conditional_0_Template_div_pMotionOnAfterLeave_0_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onAnimationEnd());
				});
				ɵɵelementStart(1, "div", 2);
				ɵɵlistener("click", function Popover_Conditional_0_Template_div_click_1_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onContentClick($event));
				})("mousedown", function Popover_Conditional_0_Template_div_mousedown_1_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onContentClick($event));
				});
				ɵɵprojection(2);
				ɵɵconditionalCreate(3, Popover_Conditional_0_Conditional_3_Template, 1, 2, "ng-container");
				ɵɵelementEnd()();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵstyleMap(ctx_r1.sx("root"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("root"), ctx_r1.styleClass()));
				ɵɵproperty("pBind", ctx_r1.ptm("root"))("pMotion", ctx_r1.overlayVisible())("pMotionName", ctx_r1.pcn("p-anchored-overlay"))("pMotionAppear", true)("pMotionOptions", ctx_r1.computedMotionOptions());
				ɵɵattribute("aria-modal", ctx_r1.overlayVisible())("aria-label", ctx_r1.ariaLabel())("aria-labelledBy", ctx_r1.ariaLabelledBy());
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("content"));
				ɵɵproperty("pBind", ctx_r1.ptm("content"));
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.contentTemplate() ? 3 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Popover,
			selectors: [["p-popover"]],
			contentQueries: function Popover_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.contentTemplate, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostBindings: function Popover_HostBindings(rf, ctx) {
				if (rf & 1) ɵɵlistener("keydown.escape", function Popover_keydown_escape_HostBindingHandler($event) {
					return ctx.onEscapeKeydown($event);
				}, ɵɵresolveDocument);
			},
			inputs: {
				ariaLabel: [1, "ariaLabel"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				dismissable: [1, "dismissable"],
				style: [1, "style"],
				styleClass: [1, "styleClass"],
				appendTo: [1, "appendTo"],
				autoZIndex: [1, "autoZIndex"],
				ariaCloseLabel: [1, "ariaCloseLabel"],
				baseZIndex: [1, "baseZIndex"],
				focusOnShow: [1, "focusOnShow"],
				motionOptions: [1, "motionOptions"]
			},
			outputs: {
				onShow: "onShow",
				onHide: "onHide"
			},
			features: [
				ɵɵProvidersFeature([
					PopoverStyle,
					{
						provide: POPOVER_INSTANCE,
						useExisting: Popover
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Popover
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c1,
			decls: 1,
			vars: 1,
			consts: [
				[
					"role",
					"dialog",
					3,
					"pBind",
					"class",
					"style",
					"pMotion",
					"pMotionName",
					"pMotionAppear",
					"pMotionOptions"
				],
				[
					"role",
					"dialog",
					3,
					"click",
					"pMotionOnEnter",
					"pMotionOnAfterLeave",
					"pBind",
					"pMotion",
					"pMotionName",
					"pMotionAppear",
					"pMotionOptions"
				],
				[
					3,
					"click",
					"mousedown",
					"pBind"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				]
			],
			template: function Popover_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵconditionalCreate(0, Popover_Conditional_0_Template, 4, 16, "div", 0);
				}
				if (rf & 2) ɵɵconditional(ctx.render() ? 0 : -1);
			},
			dependencies: [
				NgTemplateOutlet,
				SharedModule,
				Bind,
				MotionModule,
				MotionDirective
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Popover, [{
		type: Component,
		args: [{
			selector: "p-popover",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				SharedModule,
				Bind,
				MotionModule
			],
			providers: [
				PopoverStyle,
				{
					provide: POPOVER_INSTANCE,
					useExisting: Popover
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Popover
				}
			],
			hostDirectives: [Bind],
			template: `
        @if (render()) {
            <div
                [pBind]="ptm('root')"
                [class]="cn(cx('root'), styleClass())"
                [style]="sx('root')"
                (click)="onOverlayClick($event)"
                role="dialog"
                [attr.aria-modal]="overlayVisible()"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledBy]="ariaLabelledBy()"
                [pMotion]="overlayVisible()"
                [pMotionName]="pcn('p-anchored-overlay')"
                [pMotionAppear]="true"
                (pMotionOnEnter)="onAnimationStart($event)"
                (pMotionOnAfterLeave)="onAnimationEnd()"
                [pMotionOptions]="computedMotionOptions()"
            >
                <div [pBind]="ptm('content')" [class]="cx('content')" (click)="onContentClick($event)" (mousedown)="onContentClick($event)">
                    <ng-content></ng-content>
                    @if (contentTemplate()) {
                        <ng-container *ngTemplateOutlet="contentTemplate(); context: contentTemplateContext()"></ng-container>
                    }
                </div>
            </div>
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None
		}]
	}], null, {
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		dismissable: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "dismissable",
				required: false
			}]
		}],
		style: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "style",
				required: false
			}]
		}],
		styleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "styleClass",
				required: false
			}]
		}],
		appendTo: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "appendTo",
				required: false
			}]
		}],
		autoZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoZIndex",
				required: false
			}]
		}],
		ariaCloseLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaCloseLabel",
				required: false
			}]
		}],
		baseZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "baseZIndex",
				required: false
			}]
		}],
		focusOnShow: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "focusOnShow",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		onShow: [{
			type: Output,
			args: ["onShow"]
		}],
		onHide: [{
			type: Output,
			args: ["onHide"]
		}],
		contentTemplate: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}],
		onEscapeKeydown: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	});
})();
var PopoverModule = class PopoverModule {
	static ɵfac = function PopoverModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || PopoverModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: PopoverModule,
		imports: [Popover, SharedModule],
		exports: [Popover, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Popover,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PopoverModule, [{
		type: NgModule,
		args: [{
			imports: [Popover, SharedModule],
			exports: [Popover, SharedModule]
		}]
	}], null, null);
})();
export { Popover, PopoverModule, PopoverStyle };
