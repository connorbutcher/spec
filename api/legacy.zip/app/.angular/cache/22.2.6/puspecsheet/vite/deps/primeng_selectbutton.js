import { Fn as forwardRef, U as InjectionToken, Ui as signal, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Ms as ɵɵtemplateRefExtractor, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Ps as ɵɵtextInterpolate, Ro as ɵɵlistener, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, _a as ɵɵcontrolCreate, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, ds as ɵɵrepeaterCreate, ga as ɵɵcontrol, go as ɵɵgetCurrentView, ha as ɵɵcontentQuerySignal, hn as HostListener, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, rt as numberAttribute, us as ɵɵrepeater, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { FormsModule, NG_VALUE_ACCESSOR, NgControlStatus, NgModel } from "./@angular_forms.js";
import { _ as d, h as b } from "./dist-BRhwYpCB.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE } from "./primeng-basecomponent-cJWiv26K.js";
import { t as BaseEditableHolder } from "./primeng-baseeditableholder-joFSbzas.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { t as Ripple } from "./primeng-ripple-BUHk2LHf.js";
// node_modules/primeng/fesm2022/primeng-togglebutton.mjs
var style$1 = `
    
    .p-togglebutton {
        display: inline-flex;
        cursor: pointer;
        user-select: none;
        overflow: hidden;
        position: relative;
        color: dt('togglebutton.color');
        background: dt('togglebutton.background');
        border: 1px solid dt('togglebutton.border.color');
        padding: dt('togglebutton.padding');
        transition:
            background dt('togglebutton.transition.duration'),
            color dt('togglebutton.transition.duration'),
            border-color dt('togglebutton.transition.duration'),
            outline-color dt('togglebutton.transition.duration'),
            box-shadow dt('togglebutton.transition.duration');
        border-radius: dt('togglebutton.border.radius');
        outline-color: transparent;
        font-size: dt('togglebutton.font.size');
        font-weight: dt('togglebutton.font.weight');
    }

    .p-togglebutton-content {
        display: inline-flex;
        flex: 1 1 auto;
        align-items: center;
        justify-content: center;
        gap: dt('togglebutton.gap');
        padding: dt('togglebutton.content.padding');
        background: transparent;
        border-radius: dt('togglebutton.content.border.radius');
        transition:
            background dt('togglebutton.transition.duration'),
            color dt('togglebutton.transition.duration'),
            border-color dt('togglebutton.transition.duration'),
            outline-color dt('togglebutton.transition.duration'),
            box-shadow dt('togglebutton.transition.duration');
    }

    .p-togglebutton:not(:disabled):not(.p-togglebutton-checked):hover {
        background: dt('togglebutton.hover.background');
        color: dt('togglebutton.hover.color');
    }

    .p-togglebutton.p-togglebutton-checked {
        background: dt('togglebutton.checked.background');
        border-color: dt('togglebutton.checked.border.color');
        color: dt('togglebutton.checked.color');
    }

    .p-togglebutton-checked .p-togglebutton-content {
        background: dt('togglebutton.content.checked.background');
        box-shadow: dt('togglebutton.content.checked.shadow');
    }

    .p-togglebutton:focus-visible {
        box-shadow: dt('togglebutton.focus.ring.shadow');
        outline: dt('togglebutton.focus.ring.width') dt('togglebutton.focus.ring.style') dt('togglebutton.focus.ring.color');
        outline-offset: dt('togglebutton.focus.ring.offset');
    }

    .p-togglebutton.p-invalid {
        border-color: dt('togglebutton.invalid.border.color');
    }

    .p-togglebutton:disabled {
        opacity: 1;
        cursor: default;
        background: dt('togglebutton.disabled.background');
        border-color: dt('togglebutton.disabled.border.color');
        color: dt('togglebutton.disabled.color');
    }

    .p-togglebutton-label,
    .p-togglebutton-icon {
        position: relative;
        transition: none;
    }

    .p-togglebutton-icon {
        color: dt('togglebutton.icon.color');
    }

    .p-togglebutton:not(:disabled):not(.p-togglebutton-checked):hover .p-togglebutton-icon {
        color: dt('togglebutton.icon.hover.color');
    }

    .p-togglebutton.p-togglebutton-checked .p-togglebutton-icon {
        color: dt('togglebutton.icon.checked.color');
    }

    .p-togglebutton:disabled .p-togglebutton-icon {
        color: dt('togglebutton.icon.disabled.color');
    }

    .p-togglebutton-sm {
        padding: dt('togglebutton.sm.padding');
        font-size: dt('togglebutton.sm.font.size');
    }

    .p-togglebutton-sm .p-togglebutton-content {
        padding: dt('togglebutton.content.sm.padding');
    }

    .p-togglebutton-lg {
        padding: dt('togglebutton.lg.padding');
        font-size: dt('togglebutton.lg.font.size');
    }

    .p-togglebutton-lg .p-togglebutton-content {
        padding: dt('togglebutton.content.lg.padding');
    }

    .p-togglebutton-fluid {
        width: 100%;
    }

    .p-togglebutton-content .p-icon,
    .p-togglebutton-content .pi {
        line-height: dt('typography.line.height')
    }


    /* For PrimeNG (iconPos) */
    .p-togglebutton-icon-right {
        order: 1;
    }
`;
var classes$1 = {
	root: ({ instance }) => ["p-togglebutton p-component", {
		"p-togglebutton-checked": instance.checked(),
		"p-invalid": instance.invalid(),
		"p-disabled": instance.$disabled(),
		"p-togglebutton-sm p-inputfield-sm": instance.size() === "small",
		"p-togglebutton-lg p-inputfield-lg": instance.size() === "large",
		"p-togglebutton-fluid": instance.fluid()
	}],
	content: "p-togglebutton-content",
	icon: "p-togglebutton-icon",
	iconLeft: "p-togglebutton-icon-left",
	iconRight: "p-togglebutton-icon-right",
	label: "p-togglebutton-label"
};
var ToggleButtonStyle = class ToggleButtonStyle extends BaseStyle {
	name = "togglebutton";
	style = style$1;
	classes = classes$1;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵToggleButtonStyle_BaseFactory = void 0;
		return function ToggleButtonStyle_Factory(__ngFactoryType__) {
			return (ɵToggleButtonStyle_BaseFactory || (ɵToggleButtonStyle_BaseFactory = ɵɵgetInheritedFactory(ToggleButtonStyle)))(__ngFactoryType__ || ToggleButtonStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: ToggleButtonStyle,
		factory: ToggleButtonStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ToggleButtonStyle, [{ type: Injectable }], null, null);
})();
var ToggleButtonClasses;
(function(ToggleButtonClasses) {
	ToggleButtonClasses["root"] = "p-togglebutton";
	ToggleButtonClasses["icon"] = "p-togglebutton-icon";
	ToggleButtonClasses["iconLeft"] = "p-togglebutton-icon-left";
	ToggleButtonClasses["iconRight"] = "p-togglebutton-icon-right";
	ToggleButtonClasses["label"] = "p-togglebutton-label";
})(ToggleButtonClasses || (ToggleButtonClasses = {}));
var TOGGLEBUTTON_INSTANCE = new InjectionToken("TOGGLEBUTTON_INSTANCE");
var TOGGLEBUTTON_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => ToggleButton),
	multi: true
};
var ToggleButton = class ToggleButton extends BaseEditableHolder {
	componentName = "ToggleButton";
	$pcToggleButton = inject(TOGGLEBUTTON_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	_componentStyle = inject(ToggleButtonStyle);
	onLabel = input("Yes", ...ngDevMode ? [{ debugName: "onLabel" }] : /* istanbul ignore next */ []);
	offLabel = input("No", ...ngDevMode ? [{ debugName: "offLabel" }] : /* istanbul ignore next */ []);
	onIcon = input(...ngDevMode ? [void 0, { debugName: "onIcon" }] : /* istanbul ignore next */ []);
	offIcon = input(...ngDevMode ? [void 0, { debugName: "offIcon" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	inputId = input(...ngDevMode ? [void 0, { debugName: "inputId" }] : /* istanbul ignore next */ []);
	tabindex = input(0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	iconPos = input("left", ...ngDevMode ? [{ debugName: "iconPos" }] : /* istanbul ignore next */ []);
	autofocus = input(false, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	allowEmpty = input(...ngDevMode ? [void 0, { debugName: "allowEmpty" }] : /* istanbul ignore next */ []);
	fluid = input(void 0, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	onChange = output();
	iconTemplate = contentChild("icon", {
		...ngDevMode ? { debugName: "iconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	contentTemplate = contentChild("content", {
		...ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	checked = signal(false, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	hasOnLabel = computed(() => !!(this.onLabel() && this.onLabel().length > 0), ...ngDevMode ? [{ debugName: "hasOnLabel" }] : /* istanbul ignore next */ []);
	hasOffLabel = computed(() => !!(this.offLabel() && this.offLabel().length > 0), ...ngDevMode ? [{ debugName: "hasOffLabel" }] : /* istanbul ignore next */ []);
	hasIcon = computed(() => !!(this.onIcon() || this.offIcon()), ...ngDevMode ? [{ debugName: "hasIcon" }] : /* istanbul ignore next */ []);
	hasLabel = computed(() => this.checked() ? this.hasOnLabel() : this.hasOffLabel(), ...ngDevMode ? [{ debugName: "hasLabel" }] : /* istanbul ignore next */ []);
	active = computed(() => this.checked() === true, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	dataP = computed(() => this.cn({
		checked: this.active(),
		invalid: this.invalid(),
		[this.size()]: this.size()
	}), ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	$tabindex = computed(() => this.$disabled() ? -1 : this.tabindex() ?? 0, ...ngDevMode ? [{ debugName: "$tabindex" }] : /* istanbul ignore next */ []);
	iconClass = computed(() => this.cn(this.cx("icon"), this.checked() ? this.onIcon() : this.offIcon(), this.iconPos() === "left" ? this.cx("iconLeft") : this.cx("iconRight")), ...ngDevMode ? [{ debugName: "iconClass" }] : /* istanbul ignore next */ []);
	labelText = computed(() => this.checked() ? this.onLabel() : this.offLabel(), ...ngDevMode ? [{ debugName: "labelText" }] : /* istanbul ignore next */ []);
	ariaPressed = computed(() => this.checked() ? "true" : "false", ...ngDevMode ? [{ debugName: "ariaPressed" }] : /* istanbul ignore next */ []);
	getTemplateContext() {
		return { $implicit: this.checked() };
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onKeyDown(event) {
		switch (event.code) {
			case "Enter":
				this.toggle(event);
				event.preventDefault();
				break;
			case "Space":
				this.toggle(event);
				event.preventDefault();
		}
	}
	toggle(event) {
		if (!this.$disabled() && !(this.allowEmpty() === false && this.checked())) {
			this.checked.set(!this.checked());
			this.writeModelValue(this.checked());
			this.onModelChange(this.checked());
			this.onModelTouched();
			this.onChange.emit({
				originalEvent: event,
				checked: this.checked()
			});
		}
	}
	onInit() {
		if (this.checked() === null || this.checked() === void 0) this.checked.set(false);
	}
	onBlur() {
		this.onModelTouched();
	}
	writeControlValue(value, setModelValue) {
		this.checked.set(value);
		setModelValue(value);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵToggleButton_BaseFactory = void 0;
		return function ToggleButton_Factory(__ngFactoryType__) {
			return (ɵToggleButton_BaseFactory || (ɵToggleButton_BaseFactory = ɵɵgetInheritedFactory(ToggleButton)))(__ngFactoryType__ || ToggleButton);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["icon"];
		const _c1 = ["content"];
		function ToggleButton_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function ToggleButton_Conditional_2_Conditional_0_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 0);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r0.iconClass());
				ɵɵproperty("pBind", ctx_r0.ptm("icon"));
			}
		}
		function ToggleButton_Conditional_2_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, ToggleButton_Conditional_2_Conditional_0_Conditional_0_Template, 1, 3, "span", 2);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵconditional(ctx_r0.hasIcon() ? 0 : -1);
			}
		}
		function ToggleButton_Conditional_2_Conditional_1_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function ToggleButton_Conditional_2_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, ToggleButton_Conditional_2_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 1);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.iconTemplate())("ngTemplateOutletContext", ctx_r0.getTemplateContext());
			}
		}
		function ToggleButton_Conditional_2_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 0);
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r0.cx("label"));
				ɵɵproperty("pBind", ctx_r0.ptm("label"));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r0.labelText());
			}
		}
		function ToggleButton_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, ToggleButton_Conditional_2_Conditional_0_Template, 1, 1)(1, ToggleButton_Conditional_2_Conditional_1_Template, 1, 2, "ng-container");
				ɵɵconditionalCreate(2, ToggleButton_Conditional_2_Conditional_2_Template, 2, 4, "span", 2);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(!ctx_r0.iconTemplate() ? 0 : 1);
				ɵɵadvance(2);
				ɵɵconditional(ctx_r0.hasLabel() ? 2 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: ToggleButton,
			selectors: [["p-togglebutton"], ["p-toggle-button"]],
			contentQueries: function ToggleButton_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.iconTemplate, _c0, 4)(dirIndex, ctx.contentTemplate, _c1, 4);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			hostVars: 11,
			hostBindings: function ToggleButton_HostBindings(rf, ctx) {
				if (rf & 1) ɵɵlistener("keydown", function ToggleButton_keydown_HostBindingHandler($event) {
					return ctx.onKeyDown($event);
				})("click", function ToggleButton_click_HostBindingHandler($event) {
					return ctx.toggle($event);
				});
				if (rf & 2) {
					ɵɵattribute("aria-labelledby", ctx.ariaLabelledBy())("aria-label", ctx.ariaLabel())("aria-pressed", ctx.ariaPressed())("role", "button")("tabindex", ctx.$tabindex())("data-pc-name", "togglebutton")("data-p-checked", ctx.active())("data-p-disabled", ctx.$disabled())("data-p", ctx.dataP());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				onLabel: [1, "onLabel"],
				offLabel: [1, "offLabel"],
				onIcon: [1, "onIcon"],
				offIcon: [1, "offIcon"],
				ariaLabel: [1, "ariaLabel"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				inputId: [1, "inputId"],
				tabindex: [1, "tabindex"],
				iconPos: [1, "iconPos"],
				autofocus: [1, "autofocus"],
				size: [1, "size"],
				allowEmpty: [1, "allowEmpty"],
				fluid: [1, "fluid"]
			},
			outputs: { onChange: "onChange" },
			features: [
				ɵɵProvidersFeature([
					TOGGLEBUTTON_VALUE_ACCESSOR,
					ToggleButtonStyle,
					{
						provide: TOGGLEBUTTON_INSTANCE,
						useExisting: ToggleButton
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: ToggleButton
					}
				]),
				ɵɵHostDirectivesFeature([Ripple, Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 3,
			vars: 7,
			consts: [
				[3, "pBind"],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				],
				[
					3,
					"class",
					"pBind"
				]
			],
			template: function ToggleButton_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵelementStart(0, "span", 0);
					ɵɵtemplate(1, ToggleButton_ng_container_1_Template, 1, 0, "ng-container", 1);
					ɵɵconditionalCreate(2, ToggleButton_Conditional_2_Template, 3, 2);
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵclassMap(ctx.cx("content"));
					ɵɵproperty("pBind", ctx.ptm("content"));
					ɵɵattribute("data-p", ctx.dataP());
					ɵɵadvance();
					ɵɵproperty("ngTemplateOutlet", ctx.contentTemplate())("ngTemplateOutletContext", ctx.getTemplateContext());
					ɵɵadvance();
					ɵɵconditional(!ctx.contentTemplate() ? 2 : -1);
				}
			},
			dependencies: [
				NgTemplateOutlet,
				SharedModule,
				BindModule,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ToggleButton, [{
		type: Component,
		args: [{
			selector: "p-togglebutton, p-toggle-button",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				SharedModule,
				BindModule
			],
			hostDirectives: [{ directive: Ripple }, Bind],
			host: {
				"[class]": "cx('root')",
				"[attr.aria-labelledby]": "ariaLabelledBy()",
				"[attr.aria-label]": "ariaLabel()",
				"[attr.aria-pressed]": "ariaPressed()",
				"[attr.role]": "\"button\"",
				"[attr.tabindex]": "$tabindex()",
				"[attr.data-pc-name]": "'togglebutton'",
				"[attr.data-p-checked]": "active()",
				"[attr.data-p-disabled]": "$disabled()",
				"[attr.data-p]": "dataP()"
			},
			template: `<span [class]="cx('content')" [pBind]="ptm('content')" [attr.data-p]="dataP()">
        <ng-container *ngTemplateOutlet="contentTemplate(); context: getTemplateContext()"></ng-container>
        @if (!contentTemplate()) {
            @if (!iconTemplate()) {
                @if (hasIcon()) {
                    <span [class]="iconClass()" [pBind]="ptm('icon')"></span>
                }
            } @else {
                <ng-container *ngTemplateOutlet="iconTemplate(); context: getTemplateContext()"></ng-container>
            }
            @if (hasLabel()) {
                <span [class]="cx('label')" [pBind]="ptm('label')">{{ labelText() }}</span>
            }
        }
    </span>`,
			providers: [
				TOGGLEBUTTON_VALUE_ACCESSOR,
				ToggleButtonStyle,
				{
					provide: TOGGLEBUTTON_INSTANCE,
					useExisting: ToggleButton
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ToggleButton
				}
			],
			changeDetection: ChangeDetectionStrategy.OnPush
		}]
	}], null, {
		onLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "onLabel",
				required: false
			}]
		}],
		offLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "offLabel",
				required: false
			}]
		}],
		onIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "onIcon",
				required: false
			}]
		}],
		offIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "offIcon",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		inputId: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inputId",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		iconPos: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "iconPos",
				required: false
			}]
		}],
		autofocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		allowEmpty: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "allowEmpty",
				required: false
			}]
		}],
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		onChange: [{
			type: Output,
			args: ["onChange"]
		}],
		iconTemplate: [{
			type: ContentChild,
			args: ["icon", {
				descendants: false,
				isSignal: true
			}]
		}],
		contentTemplate: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}],
		onKeyDown: [{
			type: HostListener,
			args: ["keydown", ["$event"]]
		}],
		toggle: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}]
	});
})();
var ToggleButtonModule = class ToggleButtonModule {
	static ɵfac = function ToggleButtonModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ToggleButtonModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: ToggleButtonModule,
		imports: [ToggleButton, SharedModule],
		exports: [ToggleButton, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		ToggleButton,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ToggleButtonModule, [{
		type: NgModule,
		args: [{
			imports: [ToggleButton, SharedModule],
			exports: [ToggleButton, SharedModule]
		}]
	}], null, null);
})();
// node_modules/@primeuix/styles/dist/selectbutton/index.mjs
var style = "\n    .p-selectbutton {\n        display: inline-flex;\n        user-select: none;\n        vertical-align: bottom;\n        outline-color: transparent;\n        border-radius: dt('selectbutton.border.radius');\n    }\n\n    .p-selectbutton .p-togglebutton {\n        border-radius: 0;\n        border-width: 1px 1px 1px 0;\n    }\n\n    .p-selectbutton .p-togglebutton:focus-visible {\n        position: relative;\n        z-index: 1;\n    }\n\n    .p-selectbutton .p-togglebutton:first-child {\n        border-inline-start-width: 1px;\n        border-start-start-radius: dt('selectbutton.border.radius');\n        border-end-start-radius: dt('selectbutton.border.radius');\n    }\n\n    .p-selectbutton .p-togglebutton:last-child {\n        border-start-end-radius: dt('selectbutton.border.radius');\n        border-end-end-radius: dt('selectbutton.border.radius');\n    }\n\n    .p-selectbutton.p-invalid {\n        outline: 1px solid dt('selectbutton.invalid.border.color');\n        outline-offset: 0;\n    }\n\n    .p-selectbutton-fluid {\n        width: 100%;\n    }\n    \n    .p-selectbutton-fluid .p-togglebutton {\n        flex: 1 1 0;\n    }\n";
// node_modules/primeng/fesm2022/primeng-selectbutton.mjs
var classes = { root: ({ instance }) => ["p-selectbutton p-component", {
	"p-invalid": instance.invalid(),
	"p-selectbutton-fluid": instance.fluid()
}] };
var SelectButtonStyle = class SelectButtonStyle extends BaseStyle {
	name = "selectbutton";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵSelectButtonStyle_BaseFactory = void 0;
		return function SelectButtonStyle_Factory(__ngFactoryType__) {
			return (ɵSelectButtonStyle_BaseFactory || (ɵSelectButtonStyle_BaseFactory = ɵɵgetInheritedFactory(SelectButtonStyle)))(__ngFactoryType__ || SelectButtonStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: SelectButtonStyle,
		factory: SelectButtonStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectButtonStyle, [{ type: Injectable }], null, null);
})();
var SelectButtonClasses;
(function(SelectButtonClasses) {
	SelectButtonClasses["root"] = "p-selectbutton";
})(SelectButtonClasses || (SelectButtonClasses = {}));
var SELECTBUTTON_INSTANCE = new InjectionToken("SELECTBUTTON_INSTANCE");
var SELECTBUTTON_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => SelectButton),
	multi: true
};
var SelectButton = class SelectButton extends BaseEditableHolder {
	componentName = "SelectButton";
	options = input(...ngDevMode ? [void 0, { debugName: "options" }] : /* istanbul ignore next */ []);
	optionLabel = input(...ngDevMode ? [void 0, { debugName: "optionLabel" }] : /* istanbul ignore next */ []);
	optionValue = input(...ngDevMode ? [void 0, { debugName: "optionValue" }] : /* istanbul ignore next */ []);
	optionDisabled = input(...ngDevMode ? [void 0, { debugName: "optionDisabled" }] : /* istanbul ignore next */ []);
	unselectable = input(false, {
		...ngDevMode ? { debugName: "unselectable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabindex = input(0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	multiple = input(false, {
		...ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	allowEmpty = input(true, {
		...ngDevMode ? { debugName: "allowEmpty" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	styleClass = input(...ngDevMode ? [void 0, { debugName: "styleClass" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	dataKey = input(...ngDevMode ? [void 0, { debugName: "dataKey" }] : /* istanbul ignore next */ []);
	autofocus = input(false, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	fluid = input(false, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	onOptionClick = output();
	onChange = output();
	itemTemplate = contentChild("item", {
		...ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	equalityKey = computed(() => this.optionValue() ? null : this.dataKey(), ...ngDevMode ? [{ debugName: "equalityKey" }] : /* istanbul ignore next */ []);
	$allowEmpty = computed(() => this.unselectable() ? false : this.allowEmpty(), ...ngDevMode ? [{ debugName: "$allowEmpty" }] : /* istanbul ignore next */ []);
	dataP = computed(() => this.cn({ invalid: this.invalid() }), ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	value = signal(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	focusedIndex = signal(0, ...ngDevMode ? [{ debugName: "focusedIndex" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(SelectButtonStyle);
	$pcSelectButton = inject(SELECTBUTTON_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	getAllowEmpty() {
		if (this.multiple()) return this.$allowEmpty() || this.value()?.length !== 1;
		return this.$allowEmpty();
	}
	getOptionLabel(option) {
		const optionLabel = this.optionLabel();
		return optionLabel ? d(option, optionLabel) : option.label != void 0 ? option.label : option;
	}
	getOptionValue(option) {
		const optionValue = this.optionValue();
		const optionLabel = this.optionLabel();
		return optionValue ? d(option, optionValue) : optionLabel || option.value === void 0 ? option : option.value;
	}
	isOptionDisabled(option) {
		const optionDisabled = this.optionDisabled();
		return optionDisabled ? d(option, optionDisabled) : option.disabled !== void 0 ? option.disabled : false;
	}
	isButtonDisabled(option) {
		return this.$disabled() || this.isOptionDisabled(option);
	}
	getItemContext(option, index) {
		return {
			$implicit: option,
			index
		};
	}
	onOptionSelect(event, option, index) {
		if (this.$disabled() || this.isOptionDisabled(option)) return;
		let selected = this.isSelected(option);
		if (selected && this.unselectable()) return;
		let optionValue = this.getOptionValue(option);
		let newValue;
		if (this.multiple()) {
			if (selected) newValue = this.value().filter((val) => !b(val, optionValue, this.equalityKey() || void 0));
			else newValue = this.value() ? [...this.value(), optionValue] : [optionValue];
		} else {
			if (selected && !this.$allowEmpty()) return;
			newValue = selected ? null : optionValue;
		}
		this.focusedIndex.set(index);
		this.value.set(newValue);
		this.writeModelValue(this.value());
		this.onModelChange(this.value());
		this.onChange.emit({
			originalEvent: event.originalEvent,
			value: this.value()
		});
		this.onOptionClick.emit({
			originalEvent: event.originalEvent,
			option,
			index
		});
	}
	changeTabIndexes(event, direction) {
		let firstTabableChild;
		let index;
		for (let i = 0; i <= this.el.nativeElement.children.length - 1; i++) if (this.el.nativeElement.children[i].getAttribute("tabindex") === "0") firstTabableChild = {
			elem: this.el.nativeElement.children[i],
			index: i
		};
		if (!firstTabableChild) return;
		if (direction === "prev") {
			if (firstTabableChild.index === 0) index = this.el.nativeElement.children.length - 1;
			else index = firstTabableChild.index - 1;
		} else if (firstTabableChild.index === this.el.nativeElement.children.length - 1) index = 0;
		else index = firstTabableChild.index + 1;
		this.focusedIndex.set(index);
		this.el.nativeElement.children[index].focus();
	}
	onFocus(event, index) {
		this.focusedIndex.set(index);
	}
	onBlur() {
		this.onModelTouched();
	}
	removeOption(option) {
		this.value.set(this.value().filter((val) => !b(val, this.getOptionValue(option), this.dataKey())));
	}
	isSelected(option) {
		let selected = false;
		const optionValue = this.getOptionValue(option);
		if (this.multiple()) {
			if (this.value() && Array.isArray(this.value())) {
				for (let val of this.value()) if (b(val, optionValue, this.dataKey())) {
					selected = true;
					break;
				}
			}
		} else selected = b(this.getOptionValue(option), this.value(), this.equalityKey() || void 0);
		return selected;
	}
	writeControlValue(value, setModelValue) {
		this.value.set(value);
		setModelValue(this.value());
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵSelectButton_BaseFactory = void 0;
		return function SelectButton_Factory(__ngFactoryType__) {
			return (ɵSelectButton_BaseFactory || (ɵSelectButton_BaseFactory = ɵɵgetInheritedFactory(SelectButton)))(__ngFactoryType__ || SelectButton);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["item"];
		function _forTrack0($index, $item) {
			return this.getOptionLabel($item);
		}
		function SelectButton_For_1_Conditional_1_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function SelectButton_For_1_Conditional_1_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, SelectButton_For_1_Conditional_1_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 3);
			if (rf & 2) {
				const ctx_r5 = ɵɵnextContext(2);
				const option_r3 = ctx_r5.$implicit;
				const ɵ$index_1_r4 = ctx_r5.$index;
				const ctx_r4 = ɵɵnextContext();
				ɵɵproperty("ngTemplateOutlet", ctx_r4.itemTemplate())("ngTemplateOutletContext", ctx_r4.getItemContext(option_r3, ɵ$index_1_r4));
			}
		}
		function SelectButton_For_1_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, SelectButton_For_1_Conditional_1_ng_template_0_Template, 1, 2, "ng-template", null, 0, ɵɵtemplateRefExtractor);
		}
		function SelectButton_For_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "p-togglebutton", 2);
				ɵɵcontrolCreate();
				ɵɵlistener("onChange", function SelectButton_For_1_Template_p_togglebutton_onChange_0_listener($event) {
					const ctx_r1 = ɵɵrestoreView(_r1);
					const option_r3 = ctx_r1.$implicit;
					const ɵ$index_1_r4 = ctx_r1.$index;
					const ctx_r4 = ɵɵnextContext();
					return ɵɵresetView(ctx_r4.onOptionSelect($event, option_r3, ɵ$index_1_r4));
				});
				ɵɵconditionalCreate(1, SelectButton_For_1_Conditional_1_Template, 2, 0);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const option_r3 = ctx.$implicit;
				const ctx_r4 = ɵɵnextContext();
				ɵɵclassMap(ctx_r4.styleClass());
				ɵɵproperty("autofocus", ctx_r4.autofocus())("ngModel", ctx_r4.isSelected(option_r3))("onLabel", ctx_r4.getOptionLabel(option_r3))("offLabel", ctx_r4.getOptionLabel(option_r3))("ariaLabel", ctx_r4.getOptionLabel(option_r3))("disabled", ctx_r4.isButtonDisabled(option_r3))("allowEmpty", ctx_r4.getAllowEmpty())("size", ctx_r4.size())("fluid", ctx_r4.fluid())("pt", ctx_r4.ptm("pcToggleButton"))("unstyled", ctx_r4.unstyled());
				ɵɵcontrol();
				ɵɵadvance();
				ɵɵconditional(ctx_r4.itemTemplate() ? 1 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: SelectButton,
			selectors: [["p-selectbutton"], ["p-select-button"]],
			contentQueries: function SelectButton_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.itemTemplate, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 5,
			hostBindings: function SelectButton_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "group")("aria-labelledby", ctx.ariaLabelledBy())("data-p", ctx.dataP());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				options: [1, "options"],
				optionLabel: [1, "optionLabel"],
				optionValue: [1, "optionValue"],
				optionDisabled: [1, "optionDisabled"],
				unselectable: [1, "unselectable"],
				tabindex: [1, "tabindex"],
				multiple: [1, "multiple"],
				allowEmpty: [1, "allowEmpty"],
				styleClass: [1, "styleClass"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				dataKey: [1, "dataKey"],
				autofocus: [1, "autofocus"],
				size: [1, "size"],
				fluid: [1, "fluid"]
			},
			outputs: {
				onOptionClick: "onOptionClick",
				onChange: "onChange"
			},
			features: [
				ɵɵProvidersFeature([
					SELECTBUTTON_VALUE_ACCESSOR,
					SelectButtonStyle,
					{
						provide: SELECTBUTTON_INSTANCE,
						useExisting: SelectButton
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: SelectButton
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 2,
			vars: 0,
			consts: [
				["content", ""],
				[
					3,
					"autofocus",
					"class",
					"ngModel",
					"onLabel",
					"offLabel",
					"ariaLabel",
					"disabled",
					"allowEmpty",
					"size",
					"fluid",
					"pt",
					"unstyled"
				],
				[
					3,
					"onChange",
					"autofocus",
					"ngModel",
					"onLabel",
					"offLabel",
					"ariaLabel",
					"disabled",
					"allowEmpty",
					"size",
					"fluid",
					"pt",
					"unstyled"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				]
			],
			template: function SelectButton_Template(rf, ctx) {
				if (rf & 1) ɵɵrepeaterCreate(0, SelectButton_For_1_Template, 2, 14, "p-togglebutton", 1, _forTrack0, true);
				if (rf & 2) ɵɵrepeater(ctx.options());
			},
			dependencies: [
				ToggleButton,
				FormsModule,
				NgControlStatus,
				NgModel,
				NgTemplateOutlet,
				SharedModule,
				BindModule
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectButton, [{
		type: Component,
		args: [{
			selector: "p-selectbutton, p-select-button",
			standalone: true,
			imports: [
				ToggleButton,
				FormsModule,
				NgTemplateOutlet,
				SharedModule,
				BindModule
			],
			template: `
        @for (option of options(); track getOptionLabel(option); let i = $index) {
            <p-togglebutton
                [autofocus]="autofocus()"
                [class]="styleClass()"
                [ngModel]="isSelected(option)"
                [onLabel]="getOptionLabel(option)"
                [offLabel]="getOptionLabel(option)"
                [ariaLabel]="getOptionLabel(option)"
                [disabled]="isButtonDisabled(option)"
                (onChange)="onOptionSelect($event, option, i)"
                [allowEmpty]="getAllowEmpty()"
                [size]="size()"
                [fluid]="fluid()"
                [pt]="ptm('pcToggleButton')"
                [unstyled]="unstyled()"
            >
                @if (itemTemplate()) {
                    <ng-template #content>
                        <ng-container *ngTemplateOutlet="itemTemplate(); context: getItemContext(option, i)"></ng-container>
                    </ng-template>
                }
            </p-togglebutton>
        }
    `,
			providers: [
				SELECTBUTTON_VALUE_ACCESSOR,
				SelectButtonStyle,
				{
					provide: SELECTBUTTON_INSTANCE,
					useExisting: SelectButton
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: SelectButton
				}
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx('root')",
				"[attr.role]": "\"group\"",
				"[attr.aria-labelledby]": "ariaLabelledBy()",
				"[attr.data-p]": "dataP()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		options: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		optionLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "optionLabel",
				required: false
			}]
		}],
		optionValue: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "optionValue",
				required: false
			}]
		}],
		optionDisabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "optionDisabled",
				required: false
			}]
		}],
		unselectable: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "unselectable",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		multiple: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "multiple",
				required: false
			}]
		}],
		allowEmpty: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "allowEmpty",
				required: false
			}]
		}],
		styleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "styleClass",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		dataKey: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "dataKey",
				required: false
			}]
		}],
		autofocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		onOptionClick: [{
			type: Output,
			args: ["onOptionClick"]
		}],
		onChange: [{
			type: Output,
			args: ["onChange"]
		}],
		itemTemplate: [{
			type: ContentChild,
			args: ["item", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var SelectButtonModule = class SelectButtonModule {
	static ɵfac = function SelectButtonModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || SelectButtonModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: SelectButtonModule,
		imports: [SelectButton, SharedModule],
		exports: [SelectButton, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		SelectButton,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectButtonModule, [{
		type: NgModule,
		args: [{
			imports: [SelectButton, SharedModule],
			exports: [SelectButton, SharedModule]
		}]
	}], null, null);
})();
export { SELECTBUTTON_VALUE_ACCESSOR, SelectButton, SelectButtonClasses, SelectButtonModule, SelectButtonStyle };
