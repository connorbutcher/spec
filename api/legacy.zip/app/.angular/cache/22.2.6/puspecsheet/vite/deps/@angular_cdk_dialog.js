import { I as EventEmitter, T as DOCUMENT, U as InjectionToken, Ui as signal, W as Injector, et as NgZone, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Nn as NgModule, S as ViewChild, Ua as ɵɵdefineComponent, Wn as Renderer2, Xs as ɵɵviewQuery, Zn as Service, aa as ɵɵattribute, fn as ElementRef, ir as TemplateRef, js as ɵɵtemplate, pr as ViewEncapsulation, qa as ɵɵdefineService, r as ChangeDetectorRef, ss as ɵɵqueryRefresh, vr as afterNextRender, zo as ɵɵloadQuery } from "./core-BenYQOr3.js";
import { Et as take, S as startWith, Wn as Subject } from "./zipWith-3O6QFimT.js";
import { m as defer } from "./esm5-mutFUw8P.js";
import { A as createOverlayRef, F as CdkPortal, I as CdkPortalOutlet, L as ComponentPortal, O as createGlobalPositionStrategy, P as BasePortalOutlet, R as PortalModule, T as createBlockScrollStrategy, g as OverlayModule, m as OverlayContainer, p as OverlayConfig, y as OverlayRef, z as TemplatePortal } from "./_overlay-module-chunk-C1I0eHx4.js";
import { a as FocusTrapFactory, c as InteractivityChecker, g as FocusMonitor, t as A11yModule } from "./_a11y-module-chunk-CUlnMLrC.js";
import { c as _getFocusedElementPierceShadowDom, o as Platform, t as _IdGenerator } from "./_id-generator-chunk-BJRPFgfs.js";
import { t as hasModifierKey } from "./keycodes-DL40huTC.js";
import { m as Directionality } from "./scrolling-cY6EEIaN.js";
// node_modules/@angular/cdk/fesm2022/dialog.mjs
var DialogConfig = class {
	viewContainerRef;
	injector;
	id;
	role = "dialog";
	panelClass = "";
	hasBackdrop = true;
	backdropClass = "";
	disableClose = false;
	closePredicate;
	width = "";
	height = "";
	minWidth;
	minHeight;
	maxWidth;
	maxHeight;
	positionStrategy;
	data = null;
	direction;
	ariaDescribedBy = null;
	ariaLabelledBy = null;
	ariaLabel = null;
	ariaModal = false;
	autoFocus = "first-tabbable";
	restoreFocus = true;
	scrollStrategy;
	closeOnNavigation = true;
	closeOnDestroy = true;
	closeOnOverlayDetachments = true;
	disableAnimations = false;
	providers;
	container;
	templateContext;
	bindings;
};
function throwDialogContentAlreadyAttachedError() {
	throw Error("Attempting to attach dialog content after content is already attached");
}
var CdkDialogContainer = class CdkDialogContainer extends BasePortalOutlet {
	_elementRef = inject(ElementRef);
	_focusTrapFactory = inject(FocusTrapFactory);
	_config;
	_interactivityChecker = inject(InteractivityChecker);
	_ngZone = inject(NgZone);
	_focusMonitor = inject(FocusMonitor);
	_renderer = inject(Renderer2);
	_changeDetectorRef = inject(ChangeDetectorRef);
	_injector = inject(Injector);
	_platform = inject(Platform);
	_document = inject(DOCUMENT);
	_portalOutlet;
	_focusTrapped = new Subject();
	_focusTrap = null;
	_elementFocusedBeforeDialogWasOpened = null;
	_closeInteractionType = null;
	_ariaLabelledByQueue = [];
	_isDestroyed = false;
	constructor() {
		super();
		this._config = inject(DialogConfig, { optional: true }) || new DialogConfig();
		if (this._config.ariaLabelledBy) this._ariaLabelledByQueue.push(this._config.ariaLabelledBy);
	}
	_addAriaLabelledBy(id) {
		this._ariaLabelledByQueue.push(id);
		this._changeDetectorRef.markForCheck();
	}
	_removeAriaLabelledBy(id) {
		const index = this._ariaLabelledByQueue.indexOf(id);
		if (index > -1) {
			this._ariaLabelledByQueue.splice(index, 1);
			this._changeDetectorRef.markForCheck();
		}
	}
	_contentAttached() {
		this._initializeFocusTrap();
		this._captureInitialFocus();
	}
	_captureInitialFocus() {
		this._trapFocus();
	}
	ngOnDestroy() {
		this._focusTrapped.complete();
		this._isDestroyed = true;
		this._restoreFocus();
	}
	attachComponentPortal(portal) {
		if (this._portalOutlet.hasAttached() && (typeof ngDevMode === "undefined" || ngDevMode)) throwDialogContentAlreadyAttachedError();
		const result = this._portalOutlet.attachComponentPortal(portal);
		this._contentAttached();
		return result;
	}
	attachTemplatePortal(portal) {
		if (this._portalOutlet.hasAttached() && (typeof ngDevMode === "undefined" || ngDevMode)) throwDialogContentAlreadyAttachedError();
		const result = this._portalOutlet.attachTemplatePortal(portal);
		this._contentAttached();
		return result;
	}
	attachDomPortal = (portal) => {
		if (this._portalOutlet.hasAttached() && (typeof ngDevMode === "undefined" || ngDevMode)) throwDialogContentAlreadyAttachedError();
		const result = this._portalOutlet.attachDomPortal(portal);
		this._contentAttached();
		return result;
	};
	_recaptureFocus() {
		if (!this._containsFocus()) this._trapFocus();
	}
	_forceFocus(element, options) {
		if (!this._interactivityChecker.isFocusable(element)) {
			element.tabIndex = -1;
			this._ngZone.runOutsideAngular(() => {
				const callback = () => {
					deregisterBlur();
					deregisterMousedown();
					element.removeAttribute("tabindex");
				};
				const deregisterBlur = this._renderer.listen(element, "blur", callback);
				const deregisterMousedown = this._renderer.listen(element, "mousedown", callback);
			});
		}
		element.focus(options);
	}
	_focusByCssSelector(selector, options) {
		let elementToFocus = this._elementRef.nativeElement.querySelector(selector);
		if (elementToFocus) this._forceFocus(elementToFocus, options);
	}
	_trapFocus(options) {
		if (this._isDestroyed) return;
		afterNextRender(() => {
			const element = this._elementRef.nativeElement;
			switch (this._config.autoFocus) {
				case false:
				case "dialog":
					if (!this._containsFocus()) element.focus(options);
					break;
				case true:
				case "first-tabbable":
					if (!this._focusTrap?.focusInitialElement(options)) this._focusDialogContainer(options);
					break;
				case "first-heading":
					this._focusByCssSelector("h1, h2, h3, h4, h5, h6, [role=\"heading\"]", options);
					break;
				default: this._focusByCssSelector(this._config.autoFocus, options);
			}
			this._focusTrapped.next();
		}, { injector: this._injector });
	}
	_restoreFocus() {
		const focusConfig = this._config.restoreFocus;
		let focusTargetElement = null;
		if (typeof focusConfig === "string") focusTargetElement = this._document.querySelector(focusConfig);
		else if (typeof focusConfig === "boolean") focusTargetElement = focusConfig ? this._elementFocusedBeforeDialogWasOpened : null;
		else if (focusConfig) focusTargetElement = focusConfig;
		if (this._config.restoreFocus && focusTargetElement && typeof focusTargetElement.focus === "function") {
			const activeElement = _getFocusedElementPierceShadowDom();
			const element = this._elementRef.nativeElement;
			if (!activeElement || activeElement === this._document.body || activeElement === element || element.contains(activeElement)) {
				if (this._focusMonitor) {
					this._focusMonitor.focusVia(focusTargetElement, this._closeInteractionType);
					this._closeInteractionType = null;
				} else focusTargetElement.focus();
			}
		}
		if (this._focusTrap) this._focusTrap.destroy();
	}
	_focusDialogContainer(options) {
		this._elementRef.nativeElement.focus?.(options);
	}
	_containsFocus() {
		const element = this._elementRef.nativeElement;
		const activeElement = _getFocusedElementPierceShadowDom();
		return element === activeElement || element.contains(activeElement);
	}
	_initializeFocusTrap() {
		if (this._platform.isBrowser) {
			this._focusTrap = this._focusTrapFactory.create(this._elementRef.nativeElement);
			if (this._document) this._elementFocusedBeforeDialogWasOpened = _getFocusedElementPierceShadowDom();
		}
	}
	static ɵfac = function CdkDialogContainer_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkDialogContainer)();
	};
	static ɵcmp = (function() {
		function CdkDialogContainer_ng_template_0_Template(rf, ctx) {}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: CdkDialogContainer,
			selectors: [["cdk-dialog-container"]],
			viewQuery: function CdkDialogContainer_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuery(CdkPortalOutlet, 7);
				if (rf & 2) {
					let _t = void 0;
					ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx._portalOutlet = _t.first);
				}
			},
			hostAttrs: [
				"tabindex",
				"-1",
				1,
				"cdk-dialog-container"
			],
			hostVars: 6,
			hostBindings: function CdkDialogContainer_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵattribute("id", ctx._config.id || null)("role", ctx._config.role)("aria-modal", ctx._config.ariaModal)("aria-labelledby", ctx._config.ariaLabel ? null : ctx._ariaLabelledByQueue[0])("aria-label", ctx._config.ariaLabel)("aria-describedby", ctx._config.ariaDescribedBy || null);
			},
			features: [ɵɵInheritDefinitionFeature],
			decls: 1,
			vars: 0,
			consts: [["cdkPortalOutlet", ""]],
			template: function CdkDialogContainer_Template(rf, ctx) {
				if (rf & 1) ɵɵtemplate(0, CdkDialogContainer_ng_template_0_Template, 0, 0, "ng-template", 0);
			},
			dependencies: [CdkPortalOutlet],
			styles: [".cdk-dialog-container {\n  display: block;\n  width: 100%;\n  height: 100%;\n  min-height: inherit;\n  max-height: inherit;\n}\n"],
			encapsulation: 2,
			changeDetection: 1
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkDialogContainer, [{
		type: Component,
		args: [{
			selector: "cdk-dialog-container",
			encapsulation: ViewEncapsulation.None,
			changeDetection: ChangeDetectionStrategy.Eager,
			imports: [CdkPortalOutlet],
			host: {
				"class": "cdk-dialog-container",
				"tabindex": "-1",
				"[attr.id]": "_config.id || null",
				"[attr.role]": "_config.role",
				"[attr.aria-modal]": "_config.ariaModal",
				"[attr.aria-labelledby]": "_config.ariaLabel ? null : _ariaLabelledByQueue[0]",
				"[attr.aria-label]": "_config.ariaLabel",
				"[attr.aria-describedby]": "_config.ariaDescribedBy || null"
			},
			template: "<ng-template cdkPortalOutlet />\n",
			styles: [".cdk-dialog-container {\n  display: block;\n  width: 100%;\n  height: 100%;\n  min-height: inherit;\n  max-height: inherit;\n}\n"]
		}]
	}], () => [], { _portalOutlet: [{
		type: ViewChild,
		args: [CdkPortalOutlet, { static: true }]
	}] });
})();
var DialogRef = class {
	overlayRef;
	config;
	componentInstance = null;
	componentRef = null;
	containerInstance;
	disableClose;
	closed = new Subject();
	backdropClick;
	keydownEvents;
	outsidePointerEvents;
	id;
	_detachSubscription;
	constructor(overlayRef, config) {
		this.overlayRef = overlayRef;
		this.config = config;
		this.disableClose = config.disableClose;
		this.backdropClick = overlayRef.backdropClick();
		this.keydownEvents = overlayRef.keydownEvents();
		this.outsidePointerEvents = overlayRef.outsidePointerEvents();
		this.id = config.id;
		this.keydownEvents.subscribe((event) => {
			if (event.keyCode === 27 && !this.disableClose && !hasModifierKey(event)) {
				event.preventDefault();
				this.close(void 0, { focusOrigin: "keyboard" });
			}
		});
		this.backdropClick.subscribe(() => {
			if (!this.disableClose && this._canClose()) this.close(void 0, { focusOrigin: "mouse" });
			else this.containerInstance._recaptureFocus?.();
		});
		this._detachSubscription = overlayRef.detachments().subscribe(() => {
			if (config.closeOnOverlayDetachments !== false) this.close();
		});
	}
	close(result, options) {
		if (this._canClose(result)) {
			const closedSubject = this.closed;
			this.containerInstance._closeInteractionType = options?.focusOrigin || "program";
			this._detachSubscription.unsubscribe();
			this.overlayRef.dispose();
			closedSubject.next(result);
			closedSubject.complete();
			this.componentInstance = this.containerInstance = null;
		}
	}
	updatePosition() {
		this.overlayRef.updatePosition();
		return this;
	}
	updateSize(width = "", height = "") {
		this.overlayRef.updateSize({
			width,
			height
		});
		return this;
	}
	addPanelClass(classes) {
		this.overlayRef.addPanelClass(classes);
		return this;
	}
	removePanelClass(classes) {
		this.overlayRef.removePanelClass(classes);
		return this;
	}
	_canClose(result) {
		const config = this.config;
		return !!this.containerInstance && (!config.closePredicate || config.closePredicate(result, config, this.componentInstance));
	}
};
var DIALOG_SCROLL_STRATEGY = new InjectionToken("DialogScrollStrategy", {
	providedIn: "root",
	factory: () => {
		const injector = inject(Injector);
		return () => createBlockScrollStrategy(injector);
	}
});
var DIALOG_DATA = new InjectionToken("DialogData");
var DEFAULT_DIALOG_CONFIG = new InjectionToken("DefaultDialogConfig");
function getDirectionality(value) {
	const valueSignal = signal(value, ...ngDevMode ? [{ debugName: "valueSignal" }] : []);
	const change = new EventEmitter();
	return {
		valueSignal,
		get value() {
			return valueSignal();
		},
		change,
		ngOnDestroy() {
			change.complete();
		}
	};
}
var Dialog = class Dialog {
	_injector = inject(Injector);
	_defaultOptions = inject(DEFAULT_DIALOG_CONFIG, { optional: true });
	_parentDialog = inject(Dialog, {
		optional: true,
		skipSelf: true
	});
	_overlayContainer = inject(OverlayContainer);
	_idGenerator = inject(_IdGenerator);
	_openDialogsAtThisLevel = [];
	_afterAllClosedAtThisLevel = new Subject();
	_afterOpenedAtThisLevel = new Subject();
	_ariaHiddenElements = /* @__PURE__ */ new Map();
	_scrollStrategy = inject(DIALOG_SCROLL_STRATEGY);
	get openDialogs() {
		return this._parentDialog ? this._parentDialog.openDialogs : this._openDialogsAtThisLevel;
	}
	get afterOpened() {
		return this._parentDialog ? this._parentDialog.afterOpened : this._afterOpenedAtThisLevel;
	}
	afterAllClosed = defer(() => this.openDialogs.length ? this._getAfterAllClosed() : this._getAfterAllClosed().pipe(startWith(void 0)));
	open(componentOrTemplateRef, config) {
		config = {
			...this._defaultOptions || new DialogConfig(),
			...config
		};
		config.id = config.id || this._idGenerator.getId("cdk-dialog-");
		if (config.id && this.getDialogById(config.id) && (typeof ngDevMode === "undefined" || ngDevMode)) throw Error(`Dialog with id "${config.id}" exists already. The dialog id must be unique.`);
		const overlayConfig = this._getOverlayConfig(config);
		const overlayRef = createOverlayRef(this._injector, overlayConfig);
		const dialogRef = new DialogRef(overlayRef, config);
		const dialogContainer = this._attachContainer(overlayRef, dialogRef, config);
		dialogRef.containerInstance = dialogContainer;
		if (!this.openDialogs.length) {
			const overlayContainer = this._overlayContainer.getContainerElement();
			if (dialogContainer._focusTrapped) dialogContainer._focusTrapped.pipe(take(1)).subscribe(() => {
				this._hideNonDialogContentFromAssistiveTechnology(overlayContainer);
			});
			else this._hideNonDialogContentFromAssistiveTechnology(overlayContainer);
		}
		this._attachDialogContent(componentOrTemplateRef, dialogRef, dialogContainer, config);
		this.openDialogs.push(dialogRef);
		dialogRef.closed.subscribe(() => this._removeOpenDialog(dialogRef, true));
		this.afterOpened.next(dialogRef);
		return dialogRef;
	}
	closeAll() {
		reverseForEach(this.openDialogs, (dialog) => dialog.close());
	}
	getDialogById(id) {
		return this.openDialogs.find((dialog) => dialog.id === id);
	}
	ngOnDestroy() {
		reverseForEach(this._openDialogsAtThisLevel, (dialog) => {
			if (dialog.config.closeOnDestroy === false) this._removeOpenDialog(dialog, false);
		});
		reverseForEach(this._openDialogsAtThisLevel, (dialog) => dialog.close());
		this._afterAllClosedAtThisLevel.complete();
		this._afterOpenedAtThisLevel.complete();
		this._openDialogsAtThisLevel = [];
	}
	_getOverlayConfig(config) {
		const state = new OverlayConfig({
			positionStrategy: config.positionStrategy || createGlobalPositionStrategy().centerHorizontally().centerVertically(),
			scrollStrategy: config.scrollStrategy || this._scrollStrategy(),
			panelClass: config.panelClass,
			hasBackdrop: config.hasBackdrop,
			direction: config.direction,
			minWidth: config.minWidth,
			minHeight: config.minHeight,
			maxWidth: config.maxWidth,
			maxHeight: config.maxHeight,
			width: config.width,
			height: config.height,
			disposeOnNavigation: config.closeOnNavigation,
			disableAnimations: config.disableAnimations
		});
		if (config.backdropClass) state.backdropClass = config.backdropClass;
		return state;
	}
	_attachContainer(overlay, dialogRef, config) {
		const userInjector = config.injector || config.viewContainerRef?.injector;
		const providers = [
			{
				provide: DialogConfig,
				useValue: config
			},
			{
				provide: DialogRef,
				useValue: dialogRef
			},
			{
				provide: OverlayRef,
				useValue: overlay
			}
		];
		let containerType;
		if (config.container) {
			if (typeof config.container === "function") containerType = config.container;
			else {
				containerType = config.container.type;
				providers.push(...config.container.providers(config));
			}
		} else containerType = CdkDialogContainer;
		const containerPortal = new ComponentPortal(containerType, config.viewContainerRef, Injector.create({
			parent: userInjector || this._injector,
			providers
		}));
		return overlay.attach(containerPortal).instance;
	}
	_attachDialogContent(componentOrTemplateRef, dialogRef, dialogContainer, config) {
		if (componentOrTemplateRef instanceof TemplateRef) {
			const injector = this._createInjector(config, dialogRef, dialogContainer, void 0);
			let context = {
				$implicit: config.data,
				dialogRef
			};
			if (config.templateContext) context = {
				...context,
				...typeof config.templateContext === "function" ? config.templateContext() : config.templateContext
			};
			dialogContainer.attachTemplatePortal(new TemplatePortal(componentOrTemplateRef, null, context, injector));
		} else {
			const injector = this._createInjector(config, dialogRef, dialogContainer, this._injector);
			const contentRef = dialogContainer.attachComponentPortal(new ComponentPortal(componentOrTemplateRef, config.viewContainerRef, injector, null, config.bindings));
			dialogRef.componentRef = contentRef;
			dialogRef.componentInstance = contentRef.instance;
		}
	}
	_createInjector(config, dialogRef, dialogContainer, fallbackInjector) {
		const userInjector = config.injector || config.viewContainerRef?.injector;
		const providers = [{
			provide: DIALOG_DATA,
			useValue: config.data
		}, {
			provide: DialogRef,
			useValue: dialogRef
		}];
		if (config.providers) {
			if (typeof config.providers === "function") providers.push(...config.providers(dialogRef, config, dialogContainer));
			else providers.push(...config.providers);
		}
		if (config.direction && (!userInjector || !userInjector.get(Directionality, null, { optional: true }))) providers.push({
			provide: Directionality,
			useValue: getDirectionality(config.direction)
		});
		return Injector.create({
			parent: userInjector || fallbackInjector,
			providers
		});
	}
	_removeOpenDialog(dialogRef, emitEvent) {
		const index = this.openDialogs.indexOf(dialogRef);
		if (index > -1) {
			this.openDialogs.splice(index, 1);
			if (!this.openDialogs.length) {
				this._ariaHiddenElements.forEach((previousValue, element) => {
					if (previousValue) element.setAttribute("aria-hidden", previousValue);
					else element.removeAttribute("aria-hidden");
				});
				this._ariaHiddenElements.clear();
				if (emitEvent) this._getAfterAllClosed().next();
			}
		}
	}
	_hideNonDialogContentFromAssistiveTechnology(overlayContainer) {
		if (overlayContainer.parentElement) {
			const siblings = overlayContainer.parentElement.children;
			for (let i = siblings.length - 1; i > -1; i--) {
				const sibling = siblings[i];
				if (sibling !== overlayContainer && sibling.nodeName !== "SCRIPT" && sibling.nodeName !== "STYLE" && !sibling.hasAttribute("aria-live") && !sibling.hasAttribute("popover")) {
					this._ariaHiddenElements.set(sibling, sibling.getAttribute("aria-hidden"));
					sibling.setAttribute("aria-hidden", "true");
				}
			}
		}
	}
	_getAfterAllClosed() {
		const parent = this._parentDialog;
		return parent ? parent._getAfterAllClosed() : this._afterAllClosedAtThisLevel;
	}
	static ɵfac = function Dialog_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Dialog)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: Dialog,
		factory: Dialog.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dialog, [{ type: Service }], null, null);
})();
function reverseForEach(items, callback) {
	let i = items.length;
	while (i--) callback(items[i]);
}
var DialogModule = class DialogModule {
	static ɵfac = function DialogModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || DialogModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: DialogModule,
		imports: [
			OverlayModule,
			PortalModule,
			A11yModule,
			CdkDialogContainer
		],
		exports: [PortalModule, CdkDialogContainer]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({
		providers: [Dialog],
		imports: [
			OverlayModule,
			PortalModule,
			A11yModule,
			PortalModule
		]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DialogModule, [{
		type: NgModule,
		args: [{
			imports: [
				OverlayModule,
				PortalModule,
				A11yModule,
				CdkDialogContainer
			],
			exports: [PortalModule, CdkDialogContainer],
			providers: [Dialog]
		}]
	}], null, null);
})();
export { CdkDialogContainer, DEFAULT_DIALOG_CONFIG, DIALOG_DATA, DIALOG_SCROLL_STRATEGY, Dialog, DialogConfig, DialogModule, DialogRef, throwDialogContentAlreadyAttachedError, CdkPortal as ɵɵCdkPortal, CdkPortalOutlet as ɵɵCdkPortalOutlet };
