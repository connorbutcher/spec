import { Fn as forwardRef, U as InjectionToken, Ui as signal, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, xn as effect, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Ms as ɵɵtemplateRefExtractor, Nn as NgModule, O as booleanAttribute, Ro as ɵɵlistener, S as ViewChild, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, Zs as ɵɵviewQuerySignal, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, fn as ElementRef, go as ɵɵgetCurrentView, gt as viewChild, ha as ɵɵcontentQuerySignal, hn as HostListener, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, ls as ɵɵreference, no as ɵɵdomProperty, nt as model, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, rt as numberAttribute, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { J as it, L as Wt, Q as nt, V as Zt, rt as q } from "./primeng-utils-CHKSviI4.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { Y as NgTemplateOutlet, u as isPlatformBrowser } from "./common-D_MNYFJX.js";
import { h as b } from "./dist-BRhwYpCB.js";
import { SharedModule } from "./primeng_api.js";
import { n as RippleModule, t as Ripple } from "./primeng-ripple-BUHk2LHf.js";
import { t as ChevronLeft } from "./primeicons-angular-chevron-left-javWiY7W.js";
import { t as ChevronRight } from "./primeicons-angular-chevron-right-CLcOcFWl.js";
// node_modules/@primeuix/styles/dist/tabs/index.mjs
var style = "\n    .p-tabs {\n        display: flex;\n        flex-direction: column;\n    }\n\n    .p-tablist {\n        overflow: hidden;\n        display: flex;\n        position: relative;\n        background: dt('tabs.tablist.background');\n        border-style: solid;\n        border-color: dt('tabs.tablist.border.color');\n        border-width: dt('tabs.tablist.border.width');\n    }\n\n    .p-tablist-content {\n        position: relative;\n        display: flex;\n        flex-grow: 1;\n        min-height: 0;\n        overflow-x: auto;\n        overflow-y: clip;\n        scroll-behavior: smooth;\n        scrollbar-width: none;\n        overscroll-behavior: contain auto;\n    }\n\n    .p-tablist-content::-webkit-scrollbar {\n        display: none;\n    }\n\n    .p-tablist-nav-button {\n        all: unset;\n        position: absolute !important;\n        flex-shrink: 0;\n        inset-block-start: 0;\n        z-index: 2;\n        height: 100%;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        background: dt('tabs.nav.button.background');\n        color: dt('tabs.nav.button.color');\n        width: dt('tabs.nav.button.width');\n        transition:\n            color dt('tabs.transition.duration'),\n            outline-color dt('tabs.transition.duration'),\n            box-shadow dt('tabs.transition.duration');\n        box-shadow: dt('tabs.nav.button.shadow');\n        outline-color: transparent;\n        cursor: pointer;\n    }\n\n    .p-tablist-nav-button:focus-visible {\n        z-index: 1;\n        box-shadow: dt('tabs.nav.button.focus.ring.shadow');\n        outline: dt('tabs.nav.button.focus.ring.width') dt('tabs.nav.button.focus.ring.style') dt('tabs.nav.button.focus.ring.color');\n        outline-offset: dt('tabs.nav.button.focus.ring.offset');\n    }\n\n    .p-tablist-nav-button:hover {\n        color: dt('tabs.nav.button.hover.color');\n    }\n\n    .p-tablist-prev-button {\n        inset-inline-start: 0;\n    }\n\n    .p-tablist-next-button {\n        inset-inline-end: 0;\n    }\n\n    .p-tablist-prev-button:dir(rtl),\n    .p-tablist-next-button:dir(rtl) {\n        transform: rotate(180deg);\n    }\n\n    .p-tab {\n        flex-shrink: 0;\n        cursor: pointer;\n        user-select: none;\n        position: relative;\n        border-style: solid;\n        white-space: nowrap;\n        gap: dt('tabs.tab.gap');\n        background: dt('tabs.tab.background');\n        border-width: dt('tabs.tab.border.width');\n        border-color: dt('tabs.tab.border.color');\n        color: dt('tabs.tab.color');\n        padding: dt('tabs.tab.padding');\n        font-weight: dt('tabs.tab.font.weight');\n        font-size: dt('tabs.tab.font.size');\n        transition:\n            background dt('tabs.transition.duration'),\n            border-color dt('tabs.transition.duration'),\n            color dt('tabs.transition.duration'),\n            outline-color dt('tabs.transition.duration'),\n            box-shadow dt('tabs.transition.duration');\n        margin: dt('tabs.tab.margin');\n        outline-color: transparent;\n    }\n\n    .p-tab:not(.p-disabled):focus-visible {\n        z-index: 1;\n        box-shadow: dt('tabs.tab.focus.ring.shadow');\n        outline: dt('tabs.tab.focus.ring.width') dt('tabs.tab.focus.ring.style') dt('tabs.tab.focus.ring.color');\n        outline-offset: dt('tabs.tab.focus.ring.offset');\n    }\n\n    .p-tab:not(.p-tab-active):not(.p-disabled):hover {\n        background: dt('tabs.tab.hover.background');\n        border-color: dt('tabs.tab.hover.border.color');\n        color: dt('tabs.tab.hover.color');\n    }\n\n    .p-tab-active {\n        background: dt('tabs.tab.active.background');\n        border-color: dt('tabs.tab.active.border.color');\n        color: dt('tabs.tab.active.color');\n    }\n\n    .p-tabpanels {\n        background: dt('tabs.tabpanel.background');\n        color: dt('tabs.tabpanel.color');\n        padding: dt('tabs.tabpanel.padding');\n        outline: 0 none;\n    }\n\n    .p-tabpanel:focus-visible {\n        box-shadow: dt('tabs.tabpanel.focus.ring.shadow');\n        outline: dt('tabs.tabpanel.focus.ring.width') dt('tabs.tabpanel.focus.ring.style') dt('tabs.tabpanel.focus.ring.color');\n        outline-offset: dt('tabs.tabpanel.focus.ring.offset');\n    }\n\n    .p-tablist-active-bar {\n        z-index: 1;\n        display: block;\n        position: absolute;\n        background: dt('tabs.active.bar.background');\n        transition: width 250ms cubic-bezier(0.35, 0, 0.25, 1), inset-inline-start 250ms cubic-bezier(0.35, 0, 0.25, 1);\n        inset-inline-start: var(--px-active-bar-left);\n        inset-block-end: dt('tabs.active.bar.bottom');\n        width: var(--px-active-bar-width);\n        height: dt('tabs.active.bar.height');\n    }\n";
// node_modules/primeng/fesm2022/primeng-tabs.mjs
var classes$4 = { root: "p-tabs p-component" };
var TabsStyle = class TabsStyle extends BaseStyle {
	name = "tabs";
	style = style;
	classes = classes$4;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabsStyle_BaseFactory = void 0;
		return function TabsStyle_Factory(__ngFactoryType__) {
			return (ɵTabsStyle_BaseFactory || (ɵTabsStyle_BaseFactory = ɵɵgetInheritedFactory(TabsStyle)))(__ngFactoryType__ || TabsStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TabsStyle,
		factory: TabsStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabsStyle, [{ type: Injectable }], null, null);
})();
var TabsClasses;
(function(TabsClasses) {
	TabsClasses["root"] = "p-tabs";
	TabsClasses["list"] = "p-tablist";
	TabsClasses["content"] = "p-tablist-content";
	TabsClasses["tablist"] = "p-tablist-tab-list";
	TabsClasses["tab"] = "p-tab";
	TabsClasses["inkbar"] = "p-tablist-active-bar";
	TabsClasses["button"] = "p-tablist-nav-button";
	TabsClasses["tabpanels"] = "p-tabpanels";
	TabsClasses["tabpanel"] = "p-tabs-panel";
})(TabsClasses || (TabsClasses = {}));
var TABS_INSTANCE = new InjectionToken("TABS_INSTANCE");
var Tabs = class Tabs extends BaseComponent {
	componentName = "Tabs";
	$pcTabs = inject(TABS_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	value = model(void 0, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	scrollable = input(false, {
		...ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	lazy = input(false, {
		...ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	selectOnFocus = input(false, {
		...ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showNavigators = input(true, {
		...ngDevMode ? { debugName: "showNavigators" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabindex = input(0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	scrollStrategy = input("nearest", ...ngDevMode ? [{ debugName: "scrollStrategy" }] : /* istanbul ignore next */ []);
	id = signal(this.$useId.next("pn_id_"), ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(TabsStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	updateValue(newValue) {
		this.value.update(() => newValue);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabs_BaseFactory = void 0;
		return function Tabs_Factory(__ngFactoryType__) {
			return (ɵTabs_BaseFactory || (ɵTabs_BaseFactory = ɵɵgetInheritedFactory(Tabs)))(__ngFactoryType__ || Tabs);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Tabs,
			selectors: [["p-tabs"]],
			hostVars: 3,
			hostBindings: function Tabs_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("id", ctx.id());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				value: [1, "value"],
				scrollable: [1, "scrollable"],
				lazy: [1, "lazy"],
				selectOnFocus: [1, "selectOnFocus"],
				showNavigators: [1, "showNavigators"],
				tabindex: [1, "tabindex"],
				scrollStrategy: [1, "scrollStrategy"]
			},
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					TabsStyle,
					{
						provide: TABS_INSTANCE,
						useExisting: Tabs
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Tabs
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function Tabs_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Tabs, [{
		type: Component,
		args: [{
			selector: "p-tabs",
			standalone: true,
			imports: [BindModule],
			template: ` <ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				TabsStyle,
				{
					provide: TABS_INSTANCE,
					useExisting: Tabs
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Tabs
				}
			],
			host: {
				"[class]": "cx(\"root\")",
				"[attr.id]": "id()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		scrollable: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "scrollable",
				required: false
			}]
		}],
		lazy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "lazy",
				required: false
			}]
		}],
		selectOnFocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "selectOnFocus",
				required: false
			}]
		}],
		showNavigators: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "showNavigators",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		scrollStrategy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "scrollStrategy",
				required: false
			}]
		}]
	});
})();
var classes$3 = { root: ({ instance }) => ["p-tab", {
	"p-tab-active": instance.active(),
	"p-disabled": instance.disabled()
}] };
var TabStyle = class TabStyle extends BaseStyle {
	name = "tab";
	classes = classes$3;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabStyle_BaseFactory = void 0;
		return function TabStyle_Factory(__ngFactoryType__) {
			return (ɵTabStyle_BaseFactory || (ɵTabStyle_BaseFactory = ɵɵgetInheritedFactory(TabStyle)))(__ngFactoryType__ || TabStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TabStyle,
		factory: TabStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabStyle, [{ type: Injectable }], null, null);
})();
var TabClasses;
(function(TabClasses) {
	TabClasses["tab"] = "p-tab";
})(TabClasses || (TabClasses = {}));
var classes$2 = {
	root: "p-tablist",
	content: "p-tablist-content",
	activeBar: "p-tablist-active-bar",
	prevButton: "p-tablist-prev-button p-tablist-nav-button",
	nextButton: "p-tablist-next-button p-tablist-nav-button"
};
var TabListStyle = class TabListStyle extends BaseStyle {
	name = "tablist";
	classes = classes$2;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabListStyle_BaseFactory = void 0;
		return function TabListStyle_Factory(__ngFactoryType__) {
			return (ɵTabListStyle_BaseFactory || (ɵTabListStyle_BaseFactory = ɵɵgetInheritedFactory(TabListStyle)))(__ngFactoryType__ || TabListStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TabListStyle,
		factory: TabListStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabListStyle, [{ type: Injectable }], null, null);
})();
var TabListClasses;
(function(TabListClasses) {
	TabListClasses["root"] = "p-tablist";
	TabListClasses["content"] = "p-tablist-content";
	TabListClasses["activeBar"] = "p-tablist-active-bar";
	TabListClasses["prevButton"] = "p-tablist-prev-button";
	TabListClasses["nextButton"] = "p-tablist-next-button";
})(TabListClasses || (TabListClasses = {}));
var TABLIST_INSTANCE = new InjectionToken("TABLIST_INSTANCE");
var TabList = class TabList extends BaseComponent {
	componentName = "TabList";
	$pcTabList = inject(TABLIST_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	prevIconTemplate = contentChild("previcon", {
		...ngDevMode ? { debugName: "prevIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	nextIconTemplate = contentChild("nexticon", {
		...ngDevMode ? { debugName: "nextIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	content = viewChild("content", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	prevButton = viewChild("prevButton", ...ngDevMode ? [{ debugName: "prevButton" }] : /* istanbul ignore next */ []);
	nextButton = viewChild("nextButton", ...ngDevMode ? [{ debugName: "nextButton" }] : /* istanbul ignore next */ []);
	inkbar = viewChild("inkbar", ...ngDevMode ? [{ debugName: "inkbar" }] : /* istanbul ignore next */ []);
	pcTabs = inject(forwardRef(() => Tabs));
	isPrevButtonEnabled = signal(false, ...ngDevMode ? [{ debugName: "isPrevButtonEnabled" }] : /* istanbul ignore next */ []);
	isNextButtonEnabled = signal(false, ...ngDevMode ? [{ debugName: "isNextButtonEnabled" }] : /* istanbul ignore next */ []);
	resizeObserver;
	showNavigators = computed(() => this.pcTabs.showNavigators(), ...ngDevMode ? [{ debugName: "showNavigators" }] : /* istanbul ignore next */ []);
	tabindex = computed(() => this.pcTabs.tabindex(), ...ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []);
	scrollable = computed(() => this.pcTabs.scrollable(), ...ngDevMode ? [{ debugName: "scrollable" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(TabListStyle);
	constructor() {
		super();
		effect(() => {
			this.pcTabs.value();
			if (isPlatformBrowser(this.platformId)) setTimeout(() => {
				this.updateInkBar();
				this.scrollToActiveTab();
			});
		});
	}
	get prevButtonAriaLabel() {
		return this.config?.translation?.aria?.previous;
	}
	get nextButtonAriaLabel() {
		return this.config?.translation?.aria?.next;
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onAfterViewInit() {
		if (this.showNavigators() && isPlatformBrowser(this.platformId)) {
			this.updateButtonState();
			this.bindResizeObserver();
		}
	}
	onDestroy() {
		this.unbindResizeObserver();
	}
	onScroll(event) {
		if (this.showNavigators()) this.updateButtonState();
		event.preventDefault();
	}
	onPrevButtonClick() {
		const _content = this.content()?.nativeElement;
		if (!_content) return;
		const width = Zt(_content);
		const pos = Math.abs(_content.scrollLeft) - width;
		const scrollLeft = pos <= 0 ? 0 : pos;
		_content.scrollLeft = q(_content) ? -1 * scrollLeft : scrollLeft;
	}
	onNextButtonClick() {
		const _content = this.content()?.nativeElement;
		if (!_content) return;
		const width = Zt(_content) - this.getVisibleButtonWidths();
		const pos = _content.scrollLeft + width;
		const lastPos = _content.scrollWidth - width;
		const scrollLeft = pos >= lastPos ? lastPos : pos;
		_content.scrollLeft = q(_content) ? -1 * scrollLeft : scrollLeft;
	}
	updateButtonState() {
		const _content = this.content()?.nativeElement;
		const _list = this.el?.nativeElement;
		if (!_content) return;
		const { scrollWidth, offsetWidth } = _content;
		const scrollLeft = Math.abs(_content.scrollLeft);
		const width = Zt(_content);
		this.isPrevButtonEnabled.set(scrollLeft !== 0);
		this.isNextButtonEnabled.set(_list.offsetWidth >= offsetWidth && Math.abs(scrollLeft - scrollWidth + width) > 1);
	}
	updateInkBar() {
		const _content = this.content()?.nativeElement;
		const _inkbar = this.inkbar()?.nativeElement;
		if (!_content || !_inkbar) return;
		const activeTab = nt(_content, "[data-pc-name=\"tab\"][data-p-active=\"true\"]");
		if (!activeTab) return;
		_inkbar.style.setProperty("--px-active-bar-width", activeTab.offsetWidth + "px");
		_inkbar.style.setProperty("--px-active-bar-height", activeTab.offsetHeight + "px");
		_inkbar.style.setProperty("--px-active-bar-left", activeTab.offsetLeft + "px");
		_inkbar.style.setProperty("--px-active-bar-top", activeTab.offsetTop + "px");
	}
	scrollToActiveTab() {
		const _content = this.content()?.nativeElement;
		const scrollStrategy = this.pcTabs.scrollStrategy();
		if (!_content || scrollStrategy === false) return;
		const activeTab = nt(_content, "[data-pc-name=\"tab\"][data-p-active=\"true\"]");
		if (!activeTab) return;
		const contentWidth = _content.clientWidth;
		const currentScrollLeft = Math.abs(_content.scrollLeft);
		const tabLeft = activeTab.offsetLeft;
		const tabWidth = activeTab.offsetWidth;
		const tabRight = tabLeft + tabWidth;
		let targetScrollLeft;
		if (scrollStrategy === "center") targetScrollLeft = tabLeft - (contentWidth - tabWidth) / 2;
		else {
			const padding = contentWidth * .1;
			if (tabLeft < currentScrollLeft + padding) targetScrollLeft = tabLeft - padding;
			else if (tabRight > currentScrollLeft + contentWidth - padding) targetScrollLeft = tabRight - contentWidth + padding;
			else return;
		}
		const maxScrollLeft = _content.scrollWidth - contentWidth;
		const clampedScrollLeft = Math.max(0, Math.min(targetScrollLeft, maxScrollLeft));
		_content.scrollTo({
			left: q(_content) ? -clampedScrollLeft : clampedScrollLeft,
			behavior: "smooth"
		});
	}
	getVisibleButtonWidths() {
		return [this.prevButton()?.nativeElement, this.nextButton()?.nativeElement].reduce((acc, el) => el ? acc + Zt(el) : acc, 0);
	}
	bindResizeObserver() {
		this.resizeObserver = new ResizeObserver(() => this.updateButtonState());
		this.resizeObserver.observe(this.el.nativeElement);
	}
	unbindResizeObserver() {
		if (this.resizeObserver) {
			this.resizeObserver.unobserve(this.el.nativeElement);
			this.resizeObserver = null;
		}
	}
	static ɵfac = function TabList_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TabList)();
	};
	static ɵcmp = (function() {
		const _c0 = ["previcon"];
		const _c1 = ["nexticon"];
		const _c2 = ["content"];
		const _c3 = ["prevButton"];
		const _c4 = ["nextButton"];
		const _c5 = ["inkbar"];
		const _c6 = ["*"];
		function TabList_Conditional_0_Conditional_2_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TabList_Conditional_0_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TabList_Conditional_0_Conditional_2_ng_container_0_Template, 1, 0, "ng-container", 9);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.prevIconTemplate());
			}
		}
		function TabList_Conditional_0_Conditional_3_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 8);
			}
		}
		function TabList_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "button", 7, 2);
				ɵɵlistener("click", function TabList_Conditional_0_Template_button_click_0_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onPrevButtonClick());
				});
				ɵɵconditionalCreate(2, TabList_Conditional_0_Conditional_2_Template, 1, 1, "ng-container")(3, TabList_Conditional_0_Conditional_3_Template, 1, 0, "svg", 8);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("prevButton"));
				ɵɵproperty("pBind", ctx_r1.ptm("prevButton"));
				ɵɵattribute("aria-label", ctx_r1.prevButtonAriaLabel)("tabindex", ctx_r1.tabindex())("data-pc-group-section", "navigator");
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.prevIconTemplate() ? 2 : 3);
			}
		}
		function TabList_Conditional_6_Conditional_2_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TabList_Conditional_6_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TabList_Conditional_6_Conditional_2_ng_container_0_Template, 1, 0, "ng-container", 9);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.nextIconTemplate());
			}
		}
		function TabList_Conditional_6_Conditional_3_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 10);
			}
		}
		function TabList_Conditional_6_Template(rf, ctx) {
			if (rf & 1) {
				const _r3 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "button", 7, 3);
				ɵɵlistener("click", function TabList_Conditional_6_Template_button_click_0_listener() {
					ɵɵrestoreView(_r3);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNextButtonClick());
				});
				ɵɵconditionalCreate(2, TabList_Conditional_6_Conditional_2_Template, 1, 1, "ng-container")(3, TabList_Conditional_6_Conditional_3_Template, 1, 0, "svg", 10);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("nextButton"));
				ɵɵproperty("pBind", ctx_r1.ptm("nextButton"));
				ɵɵattribute("aria-label", ctx_r1.nextButtonAriaLabel)("tabindex", ctx_r1.tabindex())("data-pc-group-section", "navigator");
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.nextIconTemplate() ? 2 : 3);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: TabList,
			selectors: [["p-tablist"]],
			contentQueries: function TabList_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.prevIconTemplate, _c0, 4)(dirIndex, ctx.nextIconTemplate, _c1, 4);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			viewQuery: function TabList_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.content, _c2, 5)(ctx.prevButton, _c3, 5)(ctx.nextButton, _c4, 5)(ctx.inkbar, _c5, 5);
				if (rf & 2) ɵɵqueryAdvance(4);
			},
			hostVars: 2,
			hostBindings: function TabList_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassMap(ctx.cx("root"));
			},
			features: [
				ɵɵProvidersFeature([
					TabListStyle,
					{
						provide: TABLIST_INSTANCE,
						useExisting: TabList
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: TabList
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c6,
			decls: 7,
			vars: 8,
			consts: [
				["content", ""],
				["inkbar", ""],
				["prevButton", ""],
				["nextButton", ""],
				[
					"type",
					"button",
					"pRipple",
					"",
					3,
					"pBind",
					"class"
				],
				[
					"role",
					"tablist",
					3,
					"scroll",
					"pBind"
				],
				[
					"role",
					"presentation",
					3,
					"pBind"
				],
				[
					"type",
					"button",
					"pRipple",
					"",
					3,
					"click",
					"pBind"
				],
				["data-p-icon", "chevron-left"],
				[4, "ngTemplateOutlet"],
				["data-p-icon", "chevron-right"]
			],
			template: function TabList_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵconditionalCreate(0, TabList_Conditional_0_Template, 4, 7, "button", 4);
					ɵɵelementStart(1, "div", 5, 0);
					ɵɵlistener("scroll", function TabList_Template_div_scroll_1_listener($event) {
						return ctx.onScroll($event);
					});
					ɵɵprojection(3);
					ɵɵelement(4, "span", 6, 1);
					ɵɵelementEnd();
					ɵɵconditionalCreate(6, TabList_Conditional_6_Template, 4, 7, "button", 4);
				}
				if (rf & 2) {
					ɵɵconditional(ctx.showNavigators() && ctx.isPrevButtonEnabled() ? 0 : -1);
					ɵɵadvance();
					ɵɵclassMap(ctx.cx("content"));
					ɵɵproperty("pBind", ctx.ptm("content"));
					ɵɵadvance(3);
					ɵɵclassMap(ctx.cx("activeBar"));
					ɵɵproperty("pBind", ctx.ptm("activeBar"));
					ɵɵadvance(2);
					ɵɵconditional(ctx.showNavigators() && ctx.isNextButtonEnabled() ? 6 : -1);
				}
			},
			dependencies: [
				NgTemplateOutlet,
				ChevronLeft,
				ChevronRight,
				RippleModule,
				Ripple,
				SharedModule,
				BindModule,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabList, [{
		type: Component,
		args: [{
			selector: "p-tablist",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				ChevronLeft,
				ChevronRight,
				RippleModule,
				SharedModule,
				BindModule
			],
			template: `
        @if (showNavigators() && isPrevButtonEnabled()) {
            <button
                type="button"
                #prevButton
                pRipple
                [pBind]="ptm('prevButton')"
                [class]="cx('prevButton')"
                [attr.aria-label]="prevButtonAriaLabel"
                [attr.tabindex]="tabindex()"
                [attr.data-pc-group-section]="'navigator'"
                (click)="onPrevButtonClick()"
            >
                @if (prevIconTemplate()) {
                    <ng-container *ngTemplateOutlet="prevIconTemplate()" />
                } @else {
                    <svg data-p-icon="chevron-left" />
                }
            </button>
        }
        <div #content [pBind]="ptm('content')" [class]="cx('content')" role="tablist" (scroll)="onScroll($event)">
            <ng-content />
            <span #inkbar [pBind]="ptm('activeBar')" role="presentation" [class]="cx('activeBar')"></span>
        </div>
        @if (showNavigators() && isNextButtonEnabled()) {
            <button
                type="button"
                #nextButton
                pRipple
                [pBind]="ptm('nextButton')"
                [class]="cx('nextButton')"
                [attr.aria-label]="nextButtonAriaLabel"
                [attr.tabindex]="tabindex()"
                [attr.data-pc-group-section]="'navigator'"
                (click)="onNextButtonClick()"
            >
                @if (nextIconTemplate()) {
                    <ng-container *ngTemplateOutlet="nextIconTemplate()" />
                } @else {
                    <svg data-p-icon="chevron-right" />
                }
            </button>
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: { "[class]": "cx(\"root\")" },
			providers: [
				TabListStyle,
				{
					provide: TABLIST_INSTANCE,
					useExisting: TabList
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: TabList
				}
			],
			hostDirectives: [Bind]
		}]
	}], () => [], {
		prevIconTemplate: [{
			type: ContentChild,
			args: ["previcon", {
				descendants: false,
				isSignal: true
			}]
		}],
		nextIconTemplate: [{
			type: ContentChild,
			args: ["nexticon", {
				descendants: false,
				isSignal: true
			}]
		}],
		content: [{
			type: ViewChild,
			args: ["content", { isSignal: true }]
		}],
		prevButton: [{
			type: ViewChild,
			args: ["prevButton", { isSignal: true }]
		}],
		nextButton: [{
			type: ViewChild,
			args: ["nextButton", { isSignal: true }]
		}],
		inkbar: [{
			type: ViewChild,
			args: ["inkbar", { isSignal: true }]
		}]
	});
})();
var TAB_INSTANCE = new InjectionToken("TAB_INSTANCE");
var Tab = class Tab extends BaseComponent {
	componentName = "Tab";
	$pcTab = inject(TAB_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	pcTabs = inject(forwardRef(() => Tabs));
	pcTabList = inject(forwardRef(() => TabList));
	el = inject(ElementRef);
	_componentStyle = inject(TabStyle);
	ripple = computed(() => this.config.ripple(), ...ngDevMode ? [{ debugName: "ripple" }] : /* istanbul ignore next */ []);
	id = computed(() => `${this.pcTabs.id()}_tab_${this.value()}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	ariaControls = computed(() => `${this.pcTabs.id()}_tabpanel_${this.value()}`, ...ngDevMode ? [{ debugName: "ariaControls" }] : /* istanbul ignore next */ []);
	active = computed(() => b(this.pcTabs.value(), this.value()), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	tabindex = computed(() => this.disabled() ? -1 : this.active() ? this.pcTabs.tabindex() : -1, ...ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []);
	mutationObserver;
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onFocus(event) {
		if (!this.disabled()) {
			if (this.pcTabs.selectOnFocus()) this.changeActiveValue();
		}
	}
	onClick(event) {
		if (!this.disabled()) this.changeActiveValue();
	}
	onKeyDown(event) {
		switch (event.code) {
			case "ArrowRight":
				this.onArrowRightKey(event);
				break;
			case "ArrowLeft":
				this.onArrowLeftKey(event);
				break;
			case "Home":
				this.onHomeKey(event);
				break;
			case "End":
				this.onEndKey(event);
				break;
			case "PageDown":
				this.onPageDownKey(event);
				break;
			case "PageUp":
				this.onPageUpKey(event);
				break;
			case "Enter":
			case "NumpadEnter":
			case "Space": this.onEnterKey(event);
		}
		event.stopPropagation();
	}
	onAfterViewInit() {
		this.bindMutationObserver();
	}
	onArrowRightKey(event) {
		const nextTab = this.findNextTab(event.currentTarget);
		if (nextTab) this.changeFocusedTab(nextTab);
		else this.onHomeKey(event);
		event.preventDefault();
	}
	onArrowLeftKey(event) {
		const prevTab = this.findPrevTab(event.currentTarget);
		if (prevTab) this.changeFocusedTab(prevTab);
		else this.onEndKey(event);
		event.preventDefault();
	}
	onHomeKey(event) {
		const firstTab = this.findFirstTab();
		this.changeFocusedTab(firstTab);
		event.preventDefault();
	}
	onEndKey(event) {
		const lastTab = this.findLastTab();
		this.changeFocusedTab(lastTab);
		event.preventDefault();
	}
	onPageDownKey(event) {
		this.scrollInView(this.findLastTab());
		event.preventDefault();
	}
	onPageUpKey(event) {
		this.scrollInView(this.findFirstTab());
		event.preventDefault();
	}
	onEnterKey(event) {
		if (!this.disabled()) this.changeActiveValue();
		event.preventDefault();
	}
	findNextTab(tabElement, selfCheck = false) {
		const element = selfCheck ? tabElement : tabElement?.nextElementSibling;
		return element ? it(element, "data-p-disabled") || it(element, "data-pc-section") === "activebar" ? this.findNextTab(element) : element : null;
	}
	findPrevTab(tabElement, selfCheck = false) {
		const element = selfCheck ? tabElement : tabElement?.previousElementSibling;
		return element ? it(element, "data-p-disabled") || it(element, "data-pc-section") === "activebar" ? this.findPrevTab(element) : element : null;
	}
	findFirstTab() {
		return this.findNextTab(this.pcTabList?.content()?.nativeElement?.firstElementChild, true);
	}
	findLastTab() {
		return this.findPrevTab(this.pcTabList?.content()?.nativeElement?.lastElementChild, true);
	}
	changeActiveValue() {
		this.pcTabs.updateValue(this.value());
	}
	changeFocusedTab(element) {
		if (element) Wt(element);
		this.scrollInView(element);
	}
	scrollInView(element) {
		element?.scrollIntoView?.({ block: "nearest" });
	}
	bindMutationObserver() {
		if (isPlatformBrowser(this.platformId)) {
			this.mutationObserver = new MutationObserver((mutations) => {
				mutations.forEach(() => {
					if (this.active()) this.pcTabList?.updateInkBar();
				});
			});
			this.mutationObserver.observe(this.el.nativeElement, {
				childList: true,
				characterData: true,
				subtree: true
			});
		}
	}
	unbindMutationObserver() {
		this.mutationObserver?.disconnect();
	}
	onDestroy() {
		if (this.mutationObserver) this.unbindMutationObserver();
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTab_BaseFactory = void 0;
		return function Tab_Factory(__ngFactoryType__) {
			return (ɵTab_BaseFactory || (ɵTab_BaseFactory = ɵɵgetInheritedFactory(Tab)))(__ngFactoryType__ || Tab);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Tab,
			selectors: [["p-tab"]],
			hostVars: 10,
			hostBindings: function Tab_HostBindings(rf, ctx) {
				if (rf & 1) ɵɵlistener("focus", function Tab_focus_HostBindingHandler($event) {
					return ctx.onFocus($event);
				})("click", function Tab_click_HostBindingHandler($event) {
					return ctx.onClick($event);
				})("keydown", function Tab_keydown_HostBindingHandler($event) {
					return ctx.onKeyDown($event);
				});
				if (rf & 2) {
					ɵɵattribute("id", ctx.id())("aria-controls", ctx.ariaControls())("role", "tab")("aria-selected", ctx.active())("aria-disabled", ctx.disabled())("data-p-disabled", ctx.disabled())("data-p-active", ctx.active())("tabindex", ctx.tabindex());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				value: [1, "value"],
				disabled: [1, "disabled"]
			},
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					TabStyle,
					{
						provide: TAB_INSTANCE,
						useExisting: Tab
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Tab
					}
				]),
				ɵɵHostDirectivesFeature([Ripple, Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function Tab_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [SharedModule, BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Tab, [{
		type: Component,
		args: [{
			selector: "p-tab",
			standalone: true,
			imports: [SharedModule, BindModule],
			template: ` <ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.id]": "id()",
				"[attr.aria-controls]": "ariaControls()",
				"[attr.role]": "\"tab\"",
				"[attr.aria-selected]": "active()",
				"[attr.aria-disabled]": "disabled()",
				"[attr.data-p-disabled]": "disabled()",
				"[attr.data-p-active]": "active()",
				"[attr.tabindex]": "tabindex()"
			},
			hostDirectives: [Ripple, Bind],
			providers: [
				TabStyle,
				{
					provide: TAB_INSTANCE,
					useExisting: Tab
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Tab
				}
			]
		}]
	}], null, {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		onFocus: [{
			type: HostListener,
			args: ["focus", ["$event"]]
		}],
		onClick: [{
			type: HostListener,
			args: ["click", ["$event"]]
		}],
		onKeyDown: [{
			type: HostListener,
			args: ["keydown", ["$event"]]
		}]
	});
})();
var classes$1 = { root: ({ instance }) => ["p-tabpanel", { "p-tabpanel-active": instance.active() }] };
var TabPanelStyle = class TabPanelStyle extends BaseStyle {
	name = "tabpanel";
	classes = classes$1;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabPanelStyle_BaseFactory = void 0;
		return function TabPanelStyle_Factory(__ngFactoryType__) {
			return (ɵTabPanelStyle_BaseFactory || (ɵTabPanelStyle_BaseFactory = ɵɵgetInheritedFactory(TabPanelStyle)))(__ngFactoryType__ || TabPanelStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TabPanelStyle,
		factory: TabPanelStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabPanelStyle, [{ type: Injectable }], null, null);
})();
var TabPanelClasses;
(function(TabPanelClasses) {
	TabPanelClasses["root"] = "p-tabpanel";
})(TabPanelClasses || (TabPanelClasses = {}));
var TABPANEL_INSTANCE = new InjectionToken("TABPANEL_INSTANCE");
var TabPanel = class TabPanel extends BaseComponent {
	componentName = "TabPanel";
	$pcTabPanel = inject(TABPANEL_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	pcTabs = inject(forwardRef(() => Tabs));
	lazy = input(false, {
		...ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	value = model(void 0, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	content = contentChild("content", {
		...ngDevMode ? { debugName: "content" } : /* istanbul ignore next */ {},
		descendants: false
	});
	id = computed(() => `${this.pcTabs.id()}_tabpanel_${this.value()}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	ariaLabelledby = computed(() => `${this.pcTabs.id()}_tab_${this.value()}`, ...ngDevMode ? [{ debugName: "ariaLabelledby" }] : /* istanbul ignore next */ []);
	active = computed(() => b(this.pcTabs.value(), this.value()), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	isLazyEnabled = computed(() => this.pcTabs.lazy() || this.lazy(), ...ngDevMode ? [{ debugName: "isLazyEnabled" }] : /* istanbul ignore next */ []);
	hasBeenRendered = false;
	shouldRender = computed(() => {
		if (!this.isLazyEnabled() || this.hasBeenRendered) return true;
		if (this.active()) {
			this.hasBeenRendered = true;
			return true;
		}
		return false;
	}, ...ngDevMode ? [{ debugName: "shouldRender" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(TabPanelStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabPanel_BaseFactory = void 0;
		return function TabPanel_Factory(__ngFactoryType__) {
			return (ɵTabPanel_BaseFactory || (ɵTabPanel_BaseFactory = ɵɵgetInheritedFactory(TabPanel)))(__ngFactoryType__ || TabPanel);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["content"];
		const _c1 = ["*"];
		function TabPanel_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵprojection(0);
		}
		function TabPanel_Conditional_2_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TabPanel_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TabPanel_Conditional_2_ng_container_0_Template, 1, 0, "ng-container", 1);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				const defaultContent_r2 = ɵɵreference(1);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.content() ? ctx_r0.content() : defaultContent_r2);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: TabPanel,
			selectors: [["p-tabpanel"]],
			contentQueries: function TabPanel_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.content, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 7,
			hostBindings: function TabPanel_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵdomProperty("hidden", !ctx.active());
					ɵɵattribute("id", ctx.id())("role", "tabpanel")("aria-labelledby", ctx.ariaLabelledby())("data-p-active", ctx.active());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				lazy: [1, "lazy"],
				value: [1, "value"]
			},
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					TabPanelStyle,
					{
						provide: TABPANEL_INSTANCE,
						useExisting: TabPanel
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: TabPanel
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c1,
			decls: 3,
			vars: 1,
			consts: [["defaultContent", ""], [4, "ngTemplateOutlet"]],
			template: function TabPanel_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵtemplate(0, TabPanel_ng_template_0_Template, 1, 0, "ng-template", null, 0, ɵɵtemplateRefExtractor);
					ɵɵconditionalCreate(2, TabPanel_Conditional_2_Template, 1, 1, "ng-container");
				}
				if (rf & 2) {
					ɵɵadvance(2);
					ɵɵconditional(ctx.shouldRender() ? 2 : -1);
				}
			},
			dependencies: [NgTemplateOutlet, BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabPanel, [{
		type: Component,
		args: [{
			selector: "p-tabpanel",
			standalone: true,
			imports: [NgTemplateOutlet, BindModule],
			template: `
        <ng-template #defaultContent>
            <ng-content />
        </ng-template>

        @if (shouldRender()) {
            <ng-container *ngTemplateOutlet="content() ? content() : defaultContent" />
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				TabPanelStyle,
				{
					provide: TABPANEL_INSTANCE,
					useExisting: TabPanel
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: TabPanel
				}
			],
			host: {
				"[class]": "cx(\"root\")",
				"[attr.id]": "id()",
				"[attr.role]": "\"tabpanel\"",
				"[attr.aria-labelledby]": "ariaLabelledby()",
				"[attr.data-p-active]": "active()",
				"[hidden]": "!active()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		lazy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "lazy",
				required: false
			}]
		}],
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		content: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var classes = { root: "p-tabpanels" };
var TabPanelsStyle = class TabPanelsStyle extends BaseStyle {
	name = "tabpanels";
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabPanelsStyle_BaseFactory = void 0;
		return function TabPanelsStyle_Factory(__ngFactoryType__) {
			return (ɵTabPanelsStyle_BaseFactory || (ɵTabPanelsStyle_BaseFactory = ɵɵgetInheritedFactory(TabPanelsStyle)))(__ngFactoryType__ || TabPanelsStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TabPanelsStyle,
		factory: TabPanelsStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabPanelsStyle, [{ type: Injectable }], null, null);
})();
var TabPanelsClasses;
(function(TabPanelsClasses) {
	TabPanelsClasses["root"] = "p-tabpanels";
})(TabPanelsClasses || (TabPanelsClasses = {}));
var TABPANELS_INSTANCE = new InjectionToken("TABPANELS_INSTANCE");
var TabPanels = class TabPanels extends BaseComponent {
	componentName = "TabPanels";
	$pcTabPanels = inject(TABPANELS_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	_componentStyle = inject(TabPanelsStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTabPanels_BaseFactory = void 0;
		return function TabPanels_Factory(__ngFactoryType__) {
			return (ɵTabPanels_BaseFactory || (ɵTabPanels_BaseFactory = ɵɵgetInheritedFactory(TabPanels)))(__ngFactoryType__ || TabPanels);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: TabPanels,
			selectors: [["p-tabpanels"]],
			hostVars: 3,
			hostBindings: function TabPanels_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "presentation");
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			features: [
				ɵɵProvidersFeature([
					TabPanelsStyle,
					{
						provide: TABPANELS_INSTANCE,
						useExisting: TabPanels
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: TabPanels
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function TabPanels_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabPanels, [{
		type: Component,
		args: [{
			selector: "p-tabpanels",
			standalone: true,
			imports: [BindModule],
			template: ` <ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.role]": "\"presentation\""
			},
			providers: [
				TabPanelsStyle,
				{
					provide: TABPANELS_INSTANCE,
					useExisting: TabPanels
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: TabPanels
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, null);
})();
var TabsModule = class TabsModule {
	static ɵfac = function TabsModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TabsModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: TabsModule,
		imports: [
			Tabs,
			TabPanels,
			TabPanel,
			TabList,
			Tab,
			BindModule
		],
		exports: [
			Tabs,
			TabPanels,
			TabPanel,
			TabList,
			Tab,
			BindModule
		]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Tabs,
		TabPanels,
		TabPanel,
		TabList,
		Tab,
		BindModule,
		BindModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TabsModule, [{
		type: NgModule,
		args: [{
			imports: [
				Tabs,
				TabPanels,
				TabPanel,
				TabList,
				Tab,
				BindModule
			],
			exports: [
				Tabs,
				TabPanels,
				TabPanel,
				TabList,
				Tab,
				BindModule
			]
		}]
	}], null, null);
})();
export { Tab, TabList, TabPanel, TabPanels, Tabs, TabsClasses, TabsModule, TabsStyle };
