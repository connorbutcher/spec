import { Fn as forwardRef, U as InjectionToken, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject, xn as effect } from "./_resource-chunk-ejDdmnqV.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Ps as ɵɵtextInterpolate, Ro as ɵɵlistener, Sn as Input, Ua as ɵɵdefineComponent, Wa as ɵɵdefineDirective, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, rt as numberAttribute, un as Directive, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { t as Fluid } from "./primeng-fluid-DG0dbSem.js";
import { t as Ripple } from "./primeng-ripple-BUHk2LHf.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { t as Spinner } from "./primeicons-angular-spinner-BMRKusn6.js";
import { t as AutoFocus } from "./primeng-autofocus-C_rkAfz2.js";
import { r as BadgeModule, t as Badge } from "./primeng-badge-DVBRASwf.js";
// node_modules/@primeuix/styles/dist/button/index.mjs
var style = "\n    .p-button {\n        display: inline-flex;\n        cursor: pointer;\n        user-select: none;\n        align-items: center;\n        justify-content: center;\n        overflow: hidden;\n        position: relative;\n        color: dt('button.primary.color');\n        background: dt('button.primary.background');\n        border: 1px solid dt('button.primary.border.color');\n        padding: dt('button.padding.y') dt('button.padding.x');\n        font-size: dt('button.font.size');\n        font-weight: dt('button.label.font.weight');\n        transition:\n            background dt('button.transition.duration'),\n            color dt('button.transition.duration'),\n            border-color dt('button.transition.duration'),\n            outline-color dt('button.transition.duration'),\n            box-shadow dt('button.transition.duration');\n        border-radius: dt('button.border.radius');\n        outline-color: transparent;\n        gap: dt('button.gap');\n    }\n\n    .p-button:disabled {\n        cursor: default;\n    }\n\n    .p-button-icon-right {\n        order: 1;\n    }\n\n    .p-button-icon-right:dir(rtl) {\n        order: -1;\n    }\n\n    .p-button:not(.p-button-vertical) .p-button-icon:not(.p-button-icon-right):dir(rtl) {\n        order: 1;\n    }\n\n    .p-button-icon-bottom {\n        order: 2;\n    }\n\n    .p-button-icon-only {\n        width: dt('button.icon.only.width');\n        padding-inline-start: 0;\n        padding-inline-end: 0;\n        gap: 0;\n    }\n\n    .p-button-icon-only.p-button-rounded {\n        border-radius: 50%;\n        height: dt('button.icon.only.width');\n    }\n\n    .p-button-icon-only .p-button-label {\n        visibility: hidden;\n        width: 0;\n    }\n\n    .p-button-icon-only::after {\n        content: \"\xA0\";\n        visibility: hidden;\n        width: 0;\n    }\n\n    .p-button-sm {\n        font-size: dt('button.sm.font.size');\n        padding: dt('button.sm.padding.y') dt('button.sm.padding.x');\n    }\n\n    .p-button-sm .p-button-icon {\n        font-size: dt('button.sm.font.size');\n    }\n\n    .p-button-sm.p-button-icon-only {\n        width: dt('button.sm.icon.only.width');\n    }\n\n    .p-button-sm.p-button-icon-only.p-button-rounded {\n        height: dt('button.sm.icon.only.width');\n    }\n\n    .p-button-lg {\n        font-size: dt('button.lg.font.size');\n        padding: dt('button.lg.padding.y') dt('button.lg.padding.x');\n    }\n\n    .p-button-lg .p-button-icon {\n        font-size: dt('button.lg.font.size');\n    }\n\n    .p-button-lg.p-button-icon-only {\n        width: dt('button.lg.icon.only.width');\n    }\n\n    .p-button-lg.p-button-icon-only.p-button-rounded {\n        height: dt('button.lg.icon.only.width');\n    }\n\n    .p-button-vertical {\n        flex-direction: column;\n    }\n\n    .p-button-label {\n        font-weight: dt('button.label.font.weight');\n    }\n\n    .p-button-fluid {\n        width: 100%;\n    }\n\n    .p-button-fluid.p-button-icon-only {\n        width: dt('button.icon.only.width');\n    }\n\n    .p-button:not(:disabled):hover {\n        background: dt('button.primary.hover.background');\n        border: 1px solid dt('button.primary.hover.border.color');\n        color: dt('button.primary.hover.color');\n    }\n\n    .p-button:not(:disabled):active {\n        background: dt('button.primary.active.background');\n        border: 1px solid dt('button.primary.active.border.color');\n        color: dt('button.primary.active.color');\n    }\n\n    .p-button:focus-visible {\n        box-shadow: dt('button.primary.focus.ring.shadow');\n        outline: dt('button.focus.ring.width') dt('button.focus.ring.style') dt('button.primary.focus.ring.color');\n        outline-offset: dt('button.focus.ring.offset');\n    }\n\n    .p-button .p-badge {\n        min-width: dt('button.badge.size');\n        height: dt('button.badge.size');\n        line-height: dt('button.badge.size');\n    }\n\n    .p-button-raised {\n        box-shadow: dt('button.raised.shadow');\n    }\n\n    .p-button-rounded {\n        border-radius: dt('button.rounded.border.radius');\n    }\n\n    .p-button-secondary {\n        background: dt('button.secondary.background');\n        border: 1px solid dt('button.secondary.border.color');\n        color: dt('button.secondary.color');\n    }\n\n    .p-button-secondary:not(:disabled):hover {\n        background: dt('button.secondary.hover.background');\n        border: 1px solid dt('button.secondary.hover.border.color');\n        color: dt('button.secondary.hover.color');\n    }\n\n    .p-button-secondary:not(:disabled):active {\n        background: dt('button.secondary.active.background');\n        border: 1px solid dt('button.secondary.active.border.color');\n        color: dt('button.secondary.active.color');\n    }\n\n    .p-button-secondary:focus-visible {\n        outline-color: dt('button.secondary.focus.ring.color');\n        box-shadow: dt('button.secondary.focus.ring.shadow');\n    }\n\n    .p-button-success {\n        background: dt('button.success.background');\n        border: 1px solid dt('button.success.border.color');\n        color: dt('button.success.color');\n    }\n\n    .p-button-success:not(:disabled):hover {\n        background: dt('button.success.hover.background');\n        border: 1px solid dt('button.success.hover.border.color');\n        color: dt('button.success.hover.color');\n    }\n\n    .p-button-success:not(:disabled):active {\n        background: dt('button.success.active.background');\n        border: 1px solid dt('button.success.active.border.color');\n        color: dt('button.success.active.color');\n    }\n\n    .p-button-success:focus-visible {\n        outline-color: dt('button.success.focus.ring.color');\n        box-shadow: dt('button.success.focus.ring.shadow');\n    }\n\n    .p-button-info {\n        background: dt('button.info.background');\n        border: 1px solid dt('button.info.border.color');\n        color: dt('button.info.color');\n    }\n\n    .p-button-info:not(:disabled):hover {\n        background: dt('button.info.hover.background');\n        border: 1px solid dt('button.info.hover.border.color');\n        color: dt('button.info.hover.color');\n    }\n\n    .p-button-info:not(:disabled):active {\n        background: dt('button.info.active.background');\n        border: 1px solid dt('button.info.active.border.color');\n        color: dt('button.info.active.color');\n    }\n\n    .p-button-info:focus-visible {\n        outline-color: dt('button.info.focus.ring.color');\n        box-shadow: dt('button.info.focus.ring.shadow');\n    }\n\n    .p-button-warn {\n        background: dt('button.warn.background');\n        border: 1px solid dt('button.warn.border.color');\n        color: dt('button.warn.color');\n    }\n\n    .p-button-warn:not(:disabled):hover {\n        background: dt('button.warn.hover.background');\n        border: 1px solid dt('button.warn.hover.border.color');\n        color: dt('button.warn.hover.color');\n    }\n\n    .p-button-warn:not(:disabled):active {\n        background: dt('button.warn.active.background');\n        border: 1px solid dt('button.warn.active.border.color');\n        color: dt('button.warn.active.color');\n    }\n\n    .p-button-warn:focus-visible {\n        outline-color: dt('button.warn.focus.ring.color');\n        box-shadow: dt('button.warn.focus.ring.shadow');\n    }\n\n    .p-button-help {\n        background: dt('button.help.background');\n        border: 1px solid dt('button.help.border.color');\n        color: dt('button.help.color');\n    }\n\n    .p-button-help:not(:disabled):hover {\n        background: dt('button.help.hover.background');\n        border: 1px solid dt('button.help.hover.border.color');\n        color: dt('button.help.hover.color');\n    }\n\n    .p-button-help:not(:disabled):active {\n        background: dt('button.help.active.background');\n        border: 1px solid dt('button.help.active.border.color');\n        color: dt('button.help.active.color');\n    }\n\n    .p-button-help:focus-visible {\n        outline-color: dt('button.help.focus.ring.color');\n        box-shadow: dt('button.help.focus.ring.shadow');\n    }\n\n    .p-button-danger {\n        background: dt('button.danger.background');\n        border: 1px solid dt('button.danger.border.color');\n        color: dt('button.danger.color');\n    }\n\n    .p-button-danger:not(:disabled):hover {\n        background: dt('button.danger.hover.background');\n        border: 1px solid dt('button.danger.hover.border.color');\n        color: dt('button.danger.hover.color');\n    }\n\n    .p-button-danger:not(:disabled):active {\n        background: dt('button.danger.active.background');\n        border: 1px solid dt('button.danger.active.border.color');\n        color: dt('button.danger.active.color');\n    }\n\n    .p-button-danger:focus-visible {\n        outline-color: dt('button.danger.focus.ring.color');\n        box-shadow: dt('button.danger.focus.ring.shadow');\n    }\n\n    .p-button-contrast {\n        background: dt('button.contrast.background');\n        border: 1px solid dt('button.contrast.border.color');\n        color: dt('button.contrast.color');\n    }\n\n    .p-button-contrast:not(:disabled):hover {\n        background: dt('button.contrast.hover.background');\n        border: 1px solid dt('button.contrast.hover.border.color');\n        color: dt('button.contrast.hover.color');\n    }\n\n    .p-button-contrast:not(:disabled):active {\n        background: dt('button.contrast.active.background');\n        border: 1px solid dt('button.contrast.active.border.color');\n        color: dt('button.contrast.active.color');\n    }\n\n    .p-button-contrast:focus-visible {\n        outline-color: dt('button.contrast.focus.ring.color');\n        box-shadow: dt('button.contrast.focus.ring.shadow');\n    }\n\n    .p-button-outlined {\n        background: transparent;\n        border-color: dt('button.outlined.primary.border.color');\n        color: dt('button.outlined.primary.color');\n    }\n\n    .p-button-outlined:not(:disabled):hover {\n        background: dt('button.outlined.primary.hover.background');\n        border-color: dt('button.outlined.primary.border.color');\n        color: dt('button.outlined.primary.color');\n    }\n\n    .p-button-outlined:not(:disabled):active {\n        background: dt('button.outlined.primary.active.background');\n        border-color: dt('button.outlined.primary.border.color');\n        color: dt('button.outlined.primary.color');\n    }\n\n    .p-button-outlined.p-button-secondary {\n        border-color: dt('button.outlined.secondary.border.color');\n        color: dt('button.outlined.secondary.color');\n    }\n\n    .p-button-outlined.p-button-secondary:not(:disabled):hover {\n        background: dt('button.outlined.secondary.hover.background');\n        border-color: dt('button.outlined.secondary.border.color');\n        color: dt('button.outlined.secondary.color');\n    }\n\n    .p-button-outlined.p-button-secondary:not(:disabled):active {\n        background: dt('button.outlined.secondary.active.background');\n        border-color: dt('button.outlined.secondary.border.color');\n        color: dt('button.outlined.secondary.color');\n    }\n\n    .p-button-outlined.p-button-success {\n        border-color: dt('button.outlined.success.border.color');\n        color: dt('button.outlined.success.color');\n    }\n\n    .p-button-outlined.p-button-success:not(:disabled):hover {\n        background: dt('button.outlined.success.hover.background');\n        border-color: dt('button.outlined.success.border.color');\n        color: dt('button.outlined.success.color');\n    }\n\n    .p-button-outlined.p-button-success:not(:disabled):active {\n        background: dt('button.outlined.success.active.background');\n        border-color: dt('button.outlined.success.border.color');\n        color: dt('button.outlined.success.color');\n    }\n\n    .p-button-outlined.p-button-info {\n        border-color: dt('button.outlined.info.border.color');\n        color: dt('button.outlined.info.color');\n    }\n\n    .p-button-outlined.p-button-info:not(:disabled):hover {\n        background: dt('button.outlined.info.hover.background');\n        border-color: dt('button.outlined.info.border.color');\n        color: dt('button.outlined.info.color');\n    }\n\n    .p-button-outlined.p-button-info:not(:disabled):active {\n        background: dt('button.outlined.info.active.background');\n        border-color: dt('button.outlined.info.border.color');\n        color: dt('button.outlined.info.color');\n    }\n\n    .p-button-outlined.p-button-warn {\n        border-color: dt('button.outlined.warn.border.color');\n        color: dt('button.outlined.warn.color');\n    }\n\n    .p-button-outlined.p-button-warn:not(:disabled):hover {\n        background: dt('button.outlined.warn.hover.background');\n        border-color: dt('button.outlined.warn.border.color');\n        color: dt('button.outlined.warn.color');\n    }\n\n    .p-button-outlined.p-button-warn:not(:disabled):active {\n        background: dt('button.outlined.warn.active.background');\n        border-color: dt('button.outlined.warn.border.color');\n        color: dt('button.outlined.warn.color');\n    }\n\n    .p-button-outlined.p-button-help {\n        border-color: dt('button.outlined.help.border.color');\n        color: dt('button.outlined.help.color');\n    }\n\n    .p-button-outlined.p-button-help:not(:disabled):hover {\n        background: dt('button.outlined.help.hover.background');\n        border-color: dt('button.outlined.help.border.color');\n        color: dt('button.outlined.help.color');\n    }\n\n    .p-button-outlined.p-button-help:not(:disabled):active {\n        background: dt('button.outlined.help.active.background');\n        border-color: dt('button.outlined.help.border.color');\n        color: dt('button.outlined.help.color');\n    }\n\n    .p-button-outlined.p-button-danger {\n        border-color: dt('button.outlined.danger.border.color');\n        color: dt('button.outlined.danger.color');\n    }\n\n    .p-button-outlined.p-button-danger:not(:disabled):hover {\n        background: dt('button.outlined.danger.hover.background');\n        border-color: dt('button.outlined.danger.border.color');\n        color: dt('button.outlined.danger.color');\n    }\n\n    .p-button-outlined.p-button-danger:not(:disabled):active {\n        background: dt('button.outlined.danger.active.background');\n        border-color: dt('button.outlined.danger.border.color');\n        color: dt('button.outlined.danger.color');\n    }\n\n    .p-button-outlined.p-button-contrast {\n        border-color: dt('button.outlined.contrast.border.color');\n        color: dt('button.outlined.contrast.color');\n    }\n\n    .p-button-outlined.p-button-contrast:not(:disabled):hover {\n        background: dt('button.outlined.contrast.hover.background');\n        border-color: dt('button.outlined.contrast.border.color');\n        color: dt('button.outlined.contrast.color');\n    }\n\n    .p-button-outlined.p-button-contrast:not(:disabled):active {\n        background: dt('button.outlined.contrast.active.background');\n        border-color: dt('button.outlined.contrast.border.color');\n        color: dt('button.outlined.contrast.color');\n    }\n\n    .p-button-outlined.p-button-plain {\n        border-color: dt('button.outlined.plain.border.color');\n        color: dt('button.outlined.plain.color');\n    }\n\n    .p-button-outlined.p-button-plain:not(:disabled):hover {\n        background: dt('button.outlined.plain.hover.background');\n        border-color: dt('button.outlined.plain.border.color');\n        color: dt('button.outlined.plain.color');\n    }\n\n    .p-button-outlined.p-button-plain:not(:disabled):active {\n        background: dt('button.outlined.plain.active.background');\n        border-color: dt('button.outlined.plain.border.color');\n        color: dt('button.outlined.plain.color');\n    }\n\n    .p-button-text {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.primary.color');\n    }\n\n    .p-button-text:not(:disabled):hover {\n        background: dt('button.text.primary.hover.background');\n        border-color: transparent;\n        color: dt('button.text.primary.color');\n    }\n\n    .p-button-text:not(:disabled):active {\n        background: dt('button.text.primary.active.background');\n        border-color: transparent;\n        color: dt('button.text.primary.color');\n    }\n\n    .p-button-text.p-button-secondary {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.secondary.color');\n    }\n\n    .p-button-text.p-button-secondary:not(:disabled):hover {\n        background: dt('button.text.secondary.hover.background');\n        border-color: transparent;\n        color: dt('button.text.secondary.color');\n    }\n\n    .p-button-text.p-button-secondary:not(:disabled):active {\n        background: dt('button.text.secondary.active.background');\n        border-color: transparent;\n        color: dt('button.text.secondary.color');\n    }\n\n    .p-button-text.p-button-success {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.success.color');\n    }\n\n    .p-button-text.p-button-success:not(:disabled):hover {\n        background: dt('button.text.success.hover.background');\n        border-color: transparent;\n        color: dt('button.text.success.color');\n    }\n\n    .p-button-text.p-button-success:not(:disabled):active {\n        background: dt('button.text.success.active.background');\n        border-color: transparent;\n        color: dt('button.text.success.color');\n    }\n\n    .p-button-text.p-button-info {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.info.color');\n    }\n\n    .p-button-text.p-button-info:not(:disabled):hover {\n        background: dt('button.text.info.hover.background');\n        border-color: transparent;\n        color: dt('button.text.info.color');\n    }\n\n    .p-button-text.p-button-info:not(:disabled):active {\n        background: dt('button.text.info.active.background');\n        border-color: transparent;\n        color: dt('button.text.info.color');\n    }\n\n    .p-button-text.p-button-warn {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.warn.color');\n    }\n\n    .p-button-text.p-button-warn:not(:disabled):hover {\n        background: dt('button.text.warn.hover.background');\n        border-color: transparent;\n        color: dt('button.text.warn.color');\n    }\n\n    .p-button-text.p-button-warn:not(:disabled):active {\n        background: dt('button.text.warn.active.background');\n        border-color: transparent;\n        color: dt('button.text.warn.color');\n    }\n\n    .p-button-text.p-button-help {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.help.color');\n    }\n\n    .p-button-text.p-button-help:not(:disabled):hover {\n        background: dt('button.text.help.hover.background');\n        border-color: transparent;\n        color: dt('button.text.help.color');\n    }\n\n    .p-button-text.p-button-help:not(:disabled):active {\n        background: dt('button.text.help.active.background');\n        border-color: transparent;\n        color: dt('button.text.help.color');\n    }\n\n    .p-button-text.p-button-danger {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.danger.color');\n    }\n\n    .p-button-text.p-button-danger:not(:disabled):hover {\n        background: dt('button.text.danger.hover.background');\n        border-color: transparent;\n        color: dt('button.text.danger.color');\n    }\n\n    .p-button-text.p-button-danger:not(:disabled):active {\n        background: dt('button.text.danger.active.background');\n        border-color: transparent;\n        color: dt('button.text.danger.color');\n    }\n\n    .p-button-text.p-button-contrast {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.contrast.color');\n    }\n\n    .p-button-text.p-button-contrast:not(:disabled):hover {\n        background: dt('button.text.contrast.hover.background');\n        border-color: transparent;\n        color: dt('button.text.contrast.color');\n    }\n\n    .p-button-text.p-button-contrast:not(:disabled):active {\n        background: dt('button.text.contrast.active.background');\n        border-color: transparent;\n        color: dt('button.text.contrast.color');\n    }\n\n    .p-button-text.p-button-plain {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.text.plain.color');\n    }\n\n    .p-button-text.p-button-plain:not(:disabled):hover {\n        background: dt('button.text.plain.hover.background');\n        border-color: transparent;\n        color: dt('button.text.plain.color');\n    }\n\n    .p-button-text.p-button-plain:not(:disabled):active {\n        background: dt('button.text.plain.active.background');\n        border-color: transparent;\n        color: dt('button.text.plain.color');\n    }\n\n    .p-button-link {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.link.color');\n    }\n\n    .p-button-link:not(:disabled):hover {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.link.hover.color');\n    }\n\n    .p-button-link:not(:disabled):hover .p-button-label {\n        text-decoration: underline;\n    }\n\n    .p-button-link:not(:disabled):active {\n        background: transparent;\n        border-color: transparent;\n        color: dt('button.link.active.color');\n    }\n";
// node_modules/primeng/fesm2022/primeng-button.mjs
var classes = {
	root: ({ instance }) => {
		const hasIcon = instance.hasIcon();
		const label = instance.label();
		const buttonProps = instance.buttonProps();
		const loading = instance.loading();
		const link = instance.link();
		const severity = instance.severity();
		const raised = instance.raised();
		const rounded = instance.rounded();
		const text = instance.text();
		const variant = instance.variant();
		const outlined = instance.outlined();
		const size = instance.size();
		const plain = instance.plain();
		const badge = instance.badge();
		const hasFluid = instance.hasFluid();
		const iconPos = instance.iconPos();
		return ["p-button p-component", {
			"p-button-icon-only": hasIcon && !label && !buttonProps?.label && !badge,
			"p-button-vertical": (iconPos === "top" || iconPos === "bottom") && label,
			"p-button-loading": loading || buttonProps?.loading,
			"p-button-link": link || buttonProps?.link,
			[`p-button-${severity || buttonProps?.severity}`]: severity || buttonProps?.severity,
			"p-button-raised": raised || buttonProps?.raised,
			"p-button-rounded": rounded || buttonProps?.rounded,
			"p-button-text": text || variant === "text" || buttonProps?.text || buttonProps?.variant === "text",
			"p-button-outlined": outlined || variant === "outlined" || buttonProps?.outlined || buttonProps?.variant === "outlined",
			"p-button-sm": size === "small" || buttonProps?.size === "small",
			"p-button-lg": size === "large" || buttonProps?.size === "large",
			"p-button-plain": plain || buttonProps?.plain,
			"p-button-fluid": hasFluid
		}];
	},
	loadingIcon: "p-button-loading-icon",
	icon: ({ instance }) => {
		const iconPos = instance.iconPos();
		const buttonProps = instance.buttonProps();
		const label = instance.label();
		return ["p-button-icon", {
			[`p-button-icon-${iconPos || buttonProps?.iconPos}`]: label || buttonProps?.label,
			"p-button-icon-left": (iconPos === "left" || buttonProps?.iconPos === "left") && label || buttonProps?.label,
			"p-button-icon-right": (iconPos === "right" || buttonProps?.iconPos === "right") && label || buttonProps?.label,
			"p-button-icon-top": (iconPos === "top" || buttonProps?.iconPos === "top") && label || buttonProps?.label,
			"p-button-icon-bottom": (iconPos === "bottom" || buttonProps?.iconPos === "bottom") && label || buttonProps?.label
		}];
	},
	spinnerIcon: ({ instance }) => Object.entries(instance.cx("icon")).filter(([, value]) => !!value).reduce((acc, [key]) => acc + ` ${key}`, "p-button-loading-icon"),
	label: "p-button-label"
};
var ButtonStyle = class ButtonStyle extends BaseStyle {
	name = "button";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵButtonStyle_BaseFactory = void 0;
		return function ButtonStyle_Factory(__ngFactoryType__) {
			return (ɵButtonStyle_BaseFactory || (ɵButtonStyle_BaseFactory = ɵɵgetInheritedFactory(ButtonStyle)))(__ngFactoryType__ || ButtonStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: ButtonStyle,
		factory: ButtonStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonStyle, [{ type: Injectable }], null, null);
})();
var ButtonClasses;
(function(ButtonClasses) {
	ButtonClasses["root"] = "p-button";
	ButtonClasses["loadingIcon"] = "p-button-loading-icon";
	ButtonClasses["icon"] = "p-button-icon";
	ButtonClasses["label"] = "p-button-label";
})(ButtonClasses || (ButtonClasses = {}));
var BUTTON_INSTANCE = new InjectionToken("BUTTON_INSTANCE");
var Button = class Button extends BaseComponent {
	componentName = "Button";
	hostName = input("", ...ngDevMode ? [{ debugName: "hostName" }] : /* istanbul ignore next */ []);
	$pcButton = inject(BUTTON_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	_componentStyle = inject(ButtonStyle);
	type = input("button", ...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	badge = input(...ngDevMode ? [void 0, { debugName: "badge" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	raised = input(false, {
		...ngDevMode ? { debugName: "raised" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rounded = input(false, {
		...ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	text = input(false, {
		...ngDevMode ? { debugName: "text" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	plain = input(false, {
		...ngDevMode ? { debugName: "plain" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	outlined = input(false, {
		...ngDevMode ? { debugName: "outlined" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	link = input(false, {
		...ngDevMode ? { debugName: "link" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabindex = input(0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	style = input(...ngDevMode ? [void 0, { debugName: "style" }] : /* istanbul ignore next */ []);
	styleClass = input(...ngDevMode ? [void 0, { debugName: "styleClass" }] : /* istanbul ignore next */ []);
	badgeSeverity = input("secondary", ...ngDevMode ? [{ debugName: "badgeSeverity" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	autofocus = input(false, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	iconPos = input("left", ...ngDevMode ? [{ debugName: "iconPos" }] : /* istanbul ignore next */ []);
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loadingIcon = input(...ngDevMode ? [void 0, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []);
	severity = input(...ngDevMode ? [void 0, { debugName: "severity" }] : /* istanbul ignore next */ []);
	buttonProps = input(...ngDevMode ? [void 0, { debugName: "buttonProps" }] : /* istanbul ignore next */ []);
	fluid = input(void 0, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	iconOnly = input(false, {
		...ngDevMode ? { debugName: "iconOnly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	onClick = output();
	onFocus = output();
	onBlur = output();
	contentTemplate = contentChild("content", {
		...ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	loadingIconTemplate = contentChild("loadingicon", {
		...ngDevMode ? { debugName: "loadingIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	iconTemplate = contentChild("icon", {
		...ngDevMode ? { debugName: "iconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	pcFluid = inject(Fluid, {
		optional: true,
		host: true,
		skipSelf: true
	});
	hasFluid = computed(() => this.fluid() ?? !!this.pcFluid, ...ngDevMode ? [{ debugName: "hasFluid" }] : /* istanbul ignore next */ []);
	$type = computed(() => this.type() || this.buttonProps()?.type, ...ngDevMode ? [{ debugName: "$type" }] : /* istanbul ignore next */ []);
	$ariaLabel = computed(() => this.ariaLabel() || this.buttonProps()?.ariaLabel, ...ngDevMode ? [{ debugName: "$ariaLabel" }] : /* istanbul ignore next */ []);
	mergedStyle = computed(() => this.style() || this.buttonProps()?.style, ...ngDevMode ? [{ debugName: "mergedStyle" }] : /* istanbul ignore next */ []);
	$disabled = computed(() => this.disabled() || this.loading() || this.buttonProps()?.disabled, ...ngDevMode ? [{ debugName: "$disabled" }] : /* istanbul ignore next */ []);
	$severity = computed(() => this.severity() || this.buttonProps()?.severity, ...ngDevMode ? [{ debugName: "$severity" }] : /* istanbul ignore next */ []);
	$tabindex = computed(() => this.tabindex() || this.buttonProps()?.tabindex, ...ngDevMode ? [{ debugName: "$tabindex" }] : /* istanbul ignore next */ []);
	$autofocus = computed(() => this.autofocus() || this.buttonProps()?.autofocus, ...ngDevMode ? [{ debugName: "$autofocus" }] : /* istanbul ignore next */ []);
	$loading = computed(() => this.loading() || this.buttonProps()?.loading, ...ngDevMode ? [{ debugName: "$loading" }] : /* istanbul ignore next */ []);
	$icon = computed(() => this.icon() || this.buttonProps()?.icon, ...ngDevMode ? [{ debugName: "$icon" }] : /* istanbul ignore next */ []);
	$label = computed(() => this.label() || this.buttonProps()?.label, ...ngDevMode ? [{ debugName: "$label" }] : /* istanbul ignore next */ []);
	$badge = computed(() => this.badge() || this.buttonProps()?.badge, ...ngDevMode ? [{ debugName: "$badge" }] : /* istanbul ignore next */ []);
	$loadingIcon = computed(() => this.loadingIcon() || this.buttonProps()?.loadingIcon, ...ngDevMode ? [{ debugName: "$loadingIcon" }] : /* istanbul ignore next */ []);
	$badgeSeverity = computed(() => this.badgeSeverity() || this.buttonProps()?.badgeSeverity, ...ngDevMode ? [{ debugName: "$badgeSeverity" }] : /* istanbul ignore next */ []);
	showLabel = computed(() => !this.contentTemplate() && this.$label(), ...ngDevMode ? [{ debugName: "showLabel" }] : /* istanbul ignore next */ []);
	showBadge = computed(() => !this.contentTemplate() && this.$badge(), ...ngDevMode ? [{ debugName: "showBadge" }] : /* istanbul ignore next */ []);
	hasIcon = computed(() => this.$icon() || this.iconTemplate() || this.loadingIcon() || this.loadingIconTemplate(), ...ngDevMode ? [{ debugName: "hasIcon" }] : /* istanbul ignore next */ []);
	$outlined = computed(() => this.outlined() || this.variant() === "outlined" || this.buttonProps()?.outlined || this.buttonProps()?.variant === "outlined", ...ngDevMode ? [{ debugName: "$outlined" }] : /* istanbul ignore next */ []);
	$text = computed(() => this.text() || this.variant() === "text" || this.buttonProps()?.text || this.buttonProps()?.variant === "text", ...ngDevMode ? [{ debugName: "$text" }] : /* istanbul ignore next */ []);
	$iconOnly = computed(() => this.iconOnly() || this.hasIcon() && !this.$label() && !this.$badge(), ...ngDevMode ? [{ debugName: "$iconOnly" }] : /* istanbul ignore next */ []);
	dataP = computed(() => this.cn({
		[this.size()]: this.size(),
		"icon-only": this.$iconOnly(),
		loading: this.$loading(),
		fluid: this.hasFluid(),
		rounded: this.rounded(),
		raised: this.raised(),
		outlined: this.$outlined(),
		text: this.$text(),
		link: this.link(),
		vertical: (this.iconPos() === "top" || this.iconPos() === "bottom") && this.$label()
	}), ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	dataIconP = computed(() => this.cn({
		[this.iconPos()]: this.iconPos(),
		[this.size()]: this.size()
	}), ...ngDevMode ? [{ debugName: "dataIconP" }] : /* istanbul ignore next */ []);
	dataLabelP = computed(() => this.cn({
		[this.size()]: this.size(),
		"icon-only": this.$iconOnly()
	}), ...ngDevMode ? [{ debugName: "dataLabelP" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptm("host"));
	}
	getLoadingIconTemplateContext() {
		return {
			class: this.cx("loadingIcon"),
			pt: this.ptm("loadingIcon")
		};
	}
	getIconTemplateContext() {
		const iconClass = this.cx("icon");
		return {
			class: iconClass && this.cn(iconClass, this.$icon()),
			pt: this.ptm("icon")
		};
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵButton_BaseFactory = void 0;
		return function Button_Factory(__ngFactoryType__) {
			return (ɵButton_BaseFactory || (ɵButton_BaseFactory = ɵɵgetInheritedFactory(Button)))(__ngFactoryType__ || Button);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["content"];
		const _c1 = ["loadingicon"];
		const _c2 = ["icon"];
		const _c3 = ["*"];
		function Button_ng_container_2_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Button_Conditional_3_Conditional_0_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 5);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("loadingIcon"), "pi-spin", ctx_r0.$loadingIcon()));
				ɵɵproperty("pBind", ctx_r0.ptm("loadingIcon"));
				ɵɵattribute("aria-hidden", true);
			}
		}
		function Button_Conditional_3_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 6);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("loadingIcon"), ctx_r0.cx("spinnerIcon")));
				ɵɵproperty("spin", true)("pBind", ctx_r0.ptm("loadingIcon"));
				ɵɵattribute("aria-hidden", true);
			}
		}
		function Button_Conditional_3_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Button_Conditional_3_Conditional_0_Conditional_0_Template, 1, 4, "span", 2)(1, Button_Conditional_3_Conditional_0_Conditional_1_Template, 1, 5, "svg", 4);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵconditional(ctx_r0.$loadingIcon() ? 0 : 1);
			}
		}
		function Button_Conditional_3_Conditional_1_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Button_Conditional_3_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Button_Conditional_3_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 7);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.loadingIconTemplate())("ngTemplateOutletContext", ctx_r0.getLoadingIconTemplateContext());
			}
		}
		function Button_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Button_Conditional_3_Conditional_0_Template, 2, 1)(1, Button_Conditional_3_Conditional_1_Template, 1, 2, "ng-container");
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(!ctx_r0.loadingIconTemplate() ? 0 : 1);
			}
		}
		function Button_Conditional_4_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 5);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("icon"), ctx_r0.$icon()));
				ɵɵproperty("pBind", ctx_r0.ptm("icon"));
				ɵɵattribute("data-p", ctx_r0.dataIconP());
			}
		}
		function Button_Conditional_4_Conditional_1_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Button_Conditional_4_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Button_Conditional_4_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 7);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.iconTemplate())("ngTemplateOutletContext", ctx_r0.getIconTemplateContext());
			}
		}
		function Button_Conditional_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, Button_Conditional_4_Conditional_0_Template, 1, 4, "span", 2);
				ɵɵconditionalCreate(1, Button_Conditional_4_Conditional_1_Template, 1, 2, "ng-container");
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(ctx_r0.$icon() && !ctx_r0.iconTemplate() ? 0 : -1);
				ɵɵadvance();
				ɵɵconditional(!ctx_r0.icon() && ctx_r0.iconTemplate() ? 1 : -1);
			}
		}
		function Button_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 5);
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵclassMap(ctx_r0.cx("label"));
				ɵɵproperty("pBind", ctx_r0.ptm("label"));
				ɵɵattribute("aria-hidden", ctx_r0.$icon() && !ctx_r0.$label())("data-p", ctx_r0.dataLabelP());
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r0.$label());
			}
		}
		function Button_Conditional_6_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-badge", 3);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵproperty("value", ctx_r0.$badge())("severity", ctx_r0.$badgeSeverity())("pt", ctx_r0.ptm("pcBadge"))("unstyled", ctx_r0.unstyled());
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Button,
			selectors: [["p-button"]],
			contentQueries: function Button_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.contentTemplate, _c0, 4)(dirIndex, ctx.loadingIconTemplate, _c1, 4)(dirIndex, ctx.iconTemplate, _c2, 4);
				if (rf & 2) ɵɵqueryAdvance(3);
			},
			inputs: {
				hostName: [1, "hostName"],
				type: [1, "type"],
				badge: [1, "badge"],
				disabled: [1, "disabled"],
				raised: [1, "raised"],
				rounded: [1, "rounded"],
				text: [1, "text"],
				plain: [1, "plain"],
				outlined: [1, "outlined"],
				link: [1, "link"],
				tabindex: [1, "tabindex"],
				size: [1, "size"],
				variant: [1, "variant"],
				style: [1, "style"],
				styleClass: [1, "styleClass"],
				badgeSeverity: [1, "badgeSeverity"],
				ariaLabel: [1, "ariaLabel"],
				autofocus: [1, "autofocus"],
				iconPos: [1, "iconPos"],
				icon: [1, "icon"],
				label: [1, "label"],
				loading: [1, "loading"],
				loadingIcon: [1, "loadingIcon"],
				severity: [1, "severity"],
				buttonProps: [1, "buttonProps"],
				fluid: [1, "fluid"],
				iconOnly: [1, "iconOnly"]
			},
			outputs: {
				onClick: "onClick",
				onFocus: "onFocus",
				onBlur: "onBlur"
			},
			features: [
				ɵɵProvidersFeature([
					ButtonStyle,
					{
						provide: BUTTON_INSTANCE,
						useExisting: Button
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Button
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c3,
			decls: 7,
			vars: 18,
			consts: [
				[
					"pRipple",
					"",
					3,
					"click",
					"focus",
					"blur",
					"disabled",
					"pAutoFocus",
					"pBind"
				],
				[4, "ngTemplateOutlet"],
				[
					3,
					"class",
					"pBind"
				],
				[
					3,
					"value",
					"severity",
					"pt",
					"unstyled"
				],
				[
					"data-p-icon",
					"spinner",
					3,
					"class",
					"spin",
					"pBind"
				],
				[3, "pBind"],
				[
					"data-p-icon",
					"spinner",
					3,
					"spin",
					"pBind"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				]
			],
			template: function Button_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵelementStart(0, "button", 0);
					ɵɵlistener("click", function Button_Template_button_click_0_listener($event) {
						return ctx.onClick.emit($event);
					})("focus", function Button_Template_button_focus_0_listener($event) {
						return ctx.onFocus.emit($event);
					})("blur", function Button_Template_button_blur_0_listener($event) {
						return ctx.onBlur.emit($event);
					});
					ɵɵprojection(1);
					ɵɵtemplate(2, Button_ng_container_2_Template, 1, 0, "ng-container", 1);
					ɵɵconditionalCreate(3, Button_Conditional_3_Template, 2, 1);
					ɵɵconditionalCreate(4, Button_Conditional_4_Template, 2, 2);
					ɵɵconditionalCreate(5, Button_Conditional_5_Template, 2, 6, "span", 2);
					ɵɵconditionalCreate(6, Button_Conditional_6_Template, 1, 4, "p-badge", 3);
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵstyleMap(ctx.mergedStyle());
					ɵɵclassMap(ctx.cn(ctx.cx("root"), ctx.styleClass(), ctx.buttonProps()?.styleClass));
					ɵɵproperty("disabled", ctx.$disabled())("pAutoFocus", ctx.$autofocus())("pBind", ctx.ptm("root"));
					ɵɵattribute("type", ctx.$type())("aria-label", ctx.$ariaLabel())("tabindex", ctx.$tabindex())("data-p", ctx.dataP())("data-p-disabled", ctx.$disabled())("data-p-severity", ctx.$severity());
					ɵɵadvance(2);
					ɵɵproperty("ngTemplateOutlet", ctx.contentTemplate());
					ɵɵadvance();
					ɵɵconditional(ctx.$loading() ? 3 : -1);
					ɵɵadvance();
					ɵɵconditional(!ctx.$loading() ? 4 : -1);
					ɵɵadvance();
					ɵɵconditional(ctx.showLabel() ? 5 : -1);
					ɵɵadvance();
					ɵɵconditional(ctx.showBadge() ? 6 : -1);
				}
			},
			dependencies: [
				NgTemplateOutlet,
				Ripple,
				AutoFocus,
				Spinner,
				BadgeModule,
				Badge,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Button, [{
		type: Component,
		args: [{
			selector: "p-button",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				Ripple,
				AutoFocus,
				Spinner,
				BadgeModule,
				Bind
			],
			template: `
        <button
            [attr.type]="$type()"
            [attr.aria-label]="$ariaLabel()"
            [style]="mergedStyle()"
            [disabled]="$disabled()"
            [class]="cn(cx('root'), styleClass(), buttonProps()?.styleClass)"
            (click)="onClick.emit($event)"
            (focus)="onFocus.emit($event)"
            (blur)="onBlur.emit($event)"
            pRipple
            [attr.tabindex]="$tabindex()"
            [pAutoFocus]="$autofocus()"
            [pBind]="ptm('root')"
            [attr.data-p]="dataP()"
            [attr.data-p-disabled]="$disabled()"
            [attr.data-p-severity]="$severity()"
        >
            <ng-content />
            <ng-container *ngTemplateOutlet="contentTemplate()" />
            @if ($loading()) {
                @if (!loadingIconTemplate()) {
                    @if ($loadingIcon()) {
                        <span [class]="cn(cx('loadingIcon'), 'pi-spin', $loadingIcon())" [pBind]="ptm('loadingIcon')" [attr.aria-hidden]="true"></span>
                    } @else {
                        <svg data-p-icon="spinner" [class]="cn(cx('loadingIcon'), cx('spinnerIcon'))" [spin]="true" [pBind]="ptm('loadingIcon')" [attr.aria-hidden]="true" />
                    }
                } @else {
                    <ng-container *ngTemplateOutlet="loadingIconTemplate(); context: getLoadingIconTemplateContext()" />
                }
            }
            @if (!$loading()) {
                @if ($icon() && !iconTemplate()) {
                    <span [class]="cn(cx('icon'), $icon())" [pBind]="ptm('icon')" [attr.data-p]="dataIconP()"></span>
                }
                @if (!icon() && iconTemplate()) {
                    <ng-container *ngTemplateOutlet="iconTemplate(); context: getIconTemplateContext()" />
                }
            }
            @if (showLabel()) {
                <span [class]="cx('label')" [attr.aria-hidden]="$icon() && !$label()" [pBind]="ptm('label')" [attr.data-p]="dataLabelP()">{{ $label() }}</span>
            }
            @if (showBadge()) {
                <p-badge [value]="$badge()" [severity]="$badgeSeverity()" [pt]="ptm('pcBadge')" [unstyled]="unstyled()" />
            }
        </button>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				ButtonStyle,
				{
					provide: BUTTON_INSTANCE,
					useExisting: Button
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Button
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, {
		hostName: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "hostName",
				required: false
			}]
		}],
		type: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "type",
				required: false
			}]
		}],
		badge: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "badge",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		raised: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "raised",
				required: false
			}]
		}],
		rounded: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		text: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		plain: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		outlined: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "outlined",
				required: false
			}]
		}],
		link: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "link",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		variant: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		style: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "style",
				required: false
			}]
		}],
		styleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "styleClass",
				required: false
			}]
		}],
		badgeSeverity: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "badgeSeverity",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		autofocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		iconPos: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "iconPos",
				required: false
			}]
		}],
		icon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		label: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		loading: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		loadingIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loadingIcon",
				required: false
			}]
		}],
		severity: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "severity",
				required: false
			}]
		}],
		buttonProps: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "buttonProps",
				required: false
			}]
		}],
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		iconOnly: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "iconOnly",
				required: false
			}]
		}],
		onClick: [{
			type: Output,
			args: ["onClick"]
		}],
		onFocus: [{
			type: Output,
			args: ["onFocus"]
		}],
		onBlur: [{
			type: Output,
			args: ["onBlur"]
		}],
		contentTemplate: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}],
		loadingIconTemplate: [{
			type: ContentChild,
			args: ["loadingicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		iconTemplate: [{
			type: ContentChild,
			args: ["icon", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var BUTTON_ICON_INSTANCE = new InjectionToken("BUTTON_ICON_INSTANCE");
var ButtonIcon = class ButtonIcon extends BaseComponent {
	componentName = "ButtonIcon";
	pButtonIconPT = input(...ngDevMode ? [void 0, { debugName: "pButtonIconPT" }] : /* istanbul ignore next */ []);
	pButtonUnstyled = input(...ngDevMode ? [void 0, { debugName: "pButtonUnstyled" }] : /* istanbul ignore next */ []);
	$pcButtonIcon = inject(BUTTON_ICON_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	constructor() {
		super();
		effect(() => {
			const pt = this.pButtonIconPT();
			if (pt) this.directivePT.set(pt);
		});
		effect(() => {
			if (this.pButtonUnstyled()) this.directiveUnstyled.set(this.pButtonUnstyled());
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = function ButtonIcon_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ButtonIcon)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: ButtonIcon,
		selectors: [[
			"",
			"pButtonIcon",
			""
		]],
		hostVars: 2,
		hostBindings: function ButtonIcon_HostBindings(rf, ctx) {
			if (rf & 2) ɵɵclassMap(ctx.$unstyled() ? void 0 : ctx.pcn("p-button-icon"));
		},
		inputs: {
			pButtonIconPT: [1, "pButtonIconPT"],
			pButtonUnstyled: [1, "pButtonUnstyled"]
		},
		features: [
			ɵɵProvidersFeature([
				ButtonStyle,
				{
					provide: BUTTON_ICON_INSTANCE,
					useExisting: ButtonIcon
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ButtonIcon
				}
			]),
			ɵɵHostDirectivesFeature([Bind]),
			ɵɵInheritDefinitionFeature
		]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonIcon, [{
		type: Directive,
		args: [{
			selector: "[pButtonIcon]",
			providers: [
				ButtonStyle,
				{
					provide: BUTTON_ICON_INSTANCE,
					useExisting: ButtonIcon
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ButtonIcon
				}
			],
			standalone: true,
			host: { "[class]": "$unstyled() ? undefined : pcn('p-button-icon')" },
			hostDirectives: [Bind]
		}]
	}], () => [], {
		pButtonIconPT: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButtonIconPT",
				required: false
			}]
		}],
		pButtonUnstyled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButtonUnstyled",
				required: false
			}]
		}]
	});
})();
var BUTTON_LABEL_INSTANCE = new InjectionToken("BUTTON_LABEL_INSTANCE");
var ButtonLabel = class ButtonLabel extends BaseComponent {
	componentName = "ButtonLabel";
	pButtonLabelPT = input(...ngDevMode ? [void 0, { debugName: "pButtonLabelPT" }] : /* istanbul ignore next */ []);
	pButtonLabelUnstyled = input(...ngDevMode ? [void 0, { debugName: "pButtonLabelUnstyled" }] : /* istanbul ignore next */ []);
	$pcButtonLabel = inject(BUTTON_LABEL_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	constructor() {
		super();
		effect(() => {
			const pt = this.pButtonLabelPT();
			if (pt) this.directivePT.set(pt);
		});
		effect(() => {
			if (this.pButtonLabelUnstyled()) this.directiveUnstyled.set(this.pButtonLabelUnstyled());
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = function ButtonLabel_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ButtonLabel)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: ButtonLabel,
		selectors: [[
			"",
			"pButtonLabel",
			""
		]],
		hostVars: 2,
		hostBindings: function ButtonLabel_HostBindings(rf, ctx) {
			if (rf & 2) ɵɵclassMap(ctx.$unstyled() ? void 0 : ctx.pcn("p-button-label"));
		},
		inputs: {
			pButtonLabelPT: [1, "pButtonLabelPT"],
			pButtonLabelUnstyled: [1, "pButtonLabelUnstyled"]
		},
		features: [
			ɵɵProvidersFeature([
				ButtonStyle,
				{
					provide: BUTTON_LABEL_INSTANCE,
					useExisting: ButtonLabel
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ButtonLabel
				}
			]),
			ɵɵHostDirectivesFeature([Bind]),
			ɵɵInheritDefinitionFeature
		]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonLabel, [{
		type: Directive,
		args: [{
			selector: "[pButtonLabel]",
			providers: [
				ButtonStyle,
				{
					provide: BUTTON_LABEL_INSTANCE,
					useExisting: ButtonLabel
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ButtonLabel
				}
			],
			standalone: true,
			host: { "[class]": "$unstyled() ? undefined : pcn('p-button-label')" },
			hostDirectives: [Bind]
		}]
	}], () => [], {
		pButtonLabelPT: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButtonLabelPT",
				required: false
			}]
		}],
		pButtonLabelUnstyled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButtonLabelUnstyled",
				required: false
			}]
		}]
	});
})();
var BUTTON_DIRECTIVE_INSTANCE = new InjectionToken("BUTTON_DIRECTIVE_INSTANCE");
var ButtonDirective = class ButtonDirective extends BaseComponent {
	componentName = "Button";
	pButton = input(void 0, ...ngDevMode ? [{ debugName: "pButton" }] : /* istanbul ignore next */ []);
	pButtonPT = input(...ngDevMode ? [void 0, { debugName: "pButtonPT" }] : /* istanbul ignore next */ []);
	pButtonUnstyled = input(...ngDevMode ? [void 0, { debugName: "pButtonUnstyled" }] : /* istanbul ignore next */ []);
	hostName = input("", ...ngDevMode ? [{ debugName: "hostName" }] : /* istanbul ignore next */ []);
	text = input(false, {
		...ngDevMode ? { debugName: "text" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	plain = input(false, {
		...ngDevMode ? { debugName: "plain" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	raised = input(false, {
		...ngDevMode ? { debugName: "raised" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	outlined = input(false, {
		...ngDevMode ? { debugName: "outlined" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	link = input(false, {
		...ngDevMode ? { debugName: "link" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rounded = input(false, {
		...ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	fluid = input(void 0, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	iconOnly = input(false, {
		...ngDevMode ? { debugName: "iconOnly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	severity = input(...ngDevMode ? [void 0, { debugName: "severity" }] : /* istanbul ignore next */ []);
	$pcButtonDirective = inject(BUTTON_DIRECTIVE_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	pcFluid = inject(Fluid, {
		optional: true,
		host: true,
		skipSelf: true
	});
	_componentStyle = inject(ButtonStyle);
	iconSignal = contentChild(ButtonIcon, {
		...ngDevMode ? { debugName: "iconSignal" } : /* istanbul ignore next */ {},
		descendants: false
	});
	labelSignal = contentChild(ButtonLabel, {
		...ngDevMode ? { debugName: "labelSignal" } : /* istanbul ignore next */ {},
		descendants: false
	});
	isIconOnly = computed(() => !!(!this.labelSignal() && this.iconSignal()), ...ngDevMode ? [{ debugName: "isIconOnly" }] : /* istanbul ignore next */ []);
	styleClass = computed(() => {
		if (this.$unstyled()) return "";
		const v = this.pButton();
		const o = typeof v === "object" && v !== null ? v : {};
		const stringSeverity = typeof v === "string" && v !== "" ? v : void 0;
		const severity = o.severity ?? stringSeverity ?? this.severity();
		const size = o.size ?? this.size();
		const variant = o.variant ?? this.variant();
		const base = this.pcn("p-button", "p-component", {
			"p-button-icon-only": this.iconOnly() || o.iconOnly || this.isIconOnly(),
			"p-button-loading": this.loading(),
			"p-disabled": this.loading(),
			"p-button-text": this.text() || variant === "text" || o.text,
			"p-button-outlined": this.outlined() || variant === "outlined" || o.outlined,
			"p-button-link": this.link() || variant === "link" || o.link,
			"p-button-plain": this.plain() || o.plain,
			"p-button-raised": this.raised() || o.raised,
			"p-button-rounded": this.rounded() || o.rounded,
			"p-button-sm": size === "small",
			"p-button-lg": size === "large",
			"p-button-fluid": this.fluid() ?? o.fluid ?? !!this.pcFluid,
			[`p-button-${severity}`]: !!severity
		});
		return o.styleClass ? `${base} ${o.styleClass}` : base;
	}, ...ngDevMode ? [{ debugName: "styleClass" }] : /* istanbul ignore next */ []);
	hostStyle = computed(() => {
		const v = this.pButton();
		return (typeof v === "object" && v !== null ? v : {}).style ?? null;
	}, ...ngDevMode ? [{ debugName: "hostStyle" }] : /* istanbul ignore next */ []);
	constructor() {
		super();
		effect(() => {
			const pt = this.pButtonPT();
			if (pt) this.directivePT.set(pt);
		});
		effect(() => {
			const unstyled = this.pButtonUnstyled();
			if (unstyled !== void 0) this.directiveUnstyled.set(unstyled);
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptm("root"));
	}
	static ɵfac = function ButtonDirective_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ButtonDirective)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: ButtonDirective,
		selectors: [[
			"",
			"pButton",
			""
		]],
		contentQueries: function ButtonDirective_ContentQueries(rf, ctx, dirIndex) {
			if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.iconSignal, ButtonIcon, 4)(dirIndex, ctx.labelSignal, ButtonLabel, 4);
			if (rf & 2) ɵɵqueryAdvance(2);
		},
		hostVars: 4,
		hostBindings: function ButtonDirective_HostBindings(rf, ctx) {
			if (rf & 2) {
				ɵɵstyleMap(ctx.hostStyle());
				ɵɵclassMap(ctx.styleClass());
			}
		},
		inputs: {
			pButton: [1, "pButton"],
			pButtonPT: [1, "pButtonPT"],
			pButtonUnstyled: [1, "pButtonUnstyled"],
			hostName: [1, "hostName"],
			text: [1, "text"],
			plain: [1, "plain"],
			raised: [1, "raised"],
			size: [1, "size"],
			outlined: [1, "outlined"],
			link: [1, "link"],
			rounded: [1, "rounded"],
			fluid: [1, "fluid"],
			variant: [1, "variant"],
			iconOnly: [1, "iconOnly"],
			loading: [1, "loading"],
			severity: [1, "severity"]
		},
		features: [
			ɵɵProvidersFeature([
				ButtonStyle,
				{
					provide: BUTTON_DIRECTIVE_INSTANCE,
					useExisting: ButtonDirective
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ButtonDirective
				}
			]),
			ɵɵHostDirectivesFeature([Bind, Ripple]),
			ɵɵInheritDefinitionFeature
		]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonDirective, [{
		type: Directive,
		args: [{
			selector: "[pButton]",
			standalone: true,
			providers: [
				ButtonStyle,
				{
					provide: BUTTON_DIRECTIVE_INSTANCE,
					useExisting: ButtonDirective
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: ButtonDirective
				}
			],
			host: {
				"[class]": "styleClass()",
				"[style]": "hostStyle()"
			},
			hostDirectives: [Bind, Ripple]
		}]
	}], () => [], {
		pButton: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButton",
				required: false
			}]
		}],
		pButtonPT: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButtonPT",
				required: false
			}]
		}],
		pButtonUnstyled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pButtonUnstyled",
				required: false
			}]
		}],
		hostName: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "hostName",
				required: false
			}]
		}],
		text: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		plain: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		raised: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "raised",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		outlined: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "outlined",
				required: false
			}]
		}],
		link: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "link",
				required: false
			}]
		}],
		rounded: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		variant: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		iconOnly: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "iconOnly",
				required: false
			}]
		}],
		loading: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		severity: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "severity",
				required: false
			}]
		}],
		iconSignal: [{
			type: ContentChild,
			args: [forwardRef(() => ButtonIcon), {
				descendants: false,
				isSignal: true
			}]
		}],
		labelSignal: [{
			type: ContentChild,
			args: [forwardRef(() => ButtonLabel), {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var ButtonModule = class ButtonModule {
	static ɵfac = function ButtonModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ButtonModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: ButtonModule,
		imports: [
			ButtonDirective,
			Button,
			ButtonLabel,
			ButtonIcon
		],
		exports: [
			ButtonDirective,
			Button,
			ButtonLabel,
			ButtonIcon
		]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [Button] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonModule, [{
		type: NgModule,
		args: [{
			imports: [
				ButtonDirective,
				Button,
				ButtonLabel,
				ButtonIcon
			],
			exports: [
				ButtonDirective,
				Button,
				ButtonLabel,
				ButtonIcon
			]
		}]
	}], null, null);
})();
export { ButtonClasses as a, ButtonLabel as c, Button as i, ButtonModule as l, BUTTON_INSTANCE as n, ButtonDirective as o, BUTTON_LABEL_INSTANCE as r, ButtonIcon as s, BUTTON_ICON_INSTANCE as t, ButtonStyle as u };
