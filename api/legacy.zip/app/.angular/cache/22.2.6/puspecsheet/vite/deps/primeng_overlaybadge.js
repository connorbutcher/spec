import { U as InjectionToken, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, O as booleanAttribute, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, _o as ɵɵgetInheritedFactory, ca as ɵɵclassMap, co as ɵɵelementEnd, io as ɵɵelement, lo as ɵɵelementStart, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable } from "./core-BenYQOr3.js";
import { SharedModule } from "./primeng_api.js";
import { r as BadgeModule, t as Badge } from "./primeng-badge-DVBRASwf.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/primeng/fesm2022/primeng-overlaybadge.mjs
var style = `
.p-overlaybadge {
    position: relative;
}

.p-overlaybadge .p-badge {
    position: absolute;
    top: 0;
    right: 0;
    transform: translate(50%, -50%);
    transform-origin: 100% 0;
    margin: 0;
    outline-width: dt('overlaybadge.outline.width');
    outline-style: solid;
    outline-color: dt('overlaybadge.outline.color');
}
`;
var classes = { root: "p-overlaybadge" };
var OverlayBadgeStyle = class OverlayBadgeStyle extends BaseStyle {
	name = "overlaybadge";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵOverlayBadgeStyle_BaseFactory = void 0;
		return function OverlayBadgeStyle_Factory(__ngFactoryType__) {
			return (ɵOverlayBadgeStyle_BaseFactory || (ɵOverlayBadgeStyle_BaseFactory = ɵɵgetInheritedFactory(OverlayBadgeStyle)))(__ngFactoryType__ || OverlayBadgeStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: OverlayBadgeStyle,
		factory: OverlayBadgeStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OverlayBadgeStyle, [{ type: Injectable }], null, null);
})();
var OVERLAYBADGE_INSTANCE = new InjectionToken("OVERLAYBADGE_INSTANCE");
var OverlayBadge = class OverlayBadge extends BaseComponent {
	componentName = "OverlayBadge";
	$pcOverlayBadge = inject(OVERLAYBADGE_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	styleClass = input(...ngDevMode ? [void 0, { debugName: "styleClass" }] : /* istanbul ignore next */ []);
	style = input(...ngDevMode ? [void 0, { debugName: "style" }] : /* istanbul ignore next */ []);
	badgeSize = input(...ngDevMode ? [void 0, { debugName: "badgeSize" }] : /* istanbul ignore next */ []);
	severity = input(...ngDevMode ? [void 0, { debugName: "severity" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	badgeDisabled = input(false, {
		...ngDevMode ? { debugName: "badgeDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	_componentStyle = inject(OverlayBadgeStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptm("host"));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵOverlayBadge_BaseFactory = void 0;
		return function OverlayBadge_Factory(__ngFactoryType__) {
			return (ɵOverlayBadge_BaseFactory || (ɵOverlayBadge_BaseFactory = ɵɵgetInheritedFactory(OverlayBadge)))(__ngFactoryType__ || OverlayBadge);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: OverlayBadge,
			selectors: [["p-overlay-badge"], ["p-overlaybadge"]],
			inputs: {
				styleClass: [1, "styleClass"],
				style: [1, "style"],
				badgeSize: [1, "badgeSize"],
				severity: [1, "severity"],
				value: [1, "value"],
				badgeDisabled: [1, "badgeDisabled"]
			},
			features: [
				ɵɵProvidersFeature([
					OverlayBadgeStyle,
					{
						provide: OVERLAYBADGE_INSTANCE,
						useExisting: OverlayBadge
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: OverlayBadge
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 3,
			vars: 12,
			consts: [[3, "pBind"], [
				3,
				"pt",
				"badgeSize",
				"severity",
				"value",
				"badgeDisabled"
			]],
			template: function OverlayBadge_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵelementStart(0, "div", 0);
					ɵɵprojection(1);
					ɵɵelement(2, "p-badge", 1);
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵclassMap(ctx.cx("root"));
					ɵɵproperty("pBind", ctx.ptm("root"));
					ɵɵadvance(2);
					ɵɵstyleMap(ctx.style());
					ɵɵclassMap(ctx.styleClass());
					ɵɵproperty("pt", ctx.ptm("pcBadge"))("badgeSize", ctx.badgeSize())("severity", ctx.severity())("value", ctx.value())("badgeDisabled", ctx.badgeDisabled());
				}
			},
			dependencies: [
				BadgeModule,
				Badge,
				SharedModule,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OverlayBadge, [{
		type: Component,
		args: [{
			selector: "p-overlay-badge, p-overlaybadge",
			standalone: true,
			imports: [
				BadgeModule,
				SharedModule,
				Bind
			],
			template: `
        <div [class]="cx('root')" [pBind]="ptm('root')">
            <ng-content></ng-content>
            <p-badge [pt]="ptm('pcBadge')" [class]="styleClass()" [style]="style()" [badgeSize]="badgeSize()" [severity]="severity()" [value]="value()" [badgeDisabled]="badgeDisabled()" />
        </div>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				OverlayBadgeStyle,
				{
					provide: OVERLAYBADGE_INSTANCE,
					useExisting: OverlayBadge
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: OverlayBadge
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, {
		styleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "styleClass",
				required: false
			}]
		}],
		style: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "style",
				required: false
			}]
		}],
		badgeSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "badgeSize",
				required: false
			}]
		}],
		severity: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "severity",
				required: false
			}]
		}],
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		badgeDisabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "badgeDisabled",
				required: false
			}]
		}]
	});
})();
var OverlayBadgeModule = class OverlayBadgeModule {
	static ɵfac = function OverlayBadgeModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || OverlayBadgeModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: OverlayBadgeModule,
		imports: [OverlayBadge, SharedModule],
		exports: [OverlayBadge, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		OverlayBadge,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OverlayBadgeModule, [{
		type: NgModule,
		args: [{
			imports: [OverlayBadge, SharedModule],
			exports: [OverlayBadge, SharedModule]
		}]
	}], null, null);
})();
export { OverlayBadge, OverlayBadgeModule, OverlayBadgeStyle };
