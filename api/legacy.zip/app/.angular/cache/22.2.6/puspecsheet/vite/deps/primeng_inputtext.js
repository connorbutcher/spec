import "./@angular_forms.js";
import "./primeng_bind.js";
export { t as InputText, n as InputTextClasses, r as InputTextModule, i as InputTextStyle } from "./primeng-inputtext-DxZm8pYo.js";
