import { U as InjectionToken, Ui as signal, _ as untracked, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject, xn as effect } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Sn as Input, T as afterRenderEffect, Ua as ɵɵdefineComponent, Wa as ɵɵdefineDirective, X as input, Xi as ɵɵProvidersFeature, _o as ɵɵgetInheritedFactory, at as output, ca as ɵɵclassMap, da as ɵɵconditional, pa as ɵɵconditionalCreate, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, un as Directive, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { x as CommonModule } from "./common-D_MNYFJX.js";
import { ot as ue } from "./primeng-utils-CHKSviI4.js";
import "./dist-BRhwYpCB.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { Bind, BindModule } from "./primeng_bind.js";
// node_modules/@primeuix/motion/node_modules/@primeuix/utils/dist/object/index.mjs
function se(e) {
	if (e === "auto") return 0;
	if (typeof e == "number") return e;
	let t = Number(e.replace(",", ".").replace(/[^\d.]/g, ""));
	return Number.isNaN(t) || /ms\s*$/.test(e) ? t : t * 1e3;
}
// node_modules/@primeuix/motion/node_modules/@primeuix/utils/dist/dom/index.mjs
function D(t, e) {
	return t ? t.classList ? t.classList.contains(e) : new RegExp("(^| )" + e + "( |$)", "gi").test(t.className) : !1;
}
function M(t, e) {
	if (t && e) {
		let o = (n) => {
			D(t, n) || (t.classList ? t.classList.add(n) : t.className += " " + n);
		};
		[e].flat().filter(Boolean).forEach((n) => n.split(" ").forEach(o));
	}
}
function W$1(t, e) {
	if (t && e) {
		let o = (n) => {
			t.classList ? t.classList.remove(n) : t.className = t.className.replace(new RegExp("(^|\\b)" + n.split(" ").join("|") + "(\\b|$)", "gi"), " ");
		};
		[e].flat().filter(Boolean).forEach((n) => n.split(" ").forEach(o));
	}
}
function v(t) {
	let e = {
		width: 0,
		height: 0
	};
	if (t) {
		let [o, n] = [t.style.visibility, t.style.display], r = t.getBoundingClientRect();
		t.style.visibility = "hidden", t.style.display = "block", e.width = r.width || t.offsetWidth, e.height = r.height || t.offsetHeight, t.style.display = n, t.style.visibility = o;
	}
	return e;
}
function le() {
	return typeof window == "undefined" || !window.matchMedia ? !1 : window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function xe(t, e, o = null, n) {
	e && t != null && t.style && t.style.setProperty(e, o, n);
}
// node_modules/@primeuix/motion/dist/index.mjs
var J = Object.defineProperty;
var N = Object.getOwnPropertySymbols;
var K = Object.prototype.hasOwnProperty;
var Q = Object.prototype.propertyIsEnumerable;
var S = (t, o, e) => o in t ? J(t, o, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: e
}) : t[o] = e;
var x = (t, o) => {
	for (var e in o || (o = {})) K.call(o, e) && S(t, e, o[e]);
	if (N) for (var e of N(o)) Q.call(o, e) && S(t, e, o[e]);
	return t;
};
var k = (t, o, e) => new Promise((i, u) => {
	var a = (s) => {
		try {
			h(e.next(s));
		} catch (f) {
			u(f);
		}
	}, M = (s) => {
		try {
			h(e.throw(s));
		} catch (f) {
			u(f);
		}
	}, h = (s) => s.done ? i(s.value) : Promise.resolve(s.value).then(a, M);
	h((e = e.apply(t, o)).next());
});
var p = "animation";
var E = "transition";
var Z = [
	"data-enter-phase",
	"data-enter-from",
	"data-enter-to",
	"data-enter-active",
	"data-leave-phase",
	"data-leave-from",
	"data-leave-to",
	"data-leave-active"
];
function j(t) {
	return t ? t.disabled || !!(t.safe && le()) : !1;
}
function V(t, o) {
	return t ? x(x({}, t), Object.entries(o).reduce((e, [i, u]) => {
		var a;
		return e[i] = (a = t[i]) != null ? a : u, e;
	}, {})) : x({}, o);
}
function _(t) {
	let { name: o, enterClass: e, leaveClass: i } = t || {};
	return {
		enter: {
			from: (e == null ? void 0 : e.from) || `${o}-enter-from`,
			to: (e == null ? void 0 : e.to) || `${o}-enter-to`,
			active: (e == null ? void 0 : e.active) || `${o}-enter-active`
		},
		leave: {
			from: (i == null ? void 0 : i.from) || `${o}-leave-from`,
			to: (i == null ? void 0 : i.to) || `${o}-leave-to`,
			active: (i == null ? void 0 : i.active) || `${o}-leave-active`
		}
	};
}
function C(t) {
	return {
		enter: {
			onBefore: t == null ? void 0 : t.onBeforeEnter,
			onStart: t == null ? void 0 : t.onEnter,
			onAfter: t == null ? void 0 : t.onAfterEnter,
			onCancelled: t == null ? void 0 : t.onEnterCancelled
		},
		leave: {
			onBefore: t == null ? void 0 : t.onBeforeLeave,
			onStart: t == null ? void 0 : t.onLeave,
			onAfter: t == null ? void 0 : t.onAfterLeave,
			onCancelled: t == null ? void 0 : t.onLeaveCancelled
		}
	};
}
function R(t, o) {
	let e = window.getComputedStyle(t), i = (d) => {
		let l = e[`${d}Duration`].split(", ").map(se), m = e[`${d}Delay`].split(", ").map(se);
		return m.length < l.length && m.length > 0 && (m = l.map((v, b) => m[b % m.length])), [m, l];
	}, [u, a] = i(E), [M, h] = i(p), s = Math.max(...a.map((d, l) => d + u[l])), f = Math.max(...h.map((d, l) => d + M[l])), r, n = 0, c = 0;
	return o === "transition" ? s > 0 && (r = "transition", n = s, c = a.length) : o === "animation" ? f > 0 && (r = "animation", n = f, c = h.length) : (n = Math.max(s, f), r = n > 0 ? s > f ? E : p : void 0, c = r ? r === "transition" ? a.length : h.length : 0), {
		type: r,
		timeout: n,
		count: c
	};
}
function q(t, o) {
	return typeof t == "number" ? t : t != null && typeof t == "object" && t[o] != null ? t[o] : null;
}
function W(t, o) {
	return t ? `--${t}-${o}` : `--${o}`;
}
function g(t, o, e) {
	let { autoHeight: i, autoWidth: u, cssVarPrefix: a } = o, M = typeof e == "object";
	i && xe(t, W(a, "height"), M ? e.height : e), u && xe(t, W(a, "width"), M ? e.width : e);
}
function P(t, o) {
	if (!o.autoHeight && !o.autoWidth) return;
	let e = t.scrollHeight, i = t.scrollWidth;
	if (!e || !i) {
		let u = v(t);
		e || (e = u.height), i || (i = u.width);
	}
	g(t, o, {
		height: e + "px",
		width: i + "px"
	});
}
function z(t, o) {
	t.setAttribute(`data-${o}-phase`, "");
}
function O(t, o, e) {
	t.removeAttribute("data-enter-from"), t.removeAttribute("data-enter-to"), t.removeAttribute("data-leave-from"), t.removeAttribute("data-leave-to"), t.setAttribute(`data-${o}-${e}`, ""), t.setAttribute(`data-${o}-active`, "");
}
function T(t) {
	t.removeAttribute("data-enter-phase"), t.removeAttribute("data-leave-phase");
}
function B(t) {
	Z.forEach((o) => t.removeAttribute(o));
}
var tt = Object.freeze({
	name: "p",
	safe: !0,
	disabled: !1,
	enter: !0,
	leave: !0,
	autoHeight: !0,
	autoWidth: !0,
	cssVarPrefix: ""
});
function dt(t, o) {
	if (!t) throw new Error("Element is required.");
	let e = {}, i = !1, u = {}, a = null, M$1 = {}, h = (r) => {
		for (let n of Object.keys(e)) delete e[n];
		if (Object.assign(e, V(r, tt)), !e.enter && !e.leave) throw new Error("Enter or leave must be true.");
		M$1 = C(e), i = j(e), u = _(e), a = null;
	}, s = (r) => k(null, null, function* () {
		a?.();
		let n = t, { onBefore: c, onStart: d, onAfter: l, onCancelled: m } = M$1[r] || {}, v = { element: t };
		if (z(n, r), i) {
			c?.(v), d?.(v), l?.(v), T(n), g(n, e, r === "enter" ? "auto" : "0px");
			return;
		}
		let { from: b, active: A, to: H } = u[r] || {};
		return c?.(v), r === "enter" ? g(n, e, "0px") : r === "leave" && P(n, e), M(n, b), M(n, A), O(n, r, "from"), n.offsetHeight, r === "enter" ? P(n, e) : r === "leave" && g(n, e, "0px"), W$1(n, b), M(n, H), O(n, r, "to"), d?.(v), new Promise((D) => {
			let U = q(e.duration, r), w = () => {
				W$1(n, [H, A]), a = null, B(n), T(n);
			}, G = () => {
				w(), l?.(v), D(), r === "enter" ? g(n, e, "auto") : r === "leave" && g(n, e, "0px");
			}, L = () => {};
			a = () => {
				L(), w(), m?.(v), D();
			}, L = ot(n, e.type, U, G);
		});
	});
	h(o), g(t, e, "0px");
	let f = {
		enter: () => e.enter ? s("enter") : Promise.resolve(),
		leave: () => e.leave ? s("leave") : Promise.resolve(),
		cancel: () => {
			a?.(), a = null;
		},
		update: (r, n) => {
			if (!r) throw new Error("Element is required.");
			t = r, f.cancel(), n && h(n);
		}
	};
	return e.appear && f.enter(), f;
}
var et = 0;
function ot(t, o, e, i) {
	let u = t._motionEndId = ++et, a = () => {
		u === t._motionEndId && i();
	};
	if (e != null) {
		let m = setTimeout(a, e);
		return () => clearTimeout(m);
	}
	let { type: M, timeout: h, count: s } = R(t, o);
	if (!M) return i(), () => {};
	let f = M + "end", r = 0, n = () => {
		t.removeEventListener(f, d, !0), clearTimeout(l);
	}, c = () => {
		n(), a();
	}, d = (m) => {
		m.target === t && ++r >= s && c();
	};
	t.addEventListener(f, d, { capture: !0 });
	let l = setTimeout(() => {
		r < s && c();
	}, h + 1);
	return n;
}
// node_modules/primeng/fesm2022/primeng-motion.mjs
var originalStyles = /* @__PURE__ */ new WeakMap();
function applyHiddenStyles(element, strategy) {
	if (!element) return;
	if (!originalStyles.has(element)) originalStyles.set(element, {
		display: element.style.display,
		visibility: element.style.visibility,
		maxHeight: element.style.maxHeight
	});
	switch (strategy) {
		case "display":
			element.style.display = "none";
			break;
		case "visibility":
			element.style.visibility = "hidden";
			element.style.maxHeight = "0";
	}
}
function resetStyles(element, strategy) {
	if (!element) return;
	const original = originalStyles.get(element) ?? element.style;
	switch (strategy) {
		case "display":
			element.style.display = original?.display || "";
			break;
		case "visibility":
			element.style.visibility = original?.visibility || "";
			element.style.maxHeight = original?.maxHeight || "";
	}
	originalStyles.delete(element);
}
var style = `
    .p-motion {
        display: block;
    }
`;
var classes = { root: "p-motion" };
var MotionStyle = class MotionStyle extends BaseStyle {
	name = "motion";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵMotionStyle_BaseFactory = void 0;
		return function MotionStyle_Factory(__ngFactoryType__) {
			return (ɵMotionStyle_BaseFactory || (ɵMotionStyle_BaseFactory = ɵɵgetInheritedFactory(MotionStyle)))(__ngFactoryType__ || MotionStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: MotionStyle,
		factory: MotionStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MotionStyle, [{ type: Injectable }], null, null);
})();
var MotionClasses;
(function(MotionClasses) {
	MotionClasses["root"] = "p-motion";
})(MotionClasses || (MotionClasses = {}));
var MOTION_INSTANCE = new InjectionToken("MOTION_INSTANCE");
var Motion = class Motion extends BaseComponent {
	$pcMotion = inject(MOTION_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	_componentStyle = inject(MotionStyle);
	visible = input(false, {
		...ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? false
	});
	mountOnEnter = input(true, ...ngDevMode ? [{ debugName: "mountOnEnter" }] : /* istanbul ignore next */ []);
	unmountOnLeave = input(true, ...ngDevMode ? [{ debugName: "unmountOnLeave" }] : /* istanbul ignore next */ []);
	name = input(void 0, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	type = input(void 0, ...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	safe = input(void 0, ...ngDevMode ? [{ debugName: "safe" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	appear = input(false, ...ngDevMode ? [{ debugName: "appear" }] : /* istanbul ignore next */ []);
	enter = input(true, ...ngDevMode ? [{ debugName: "enter" }] : /* istanbul ignore next */ []);
	leave = input(true, ...ngDevMode ? [{ debugName: "leave" }] : /* istanbul ignore next */ []);
	duration = input(void 0, ...ngDevMode ? [{ debugName: "duration" }] : /* istanbul ignore next */ []);
	hideStrategy = input("display", ...ngDevMode ? [{ debugName: "hideStrategy" }] : /* istanbul ignore next */ []);
	enterFromClass = input(void 0, ...ngDevMode ? [{ debugName: "enterFromClass" }] : /* istanbul ignore next */ []);
	enterToClass = input(void 0, ...ngDevMode ? [{ debugName: "enterToClass" }] : /* istanbul ignore next */ []);
	enterActiveClass = input(void 0, ...ngDevMode ? [{ debugName: "enterActiveClass" }] : /* istanbul ignore next */ []);
	leaveFromClass = input(void 0, ...ngDevMode ? [{ debugName: "leaveFromClass" }] : /* istanbul ignore next */ []);
	leaveToClass = input(void 0, ...ngDevMode ? [{ debugName: "leaveToClass" }] : /* istanbul ignore next */ []);
	leaveActiveClass = input(void 0, ...ngDevMode ? [{ debugName: "leaveActiveClass" }] : /* istanbul ignore next */ []);
	options = input({}, {
		...ngDevMode ? { debugName: "options" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? {}
	});
	onBeforeEnter = output();
	onEnter = output();
	onAfterEnter = output();
	onEnterCancelled = output();
	onBeforeLeave = output();
	onLeave = output();
	onAfterLeave = output();
	onLeaveCancelled = output();
	motionOptions = computed(() => {
		const options = this.options();
		return {
			name: options.name ?? this.name(),
			type: options.type ?? this.type(),
			safe: options.safe ?? this.safe(),
			disabled: options.disabled ?? this.disabled(),
			appear: false,
			enter: options.enter ?? this.enter(),
			leave: options.leave ?? this.leave(),
			duration: options.duration ?? this.duration(),
			enterClass: {
				from: options.enterClass?.from ?? (!options.name ? this.enterFromClass() : void 0),
				to: options.enterClass?.to ?? (!options.name ? this.enterToClass() : void 0),
				active: options.enterClass?.active ?? (!options.name ? this.enterActiveClass() : void 0)
			},
			leaveClass: {
				from: options.leaveClass?.from ?? (!options.name ? this.leaveFromClass() : void 0),
				to: options.leaveClass?.to ?? (!options.name ? this.leaveToClass() : void 0),
				active: options.leaveClass?.active ?? (!options.name ? this.leaveActiveClass() : void 0)
			},
			onBeforeEnter: options.onBeforeEnter ?? this.handleBeforeEnter,
			onEnter: options.onEnter ?? this.handleEnter,
			onAfterEnter: options.onAfterEnter ?? this.handleAfterEnter,
			onEnterCancelled: options.onEnterCancelled ?? this.handleEnterCancelled,
			onBeforeLeave: options.onBeforeLeave ?? this.handleBeforeLeave,
			onLeave: options.onLeave ?? this.handleLeave,
			onAfterLeave: options.onAfterLeave ?? this.handleAfterLeave,
			onLeaveCancelled: options.onLeaveCancelled ?? this.handleLeaveCancelled
		};
	}, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	motion;
	isInitialMount = true;
	cancelled = false;
	destroyed = false;
	rendered = signal(false, ...ngDevMode ? [{ debugName: "rendered" }] : /* istanbul ignore next */ []);
	handleBeforeEnter = (event) => !this.destroyed && this.onBeforeEnter.emit(event);
	handleEnter = (event) => !this.destroyed && this.onEnter.emit(event);
	handleAfterEnter = (event) => !this.destroyed && this.onAfterEnter.emit(event);
	handleEnterCancelled = (event) => !this.destroyed && this.onEnterCancelled.emit(event);
	handleBeforeLeave = (event) => !this.destroyed && this.onBeforeLeave.emit(event);
	handleLeave = (event) => !this.destroyed && this.onLeave.emit(event);
	handleAfterLeave = (event) => !this.destroyed && this.onAfterLeave.emit(event);
	handleLeaveCancelled = (event) => !this.destroyed && this.onLeaveCancelled.emit(event);
	constructor() {
		super();
		effect(() => {
			const hideStrategy = this.hideStrategy();
			if (this.isInitialMount) {
				applyHiddenStyles(this.$el, hideStrategy);
				this.rendered.set(this.visible() && this.mountOnEnter() || !this.mountOnEnter());
			} else if (this.visible() && !this.rendered()) {
				applyHiddenStyles(this.$el, hideStrategy);
				this.rendered.set(true);
			}
		});
		effect(() => {
			if (!this.motion) this.motion = dt(this.$el, this.motionOptions());
		});
		afterRenderEffect(async () => {
			if (!this.$el) return;
			const shouldAppear = this.isInitialMount && this.visible() && this.appear();
			const hideStrategy = this.hideStrategy();
			if (this.visible()) {
				await ue();
				resetStyles(this.$el, hideStrategy);
				if (shouldAppear || !this.isInitialMount) {
					this.applyMotionDuration("enter");
					this.motion?.enter();
				}
			} else if (!this.isInitialMount) {
				await ue();
				this.applyMotionDuration("leave");
				this.motion?.leave()?.then(async () => {
					if (this.$el && !this.cancelled && !this.visible()) {
						applyHiddenStyles(this.$el, hideStrategy);
						if (this.unmountOnLeave()) {
							await ue();
							if (!this.cancelled) this.rendered.set(false);
						}
					}
				});
			}
			this.isInitialMount = false;
		});
	}
	applyMotionDuration(phase) {
		const options = untracked(this.motionOptions);
		const ms = q(options.duration, phase);
		if (ms == null || !this.$el) return;
		const el = this.$el;
		const durationValue = `${ms}ms`;
		if (options.type === "transition") el.style.transitionDuration = durationValue;
		else el.style.animationDuration = durationValue;
	}
	onAfterViewChecked() {
		const optionsAttrs = this.options()?.root || {};
		this.bindDirectiveInstance.setAttrs({
			...this.ptms(["host", "root"]),
			...optionsAttrs
		});
	}
	onDestroy() {
		this.destroyed = true;
		this.cancelled = true;
		this.motion?.cancel();
		this.motion = void 0;
		resetStyles(this.$el, this.hideStrategy());
		this.$el?.remove();
		this.isInitialMount = true;
	}
	static ɵfac = function Motion_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Motion)();
	};
	static ɵcmp = (function() {
		const _c0 = ["*"];
		function Motion_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵprojection(0);
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Motion,
			selectors: [["p-motion"]],
			hostVars: 2,
			hostBindings: function Motion_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassMap(ctx.cx("root"));
			},
			inputs: {
				visible: [1, "visible"],
				mountOnEnter: [1, "mountOnEnter"],
				unmountOnLeave: [1, "unmountOnLeave"],
				name: [1, "name"],
				type: [1, "type"],
				safe: [1, "safe"],
				disabled: [1, "disabled"],
				appear: [1, "appear"],
				enter: [1, "enter"],
				leave: [1, "leave"],
				duration: [1, "duration"],
				hideStrategy: [1, "hideStrategy"],
				enterFromClass: [1, "enterFromClass"],
				enterToClass: [1, "enterToClass"],
				enterActiveClass: [1, "enterActiveClass"],
				leaveFromClass: [1, "leaveFromClass"],
				leaveToClass: [1, "leaveToClass"],
				leaveActiveClass: [1, "leaveActiveClass"],
				options: [1, "options"]
			},
			outputs: {
				onBeforeEnter: "onBeforeEnter",
				onEnter: "onEnter",
				onAfterEnter: "onAfterEnter",
				onEnterCancelled: "onEnterCancelled",
				onBeforeLeave: "onBeforeLeave",
				onLeave: "onLeave",
				onAfterLeave: "onAfterLeave",
				onLeaveCancelled: "onLeaveCancelled"
			},
			features: [
				ɵɵProvidersFeature([
					MotionStyle,
					{
						provide: MOTION_INSTANCE,
						useExisting: Motion
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Motion
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c0,
			decls: 1,
			vars: 1,
			template: function Motion_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵconditionalCreate(0, Motion_Conditional_0_Template, 1, 0);
				}
				if (rf & 2) ɵɵconditional(ctx.rendered() ? 0 : -1);
			},
			dependencies: [CommonModule, BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Motion, [{
		type: Component,
		args: [{
			selector: "p-motion",
			standalone: true,
			imports: [CommonModule, BindModule],
			template: `
        @if (rendered()) {
            <ng-content />
        }
    `,
			providers: [
				MotionStyle,
				{
					provide: MOTION_INSTANCE,
					useExisting: Motion
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Motion
				}
			],
			host: { "[class]": "cx('root')" },
			hostDirectives: [Bind]
		}]
	}], () => [], {
		visible: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}],
		mountOnEnter: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "mountOnEnter",
				required: false
			}]
		}],
		unmountOnLeave: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "unmountOnLeave",
				required: false
			}]
		}],
		name: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		type: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "type",
				required: false
			}]
		}],
		safe: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "safe",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		appear: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "appear",
				required: false
			}]
		}],
		enter: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "enter",
				required: false
			}]
		}],
		leave: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "leave",
				required: false
			}]
		}],
		duration: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "duration",
				required: false
			}]
		}],
		hideStrategy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "hideStrategy",
				required: false
			}]
		}],
		enterFromClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "enterFromClass",
				required: false
			}]
		}],
		enterToClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "enterToClass",
				required: false
			}]
		}],
		enterActiveClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "enterActiveClass",
				required: false
			}]
		}],
		leaveFromClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "leaveFromClass",
				required: false
			}]
		}],
		leaveToClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "leaveToClass",
				required: false
			}]
		}],
		leaveActiveClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "leaveActiveClass",
				required: false
			}]
		}],
		options: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		onBeforeEnter: [{
			type: Output,
			args: ["onBeforeEnter"]
		}],
		onEnter: [{
			type: Output,
			args: ["onEnter"]
		}],
		onAfterEnter: [{
			type: Output,
			args: ["onAfterEnter"]
		}],
		onEnterCancelled: [{
			type: Output,
			args: ["onEnterCancelled"]
		}],
		onBeforeLeave: [{
			type: Output,
			args: ["onBeforeLeave"]
		}],
		onLeave: [{
			type: Output,
			args: ["onLeave"]
		}],
		onAfterLeave: [{
			type: Output,
			args: ["onAfterLeave"]
		}],
		onLeaveCancelled: [{
			type: Output,
			args: ["onLeaveCancelled"]
		}]
	});
})();
var MOTION_DIRECTIVE_INSTANCE = new InjectionToken("MOTION_DIRECTIVE_INSTANCE");
var MotionDirective = class MotionDirective extends BaseComponent {
	$pcMotionDirective = inject(MOTION_DIRECTIVE_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	visible = input(false, {
		...ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {},
		alias: "pMotion",
		transform: (value) => value ?? false
	});
	name = input(void 0, {
		...ngDevMode ? { debugName: "name" } : /* istanbul ignore next */ {},
		alias: "pMotionName"
	});
	type = input(void 0, {
		...ngDevMode ? { debugName: "type" } : /* istanbul ignore next */ {},
		alias: "pMotionType"
	});
	safe = input(void 0, {
		...ngDevMode ? { debugName: "safe" } : /* istanbul ignore next */ {},
		alias: "pMotionSafe"
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		alias: "pMotionDisabled"
	});
	appear = input(false, {
		...ngDevMode ? { debugName: "appear" } : /* istanbul ignore next */ {},
		alias: "pMotionAppear"
	});
	enter = input(true, {
		...ngDevMode ? { debugName: "enter" } : /* istanbul ignore next */ {},
		alias: "pMotionEnter"
	});
	leave = input(true, {
		...ngDevMode ? { debugName: "leave" } : /* istanbul ignore next */ {},
		alias: "pMotionLeave"
	});
	duration = input(void 0, {
		...ngDevMode ? { debugName: "duration" } : /* istanbul ignore next */ {},
		alias: "pMotionDuration"
	});
	hideStrategy = input("display", {
		...ngDevMode ? { debugName: "hideStrategy" } : /* istanbul ignore next */ {},
		alias: "pMotionHideStrategy"
	});
	enterFromClass = input(void 0, {
		...ngDevMode ? { debugName: "enterFromClass" } : /* istanbul ignore next */ {},
		alias: "pMotionEnterFromClass"
	});
	enterToClass = input(void 0, {
		...ngDevMode ? { debugName: "enterToClass" } : /* istanbul ignore next */ {},
		alias: "pMotionEnterToClass"
	});
	enterActiveClass = input(void 0, {
		...ngDevMode ? { debugName: "enterActiveClass" } : /* istanbul ignore next */ {},
		alias: "pMotionEnterActiveClass"
	});
	leaveFromClass = input(void 0, {
		...ngDevMode ? { debugName: "leaveFromClass" } : /* istanbul ignore next */ {},
		alias: "pMotionLeaveFromClass"
	});
	leaveToClass = input(void 0, {
		...ngDevMode ? { debugName: "leaveToClass" } : /* istanbul ignore next */ {},
		alias: "pMotionLeaveToClass"
	});
	leaveActiveClass = input(void 0, {
		...ngDevMode ? { debugName: "leaveActiveClass" } : /* istanbul ignore next */ {},
		alias: "pMotionLeaveActiveClass"
	});
	options = input({}, {
		...ngDevMode ? { debugName: "options" } : /* istanbul ignore next */ {},
		alias: "pMotionOptions",
		transform: (value) => value ?? {}
	});
	onBeforeEnter = output({ alias: "pMotionOnBeforeEnter" });
	onEnter = output({ alias: "pMotionOnEnter" });
	onAfterEnter = output({ alias: "pMotionOnAfterEnter" });
	onEnterCancelled = output({ alias: "pMotionOnEnterCancelled" });
	onBeforeLeave = output({ alias: "pMotionOnBeforeLeave" });
	onLeave = output({ alias: "pMotionOnLeave" });
	onAfterLeave = output({ alias: "pMotionOnAfterLeave" });
	onLeaveCancelled = output({ alias: "pMotionOnLeaveCancelled" });
	motionOptions = computed(() => {
		const options = this.options() ?? {};
		return {
			name: options.name ?? this.name(),
			type: options.type ?? this.type(),
			safe: options.safe ?? this.safe(),
			disabled: options.disabled ?? this.disabled(),
			appear: false,
			enter: options.enter ?? this.enter(),
			leave: options.leave ?? this.leave(),
			duration: options.duration ?? this.duration(),
			enterClass: {
				from: options.enterClass?.from ?? (!options.name ? this.enterFromClass() : void 0),
				to: options.enterClass?.to ?? (!options.name ? this.enterToClass() : void 0),
				active: options.enterClass?.active ?? (!options.name ? this.enterActiveClass() : void 0)
			},
			leaveClass: {
				from: options.leaveClass?.from ?? (!options.name ? this.leaveFromClass() : void 0),
				to: options.leaveClass?.to ?? (!options.name ? this.leaveToClass() : void 0),
				active: options.leaveClass?.active ?? (!options.name ? this.leaveActiveClass() : void 0)
			},
			onBeforeEnter: options.onBeforeEnter ?? this.handleBeforeEnter,
			onEnter: options.onEnter ?? this.handleEnter,
			onAfterEnter: options.onAfterEnter ?? this.handleAfterEnter,
			onEnterCancelled: options.onEnterCancelled ?? this.handleEnterCancelled,
			onBeforeLeave: options.onBeforeLeave ?? this.handleBeforeLeave,
			onLeave: options.onLeave ?? this.handleLeave,
			onAfterLeave: options.onAfterLeave ?? this.handleAfterLeave,
			onLeaveCancelled: options.onLeaveCancelled ?? this.handleLeaveCancelled
		};
	}, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	motion;
	isInitialMount = true;
	cancelled = false;
	destroyed = false;
	handleBeforeEnter = (event) => !this.destroyed && this.onBeforeEnter.emit(event);
	handleEnter = (event) => !this.destroyed && this.onEnter.emit(event);
	handleAfterEnter = (event) => !this.destroyed && this.onAfterEnter.emit(event);
	handleEnterCancelled = (event) => !this.destroyed && this.onEnterCancelled.emit(event);
	handleBeforeLeave = (event) => !this.destroyed && this.onBeforeLeave.emit(event);
	handleLeave = (event) => !this.destroyed && this.onLeave.emit(event);
	handleAfterLeave = (event) => !this.destroyed && this.onAfterLeave.emit(event);
	handleLeaveCancelled = (event) => !this.destroyed && this.onLeaveCancelled.emit(event);
	constructor() {
		super();
		afterRenderEffect(() => {
			if (!this.$el) return;
			this.motion ??= dt(this.$el, untracked(this.motionOptions));
			const shouldAppear = this.isInitialMount && this.visible() && this.appear();
			const hideStrategy = this.hideStrategy();
			if (this.visible()) {
				resetStyles(this.$el, hideStrategy);
				if (shouldAppear || !this.isInitialMount) {
					this.applyMotionDuration("enter");
					this.motion?.enter();
				}
			} else if (!this.isInitialMount) {
				this.applyMotionDuration("leave");
				this.motion?.leave()?.then(() => {
					if (this.$el && !this.cancelled && !this.visible()) applyHiddenStyles(this.$el, hideStrategy);
				});
			} else applyHiddenStyles(this.$el, hideStrategy);
			this.isInitialMount = false;
		});
	}
	applyMotionDuration(phase) {
		const options = untracked(this.motionOptions);
		const ms = q(options.duration, phase);
		if (ms == null || !this.$el) return;
		const el = this.$el;
		const durationValue = `${ms}ms`;
		if (options.type === "transition") el.style.transitionDuration = durationValue;
		else el.style.animationDuration = durationValue;
	}
	onDestroy() {
		this.destroyed = true;
		this.cancelled = true;
		this.motion?.cancel();
		this.motion = void 0;
		resetStyles(this.$el, this.hideStrategy());
		this.$el?.remove();
		this.isInitialMount = true;
	}
	static ɵfac = function MotionDirective_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || MotionDirective)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: MotionDirective,
		selectors: [[
			"",
			"pMotion",
			""
		]],
		inputs: {
			visible: [
				1,
				"pMotion",
				"visible"
			],
			name: [
				1,
				"pMotionName",
				"name"
			],
			type: [
				1,
				"pMotionType",
				"type"
			],
			safe: [
				1,
				"pMotionSafe",
				"safe"
			],
			disabled: [
				1,
				"pMotionDisabled",
				"disabled"
			],
			appear: [
				1,
				"pMotionAppear",
				"appear"
			],
			enter: [
				1,
				"pMotionEnter",
				"enter"
			],
			leave: [
				1,
				"pMotionLeave",
				"leave"
			],
			duration: [
				1,
				"pMotionDuration",
				"duration"
			],
			hideStrategy: [
				1,
				"pMotionHideStrategy",
				"hideStrategy"
			],
			enterFromClass: [
				1,
				"pMotionEnterFromClass",
				"enterFromClass"
			],
			enterToClass: [
				1,
				"pMotionEnterToClass",
				"enterToClass"
			],
			enterActiveClass: [
				1,
				"pMotionEnterActiveClass",
				"enterActiveClass"
			],
			leaveFromClass: [
				1,
				"pMotionLeaveFromClass",
				"leaveFromClass"
			],
			leaveToClass: [
				1,
				"pMotionLeaveToClass",
				"leaveToClass"
			],
			leaveActiveClass: [
				1,
				"pMotionLeaveActiveClass",
				"leaveActiveClass"
			],
			options: [
				1,
				"pMotionOptions",
				"options"
			]
		},
		outputs: {
			onBeforeEnter: "pMotionOnBeforeEnter",
			onEnter: "pMotionOnEnter",
			onAfterEnter: "pMotionOnAfterEnter",
			onEnterCancelled: "pMotionOnEnterCancelled",
			onBeforeLeave: "pMotionOnBeforeLeave",
			onLeave: "pMotionOnLeave",
			onAfterLeave: "pMotionOnAfterLeave",
			onLeaveCancelled: "pMotionOnLeaveCancelled"
		},
		features: [ɵɵProvidersFeature([
			MotionStyle,
			{
				provide: MOTION_DIRECTIVE_INSTANCE,
				useExisting: MotionDirective
			},
			{
				provide: PARENT_INSTANCE,
				useExisting: MotionDirective
			}
		]), ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MotionDirective, [{
		type: Directive,
		args: [{
			selector: "[pMotion]",
			standalone: true,
			providers: [
				MotionStyle,
				{
					provide: MOTION_DIRECTIVE_INSTANCE,
					useExisting: MotionDirective
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: MotionDirective
				}
			]
		}]
	}], () => [], {
		visible: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotion",
				required: false
			}]
		}],
		name: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionName",
				required: false
			}]
		}],
		type: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionType",
				required: false
			}]
		}],
		safe: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionSafe",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionDisabled",
				required: false
			}]
		}],
		appear: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionAppear",
				required: false
			}]
		}],
		enter: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionEnter",
				required: false
			}]
		}],
		leave: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionLeave",
				required: false
			}]
		}],
		duration: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionDuration",
				required: false
			}]
		}],
		hideStrategy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionHideStrategy",
				required: false
			}]
		}],
		enterFromClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionEnterFromClass",
				required: false
			}]
		}],
		enterToClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionEnterToClass",
				required: false
			}]
		}],
		enterActiveClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionEnterActiveClass",
				required: false
			}]
		}],
		leaveFromClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionLeaveFromClass",
				required: false
			}]
		}],
		leaveToClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionLeaveToClass",
				required: false
			}]
		}],
		leaveActiveClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionLeaveActiveClass",
				required: false
			}]
		}],
		options: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pMotionOptions",
				required: false
			}]
		}],
		onBeforeEnter: [{
			type: Output,
			args: ["pMotionOnBeforeEnter"]
		}],
		onEnter: [{
			type: Output,
			args: ["pMotionOnEnter"]
		}],
		onAfterEnter: [{
			type: Output,
			args: ["pMotionOnAfterEnter"]
		}],
		onEnterCancelled: [{
			type: Output,
			args: ["pMotionOnEnterCancelled"]
		}],
		onBeforeLeave: [{
			type: Output,
			args: ["pMotionOnBeforeLeave"]
		}],
		onLeave: [{
			type: Output,
			args: ["pMotionOnLeave"]
		}],
		onAfterLeave: [{
			type: Output,
			args: ["pMotionOnAfterLeave"]
		}],
		onLeaveCancelled: [{
			type: Output,
			args: ["pMotionOnLeaveCancelled"]
		}]
	});
})();
var MotionModule = class MotionModule {
	static ɵfac = function MotionModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || MotionModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: MotionModule,
		imports: [Motion, MotionDirective],
		exports: [Motion, MotionDirective]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [Motion] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MotionModule, [{
		type: NgModule,
		args: [{
			imports: [Motion, MotionDirective],
			exports: [Motion, MotionDirective]
		}]
	}], null, null);
})();
export { MotionDirective as n, MotionModule as r, Motion as t };
