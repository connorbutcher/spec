import { Ai as setClassMetadata, Ji as ɵɵInheritDefinitionFeature, Wa as ɵɵdefineDirective, _o as ɵɵgetInheritedFactory, un as Directive } from "./core-BenYQOr3.js";
import { Ui as signal, c as computed } from "./_resource-chunk-ejDdmnqV.js";
import { b as l } from "./dist-BRhwYpCB.js";
import { t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
// node_modules/primeng/fesm2022/primeng-basemodelholder.mjs
var BaseModelHolder = class BaseModelHolder extends BaseComponent {
	modelValue = signal(void 0, ...ngDevMode ? [{ debugName: "modelValue" }] : /* istanbul ignore next */ []);
	$filled = computed(() => l(this.modelValue()), ...ngDevMode ? [{ debugName: "$filled" }] : /* istanbul ignore next */ []);
	writeModelValue(value) {
		this.modelValue.set(value);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵBaseModelHolder_BaseFactory = void 0;
		return function BaseModelHolder_Factory(__ngFactoryType__) {
			return (ɵBaseModelHolder_BaseFactory || (ɵBaseModelHolder_BaseFactory = ɵɵgetInheritedFactory(BaseModelHolder)))(__ngFactoryType__ || BaseModelHolder);
		};
	})();
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: BaseModelHolder,
		features: [ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BaseModelHolder, [{
		type: Directive,
		args: [{ standalone: true }]
	}], null, null);
})();
export { BaseModelHolder as t };
