import { $a as ɵɵdomElementEnd, Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Gn as RendererFactory2, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, O as booleanAttribute, Os as ɵɵstyleProp, S as ViewChild, Sn as Input, Ua as ɵɵdefineComponent, Vt as ApplicationRef, Wa as ɵɵdefineDirective, Wn as Renderer2, Xi as ɵɵProvidersFeature, Xs as ɵɵviewQuery, Ya as ɵɵdomElement, Yi as ɵɵNgOnChangesFeature, Zi as ɵɵadvance, Zn as Service, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, eo as ɵɵdomElementStart, fn as ElementRef, fr as ViewContainerRef, ir as TemplateRef, la as ɵɵclassProp, p as IterableDiffers, pr as ViewEncapsulation, qa as ɵɵdefineService, qo as ɵɵprojection, r as ChangeDetectorRef, ss as ɵɵqueryRefresh, un as Directive, vr as afterNextRender, zn as Output, zo as ɵɵloadQuery } from "./core-BenYQOr3.js";
import { Jt as auditTime, Kn as ConnectableObservable, O as shareReplay, Qt as filter, S as startWith, Sn as of, W as pairwise, Wn as Subject, Yn as Observable, _ as takeUntil, rr as Subscription, x as switchMap, yt as distinctUntilChanged } from "./zipWith-3O6QFimT.js";
import { C as animationFrameScheduler, D as asapScheduler, y as isObservable } from "./esm5-mutFUw8P.js";
import { a as coerceNumberProperty, i as coerceElement, o as Platform } from "./_id-generator-chunk-BJRPFgfs.js";
import { D as DestroyRef, Fn as forwardRef, I as EventEmitter, T as DOCUMENT, U as InjectionToken, Ui as signal, W as Injector, _ as untracked, et as NgZone, ua as ɵɵdefineInjector, wr as inject, xn as effect } from "./_resource-chunk-ejDdmnqV.js";
// node_modules/@angular/cdk/fesm2022/_directionality-chunk.mjs
var DIR_DOCUMENT = new InjectionToken("cdk-dir-doc", {
	providedIn: "root",
	factory: () => inject(DOCUMENT)
});
var RTL_LOCALE_PATTERN = /^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;
function _resolveDirectionality(rawValue) {
	const value = rawValue?.toLowerCase() || "";
	if (value === "auto" && typeof navigator !== "undefined" && navigator?.language) return RTL_LOCALE_PATTERN.test(navigator.language) ? "rtl" : "ltr";
	return value === "rtl" ? "rtl" : "ltr";
}
var Directionality = class Directionality {
	get value() {
		return this.valueSignal();
	}
	valueSignal = signal("ltr", ...ngDevMode ? [{ debugName: "valueSignal" }] : []);
	change = new EventEmitter();
	constructor() {
		const _document = inject(DIR_DOCUMENT, { optional: true });
		if (_document) {
			const bodyDir = _document.body ? _document.body.dir : null;
			const htmlDir = _document.documentElement ? _document.documentElement.dir : null;
			this.valueSignal.set(_resolveDirectionality(bodyDir || htmlDir || "ltr"));
		}
	}
	ngOnDestroy() {
		this.change.complete();
	}
	static ɵfac = function Directionality_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Directionality)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: Directionality,
		factory: Directionality.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Directionality, [{ type: Service }], () => [], null);
})();
// node_modules/@angular/cdk/fesm2022/_scrolling-chunk.mjs
var RtlScrollAxisType;
(function(RtlScrollAxisType) {
	RtlScrollAxisType[RtlScrollAxisType["NORMAL"] = 0] = "NORMAL";
	RtlScrollAxisType[RtlScrollAxisType["NEGATED"] = 1] = "NEGATED";
	RtlScrollAxisType[RtlScrollAxisType["INVERTED"] = 2] = "INVERTED";
})(RtlScrollAxisType || (RtlScrollAxisType = {}));
var rtlScrollAxisType;
var scrollBehaviorSupported;
function supportsScrollBehavior() {
	if (scrollBehaviorSupported == null) {
		if (typeof document !== "object" || !document || typeof Element !== "function" || !Element) {
			scrollBehaviorSupported = false;
			return scrollBehaviorSupported;
		}
		if (document.documentElement?.style && "scrollBehavior" in document.documentElement.style) scrollBehaviorSupported = true;
		else {
			const scrollToFunction = Element.prototype.scrollTo;
			if (scrollToFunction) scrollBehaviorSupported = !/\{\s*\[native code\]\s*\}/.test(scrollToFunction.toString());
			else scrollBehaviorSupported = false;
		}
	}
	return scrollBehaviorSupported;
}
function getRtlScrollAxisType() {
	if (typeof document !== "object" || !document) return RtlScrollAxisType.NORMAL;
	if (rtlScrollAxisType == null) {
		const scrollContainer = document.createElement("div");
		const containerStyle = scrollContainer.style;
		scrollContainer.dir = "rtl";
		containerStyle.width = "1px";
		containerStyle.overflow = "auto";
		containerStyle.visibility = "hidden";
		containerStyle.pointerEvents = "none";
		containerStyle.position = "absolute";
		const content = document.createElement("div");
		const contentStyle = content.style;
		contentStyle.width = "2px";
		contentStyle.height = "1px";
		scrollContainer.appendChild(content);
		document.body.appendChild(scrollContainer);
		rtlScrollAxisType = RtlScrollAxisType.NORMAL;
		if (scrollContainer.scrollLeft === 0) {
			scrollContainer.scrollLeft = 1;
			rtlScrollAxisType = scrollContainer.scrollLeft === 0 ? RtlScrollAxisType.NEGATED : RtlScrollAxisType.INVERTED;
		}
		scrollContainer.remove();
	}
	return rtlScrollAxisType;
}
// node_modules/@angular/cdk/fesm2022/_data-source-chunk.mjs
var DataSource = class {};
function isDataSource(value) {
	return value && typeof value.connect === "function" && !(value instanceof ConnectableObservable);
}
// node_modules/@angular/cdk/fesm2022/_recycle-view-repeater-strategy-chunk.mjs
var ArrayDataSource = class extends DataSource {
	_data;
	constructor(_data) {
		super();
		this._data = _data;
	}
	connect() {
		return isObservable(this._data) ? this._data : of(this._data);
	}
	disconnect() {}
};
var _ViewRepeaterOperation;
(function(_ViewRepeaterOperation) {
	_ViewRepeaterOperation[_ViewRepeaterOperation["REPLACED"] = 0] = "REPLACED";
	_ViewRepeaterOperation[_ViewRepeaterOperation["INSERTED"] = 1] = "INSERTED";
	_ViewRepeaterOperation[_ViewRepeaterOperation["MOVED"] = 2] = "MOVED";
	_ViewRepeaterOperation[_ViewRepeaterOperation["REMOVED"] = 3] = "REMOVED";
})(_ViewRepeaterOperation || (_ViewRepeaterOperation = {}));
var _RecycleViewRepeaterStrategy = class {
	viewCacheSize = 20;
	_viewCache = [];
	applyChanges(changes, viewContainerRef, itemContextFactory, itemValueResolver, itemViewChanged) {
		changes.forEachOperation((record, adjustedPreviousIndex, currentIndex) => {
			let view;
			let operation;
			if (record.previousIndex == null) {
				const viewArgsFactory = () => itemContextFactory(record, adjustedPreviousIndex, currentIndex);
				view = this._insertView(viewArgsFactory, currentIndex, viewContainerRef, itemValueResolver(record));
				operation = view ? _ViewRepeaterOperation.INSERTED : _ViewRepeaterOperation.REPLACED;
			} else if (currentIndex == null) {
				this._detachAndCacheView(adjustedPreviousIndex, viewContainerRef);
				operation = _ViewRepeaterOperation.REMOVED;
			} else {
				view = this._moveView(adjustedPreviousIndex, currentIndex, viewContainerRef, itemValueResolver(record));
				operation = _ViewRepeaterOperation.MOVED;
			}
			if (itemViewChanged) itemViewChanged({
				context: view?.context,
				operation,
				record
			});
		});
	}
	detach() {
		for (const view of this._viewCache) view.destroy();
		this._viewCache = [];
	}
	_insertView(viewArgsFactory, currentIndex, viewContainerRef, value) {
		const cachedView = this._insertViewFromCache(currentIndex, viewContainerRef);
		if (cachedView) {
			cachedView.context.$implicit = value;
			return;
		}
		const viewArgs = viewArgsFactory();
		return viewContainerRef.createEmbeddedView(viewArgs.templateRef, viewArgs.context, viewArgs.index);
	}
	_detachAndCacheView(index, viewContainerRef) {
		const detachedView = viewContainerRef.detach(index);
		this._maybeCacheView(detachedView, viewContainerRef);
	}
	_moveView(adjustedPreviousIndex, currentIndex, viewContainerRef, value) {
		const view = viewContainerRef.get(adjustedPreviousIndex);
		viewContainerRef.move(view, currentIndex);
		view.context.$implicit = value;
		return view;
	}
	_maybeCacheView(view, viewContainerRef) {
		if (this._viewCache.length < this.viewCacheSize) this._viewCache.push(view);
		else {
			const index = viewContainerRef.indexOf(view);
			if (index === -1) view.destroy();
			else viewContainerRef.remove(index);
		}
	}
	_insertViewFromCache(index, viewContainerRef) {
		const cachedView = this._viewCache.pop();
		if (cachedView) viewContainerRef.insert(cachedView, index);
		return cachedView || null;
	}
};
// node_modules/@angular/cdk/fesm2022/bidi.mjs
var Dir = class Dir {
	_isInitialized = false;
	_rawDir = "";
	change = new EventEmitter();
	get dir() {
		return this.valueSignal();
	}
	set dir(value) {
		const previousValue = this.valueSignal();
		this.valueSignal.set(_resolveDirectionality(value));
		this._rawDir = value;
		if (previousValue !== this.valueSignal() && this._isInitialized) this.change.emit(this.valueSignal());
	}
	get value() {
		return this.dir;
	}
	valueSignal = signal("ltr", ...ngDevMode ? [{ debugName: "valueSignal" }] : []);
	ngAfterContentInit() {
		this._isInitialized = true;
	}
	ngOnDestroy() {
		this.change.complete();
	}
	static ɵfac = function Dir_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Dir)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: Dir,
		selectors: [[
			"",
			"dir",
			""
		]],
		hostVars: 1,
		hostBindings: function Dir_HostBindings(rf, ctx) {
			if (rf & 2) ɵɵattribute("dir", ctx._rawDir);
		},
		inputs: { dir: "dir" },
		outputs: { change: "dirChange" },
		exportAs: ["dir"],
		features: [ɵɵProvidersFeature([{
			provide: Directionality,
			useExisting: Dir
		}])]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dir, [{
		type: Directive,
		args: [{
			selector: "[dir]",
			providers: [{
				provide: Directionality,
				useExisting: Dir
			}],
			host: { "[attr.dir]": "_rawDir" },
			exportAs: "dir"
		}]
	}], null, {
		change: [{
			type: Output,
			args: ["dirChange"]
		}],
		dir: [{ type: Input }]
	});
})();
var BidiModule = class BidiModule {
	static ɵfac = function BidiModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || BidiModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: BidiModule,
		imports: [Dir],
		exports: [Dir]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BidiModule, [{
		type: NgModule,
		args: [{
			imports: [Dir],
			exports: [Dir]
		}]
	}], null, null);
})();
// node_modules/@angular/cdk/fesm2022/scrolling.mjs
var VIRTUAL_SCROLL_STRATEGY = new InjectionToken("VIRTUAL_SCROLL_STRATEGY");
var FixedSizeVirtualScrollStrategy = class {
	_scrolledIndexChange = new Subject();
	scrolledIndexChange = this._scrolledIndexChange.pipe(distinctUntilChanged());
	_viewport = null;
	_itemSize;
	_minBufferPx;
	_maxBufferPx;
	constructor(itemSize, minBufferPx, maxBufferPx) {
		this._itemSize = itemSize;
		this._minBufferPx = minBufferPx;
		this._maxBufferPx = maxBufferPx;
	}
	attach(viewport) {
		this._viewport = viewport;
		this._updateTotalContentSize();
		this._updateRenderedRange();
	}
	detach() {
		this._scrolledIndexChange.complete();
		this._viewport = null;
	}
	updateItemAndBufferSize(itemSize, minBufferPx, maxBufferPx) {
		if (maxBufferPx < minBufferPx && (typeof ngDevMode === "undefined" || ngDevMode)) throw Error("CDK virtual scroll: maxBufferPx must be greater than or equal to minBufferPx");
		this._itemSize = itemSize;
		this._minBufferPx = minBufferPx;
		this._maxBufferPx = maxBufferPx;
		this._updateTotalContentSize();
		this._updateRenderedRange();
	}
	onContentScrolled() {
		this._updateRenderedRange();
	}
	onDataLengthChanged() {
		this._updateTotalContentSize();
		this._updateRenderedRange();
	}
	onContentRendered() {}
	onRenderedOffsetChanged() {}
	scrollToIndex(index, behavior) {
		if (this._viewport) this._viewport.scrollToOffset(index * this._itemSize, behavior);
	}
	_updateTotalContentSize() {
		if (!this._viewport) return;
		this._viewport.setTotalContentSize(this._viewport.getDataLength() * this._itemSize);
	}
	_updateRenderedRange() {
		if (!this._viewport) return;
		const renderedRange = this._viewport.getRenderedRange();
		const newRange = {
			start: renderedRange.start,
			end: renderedRange.end
		};
		const viewportSize = this._viewport.getViewportSize();
		const dataLength = this._viewport.getDataLength();
		let scrollOffset = this._viewport.measureScrollOffset();
		let firstVisibleIndex = this._itemSize > 0 ? scrollOffset / this._itemSize : 0;
		if (newRange.end > dataLength) {
			const maxVisibleItems = Math.ceil(viewportSize / this._itemSize);
			const newVisibleIndex = Math.max(0, Math.min(firstVisibleIndex, dataLength - maxVisibleItems));
			if (firstVisibleIndex != newVisibleIndex) {
				firstVisibleIndex = newVisibleIndex;
				scrollOffset = newVisibleIndex * this._itemSize;
				newRange.start = Math.floor(firstVisibleIndex);
			}
			newRange.end = Math.max(0, Math.min(dataLength, newRange.start + maxVisibleItems));
		}
		const startBuffer = scrollOffset - newRange.start * this._itemSize;
		if (startBuffer < this._minBufferPx && newRange.start != 0) {
			const expandStart = Math.ceil((this._maxBufferPx - startBuffer) / this._itemSize);
			newRange.start = Math.max(0, newRange.start - expandStart);
			newRange.end = Math.min(dataLength, Math.ceil(firstVisibleIndex + (viewportSize + this._minBufferPx) / this._itemSize));
		} else {
			const endBuffer = newRange.end * this._itemSize - (scrollOffset + viewportSize);
			if (endBuffer < this._minBufferPx && newRange.end != dataLength) {
				const expandEnd = Math.ceil((this._maxBufferPx - endBuffer) / this._itemSize);
				if (expandEnd > 0) {
					newRange.end = Math.min(dataLength, newRange.end + expandEnd);
					newRange.start = Math.max(0, Math.floor(firstVisibleIndex - this._minBufferPx / this._itemSize));
				}
			}
		}
		this._viewport.setRenderedRange(newRange);
		this._viewport.setRenderedContentOffset(Math.round(this._itemSize * newRange.start));
		this._scrolledIndexChange.next(Math.floor(firstVisibleIndex));
	}
};
function _fixedSizeVirtualScrollStrategyFactory(fixedSizeDir) {
	return fixedSizeDir._scrollStrategy;
}
var CdkFixedSizeVirtualScroll = class CdkFixedSizeVirtualScroll {
	get itemSize() {
		return this._itemSize;
	}
	set itemSize(value) {
		this._itemSize = coerceNumberProperty(value);
	}
	_itemSize = 20;
	get minBufferPx() {
		return this._minBufferPx;
	}
	set minBufferPx(value) {
		this._minBufferPx = coerceNumberProperty(value);
	}
	_minBufferPx = 100;
	get maxBufferPx() {
		return this._maxBufferPx;
	}
	set maxBufferPx(value) {
		this._maxBufferPx = coerceNumberProperty(value);
	}
	_maxBufferPx = 200;
	_scrollStrategy = new FixedSizeVirtualScrollStrategy(this.itemSize, this.minBufferPx, this.maxBufferPx);
	ngOnChanges() {
		this._scrollStrategy.updateItemAndBufferSize(this.itemSize, this.minBufferPx, this.maxBufferPx);
	}
	static ɵfac = function CdkFixedSizeVirtualScroll_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkFixedSizeVirtualScroll)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: CdkFixedSizeVirtualScroll,
		selectors: [[
			"cdk-virtual-scroll-viewport",
			"itemSize",
			""
		]],
		inputs: {
			itemSize: "itemSize",
			minBufferPx: "minBufferPx",
			maxBufferPx: "maxBufferPx"
		},
		features: [ɵɵProvidersFeature([{
			provide: VIRTUAL_SCROLL_STRATEGY,
			useFactory: _fixedSizeVirtualScrollStrategyFactory,
			deps: [forwardRef(() => CdkFixedSizeVirtualScroll)]
		}]), ɵɵNgOnChangesFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkFixedSizeVirtualScroll, [{
		type: Directive,
		args: [{
			selector: "cdk-virtual-scroll-viewport[itemSize]",
			providers: [{
				provide: VIRTUAL_SCROLL_STRATEGY,
				useFactory: _fixedSizeVirtualScrollStrategyFactory,
				deps: [forwardRef(() => CdkFixedSizeVirtualScroll)]
			}]
		}]
	}], null, {
		itemSize: [{ type: Input }],
		minBufferPx: [{ type: Input }],
		maxBufferPx: [{ type: Input }]
	});
})();
var ScrollDispatcher = class ScrollDispatcher {
	_ngZone = inject(NgZone);
	_platform = inject(Platform);
	_renderer = inject(RendererFactory2).createRenderer(null, null);
	_cleanupGlobalListener;
	_scrolled = new Subject();
	_scrolledCount = 0;
	scrollContainers = /* @__PURE__ */ new Map();
	register(target) {
		if (!this.scrollContainers.has(target)) this.scrollContainers.set(target, target.elementScrolled().subscribe(() => this._scrolled.next(target)));
	}
	deregister(target) {
		const ref = this.scrollContainers.get(target);
		if (ref) {
			ref.unsubscribe();
			this.scrollContainers.delete(target);
		}
	}
	scrolled(auditTimeInMs = 20) {
		if (!this._platform.isBrowser) return of();
		return new Observable((observer) => {
			if (!this._cleanupGlobalListener) this._cleanupGlobalListener = this._ngZone.runOutsideAngular(() => this._renderer.listen("document", "scroll", () => this._scrolled.next()));
			const subscription = auditTimeInMs > 0 ? this._scrolled.pipe(auditTime(auditTimeInMs)).subscribe(observer) : this._scrolled.subscribe(observer);
			this._scrolledCount++;
			return () => {
				subscription.unsubscribe();
				this._scrolledCount--;
				if (!this._scrolledCount) {
					this._cleanupGlobalListener?.();
					this._cleanupGlobalListener = void 0;
				}
			};
		});
	}
	ngOnDestroy() {
		this._cleanupGlobalListener?.();
		this._cleanupGlobalListener = void 0;
		this.scrollContainers.forEach((_, container) => this.deregister(container));
		this._scrolled.complete();
	}
	ancestorScrolled(elementOrElementRef, auditTimeInMs) {
		const ancestors = this.getAncestorScrollContainers(elementOrElementRef);
		return this.scrolled(auditTimeInMs).pipe(filter((target) => !target || ancestors.indexOf(target) > -1));
	}
	getAncestorScrollContainers(elementOrElementRef) {
		const scrollingContainers = [];
		this.scrollContainers.forEach((_, target) => {
			if (this._targetContainsElement(target, elementOrElementRef)) scrollingContainers.push(target);
		});
		return scrollingContainers;
	}
	_targetContainsElement(scrollable, elementOrElementRef) {
		let element = coerceElement(elementOrElementRef);
		let targetElement = scrollable.getElementRef().nativeElement;
		do
			if (element == targetElement) return true;
		while (element = element.parentElement);
		return false;
	}
	static ɵfac = function ScrollDispatcher_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ScrollDispatcher)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ScrollDispatcher,
		factory: ScrollDispatcher.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ScrollDispatcher, [{ type: Service }], null, null);
})();
var CdkScrollable = class CdkScrollable {
	elementRef = inject(ElementRef);
	scrollDispatcher = inject(ScrollDispatcher);
	ngZone = inject(NgZone);
	dir = inject(Directionality, { optional: true });
	_scrollElement = this.elementRef.nativeElement;
	_destroyed = new Subject();
	_renderer = inject(Renderer2);
	_cleanupScroll;
	_elementScrolled = new Subject();
	ngOnInit() {
		this._cleanupScroll = this.ngZone.runOutsideAngular(() => this._renderer.listen(this._scrollElement, "scroll", (event) => this._elementScrolled.next(event)));
		this.scrollDispatcher.register(this);
	}
	ngOnDestroy() {
		this._cleanupScroll?.();
		this._elementScrolled.complete();
		this.scrollDispatcher.deregister(this);
		this._destroyed.next();
		this._destroyed.complete();
	}
	elementScrolled() {
		return this._elementScrolled;
	}
	getElementRef() {
		return this.elementRef;
	}
	scrollTo(options) {
		const el = this.elementRef.nativeElement;
		const isRtl = this.dir && this.dir.value == "rtl";
		if (options.left == null) options.left = isRtl ? options.end : options.start;
		if (options.right == null) options.right = isRtl ? options.start : options.end;
		if (options.bottom != null) options.top = el.scrollHeight - el.clientHeight - options.bottom;
		if (isRtl && getRtlScrollAxisType() != RtlScrollAxisType.NORMAL) {
			if (options.left != null) options.right = el.scrollWidth - el.clientWidth - options.left;
			if (getRtlScrollAxisType() == RtlScrollAxisType.INVERTED) options.left = options.right;
			else if (getRtlScrollAxisType() == RtlScrollAxisType.NEGATED) options.left = options.right ? -options.right : options.right;
		} else if (options.right != null) options.left = el.scrollWidth - el.clientWidth - options.right;
		this._applyScrollToOptions(options);
	}
	_applyScrollToOptions(options) {
		const el = this.elementRef.nativeElement;
		if (supportsScrollBehavior()) el.scrollTo(options);
		else {
			if (options.top != null) el.scrollTop = options.top;
			if (options.left != null) el.scrollLeft = options.left;
		}
	}
	measureScrollOffset(from) {
		const LEFT = "left";
		const RIGHT = "right";
		const el = this.elementRef.nativeElement;
		if (from == "top") return el.scrollTop;
		if (from == "bottom") return el.scrollHeight - el.clientHeight - el.scrollTop;
		const isRtl = this.dir && this.dir.value == "rtl";
		if (from == "start") from = isRtl ? RIGHT : LEFT;
		else if (from == "end") from = isRtl ? LEFT : RIGHT;
		if (isRtl && getRtlScrollAxisType() == RtlScrollAxisType.INVERTED) {
			if (from == LEFT) return el.scrollWidth - el.clientWidth - el.scrollLeft;
			else return el.scrollLeft;
		} else if (isRtl && getRtlScrollAxisType() == RtlScrollAxisType.NEGATED) {
			if (from == LEFT) return el.scrollLeft + el.scrollWidth - el.clientWidth;
			else return -el.scrollLeft;
		} else if (from == LEFT) return el.scrollLeft;
		else return el.scrollWidth - el.clientWidth - el.scrollLeft;
	}
	static ɵfac = function CdkScrollable_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkScrollable)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: CdkScrollable,
		selectors: [[
			"",
			"cdk-scrollable",
			""
		], [
			"",
			"cdkScrollable",
			""
		]]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkScrollable, [{
		type: Directive,
		args: [{ selector: "[cdk-scrollable], [cdkScrollable]" }]
	}], null, null);
})();
var ViewportRuler = class ViewportRuler {
	_platform = inject(Platform);
	_listeners;
	_viewportSize = null;
	_change = new Subject();
	_document = inject(DOCUMENT);
	constructor() {
		const ngZone = inject(NgZone);
		const renderer = inject(RendererFactory2).createRenderer(null, null);
		ngZone.runOutsideAngular(() => {
			if (this._platform.isBrowser) {
				const changeListener = (event) => this._change.next(event);
				this._listeners = [renderer.listen("window", "resize", changeListener), renderer.listen("window", "orientationchange", changeListener)];
			}
			this.change().subscribe(() => this._viewportSize = null);
		});
	}
	ngOnDestroy() {
		this._listeners?.forEach((cleanup) => cleanup());
		this._change.complete();
	}
	getViewportSize() {
		if (!this._viewportSize) this._updateViewportSize();
		const output = {
			width: this._viewportSize.width,
			height: this._viewportSize.height
		};
		if (!this._platform.isBrowser) this._viewportSize = null;
		return output;
	}
	getViewportRect() {
		const scrollPosition = this.getViewportScrollPosition();
		const { width, height } = this.getViewportSize();
		return {
			top: scrollPosition.top,
			left: scrollPosition.left,
			bottom: scrollPosition.top + height,
			right: scrollPosition.left + width,
			height,
			width
		};
	}
	getViewportScrollPosition() {
		if (!this._platform.isBrowser) return {
			top: 0,
			left: 0
		};
		const document = this._document;
		const window = this._getWindow();
		const documentElement = document.documentElement;
		const documentRect = documentElement.getBoundingClientRect();
		return {
			top: -documentRect.top || document.body?.scrollTop || window.scrollY || documentElement.scrollTop || 0,
			left: -documentRect.left || document.body?.scrollLeft || window.scrollX || documentElement.scrollLeft || 0
		};
	}
	change(throttleTime = 20) {
		return throttleTime > 0 ? this._change.pipe(auditTime(throttleTime)) : this._change;
	}
	_getWindow() {
		return this._document.defaultView || window;
	}
	_updateViewportSize() {
		const window = this._getWindow();
		this._viewportSize = this._platform.isBrowser ? {
			width: window.innerWidth,
			height: window.innerHeight
		} : {
			width: 0,
			height: 0
		};
	}
	static ɵfac = function ViewportRuler_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ViewportRuler)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: ViewportRuler,
		factory: ViewportRuler.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ViewportRuler, [{ type: Service }], () => [], null);
})();
var VIRTUAL_SCROLLABLE = new InjectionToken("VIRTUAL_SCROLLABLE");
var CdkVirtualScrollable = class CdkVirtualScrollable extends CdkScrollable {
	measureViewportSize(orientation) {
		const viewportEl = this.elementRef.nativeElement;
		return orientation === "horizontal" ? viewportEl.clientWidth : viewportEl.clientHeight;
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵCdkVirtualScrollable_BaseFactory = void 0;
		return function CdkVirtualScrollable_Factory(__ngFactoryType__) {
			return (ɵCdkVirtualScrollable_BaseFactory || (ɵCdkVirtualScrollable_BaseFactory = ɵɵgetInheritedFactory(CdkVirtualScrollable)))(__ngFactoryType__ || CdkVirtualScrollable);
		};
	})();
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: CdkVirtualScrollable,
		features: [ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkVirtualScrollable, [{ type: Directive }], null, null);
})();
function rangesEqual(r1, r2) {
	return r1.start == r2.start && r1.end == r2.end;
}
var SCROLL_SCHEDULER = typeof requestAnimationFrame !== "undefined" ? animationFrameScheduler : asapScheduler;
var CDK_VIRTUAL_SCROLL_VIEWPORT = new InjectionToken("CDK_VIRTUAL_SCROLL_VIEWPORT");
var CdkVirtualScrollViewport = class CdkVirtualScrollViewport extends CdkVirtualScrollable {
	elementRef = inject(ElementRef);
	_changeDetectorRef = inject(ChangeDetectorRef);
	_scrollStrategy = inject(VIRTUAL_SCROLL_STRATEGY, { optional: true });
	scrollable = inject(VIRTUAL_SCROLLABLE, { optional: true });
	_platform = inject(Platform);
	_detachedSubject = new Subject();
	_renderedRangeSubject = new Subject();
	_renderedContentOffsetSubject = new Subject();
	get orientation() {
		return this._orientation;
	}
	set orientation(orientation) {
		if (this._orientation !== orientation) {
			this._orientation = orientation;
			this._calculateSpacerSize();
		}
	}
	_orientation = "vertical";
	appendOnly = false;
	scrolledIndexChange = new Observable((observer) => this._scrollStrategy.scrolledIndexChange.subscribe((index) => Promise.resolve().then(() => this.ngZone.run(() => observer.next(index)))));
	_contentWrapper;
	renderedRangeStream = this._renderedRangeSubject;
	renderedContentOffset = this._renderedContentOffsetSubject.pipe(filter((offset) => offset !== null), distinctUntilChanged());
	_totalContentSize = 0;
	_totalContentWidth = signal("", ...ngDevMode ? [{ debugName: "_totalContentWidth" }] : []);
	_totalContentHeight = signal("", ...ngDevMode ? [{ debugName: "_totalContentHeight" }] : []);
	_renderedContentTransform;
	_renderedRange = {
		start: 0,
		end: 0
	};
	_dataLength = 0;
	_viewportSize = 0;
	_forOf = null;
	_renderedContentOffset = 0;
	_renderedContentOffsetNeedsRewrite = false;
	_changeDetectionNeeded = signal(false, ...ngDevMode ? [{ debugName: "_changeDetectionNeeded" }] : []);
	_runAfterChangeDetection = [];
	_viewportChanges = Subscription.EMPTY;
	_injector = inject(Injector);
	_isDestroyed = false;
	constructor() {
		super();
		const viewportRuler = inject(ViewportRuler);
		if (!this._scrollStrategy && (typeof ngDevMode === "undefined" || ngDevMode)) throw Error("Error: cdk-virtual-scroll-viewport requires the \"itemSize\" property to be set.");
		this._viewportChanges = viewportRuler.change().subscribe(() => {
			this.checkViewportSize();
		});
		if (!this.scrollable) {
			this.elementRef.nativeElement.classList.add("cdk-virtual-scrollable");
			this.scrollable = this;
		}
		const ref = effect(() => {
			if (this._changeDetectionNeeded()) this._doChangeDetection();
		}, {
			...ngDevMode ? { debugName: "ref" } : {},
			injector: inject(ApplicationRef).injector
		});
		inject(DestroyRef).onDestroy(() => void ref.destroy());
	}
	ngOnInit() {
		if (!this._platform.isBrowser) return;
		if (this.scrollable === this) super.ngOnInit();
		this.ngZone.runOutsideAngular(() => Promise.resolve().then(() => {
			this._measureViewportSize();
			this._scrollStrategy.attach(this);
			this.scrollable.elementScrolled().pipe(startWith(null), auditTime(0, SCROLL_SCHEDULER), takeUntil(this._destroyed)).subscribe(() => this._scrollStrategy.onContentScrolled());
			this._markChangeDetectionNeeded();
		}));
	}
	ngOnDestroy() {
		this.detach();
		this._scrollStrategy.detach();
		this._renderedRangeSubject.complete();
		this._detachedSubject.complete();
		this._viewportChanges.unsubscribe();
		this._isDestroyed = true;
		super.ngOnDestroy();
	}
	attach(forOf) {
		if (this._forOf && (typeof ngDevMode === "undefined" || ngDevMode)) throw Error("CdkVirtualScrollViewport is already attached.");
		this.ngZone.runOutsideAngular(() => {
			this._forOf = forOf;
			this._forOf.dataStream.pipe(takeUntil(this._detachedSubject)).subscribe((data) => {
				const newLength = data.length;
				if (newLength !== this._dataLength) {
					this._dataLength = newLength;
					this._scrollStrategy.onDataLengthChanged();
				}
				this._doChangeDetection();
			});
		});
	}
	detach() {
		this._forOf = null;
		this._detachedSubject.next();
	}
	getDataLength() {
		return this._dataLength;
	}
	getViewportSize() {
		return this._viewportSize;
	}
	getRenderedRange() {
		return this._renderedRange;
	}
	measureBoundingClientRectWithScrollOffset(from) {
		return this.getElementRef().nativeElement.getBoundingClientRect()[from];
	}
	setTotalContentSize(size) {
		if (this._totalContentSize !== size) {
			this._totalContentSize = size;
			this._calculateSpacerSize();
			this._markChangeDetectionNeeded();
		}
	}
	setRenderedRange(range) {
		if (!rangesEqual(this._renderedRange, range)) {
			if (this.appendOnly) range = {
				start: 0,
				end: Math.max(this._renderedRange.end, range.end)
			};
			this._renderedRangeSubject.next(this._renderedRange = range);
			this._markChangeDetectionNeeded(() => this._scrollStrategy.onContentRendered());
		}
	}
	getOffsetToRenderedContentStart() {
		return this._renderedContentOffsetNeedsRewrite ? null : this._renderedContentOffset;
	}
	setRenderedContentOffset(offset, to = "to-start") {
		offset = this.appendOnly && to === "to-start" ? 0 : offset;
		const isRtl = this.dir && this.dir.value == "rtl";
		const isHorizontal = this.orientation == "horizontal";
		const axis = isHorizontal ? "X" : "Y";
		let transform = `translate${axis}(${Number((isHorizontal && isRtl ? -1 : 1) * offset)}px)`;
		this._renderedContentOffset = offset;
		if (to === "to-end") {
			transform += ` translate${axis}(-100%)`;
			this._renderedContentOffsetNeedsRewrite = true;
		}
		if (this._renderedContentTransform != transform) {
			this._renderedContentTransform = transform;
			this._markChangeDetectionNeeded(() => {
				if (this._renderedContentOffsetNeedsRewrite) {
					this._renderedContentOffset -= this.measureRenderedContentSize();
					this._renderedContentOffsetNeedsRewrite = false;
					this.setRenderedContentOffset(this._renderedContentOffset);
				} else this._scrollStrategy.onRenderedOffsetChanged();
			});
		}
	}
	scrollToOffset(offset, behavior = "auto") {
		const options = { behavior };
		if (this.orientation === "horizontal") options.start = offset;
		else options.top = offset;
		this.scrollable.scrollTo(options);
	}
	scrollToIndex(index, behavior = "auto") {
		this._scrollStrategy.scrollToIndex(index, behavior);
	}
	measureScrollOffset(from) {
		let measureScrollOffset;
		if (this.scrollable == this) measureScrollOffset = (_from) => super.measureScrollOffset(_from);
		else measureScrollOffset = (_from) => this.scrollable.measureScrollOffset(_from);
		return Math.max(0, measureScrollOffset(from ?? (this.orientation === "horizontal" ? "start" : "top")) - this.measureViewportOffset());
	}
	measureViewportOffset(from) {
		let fromRect;
		const LEFT = "left";
		const RIGHT = "right";
		const isRtl = this.dir?.value == "rtl";
		if (from == "start") fromRect = isRtl ? RIGHT : LEFT;
		else if (from == "end") fromRect = isRtl ? LEFT : RIGHT;
		else if (from) fromRect = from;
		else fromRect = this.orientation === "horizontal" ? "left" : "top";
		const scrollerClientRect = this.scrollable.measureBoundingClientRectWithScrollOffset(fromRect);
		return this.elementRef.nativeElement.getBoundingClientRect()[fromRect] - scrollerClientRect;
	}
	measureRenderedContentSize() {
		const contentEl = this._contentWrapper.nativeElement;
		return this.orientation === "horizontal" ? contentEl.offsetWidth : contentEl.offsetHeight;
	}
	measureRangeSize(range) {
		if (!this._forOf) return 0;
		return this._forOf.measureRangeSize(range, this.orientation);
	}
	checkViewportSize() {
		this._measureViewportSize();
		this._scrollStrategy.onDataLengthChanged();
	}
	_measureViewportSize() {
		this._viewportSize = this.scrollable.measureViewportSize(this.orientation);
	}
	_markChangeDetectionNeeded(runAfter) {
		if (runAfter) this._runAfterChangeDetection.push(runAfter);
		if (untracked(this._changeDetectionNeeded)) return;
		this.ngZone.runOutsideAngular(() => {
			Promise.resolve().then(() => {
				this.ngZone.run(() => {
					this._changeDetectionNeeded.set(true);
				});
			});
		});
	}
	_doChangeDetection() {
		if (this._isDestroyed) return;
		this.ngZone.run(() => {
			this._changeDetectorRef.markForCheck();
			this._contentWrapper.nativeElement.style.transform = this._renderedContentTransform;
			this._renderedContentOffsetSubject.next(this.getOffsetToRenderedContentStart());
			afterNextRender(() => {
				this._changeDetectionNeeded.set(false);
				const runAfterChangeDetection = this._runAfterChangeDetection;
				this._runAfterChangeDetection = [];
				for (const fn of runAfterChangeDetection) fn();
			}, { injector: this._injector });
		});
	}
	_calculateSpacerSize() {
		this._totalContentHeight.set(this.orientation === "horizontal" ? "" : `${this._totalContentSize}px`);
		this._totalContentWidth.set(this.orientation === "horizontal" ? `${this._totalContentSize}px` : "");
	}
	static ɵfac = function CdkVirtualScrollViewport_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkVirtualScrollViewport)();
	};
	static ɵcmp = (function() {
		const _c0 = ["contentWrapper"];
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: CdkVirtualScrollViewport,
			selectors: [["cdk-virtual-scroll-viewport"]],
			viewQuery: function CdkVirtualScrollViewport_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuery(_c0, 7);
				if (rf & 2) {
					let _t = void 0;
					ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx._contentWrapper = _t.first);
				}
			},
			hostAttrs: [1, "cdk-virtual-scroll-viewport"],
			hostVars: 4,
			hostBindings: function CdkVirtualScrollViewport_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassProp("cdk-virtual-scroll-orientation-horizontal", ctx.orientation === "horizontal")("cdk-virtual-scroll-orientation-vertical", ctx.orientation !== "horizontal");
			},
			inputs: {
				orientation: "orientation",
				appendOnly: [
					2,
					"appendOnly",
					"appendOnly",
					booleanAttribute
				]
			},
			outputs: { scrolledIndexChange: "scrolledIndexChange" },
			features: [ɵɵProvidersFeature([{
				provide: CdkScrollable,
				useFactory: () => inject(VIRTUAL_SCROLLABLE, { optional: true }) || inject(CdkVirtualScrollViewport)
			}, {
				provide: CDK_VIRTUAL_SCROLL_VIEWPORT,
				useExisting: CdkVirtualScrollViewport
			}]), ɵɵInheritDefinitionFeature],
			ngContentSelectors: ["*"],
			decls: 4,
			vars: 4,
			consts: [
				["contentWrapper", ""],
				[1, "cdk-virtual-scroll-content-wrapper"],
				[1, "cdk-virtual-scroll-spacer"]
			],
			template: function CdkVirtualScrollViewport_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵdomElementStart(0, "div", 1, 0);
					ɵɵprojection(2);
					ɵɵdomElementEnd();
					ɵɵdomElement(3, "div", 2);
				}
				if (rf & 2) {
					ɵɵadvance(3);
					ɵɵstyleProp("width", ctx._totalContentWidth())("height", ctx._totalContentHeight());
				}
			},
			styles: ["cdk-virtual-scroll-viewport {\n  display: block;\n  position: relative;\n  transform: translateZ(0);\n}\n\n.cdk-virtual-scrollable {\n  overflow: auto;\n  will-change: scroll-position;\n  contain: strict;\n  overflow-anchor: none;\n  scroll-behavior: auto;\n}\n\n.cdk-virtual-scroll-content-wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  contain: content;\n}\n[dir=rtl] .cdk-virtual-scroll-content-wrapper {\n  right: 0;\n  left: auto;\n}\n\n.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper {\n  min-height: 100%;\n}\n.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > dl:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > ol:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > table:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > ul:not([cdkVirtualFor]) {\n  padding-left: 0;\n  padding-right: 0;\n  margin-left: 0;\n  margin-right: 0;\n  border-left-width: 0;\n  border-right-width: 0;\n  outline: none;\n}\n\n.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper {\n  min-width: 100%;\n}\n.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > dl:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > ol:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > table:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > ul:not([cdkVirtualFor]) {\n  padding-top: 0;\n  padding-bottom: 0;\n  margin-top: 0;\n  margin-bottom: 0;\n  border-top-width: 0;\n  border-bottom-width: 0;\n  outline: none;\n}\n\n.cdk-virtual-scroll-spacer {\n  height: 1px;\n  transform-origin: 0 0;\n  flex: 0 0 auto;\n}\n[dir=rtl] .cdk-virtual-scroll-spacer {\n  transform-origin: 100% 0;\n}\n"],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkVirtualScrollViewport, [{
		type: Component,
		args: [{
			selector: "cdk-virtual-scroll-viewport",
			host: {
				"class": "cdk-virtual-scroll-viewport",
				"[class.cdk-virtual-scroll-orientation-horizontal]": "orientation === \"horizontal\"",
				"[class.cdk-virtual-scroll-orientation-vertical]": "orientation !== \"horizontal\""
			},
			encapsulation: ViewEncapsulation.None,
			providers: [{
				provide: CdkScrollable,
				useFactory: () => inject(VIRTUAL_SCROLLABLE, { optional: true }) || inject(CdkVirtualScrollViewport)
			}, {
				provide: CDK_VIRTUAL_SCROLL_VIEWPORT,
				useExisting: CdkVirtualScrollViewport
			}],
			template: "<!--\n  Wrap the rendered content in an element that will be used to offset it based on the scroll\n  position.\n-->\n<div #contentWrapper class=\"cdk-virtual-scroll-content-wrapper\">\n  <ng-content></ng-content>\n</div>\n<!--\n  Spacer used to force the scrolling container to the correct size for the *total* number of items\n  so that the scrollbar captures the size of the entire data set.\n-->\n<div class=\"cdk-virtual-scroll-spacer\"\n     [style.width]=\"_totalContentWidth()\" [style.height]=\"_totalContentHeight()\"></div>\n",
			styles: ["cdk-virtual-scroll-viewport {\n  display: block;\n  position: relative;\n  transform: translateZ(0);\n}\n\n.cdk-virtual-scrollable {\n  overflow: auto;\n  will-change: scroll-position;\n  contain: strict;\n  overflow-anchor: none;\n  scroll-behavior: auto;\n}\n\n.cdk-virtual-scroll-content-wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  contain: content;\n}\n[dir=rtl] .cdk-virtual-scroll-content-wrapper {\n  right: 0;\n  left: auto;\n}\n\n.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper {\n  min-height: 100%;\n}\n.cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > dl:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > ol:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > table:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-horizontal .cdk-virtual-scroll-content-wrapper > ul:not([cdkVirtualFor]) {\n  padding-left: 0;\n  padding-right: 0;\n  margin-left: 0;\n  margin-right: 0;\n  border-left-width: 0;\n  border-right-width: 0;\n  outline: none;\n}\n\n.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper {\n  min-width: 100%;\n}\n.cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > dl:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > ol:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > table:not([cdkVirtualFor]), .cdk-virtual-scroll-orientation-vertical .cdk-virtual-scroll-content-wrapper > ul:not([cdkVirtualFor]) {\n  padding-top: 0;\n  padding-bottom: 0;\n  margin-top: 0;\n  margin-bottom: 0;\n  border-top-width: 0;\n  border-bottom-width: 0;\n  outline: none;\n}\n\n.cdk-virtual-scroll-spacer {\n  height: 1px;\n  transform-origin: 0 0;\n  flex: 0 0 auto;\n}\n[dir=rtl] .cdk-virtual-scroll-spacer {\n  transform-origin: 100% 0;\n}\n"]
		}]
	}], () => [], {
		orientation: [{ type: Input }],
		appendOnly: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		scrolledIndexChange: [{ type: Output }],
		_contentWrapper: [{
			type: ViewChild,
			args: ["contentWrapper", { static: true }]
		}]
	});
})();
function getOffset(orientation, direction, node) {
	const el = node;
	if (!el.getBoundingClientRect) return 0;
	const rect = el.getBoundingClientRect();
	if (orientation === "horizontal") return direction === "start" ? rect.left : rect.right;
	return direction === "start" ? rect.top : rect.bottom;
}
var CdkVirtualForOf = class CdkVirtualForOf {
	_viewContainerRef = inject(ViewContainerRef);
	_template = inject(TemplateRef);
	_differs = inject(IterableDiffers);
	_viewRepeater = new _RecycleViewRepeaterStrategy();
	_viewport = inject(CDK_VIRTUAL_SCROLL_VIEWPORT, { skipSelf: true });
	viewChange = new Subject();
	_dataSourceChanges = new Subject();
	get cdkVirtualForOf() {
		return this._cdkVirtualForOf;
	}
	set cdkVirtualForOf(value) {
		this._cdkVirtualForOf = value;
		if (isDataSource(value)) this._dataSourceChanges.next(value);
		else this._dataSourceChanges.next(new ArrayDataSource(isObservable(value) ? value : Array.from(value || [])));
	}
	_cdkVirtualForOf;
	get cdkVirtualForTrackBy() {
		return this._cdkVirtualForTrackBy;
	}
	set cdkVirtualForTrackBy(fn) {
		this._needsUpdate = true;
		this._cdkVirtualForTrackBy = fn ? (index, item) => fn(index + (this._renderedRange ? this._renderedRange.start : 0), item) : void 0;
	}
	_cdkVirtualForTrackBy;
	set cdkVirtualForTemplate(value) {
		if (value) {
			this._needsUpdate = true;
			this._template = value;
		}
	}
	get cdkVirtualForTemplateCacheSize() {
		return this._viewRepeater.viewCacheSize;
	}
	set cdkVirtualForTemplateCacheSize(size) {
		this._viewRepeater.viewCacheSize = coerceNumberProperty(size);
	}
	dataStream = this._dataSourceChanges.pipe(startWith(null), pairwise(), switchMap(([prev, cur]) => this._changeDataSource(prev, cur)), shareReplay(1));
	_differ = null;
	_data = [];
	_renderedItems = [];
	_renderedRange = {
		start: 0,
		end: 0
	};
	_needsUpdate = false;
	_destroyed = new Subject();
	constructor() {
		const ngZone = inject(NgZone);
		this.dataStream.subscribe((data) => {
			this._data = data;
			this._onRenderedDataChange();
		});
		this._viewport.renderedRangeStream.pipe(takeUntil(this._destroyed)).subscribe((range) => {
			this._renderedRange = range;
			if (this.viewChange.observers.length) ngZone.run(() => this.viewChange.next(this._renderedRange));
			this._onRenderedDataChange();
		});
		this._viewport.attach(this);
	}
	measureRangeSize(range, orientation) {
		if (range.start >= range.end) return 0;
		if ((range.start < this._renderedRange.start || range.end > this._renderedRange.end) && (typeof ngDevMode === "undefined" || ngDevMode)) throw Error(`Error: attempted to measure an item that isn't rendered.`);
		const renderedStartIndex = range.start - this._renderedRange.start;
		const rangeLen = range.end - range.start;
		let firstNode;
		let lastNode;
		for (let i = 0; i < rangeLen; i++) {
			const view = this._viewContainerRef.get(i + renderedStartIndex);
			if (view && view.rootNodes.length) {
				firstNode = lastNode = view.rootNodes[0];
				break;
			}
		}
		for (let i = rangeLen - 1; i > -1; i--) {
			const view = this._viewContainerRef.get(i + renderedStartIndex);
			if (view && view.rootNodes.length) {
				lastNode = view.rootNodes[view.rootNodes.length - 1];
				break;
			}
		}
		return firstNode && lastNode ? getOffset(orientation, "end", lastNode) - getOffset(orientation, "start", firstNode) : 0;
	}
	ngDoCheck() {
		if (this._differ && this._needsUpdate) {
			const changes = this._differ.diff(this._renderedItems);
			if (!changes) this._updateContext();
			else this._applyChanges(changes);
			this._needsUpdate = false;
		}
	}
	ngOnDestroy() {
		this._viewport.detach();
		this._dataSourceChanges.next(void 0);
		this._dataSourceChanges.complete();
		this.viewChange.complete();
		this._destroyed.next();
		this._destroyed.complete();
		this._viewRepeater.detach();
	}
	_onRenderedDataChange() {
		if (!this._renderedRange) return;
		this._renderedItems = this._data.slice(this._renderedRange.start, this._renderedRange.end);
		if (!this._differ) this._differ = this._differs.find(this._renderedItems).create((index, item) => {
			return this.cdkVirtualForTrackBy ? this.cdkVirtualForTrackBy(index, item) : item;
		});
		this._needsUpdate = true;
	}
	_changeDataSource(oldDs, newDs) {
		if (oldDs) oldDs.disconnect(this);
		this._needsUpdate = true;
		return newDs ? newDs.connect(this) : of();
	}
	_updateContext() {
		const count = this._data.length;
		let i = this._viewContainerRef.length;
		while (i--) {
			const view = this._viewContainerRef.get(i);
			view.context.index = this._renderedRange.start + i;
			view.context.count = count;
			this._updateComputedContextProperties(view.context);
			view.detectChanges();
		}
	}
	_applyChanges(changes) {
		this._viewRepeater.applyChanges(changes, this._viewContainerRef, (record, _adjustedPreviousIndex, currentIndex) => this._getEmbeddedViewArgs(record, currentIndex), (record) => record.item);
		changes.forEachIdentityChange((record) => {
			const view = this._viewContainerRef.get(record.currentIndex);
			view.context.$implicit = record.item;
		});
		const count = this._data.length;
		let i = this._viewContainerRef.length;
		while (i--) {
			const view = this._viewContainerRef.get(i);
			view.context.index = this._renderedRange.start + i;
			view.context.count = count;
			this._updateComputedContextProperties(view.context);
		}
	}
	_updateComputedContextProperties(context) {
		context.first = context.index === 0;
		context.last = context.index === context.count - 1;
		context.even = context.index % 2 === 0;
		context.odd = !context.even;
	}
	_getEmbeddedViewArgs(record, index) {
		return {
			templateRef: this._template,
			context: {
				$implicit: record.item,
				cdkVirtualForOf: this._cdkVirtualForOf,
				index: -1,
				count: -1,
				first: false,
				last: false,
				odd: false,
				even: false
			},
			index
		};
	}
	static ngTemplateContextGuard(directive, context) {
		return true;
	}
	static ɵfac = function CdkVirtualForOf_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkVirtualForOf)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: CdkVirtualForOf,
		selectors: [[
			"",
			"cdkVirtualFor",
			"",
			"cdkVirtualForOf",
			""
		]],
		inputs: {
			cdkVirtualForOf: "cdkVirtualForOf",
			cdkVirtualForTrackBy: "cdkVirtualForTrackBy",
			cdkVirtualForTemplate: "cdkVirtualForTemplate",
			cdkVirtualForTemplateCacheSize: "cdkVirtualForTemplateCacheSize"
		}
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkVirtualForOf, [{
		type: Directive,
		args: [{ selector: "[cdkVirtualFor][cdkVirtualForOf]" }]
	}], () => [], {
		cdkVirtualForOf: [{ type: Input }],
		cdkVirtualForTrackBy: [{ type: Input }],
		cdkVirtualForTemplate: [{ type: Input }],
		cdkVirtualForTemplateCacheSize: [{ type: Input }]
	});
})();
var CdkVirtualScrollableElement = class CdkVirtualScrollableElement extends CdkVirtualScrollable {
	measureBoundingClientRectWithScrollOffset(from) {
		return this.getElementRef().nativeElement.getBoundingClientRect()[from] - this.measureScrollOffset(from);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵCdkVirtualScrollableElement_BaseFactory = void 0;
		return function CdkVirtualScrollableElement_Factory(__ngFactoryType__) {
			return (ɵCdkVirtualScrollableElement_BaseFactory || (ɵCdkVirtualScrollableElement_BaseFactory = ɵɵgetInheritedFactory(CdkVirtualScrollableElement)))(__ngFactoryType__ || CdkVirtualScrollableElement);
		};
	})();
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: CdkVirtualScrollableElement,
		selectors: [[
			"",
			"cdkVirtualScrollingElement",
			""
		]],
		hostAttrs: [1, "cdk-virtual-scrollable"],
		features: [ɵɵProvidersFeature([{
			provide: VIRTUAL_SCROLLABLE,
			useExisting: CdkVirtualScrollableElement
		}]), ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkVirtualScrollableElement, [{
		type: Directive,
		args: [{
			selector: "[cdkVirtualScrollingElement]",
			providers: [{
				provide: VIRTUAL_SCROLLABLE,
				useExisting: CdkVirtualScrollableElement
			}],
			host: { "class": "cdk-virtual-scrollable" }
		}]
	}], null, null);
})();
var CdkVirtualScrollableWindow = class CdkVirtualScrollableWindow extends CdkVirtualScrollable {
	constructor() {
		super();
		const document = inject(DOCUMENT);
		this.elementRef = new ElementRef(document.documentElement);
		this._scrollElement = document;
	}
	measureBoundingClientRectWithScrollOffset(from) {
		return this.getElementRef().nativeElement.getBoundingClientRect()[from];
	}
	static ɵfac = function CdkVirtualScrollableWindow_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkVirtualScrollableWindow)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: CdkVirtualScrollableWindow,
		selectors: [[
			"cdk-virtual-scroll-viewport",
			"scrollWindow",
			""
		]],
		features: [ɵɵProvidersFeature([{
			provide: VIRTUAL_SCROLLABLE,
			useExisting: CdkVirtualScrollableWindow
		}]), ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkVirtualScrollableWindow, [{
		type: Directive,
		args: [{
			selector: "cdk-virtual-scroll-viewport[scrollWindow]",
			providers: [{
				provide: VIRTUAL_SCROLLABLE,
				useExisting: CdkVirtualScrollableWindow
			}]
		}]
	}], () => [], null);
})();
var CdkScrollableModule = class CdkScrollableModule {
	static ɵfac = function CdkScrollableModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CdkScrollableModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: CdkScrollableModule,
		imports: [CdkScrollable],
		exports: [CdkScrollable]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CdkScrollableModule, [{
		type: NgModule,
		args: [{
			exports: [CdkScrollable],
			imports: [CdkScrollable]
		}]
	}], null, null);
})();
var ScrollingModule = class ScrollingModule {
	static ɵfac = function ScrollingModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ScrollingModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: ScrollingModule,
		imports: [
			BidiModule,
			CdkScrollableModule,
			CdkVirtualScrollViewport,
			CdkFixedSizeVirtualScroll,
			CdkVirtualForOf,
			CdkVirtualScrollableWindow,
			CdkVirtualScrollableElement
		],
		exports: [
			BidiModule,
			CdkScrollableModule,
			CdkFixedSizeVirtualScroll,
			CdkVirtualForOf,
			CdkVirtualScrollViewport,
			CdkVirtualScrollableWindow,
			CdkVirtualScrollableElement
		]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		BidiModule,
		CdkScrollableModule,
		BidiModule,
		CdkScrollableModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ScrollingModule, [{
		type: NgModule,
		args: [{
			imports: [
				BidiModule,
				CdkScrollableModule,
				CdkVirtualScrollViewport,
				CdkFixedSizeVirtualScroll,
				CdkVirtualForOf,
				CdkVirtualScrollableWindow,
				CdkVirtualScrollableElement
			],
			exports: [
				BidiModule,
				CdkScrollableModule,
				CdkFixedSizeVirtualScroll,
				CdkVirtualForOf,
				CdkVirtualScrollViewport,
				CdkVirtualScrollableWindow,
				CdkVirtualScrollableElement
			]
		}]
	}], null, null);
})();
export { CdkVirtualScrollViewport as a, ScrollDispatcher as c, BidiModule as d, Dir as f, CdkVirtualForOf as i, ScrollingModule as l, Directionality as m, CdkScrollable as n, CdkVirtualScrollableElement as o, supportsScrollBehavior as p, CdkScrollableModule as r, CdkVirtualScrollableWindow as s, CdkFixedSizeVirtualScroll as t, ViewportRuler as u };
