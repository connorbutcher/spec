import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ua as ɵɵdefineComponent, Xi as ɵɵProvidersFeature, _o as ɵɵgetInheritedFactory, ca as ɵɵclassMap, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable } from "./core-BenYQOr3.js";
import { U as InjectionToken, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/primeng/fesm2022/primeng-inputgroupaddon.mjs
var classes = { root: "p-inputgroupaddon" };
var InputGroupAddonStyle = class InputGroupAddonStyle extends BaseStyle {
	name = "inputgroupaddon";
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵInputGroupAddonStyle_BaseFactory = void 0;
		return function InputGroupAddonStyle_Factory(__ngFactoryType__) {
			return (ɵInputGroupAddonStyle_BaseFactory || (ɵInputGroupAddonStyle_BaseFactory = ɵɵgetInheritedFactory(InputGroupAddonStyle)))(__ngFactoryType__ || InputGroupAddonStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: InputGroupAddonStyle,
		factory: InputGroupAddonStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InputGroupAddonStyle, [{ type: Injectable }], null, null);
})();
var INPUTGROUPADDON_INSTANCE = new InjectionToken("INPUTGROUPADDON_INSTANCE");
var InputGroupAddon = class InputGroupAddon extends BaseComponent {
	componentName = "InputGroupAddon";
	_componentStyle = inject(InputGroupAddonStyle);
	$pcInputGroupAddon = inject(INPUTGROUPADDON_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵInputGroupAddon_BaseFactory = void 0;
		return function InputGroupAddon_Factory(__ngFactoryType__) {
			return (ɵInputGroupAddon_BaseFactory || (ɵInputGroupAddon_BaseFactory = ɵɵgetInheritedFactory(InputGroupAddon)))(__ngFactoryType__ || InputGroupAddon);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: InputGroupAddon,
			selectors: [["p-inputgroup-addon"]],
			hostVars: 2,
			hostBindings: function InputGroupAddon_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassMap(ctx.cx("root"));
			},
			features: [
				ɵɵProvidersFeature([
					InputGroupAddonStyle,
					{
						provide: INPUTGROUPADDON_INSTANCE,
						useExisting: InputGroupAddon
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: InputGroupAddon
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function InputGroupAddon_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InputGroupAddon, [{
		type: Component,
		args: [{
			selector: "p-inputgroup-addon",
			template: ` <ng-content></ng-content> `,
			standalone: true,
			imports: [BindModule],
			host: { "[class]": "cx('root')" },
			providers: [
				InputGroupAddonStyle,
				{
					provide: INPUTGROUPADDON_INSTANCE,
					useExisting: InputGroupAddon
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: InputGroupAddon
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, null);
})();
var InputGroupAddonModule = class InputGroupAddonModule {
	static ɵfac = function InputGroupAddonModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || InputGroupAddonModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: InputGroupAddonModule,
		imports: [InputGroupAddon, SharedModule],
		exports: [InputGroupAddon, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		InputGroupAddon,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InputGroupAddonModule, [{
		type: NgModule,
		args: [{
			imports: [InputGroupAddon, SharedModule],
			exports: [InputGroupAddon, SharedModule]
		}]
	}], null, null);
})();
export { InputGroupAddon, InputGroupAddonModule, InputGroupAddonStyle };
