import { D as DestroyRef, U as InjectionToken, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject, xn as effect } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Ji as ɵɵInheritDefinitionFeature, Nn as NgModule, O as booleanAttribute, Ro as ɵɵlistener, Sn as Input, Wa as ɵɵdefineDirective, X as input, Xi as ɵɵProvidersFeature, _o as ɵɵgetInheritedFactory, at as output, ca as ɵɵclassMap, hn as HostListener, qi as ɵɵHostDirectivesFeature, un as Directive, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { takeUntilDestroyed } from "./@angular_core_rxjs-interop.js";
import { NgControl } from "./@angular_forms.js";
import { n as PARENT_INSTANCE } from "./primeng-basecomponent-cJWiv26K.js";
import { t as BaseModelHolder } from "./primeng-basemodelholder-DPekCZjY.js";
import { Bind } from "./primeng_bind.js";
import { t as Fluid } from "./primeng-fluid-DG0dbSem.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeuix/styles/dist/textarea/index.mjs
var style = "\n    .p-textarea {\n        font-weight: dt('textarea.font.weight');\n        font-size: dt('textarea.font.size');\n        color: dt('textarea.color');\n        background: dt('textarea.background');\n        padding-block: dt('textarea.padding.y');\n        padding-inline: dt('textarea.padding.x');\n        border: 1px solid dt('textarea.border.color');\n        transition:\n            background dt('textarea.transition.duration'),\n            color dt('textarea.transition.duration'),\n            border-color dt('textarea.transition.duration'),\n            outline-color dt('textarea.transition.duration'),\n            box-shadow dt('textarea.transition.duration');\n        appearance: none;\n        border-radius: dt('textarea.border.radius');\n        outline-color: transparent;\n        box-shadow: dt('textarea.shadow');\n    }\n\n    .p-textarea:enabled:hover {\n        border-color: dt('textarea.hover.border.color');\n    }\n\n    .p-textarea:enabled:focus {\n        border-color: dt('textarea.focus.border.color');\n        box-shadow: dt('textarea.focus.ring.shadow');\n        outline: dt('textarea.focus.ring.width') dt('textarea.focus.ring.style') dt('textarea.focus.ring.color');\n        outline-offset: dt('textarea.focus.ring.offset');\n    }\n\n    .p-textarea.p-invalid {\n        border-color: dt('textarea.invalid.border.color');\n    }\n\n    .p-textarea.p-variant-filled {\n        background: dt('textarea.filled.background');\n    }\n\n    .p-textarea.p-variant-filled:enabled:hover {\n        background: dt('textarea.filled.hover.background');\n    }\n\n    .p-textarea.p-variant-filled:enabled:focus {\n        background: dt('textarea.filled.focus.background');\n    }\n\n    .p-textarea:disabled {\n        opacity: 1;\n        background: dt('textarea.disabled.background');\n        color: dt('textarea.disabled.color');\n    }\n\n    .p-textarea::placeholder {\n        color: dt('textarea.placeholder.color');\n    }\n\n    .p-textarea.p-invalid::placeholder {\n        color: dt('textarea.invalid.placeholder.color');\n    }\n\n    .p-textarea-fluid {\n        width: 100%;\n    }\n\n    .p-textarea-resizable {\n        overflow: hidden;\n        resize: none;\n    }\n\n    .p-textarea-sm {\n        font-size: dt('textarea.sm.font.size');\n        padding-block: dt('textarea.sm.padding.y');\n        padding-inline: dt('textarea.sm.padding.x');\n    }\n\n    .p-textarea-lg {\n        font-size: dt('textarea.lg.font.size');\n        padding-block: dt('textarea.lg.padding.y');\n        padding-inline: dt('textarea.lg.padding.x');\n    }\n";
// node_modules/primeng/fesm2022/primeng-textarea.mjs
var classes = { root: ({ instance }) => ["p-textarea p-component", {
	"p-filled": instance.$filled(),
	"p-textarea-resizable ": instance.autoResize(),
	"p-variant-filled": instance.$variant() === "filled",
	"p-textarea-fluid": instance.hasFluid,
	"p-inputfield-sm p-textarea-sm": instance.pSize() === "small",
	"p-textarea-lg p-inputfield-lg": instance.pSize() === "large",
	"p-invalid": instance.invalid()
}] };
var TextareaStyle = class TextareaStyle extends BaseStyle {
	name = "textarea";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTextareaStyle_BaseFactory = void 0;
		return function TextareaStyle_Factory(__ngFactoryType__) {
			return (ɵTextareaStyle_BaseFactory || (ɵTextareaStyle_BaseFactory = ɵɵgetInheritedFactory(TextareaStyle)))(__ngFactoryType__ || TextareaStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TextareaStyle,
		factory: TextareaStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TextareaStyle, [{ type: Injectable }], null, null);
})();
var TextareaClasses;
(function(TextareaClasses) {
	TextareaClasses["root"] = "p-textarea";
})(TextareaClasses || (TextareaClasses = {}));
var TEXTAREA_INSTANCE = new InjectionToken("TEXTAREA_INSTANCE");
var Textarea = class Textarea extends BaseModelHolder {
	componentName = "Textarea";
	bindDirectiveInstance = inject(Bind, { self: true });
	$pcTextarea = inject(TEXTAREA_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	pTextareaPT = input(...ngDevMode ? [void 0, { debugName: "pTextareaPT" }] : /* istanbul ignore next */ []);
	pTextareaUnstyled = input(...ngDevMode ? [void 0, { debugName: "pTextareaUnstyled" }] : /* istanbul ignore next */ []);
	autoResize = input(false, {
		...ngDevMode ? { debugName: "autoResize" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	pSize = input(...ngDevMode ? [void 0, { debugName: "pSize" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	fluid = input(void 0, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	invalid = input(false, {
		...ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	$variant = computed(() => this.variant() || this.config.inputVariant() || void 0, ...ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []);
	onResize = output();
	get hasFluid() {
		return this.fluid() ?? !!this.pcFluid;
	}
	_componentStyle = inject(TextareaStyle);
	ngControl = inject(NgControl, {
		optional: true,
		self: true
	});
	pcFluid = inject(Fluid, {
		optional: true,
		host: true,
		skipSelf: true
	});
	destroyRef = inject(DestroyRef);
	constructor() {
		super();
		effect(() => {
			const pt = this.pTextareaPT();
			if (pt) this.directivePT.set(pt);
		});
		effect(() => {
			if (this.pTextareaUnstyled()) this.directiveUnstyled.set(this.pTextareaUnstyled());
		});
	}
	onInit() {
		if (this.ngControl && this.ngControl.valueChanges) this.ngControl.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
			this.updateState();
		});
	}
	onAfterViewInit() {
		if (this.autoResize()) this.resize();
		this.cd.detectChanges();
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
		if (this.autoResize()) this.resize();
		this.writeModelValue(this.ngControl?.value ?? this.el.nativeElement.value);
	}
	onInput(e) {
		this.writeModelValue(e.target?.value);
		this.updateState();
	}
	resize(event) {
		this.el.nativeElement.style.height = "auto";
		this.el.nativeElement.style.height = this.el.nativeElement.scrollHeight + "px";
		if (parseFloat(this.el.nativeElement.style.height) >= parseFloat(this.el.nativeElement.style.maxHeight)) {
			this.el.nativeElement.style.overflowY = "scroll";
			this.el.nativeElement.style.height = this.el.nativeElement.style.maxHeight;
		} else this.el.nativeElement.style.overflow = "hidden";
		this.onResize.emit(event || {});
	}
	updateState() {
		if (this.autoResize()) this.resize();
	}
	static ɵfac = function Textarea_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Textarea)();
	};
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: Textarea,
		selectors: [[
			"",
			"pTextarea",
			""
		], [
			"",
			"pInputTextarea",
			""
		]],
		hostVars: 2,
		hostBindings: function Textarea_HostBindings(rf, ctx) {
			if (rf & 1) ɵɵlistener("input", function Textarea_input_HostBindingHandler($event) {
				return ctx.onInput($event);
			});
			if (rf & 2) ɵɵclassMap(ctx.cx("root"));
		},
		inputs: {
			pTextareaPT: [1, "pTextareaPT"],
			pTextareaUnstyled: [1, "pTextareaUnstyled"],
			autoResize: [1, "autoResize"],
			pSize: [1, "pSize"],
			variant: [1, "variant"],
			fluid: [1, "fluid"],
			invalid: [1, "invalid"]
		},
		outputs: { onResize: "onResize" },
		features: [
			ɵɵProvidersFeature([
				TextareaStyle,
				{
					provide: TEXTAREA_INSTANCE,
					useExisting: Textarea
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Textarea
				}
			]),
			ɵɵHostDirectivesFeature([Bind]),
			ɵɵInheritDefinitionFeature
		]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Textarea, [{
		type: Directive,
		args: [{
			selector: "[pTextarea], [pInputTextarea]",
			standalone: true,
			host: { "[class]": "cx('root')" },
			providers: [
				TextareaStyle,
				{
					provide: TEXTAREA_INSTANCE,
					useExisting: Textarea
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Textarea
				}
			],
			hostDirectives: [Bind]
		}]
	}], () => [], {
		pTextareaPT: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pTextareaPT",
				required: false
			}]
		}],
		pTextareaUnstyled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pTextareaUnstyled",
				required: false
			}]
		}],
		autoResize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoResize",
				required: false
			}]
		}],
		pSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "pSize",
				required: false
			}]
		}],
		variant: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		invalid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		onResize: [{
			type: Output,
			args: ["onResize"]
		}],
		onInput: [{
			type: HostListener,
			args: ["input", ["$event"]]
		}]
	});
})();
var TextareaModule = class TextareaModule {
	static ɵfac = function TextareaModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TextareaModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: TextareaModule,
		imports: [Textarea],
		exports: [Textarea]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TextareaModule, [{
		type: NgModule,
		args: [{
			imports: [Textarea],
			exports: [Textarea]
		}]
	}], null, null);
})();
export { Textarea, TextareaClasses, TextareaModule, TextareaStyle };
