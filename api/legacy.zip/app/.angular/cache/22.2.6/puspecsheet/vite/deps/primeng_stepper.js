import { Fn as forwardRef, U as InjectionToken, Ui as signal, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, xn as effect, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ns as ɵɵtext, Ps as ɵɵtextInterpolate, Ro as ɵɵlistener, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, _o as ɵɵgetInheritedFactory, a as ContentChildren, aa as ɵɵattribute, ao as ɵɵelementContainer, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, go as ɵɵgetCurrentView, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, j as contentChildren, js as ɵɵtemplate, lo as ɵɵelementStart, nt as model, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { et as ot, o as transformToBoolean } from "./primeng-utils-CHKSviI4.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { i as D } from "./dist-BRhwYpCB.js";
import { r as MotionModule, t as Motion } from "./primeng-motion-BhkauyGA.js";
// node_modules/primeng/fesm2022/primeng-stepper.mjs
var style$1 = `

    .p-steplist {
        position: relative;
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 0;
        padding: 0;
        list-style-type: none;
        overflow-x: auto;
    }

    .p-step {
        position: relative;
        display: flex;
        flex: 1 1 auto;
        align-items: center;
        gap: dt('stepper.step.gap');
        padding: dt('stepper.step.padding');
    }

    .p-step:last-of-type {
        flex: initial;
    }

    .p-step-header {
        border: 0 none;
        display: inline-flex;
        align-items: center;
        text-decoration: none;
        cursor: pointer;
        transition:
            background dt('stepper.transition.duration'),
            color dt('stepper.transition.duration'),
            border-color dt('stepper.transition.duration'),
            outline-color dt('stepper.transition.duration'),
            box-shadow dt('stepper.transition.duration');
        border-radius: dt('stepper.step.header.border.radius');
        outline-color: transparent;
        background: transparent;
        padding: dt('stepper.step.header.padding');
        gap: dt('stepper.step.header.gap');
    }

    .p-step-header:focus-visible {
        box-shadow: dt('stepper.step.header.focus.ring.shadow');
        outline: dt('stepper.step.header.focus.ring.width') dt('stepper.step.header.focus.ring.style') dt('stepper.step.header.focus.ring.color');
        outline-offset: dt('stepper.step.header.focus.ring.offset');
    }

    .p-stepper.p-stepper-readonly .p-step {
        cursor: auto;
    }

    .p-step-title {
        display: block;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 100%;
        color: dt('stepper.step.title.color');
        font-weight: dt('stepper.step.title.font.weight');
        font-size: dt('stepper.step.title.font.size');
        transition:
            background dt('stepper.transition.duration'),
            color dt('stepper.transition.duration'),
            border-color dt('stepper.transition.duration'),
            box-shadow dt('stepper.transition.duration'),
            outline-color dt('stepper.transition.duration');
    }

    .p-step-number {
        display: flex;
        align-items: center;
        justify-content: center;
        color: dt('stepper.step.number.color');
        border: 2px solid dt('stepper.step.number.border.color');
        background: dt('stepper.step.number.background');
        min-width: dt('stepper.step.number.size');
        height: dt('stepper.step.number.size');
        line-height: dt('stepper.step.number.size');
        font-size: dt('stepper.step.number.font.size');
        z-index: 1;
        border-radius: dt('stepper.step.number.border.radius');
        position: relative;
        font-weight: dt('stepper.step.number.font.weight');
    }

    .p-step-number::after {
        content: ' ';
        position: absolute;
        width: 100%;
        height: 100%;
        border-radius: dt('stepper.step.number.border.radius');
        box-shadow: dt('stepper.step.number.shadow');
    }

    .p-step-active .p-step-header {
        cursor: default;
    }

    .p-step-active .p-step-number {
        background: dt('stepper.step.number.active.background');
        border-color: dt('stepper.step.number.active.border.color');
        color: dt('stepper.step.number.active.color');
    }

    .p-step-active .p-step-title {
        color: dt('stepper.step.title.active.color');
    }

    .p-step:not(.p-disabled):focus-visible {
        outline: dt('focus.ring.width') dt('focus.ring.style') dt('focus.ring.color');
        outline-offset: dt('focus.ring.offset');
    }

    .p-step:has(~ .p-step-active) .p-stepper-separator {
        background: dt('stepper.separator.active.background');
    }

    .p-stepper-separator {
        flex: 1 1 0;
        background: dt('stepper.separator.background');
        width: 100%;
        height: dt('stepper.separator.size');
        transition:
            background dt('stepper.transition.duration'),
            color dt('stepper.transition.duration'),
            border-color dt('stepper.transition.duration'),
            box-shadow dt('stepper.transition.duration'),
            outline-color dt('stepper.transition.duration');
    }

    .p-steppanels {
        padding: dt('stepper.steppanels.padding');
    }

    .p-steppanel {
        background: dt('stepper.steppanel.background');
        color: dt('stepper.steppanel.color');
    }

    .p-stepper:has(.p-stepitem) {
        display: flex;
        flex-direction: column;
    }

    .p-stepitem {
        display: flex;
        flex-direction: column;
        flex: initial;
    }

    .p-stepitem.p-stepitem-active {
        flex: 1 1 auto;
    }

    .p-stepitem .p-step {
        flex: initial;
    }
    
    .p-stepitem .p-steppanel {
        display: grid;
        grid-template-rows: 1fr;
    }

    .p-stepitem .p-steppanel-content-wrapper {
        display: flex;
        flex: 1 1 auto;
        min-height: 0;
    }
    .p-stepitem .p-steppanel-content {
        width: 100%;
        padding: dt('stepper.steppanel.padding');
        margin-inline-start: 1rem;
    }

    .p-stepitem .p-stepper-separator {
        flex: 0 0 auto;
        width: dt('stepper.separator.size');
        height: auto;
        margin: dt('stepper.separator.margin');
        position: relative;
        left: calc(-1 * dt('stepper.separator.size'));
    }

    .p-stepitem .p-stepper-separator:dir(rtl) {
        left: calc(-9 * dt('stepper.separator.size'));
    }

    .p-stepitem:has(~ .p-stepitem-active) .p-stepper-separator {
        background: dt('stepper.separator.active.background');
    }

    .p-stepitem:last-of-type .p-steppanel {
        padding-inline-start: dt('stepper.step.number.size');
    }


.p-steppanel .p-motion {
    display: grid;
    grid-template-rows: 1fr;
}
`;
var classes$5 = {
	root: ({ instance }) => ["p-stepper p-component", { "p-readonly": instance.linear() }],
	separator: "p-stepper-separator"
};
var StepperStyle = class StepperStyle extends BaseStyle {
	name = "stepper";
	style = style$1;
	classes = classes$5;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepperStyle_BaseFactory = void 0;
		return function StepperStyle_Factory(__ngFactoryType__) {
			return (ɵStepperStyle_BaseFactory || (ɵStepperStyle_BaseFactory = ɵɵgetInheritedFactory(StepperStyle)))(__ngFactoryType__ || StepperStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: StepperStyle,
		factory: StepperStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepperStyle, [{ type: Injectable }], null, null);
})();
var StepperClasses;
(function(StepperClasses) {
	StepperClasses["root"] = "p-stepper";
	StepperClasses["separator"] = "p-stepper-separator";
})(StepperClasses || (StepperClasses = {}));
var STEPPER_INSTANCE = new InjectionToken("STEPPER_INSTANCE");
var STEPLIST_INSTANCE = new InjectionToken("STEPLIST_INSTANCE");
var STEPITEM_INSTANCE = new InjectionToken("STEPITEM_INSTANCE");
var STEP_INSTANCE = new InjectionToken("STEP_INSTANCE");
var STEPPANEL_INSTANCE = new InjectionToken("STEPPANEL_INSTANCE");
var STEPPANELS_INSTANCE = new InjectionToken("STEPPANELS_INSTANCE");
var STEPPERSEPARATOR_INSTANCE = new InjectionToken("STEPPERSEPARATOR_INSTANCE");
var StepperSeparator = class StepperSeparator extends BaseComponent {
	$pcStepperSeparator = inject(STEPPERSEPARATOR_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	componentName = "StepperSeparator";
	_componentStyle = inject(StepperStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepperSeparator_BaseFactory = void 0;
		return function StepperSeparator_Factory(__ngFactoryType__) {
			return (ɵStepperSeparator_BaseFactory || (ɵStepperSeparator_BaseFactory = ɵɵgetInheritedFactory(StepperSeparator)))(__ngFactoryType__ || StepperSeparator);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: StepperSeparator,
			selectors: [["p-stepper-separator"]],
			hostVars: 2,
			hostBindings: function StepperSeparator_HostBindings(rf, ctx) {
				if (rf & 2) ɵɵclassMap(ctx.cx("separator"));
			},
			features: [
				ɵɵProvidersFeature([
					StepperStyle,
					{
						provide: STEPPERSEPARATOR_INSTANCE,
						useExisting: StepperSeparator
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: StepperSeparator
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function StepperSeparator_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepperSeparator, [{
		type: Component,
		args: [{
			selector: "p-stepper-separator",
			standalone: true,
			imports: [BindModule],
			template: `<ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: { "[class]": "cx(\"separator\")" },
			providers: [
				StepperStyle,
				{
					provide: STEPPERSEPARATOR_INSTANCE,
					useExisting: StepperSeparator
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: StepperSeparator
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, null);
})();
var classes$4 = {
	root: ({ instance }) => ["p-step", {
		"p-step-active": instance.active(),
		"p-disabled": instance.isStepDisabled()
	}],
	header: "p-step-header",
	number: "p-step-number",
	title: "p-step-title"
};
var StepStyle = class StepStyle extends BaseStyle {
	name = "step";
	classes = classes$4;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepStyle_BaseFactory = void 0;
		return function StepStyle_Factory(__ngFactoryType__) {
			return (ɵStepStyle_BaseFactory || (ɵStepStyle_BaseFactory = ɵɵgetInheritedFactory(StepStyle)))(__ngFactoryType__ || StepStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: StepStyle,
		factory: StepStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepStyle, [{ type: Injectable }], null, null);
})();
var StepClasses;
(function(StepClasses) {
	StepClasses["root"] = "p-step";
	StepClasses["header"] = "p-step-header";
	StepClasses["number"] = "p-step-number";
	StepClasses["title"] = "p-step-title";
})(StepClasses || (StepClasses = {}));
var Step = class Step extends BaseComponent {
	$pcStep = inject(STEP_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	componentName = "Step";
	pcStepper = inject(STEPPER_INSTANCE);
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: (v) => transformToBoolean(v)
	});
	active = computed(() => this.pcStepper.isStepActive(this.value()), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	isStepDisabled = computed(() => !this.active() && (this.pcStepper.linear() || this.disabled()), ...ngDevMode ? [{ debugName: "isStepDisabled" }] : /* istanbul ignore next */ []);
	stepTabindex = computed(() => this.isStepDisabled() ? -1 : void 0, ...ngDevMode ? [{ debugName: "stepTabindex" }] : /* istanbul ignore next */ []);
	ariaCurrent = computed(() => this.active() ? "step" : void 0, ...ngDevMode ? [{ debugName: "ariaCurrent" }] : /* istanbul ignore next */ []);
	id = computed(() => `${this.pcStepper.id()}_step_${this.value()}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	ariaControls = computed(() => `${this.pcStepper.id()}_steppanel_${this.value()}`, ...ngDevMode ? [{ debugName: "ariaControls" }] : /* istanbul ignore next */ []);
	isSeparatorVisible = computed(() => {
		const stepList = this.pcStepper.stepList();
		if (stepList) {
			const steps = stepList.steps();
			return steps.indexOf(this) !== steps.length - 1;
		} else return false;
	}, ...ngDevMode ? [{ debugName: "isSeparatorVisible" }] : /* istanbul ignore next */ []);
	content = contentChild("content", {
		...ngDevMode ? { debugName: "content" } : /* istanbul ignore next */ {},
		descendants: false
	});
	_componentStyle = inject(StepStyle);
	onStepClickCallback = this.onStepClick.bind(this);
	contentContext = computed(() => ({
		activateCallback: this.onStepClickCallback,
		value: this.value(),
		active: this.active()
	}), ...ngDevMode ? [{ debugName: "contentContext" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onStepClick() {
		this.pcStepper.updateValue(this.value());
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStep_BaseFactory = void 0;
		return function Step_Factory(__ngFactoryType__) {
			return (ɵStep_BaseFactory || (ɵStep_BaseFactory = ɵɵgetInheritedFactory(Step)))(__ngFactoryType__ || Step);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["content"];
		const _c1 = ["*"];
		function Step_Conditional_0_Conditional_5_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-stepper-separator");
		}
		function Step_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "button", 0);
				ɵɵlistener("click", function Step_Conditional_0_Template_button_click_0_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onStepClick());
				});
				ɵɵelementStart(1, "span", 1);
				ɵɵtext(2);
				ɵɵelementEnd();
				ɵɵelementStart(3, "span", 1);
				ɵɵprojection(4);
				ɵɵelementEnd()();
				ɵɵconditionalCreate(5, Step_Conditional_0_Conditional_5_Template, 1, 0, "p-stepper-separator");
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("header"));
				ɵɵproperty("pBind", ctx_r1.ptm("header"))("tabindex", ctx_r1.stepTabindex())("disabled", ctx_r1.isStepDisabled());
				ɵɵattribute("id", ctx_r1.id())("role", "tab")("aria-controls", ctx_r1.ariaControls());
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("number"));
				ɵɵproperty("pBind", ctx_r1.ptm("number"));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1.value());
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("title"));
				ɵɵproperty("pBind", ctx_r1.ptm("title"));
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.isSeparatorVisible() ? 5 : -1);
			}
		}
		function Step_Conditional_1_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Step_Conditional_1_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-stepper-separator");
		}
		function Step_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵtemplate(0, Step_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 2);
				ɵɵconditionalCreate(1, Step_Conditional_1_Conditional_1_Template, 1, 0, "p-stepper-separator");
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.content())("ngTemplateOutletContext", ctx_r1.contentContext());
				ɵɵadvance();
				ɵɵconditional(ctx_r1.isSeparatorVisible() ? 1 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Step,
			selectors: [["p-step"]],
			contentQueries: function Step_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.content, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 6,
			hostBindings: function Step_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("aria-current", ctx.ariaCurrent())("role", "presentation")("data-p-active", ctx.active())("data-p-disabled", ctx.isStepDisabled());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				value: [1, "value"],
				disabled: [1, "disabled"]
			},
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					StepStyle,
					{
						provide: STEP_INSTANCE,
						useExisting: Step
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Step
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c1,
			decls: 2,
			vars: 1,
			consts: [
				[
					"type",
					"button",
					3,
					"click",
					"pBind",
					"tabindex",
					"disabled"
				],
				[3, "pBind"],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				]
			],
			template: function Step_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵconditionalCreate(0, Step_Conditional_0_Template, 6, 16)(1, Step_Conditional_1_Template, 2, 3);
				}
				if (rf & 2) ɵɵconditional(!ctx.content() ? 0 : 1);
			},
			dependencies: [
				NgTemplateOutlet,
				StepperSeparator,
				SharedModule,
				BindModule,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Step, [{
		type: Component,
		args: [{
			selector: "p-step",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				StepperSeparator,
				SharedModule,
				BindModule
			],
			template: `
        @if (!content()) {
            <button [attr.id]="id()" [class]="cx('header')" [pBind]="ptm('header')" [attr.role]="'tab'" [tabindex]="stepTabindex()" [attr.aria-controls]="ariaControls()" [disabled]="isStepDisabled()" (click)="onStepClick()" type="button">
                <span [class]="cx('number')" [pBind]="ptm('number')">{{ value() }}</span>
                <span [class]="cx('title')" [pBind]="ptm('title')">
                    <ng-content></ng-content>
                </span>
            </button>
            @if (isSeparatorVisible()) {
                <p-stepper-separator />
            }
        } @else {
            <ng-container *ngTemplateOutlet="content(); context: contentContext()"></ng-container>
            @if (isSeparatorVisible()) {
                <p-stepper-separator />
            }
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.aria-current]": "ariaCurrent()",
				"[attr.role]": "\"presentation\"",
				"[attr.data-p-active]": "active()",
				"[attr.data-p-disabled]": "isStepDisabled()"
			},
			providers: [
				StepStyle,
				{
					provide: STEP_INSTANCE,
					useExisting: Step
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Step
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		content: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var classes$3 = {
	root: ({ instance }) => ["p-steppanel", { "p-steppanel-active": instance.isVertical() && instance.active() }],
	contentWrapper: "p-steppanel-content-wrapper",
	content: "p-steppanel-content"
};
var StepPanelStyle = class StepPanelStyle extends BaseStyle {
	name = "steppanel";
	classes = classes$3;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepPanelStyle_BaseFactory = void 0;
		return function StepPanelStyle_Factory(__ngFactoryType__) {
			return (ɵStepPanelStyle_BaseFactory || (ɵStepPanelStyle_BaseFactory = ɵɵgetInheritedFactory(StepPanelStyle)))(__ngFactoryType__ || StepPanelStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: StepPanelStyle,
		factory: StepPanelStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepPanelStyle, [{ type: Injectable }], null, null);
})();
var StepPanelClasses;
(function(StepPanelClasses) {
	StepPanelClasses["root"] = "p-steppanel";
	StepPanelClasses["contentWrapper"] = "p-steppanel-content-wrapper";
	StepPanelClasses["content"] = "p-steppanel-content";
})(StepPanelClasses || (StepPanelClasses = {}));
var StepPanel = class StepPanel extends BaseComponent {
	$pcStepPanel = inject(STEPPANEL_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	componentName = "StepPanel";
	pcStepper = inject(STEPPER_INSTANCE);
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	active = computed(() => this.pcStepper.value() === this.value(), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	ariaControls = computed(() => `${this.pcStepper.id()}_step_${this.value()}`, ...ngDevMode ? [{ debugName: "ariaControls" }] : /* istanbul ignore next */ []);
	id = computed(() => `${this.pcStepper.id()}_steppanel_${this.value()}`, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	isVertical = computed(() => this.pcStepper.stepItems().length > 0, ...ngDevMode ? [{ debugName: "isVertical" }] : /* istanbul ignore next */ []);
	isSeparatorVisible = computed(() => {
		if (this.pcStepper.stepItems()) {
			const stepLen = this.pcStepper.stepItems().length;
			const stepPanelElements = ot(this.pcStepper.el.nativeElement, "[data-pc-name=\"steppanel\"]");
			return D(this.el.nativeElement, stepPanelElements) !== stepLen - 1;
		}
	}, ...ngDevMode ? [{ debugName: "isSeparatorVisible" }] : /* istanbul ignore next */ []);
	computedMotionOptions = computed(() => ({
		...this.ptm("motion"),
		...this.pcStepper.computedMotionOptions()
	}), ...ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []);
	contentTemplate = contentChild("content", {
		...ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	_componentStyle = inject(StepPanelStyle);
	updateValueCallback = this.updateValue.bind(this);
	contentContext = computed(() => ({
		activateCallback: this.updateValueCallback,
		value: this.value(),
		active: this.active()
	}), ...ngDevMode ? [{ debugName: "contentContext" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	updateValue(value) {
		this.pcStepper.updateValue(value);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepPanel_BaseFactory = void 0;
		return function StepPanel_Factory(__ngFactoryType__) {
			return (ɵStepPanel_BaseFactory || (ɵStepPanel_BaseFactory = ɵɵgetInheritedFactory(StepPanel)))(__ngFactoryType__ || StepPanel);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["content"];
		function StepPanel_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-stepper-separator");
		}
		function StepPanel_ng_container_4_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: StepPanel,
			selectors: [["p-step-panel"]],
			contentQueries: function StepPanel_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.contentTemplate, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 7,
			hostBindings: function StepPanel_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "tabpanel")("aria-controls", ctx.ariaControls())("id", ctx.id())("data-p-active", ctx.active())("data-pc-name", "steppanel");
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: { value: [1, "value"] },
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					StepPanelStyle,
					{
						provide: STEPPANEL_INSTANCE,
						useExisting: StepPanel
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: StepPanel
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 5,
			vars: 13,
			consts: [
				[
					3,
					"visible",
					"name",
					"disabled",
					"options"
				],
				[3, "pBind"],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				]
			],
			template: function StepPanel_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵelementStart(0, "p-motion", 0)(1, "div", 1);
					ɵɵconditionalCreate(2, StepPanel_Conditional_2_Template, 1, 0, "p-stepper-separator");
					ɵɵelementStart(3, "div", 1);
					ɵɵtemplate(4, StepPanel_ng_container_4_Template, 1, 0, "ng-container", 2);
					ɵɵelementEnd()()();
				}
				if (rf & 2) {
					ɵɵproperty("visible", ctx.active())("name", ctx.pcn("p-collapsible"))("disabled", !ctx.isVertical())("options", ctx.computedMotionOptions());
					ɵɵadvance();
					ɵɵclassMap(ctx.cx("contentWrapper"));
					ɵɵproperty("pBind", ctx.ptm("contentWrapper"));
					ɵɵadvance();
					ɵɵconditional(ctx.isSeparatorVisible() ? 2 : -1);
					ɵɵadvance();
					ɵɵclassMap(ctx.cx("content"));
					ɵɵproperty("pBind", ctx.ptm("content"));
					ɵɵadvance();
					ɵɵproperty("ngTemplateOutlet", ctx.contentTemplate())("ngTemplateOutletContext", ctx.contentContext());
				}
			},
			dependencies: [
				NgTemplateOutlet,
				StepperSeparator,
				SharedModule,
				BindModule,
				Bind,
				MotionModule,
				Motion
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepPanel, [{
		type: Component,
		args: [{
			selector: "p-step-panel",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				StepperSeparator,
				SharedModule,
				BindModule,
				MotionModule
			],
			template: `
        <p-motion [visible]="active()" [name]="pcn('p-collapsible')" [disabled]="!isVertical()" [options]="computedMotionOptions()">
            <div [class]="cx('contentWrapper')" [pBind]="ptm('contentWrapper')">
                @if (isSeparatorVisible()) {
                    <p-stepper-separator />
                }
                <div [class]="cx('content')" [pBind]="ptm('content')">
                    <ng-container *ngTemplateOutlet="contentTemplate(); context: contentContext()"></ng-container>
                </div>
            </div>
        </p-motion>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.role]": "\"tabpanel\"",
				"[attr.aria-controls]": "ariaControls()",
				"[attr.id]": "id()",
				"[attr.data-p-active]": "active()",
				"[attr.data-pc-name]": "\"steppanel\""
			},
			providers: [
				StepPanelStyle,
				{
					provide: STEPPANEL_INSTANCE,
					useExisting: StepPanel
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: StepPanel
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		contentTemplate: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var classes$2 = { root: ({ instance }) => ["p-stepitem", { "p-stepitem-active": instance.isActive() }] };
var StepItemStyle = class StepItemStyle extends BaseStyle {
	name = "stepitem";
	classes = classes$2;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepItemStyle_BaseFactory = void 0;
		return function StepItemStyle_Factory(__ngFactoryType__) {
			return (ɵStepItemStyle_BaseFactory || (ɵStepItemStyle_BaseFactory = ɵɵgetInheritedFactory(StepItemStyle)))(__ngFactoryType__ || StepItemStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: StepItemStyle,
		factory: StepItemStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepItemStyle, [{ type: Injectable }], null, null);
})();
var StepItemClasses;
(function(StepItemClasses) {
	StepItemClasses["root"] = "p-stepitem";
})(StepItemClasses || (StepItemClasses = {}));
var StepItem = class StepItem extends BaseComponent {
	$pcStepItem = inject(STEPITEM_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	componentName = "StepItem";
	_componentStyle = inject(StepItemStyle);
	pcStepper = inject(STEPPER_INSTANCE);
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	isActive = computed(() => this.pcStepper.value() === this.value(), ...ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ []);
	step = contentChild(Step, {
		...ngDevMode ? { debugName: "step" } : /* istanbul ignore next */ {},
		descendants: false
	});
	stepPanel = contentChild(StepPanel, {
		...ngDevMode ? { debugName: "stepPanel" } : /* istanbul ignore next */ {},
		descendants: false
	});
	constructor() {
		super();
		effect(() => {
			this.step()?.value.set(this.value());
		});
		effect(() => {
			this.stepPanel()?.value.set(this.value());
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = function StepItem_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || StepItem)();
	};
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: StepItem,
			selectors: [["p-step-item"]],
			contentQueries: function StepItem_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.step, Step, 4)(dirIndex, ctx.stepPanel, StepPanel, 4);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			hostVars: 4,
			hostBindings: function StepItem_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "presentation")("data-p-active", ctx.isActive());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: { value: [1, "value"] },
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					StepItemStyle,
					{
						provide: STEPITEM_INSTANCE,
						useExisting: StepItem
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: StepItem
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function StepItem_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepItem, [{
		type: Component,
		args: [{
			selector: "p-step-item",
			standalone: true,
			imports: [BindModule],
			template: `<ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.role]": "\"presentation\"",
				"[attr.data-p-active]": "isActive()"
			},
			providers: [
				StepItemStyle,
				{
					provide: STEPITEM_INSTANCE,
					useExisting: StepItem
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: StepItem
				}
			],
			hostDirectives: [Bind]
		}]
	}], () => [], {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		step: [{
			type: ContentChild,
			args: [forwardRef(() => Step), {
				descendants: false,
				isSignal: true
			}]
		}],
		stepPanel: [{
			type: ContentChild,
			args: [forwardRef(() => StepPanel), {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var classes$1 = { root: "p-steplist" };
var StepListStyle = class StepListStyle extends BaseStyle {
	name = "steplist";
	classes = classes$1;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepListStyle_BaseFactory = void 0;
		return function StepListStyle_Factory(__ngFactoryType__) {
			return (ɵStepListStyle_BaseFactory || (ɵStepListStyle_BaseFactory = ɵɵgetInheritedFactory(StepListStyle)))(__ngFactoryType__ || StepListStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: StepListStyle,
		factory: StepListStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepListStyle, [{ type: Injectable }], null, null);
})();
var StepListClasses;
(function(StepListClasses) {
	StepListClasses["root"] = "p-stepitem";
})(StepListClasses || (StepListClasses = {}));
var StepList = class StepList extends BaseComponent {
	$pcStepList = inject(STEPLIST_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	componentName = "StepList";
	steps = contentChildren(Step, ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(StepListStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepList_BaseFactory = void 0;
		return function StepList_Factory(__ngFactoryType__) {
			return (ɵStepList_BaseFactory || (ɵStepList_BaseFactory = ɵɵgetInheritedFactory(StepList)))(__ngFactoryType__ || StepList);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: StepList,
			selectors: [["p-step-list"]],
			contentQueries: function StepList_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.steps, Step, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 3,
			hostBindings: function StepList_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "presentation");
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			features: [
				ɵɵProvidersFeature([
					StepListStyle,
					{
						provide: STEPLIST_INSTANCE,
						useExisting: StepList
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: StepList
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function StepList_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepList, [{
		type: Component,
		args: [{
			selector: "p-step-list",
			standalone: true,
			imports: [BindModule],
			template: `<ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.role]": "\"presentation\""
			},
			providers: [
				StepListStyle,
				{
					provide: STEPLIST_INSTANCE,
					useExisting: StepList
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: StepList
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, { steps: [{
		type: ContentChildren,
		args: [forwardRef(() => Step), { isSignal: true }]
	}] });
})();
var classes = { root: "p-steppanels" };
var StepPanelsStyle = class StepPanelsStyle extends BaseStyle {
	name = "steppanel";
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepPanelsStyle_BaseFactory = void 0;
		return function StepPanelsStyle_Factory(__ngFactoryType__) {
			return (ɵStepPanelsStyle_BaseFactory || (ɵStepPanelsStyle_BaseFactory = ɵɵgetInheritedFactory(StepPanelsStyle)))(__ngFactoryType__ || StepPanelsStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: StepPanelsStyle,
		factory: StepPanelsStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepPanelsStyle, [{ type: Injectable }], null, null);
})();
var StepPanelsClasses;
(function(StepPanelsClasses) {
	StepPanelsClasses["root"] = "p-steppanels";
})(StepPanelsClasses || (StepPanelsClasses = {}));
var StepPanels = class StepPanels extends BaseComponent {
	$pcStepPanels = inject(STEPPANELS_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	componentName = "StepPanels";
	_componentStyle = inject(StepPanelsStyle);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepPanels_BaseFactory = void 0;
		return function StepPanels_Factory(__ngFactoryType__) {
			return (ɵStepPanels_BaseFactory || (ɵStepPanels_BaseFactory = ɵɵgetInheritedFactory(StepPanels)))(__ngFactoryType__ || StepPanels);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: StepPanels,
			selectors: [["p-step-panels"]],
			hostVars: 3,
			hostBindings: function StepPanels_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "presentation");
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			features: [
				ɵɵProvidersFeature([
					StepPanelsStyle,
					{
						provide: STEPPANELS_INSTANCE,
						useExisting: StepPanels
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: StepPanels
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function StepPanels_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [SharedModule, BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepPanels, [{
		type: Component,
		args: [{
			selector: "p-step-panels",
			standalone: true,
			imports: [SharedModule, BindModule],
			template: ` <ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx(\"root\")",
				"[attr.role]": "\"presentation\""
			},
			providers: [
				StepPanelsStyle,
				{
					provide: STEPPANELS_INSTANCE,
					useExisting: StepPanels
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: StepPanels
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, null);
})();
var Stepper = class Stepper extends BaseComponent {
	componentName = "Stepper";
	$pcStepper = inject(STEPPER_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	_componentStyle = inject(StepperStyle);
	value = model(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	linear = input(false, {
		...ngDevMode ? { debugName: "linear" } : /* istanbul ignore next */ {},
		transform: (v) => transformToBoolean(v)
	});
	motionOptions = input(void 0, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	computedMotionOptions = computed(() => ({
		...this.ptm("motion"),
		...this.motionOptions()
	}), ...ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []);
	id = signal(this.$useId.next("pn_id_"), ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	stepItems = contentChildren(StepItem, ...ngDevMode ? [{ debugName: "stepItems" }] : /* istanbul ignore next */ []);
	steps = contentChildren(Step, ...ngDevMode ? [{ debugName: "steps" }] : /* istanbul ignore next */ []);
	stepList = contentChild(StepList, {
		...ngDevMode ? { debugName: "stepList" } : /* istanbul ignore next */ {},
		descendants: false
	});
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	updateValue(value) {
		this.value.set(value);
	}
	isStepActive(value) {
		return this.value() === value;
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵStepper_BaseFactory = void 0;
		return function Stepper_Factory(__ngFactoryType__) {
			return (ɵStepper_BaseFactory || (ɵStepper_BaseFactory = ɵɵgetInheritedFactory(Stepper)))(__ngFactoryType__ || Stepper);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Stepper,
			selectors: [["p-stepper"]],
			contentQueries: function Stepper_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.stepItems, StepItem, 4)(dirIndex, ctx.steps, Step, 4)(dirIndex, ctx.stepList, StepList, 4);
				if (rf & 2) ɵɵqueryAdvance(3);
			},
			hostVars: 4,
			hostBindings: function Stepper_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("role", "tablist")("id", ctx.id());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				value: [1, "value"],
				linear: [1, "linear"],
				motionOptions: [1, "motionOptions"]
			},
			outputs: { value: "valueChange" },
			features: [
				ɵɵProvidersFeature([
					StepperStyle,
					{
						provide: STEPPER_INSTANCE,
						useExisting: Stepper
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Stepper
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 1,
			vars: 0,
			template: function Stepper_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵprojection(0);
				}
			},
			dependencies: [SharedModule, BindModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Stepper, [{
		type: Component,
		args: [{
			selector: "p-stepper",
			standalone: true,
			imports: [SharedModule, BindModule],
			template: ` <ng-content></ng-content>`,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				StepperStyle,
				{
					provide: STEPPER_INSTANCE,
					useExisting: Stepper
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Stepper
				}
			],
			host: {
				"[class]": "cx(\"root\")",
				"[attr.role]": "\"tablist\"",
				"[attr.id]": "id()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: Output,
			args: ["valueChange"]
		}],
		linear: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "linear",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		stepItems: [{
			type: ContentChildren,
			args: [forwardRef(() => StepItem), { isSignal: true }]
		}],
		steps: [{
			type: ContentChildren,
			args: [forwardRef(() => Step), { isSignal: true }]
		}],
		stepList: [{
			type: ContentChild,
			args: [forwardRef(() => StepList), {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var StepperModule = class StepperModule {
	static ɵfac = function StepperModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || StepperModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: StepperModule,
		imports: [
			Stepper,
			StepList,
			StepPanels,
			StepPanel,
			StepItem,
			Step,
			StepperSeparator,
			SharedModule,
			BindModule
		],
		exports: [
			Stepper,
			StepList,
			StepPanels,
			StepPanel,
			StepItem,
			Step,
			StepperSeparator,
			SharedModule,
			BindModule
		]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Stepper,
		StepList,
		StepPanels,
		StepPanel,
		StepItem,
		Step,
		StepperSeparator,
		SharedModule,
		BindModule,
		SharedModule,
		BindModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StepperModule, [{
		type: NgModule,
		args: [{
			imports: [
				Stepper,
				StepList,
				StepPanels,
				StepPanel,
				StepItem,
				Step,
				StepperSeparator,
				SharedModule,
				BindModule
			],
			exports: [
				Stepper,
				StepList,
				StepPanels,
				StepPanel,
				StepItem,
				Step,
				StepperSeparator,
				SharedModule,
				BindModule
			]
		}]
	}], null, null);
})();
export { STEPITEM_INSTANCE, STEPLIST_INSTANCE, STEPPANELS_INSTANCE, STEPPANEL_INSTANCE, STEPPERSEPARATOR_INSTANCE, STEPPER_INSTANCE, STEP_INSTANCE, Step, StepItem, StepList, StepPanel, StepPanels, Stepper, StepperClasses, StepperModule, StepperSeparator, StepperStyle };
