import { x as CommonModule } from "./common-D_MNYFJX.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ua as ɵɵdefineComponent, Xi as ɵɵProvidersFeature, _o as ɵɵgetInheritedFactory, ca as ɵɵclassMap, co as ɵɵelementEnd, lo as ɵɵelementStart, pr as ViewEncapsulation, qo as ɵɵprojection, xn as Injectable } from "./core-BenYQOr3.js";
import { la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/primeng/fesm2022/primeng-buttongroup.mjs
var style$1 = `
    
    .p-buttongroup {
        display: inline-flex;
        border-radius: dt('button.border.radius');
    }

    .p-buttongroup .p-button {
        margin: 0;
    }

    .p-buttongroup .p-button:not(:last-child),
    .p-buttongroup .p-button:not(:last-child):hover {
        border-inline-end: 0 none;
    }

    .p-buttongroup .p-button:not(:first-of-type):not(:last-of-type) {
        border-radius: 0;
    }

    .p-buttongroup .p-button:first-of-type:not(:only-of-type) {
        border-start-end-radius: 0;
        border-end-end-radius: 0;
    }

    .p-buttongroup .p-button:last-of-type:not(:only-of-type) {
        border-start-start-radius: 0;
        border-end-start-radius: 0;
    }

    .p-buttongroup .p-button:focus {
        position: relative;
        z-index: 1;
    }

    .p-buttongroup:has(.p-button-raised) {
        box-shadow: dt('button.raised.shadow');
    }

    .p-buttongroup .p-button-raised {
        box-shadow: none;
    }


    /* For PrimeNG */
    .p-buttongroup p-button:focus .p-button {
        position: relative;
        z-index: 1;
    }

    .p-buttongroup p-button:not(:last-child) .p-button,
    .p-buttongroup p-button:not(:last-child) .p-button:hover {
        border-right: 0 none;
    }

    .p-buttongroup p-button:not(:first-of-type):not(:last-of-type) .p-button {
        border-radius: 0;
    }

    .p-buttongroup p-button:first-of-type:not(:only-of-type) .p-button {
        border-start-end-radius: 0;
        border-end-end-radius: 0;
    }

    .p-buttongroup p-button:last-of-type:not(:only-of-type) .p-button {
        border-start-start-radius: 0;
        border-end-start-radius: 0;
    }
`;
var classes = { root: "p-buttongroup p-component" };
var ButtonGroupStyle = class ButtonGroupStyle extends BaseStyle {
	name = "buttongroup";
	style = style$1;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵButtonGroupStyle_BaseFactory = void 0;
		return function ButtonGroupStyle_Factory(__ngFactoryType__) {
			return (ɵButtonGroupStyle_BaseFactory || (ɵButtonGroupStyle_BaseFactory = ɵɵgetInheritedFactory(ButtonGroupStyle)))(__ngFactoryType__ || ButtonGroupStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: ButtonGroupStyle,
		factory: ButtonGroupStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonGroupStyle, [{ type: Injectable }], null, null);
})();
var ButtonGroupClasses;
(function(ButtonGroupClasses) {
	ButtonGroupClasses["root"] = "p-buttongroup";
})(ButtonGroupClasses || (ButtonGroupClasses = {}));
var ButtonGroup = class ButtonGroup extends BaseComponent {
	componentName = "ButtonGroup";
	_componentStyle = inject(ButtonGroupStyle);
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵButtonGroup_BaseFactory = void 0;
		return function ButtonGroup_Factory(__ngFactoryType__) {
			return (ɵButtonGroup_BaseFactory || (ɵButtonGroup_BaseFactory = ɵɵgetInheritedFactory(ButtonGroup)))(__ngFactoryType__ || ButtonGroup);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: ButtonGroup,
			selectors: [["p-buttongroup"], ["p-button-group"]],
			features: [ɵɵProvidersFeature([ButtonGroupStyle]), ɵɵInheritDefinitionFeature],
			ngContentSelectors: ["*"],
			decls: 2,
			vars: 2,
			consts: [["role", "group"]],
			template: function ButtonGroup_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵelementStart(0, "span", 0);
					ɵɵprojection(1);
					ɵɵelementEnd();
				}
				if (rf & 2) ɵɵclassMap(ctx.pcn("p-buttongroup p-component"));
			},
			dependencies: [CommonModule],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonGroup, [{
		type: Component,
		args: [{
			selector: "p-buttongroup, p-button-group",
			standalone: true,
			imports: [CommonModule],
			template: `
        <span [class]="pcn('p-buttongroup p-component')" role="group">
            <ng-content></ng-content>
        </span>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [ButtonGroupStyle]
		}]
	}], null, null);
})();
var ButtonGroupModule = class ButtonGroupModule {
	static ɵfac = function ButtonGroupModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ButtonGroupModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: ButtonGroupModule,
		imports: [ButtonGroup],
		exports: [ButtonGroup]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [ButtonGroup] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ButtonGroupModule, [{
		type: NgModule,
		args: [{
			imports: [ButtonGroup],
			exports: [ButtonGroup]
		}]
	}], null, null);
})();
export { ButtonGroup, ButtonGroupClasses, ButtonGroupModule, ButtonGroupStyle };
