import { U as InjectionToken, Ui as signal, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, xn as effect, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet, u as isPlatformBrowser } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Ro as ɵɵlistener, S as ViewChild, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Xo as ɵɵpureFunction0, Yo as ɵɵproperty, Zi as ɵɵadvance, Zo as ɵɵpureFunction1, Zs as ɵɵviewQuerySignal, _o as ɵɵgetInheritedFactory, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, go as ɵɵgetCurrentView, gt as viewChild, ha as ɵɵcontentQuerySignal, i as ContentChild, js as ɵɵtemplate, lo as ɵɵelementStart, nt as model, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import "./dist-BRhwYpCB.js";
import { OverlayService, SharedModule } from "./primeng_api.js";
import { a as getEventTarget, n as PARENT_INSTANCE, r as ConnectedOverlayScrollHandler, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { r as MotionModule, t as Motion } from "./primeng-motion-BhkauyGA.js";
import { C as G, G as fe, L as Wt, O as L, dt as z, r as markInstance, s as zindexutils_default, y as Ct, z as Y } from "./primeng-utils-CHKSviI4.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/primeng/fesm2022/primeng-overlay.mjs
var inlineStyles = {
	root: ({ instance }) => {
		return {
			position: "absolute",
			top: "0",
			...instance.modal() ? instance.$overlayResponsiveOptions()?.style : instance.$overlayOptions()?.style,
			...instance.style()
		};
	},
	content: ({ instance }) => {
		return {
			...instance.modal() ? instance.$overlayResponsiveOptions()?.contentStyle : instance.$overlayOptions()?.contentStyle,
			...instance.contentStyle()
		};
	}
};
var style = `
.p-overlay-modal {
    display: flex;
    align-items: center;
    justify-content: center;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.p-overlay-content {
    transform-origin: inherit;
    will-change: transform;
}

/* Github Issue #18560 */
.p-component-overlay.p-component {
    position: relative;
}

.p-overlay-modal > .p-overlay-content {
    z-index: 1;
    width: 90%;
}

/* Position */
/* top */
.p-overlay-top {
    align-items: flex-start;
}
.p-overlay-top-start {
    align-items: flex-start;
    justify-content: flex-start;
}
.p-overlay-top-end {
    align-items: flex-start;
    justify-content: flex-end;
}

/* bottom */
.p-overlay-bottom {
    align-items: flex-end;
}
.p-overlay-bottom-start {
    align-items: flex-end;
    justify-content: flex-start;
}
.p-overlay-bottom-end {
    align-items: flex-end;
    justify-content: flex-end;
}

/* left */
.p-overlay-left {
    justify-content: flex-start;
}
.p-overlay-left-start {
    justify-content: flex-start;
    align-items: flex-start;
}
.p-overlay-left-end {
    justify-content: flex-start;
    align-items: flex-end;
}

/* right */
.p-overlay-right {
    justify-content: flex-end;
}
.p-overlay-right-start {
    justify-content: flex-end;
    align-items: flex-start;
}
.p-overlay-right-end {
    justify-content: flex-end;
    align-items: flex-end;
}

.p-overlay-content ~ .p-overlay-content {
    display: none;
}
`;
var classes = {
	host: "p-overlay-host",
	root: ({ instance }) => {
		const modal = instance.modal();
		const dir = instance.overlayResponsiveDirection();
		return ["p-overlay p-component", {
			"p-overlay-modal p-overlay-mask p-overlay-mask-enter-active": modal,
			"p-overlay-center": modal && dir === "center",
			"p-overlay-top": modal && dir === "top",
			"p-overlay-top-start": modal && dir === "top-start",
			"p-overlay-top-end": modal && dir === "top-end",
			"p-overlay-bottom": modal && dir === "bottom",
			"p-overlay-bottom-start": modal && dir === "bottom-start",
			"p-overlay-bottom-end": modal && dir === "bottom-end",
			"p-overlay-left": modal && dir === "left",
			"p-overlay-left-start": modal && dir === "left-start",
			"p-overlay-left-end": modal && dir === "left-end",
			"p-overlay-right": modal && dir === "right",
			"p-overlay-right-start": modal && dir === "right-start",
			"p-overlay-right-end": modal && dir === "right-end"
		}];
	},
	content: "p-overlay-content"
};
var OverlayStyle = class OverlayStyle extends BaseStyle {
	name = "overlay";
	style = style;
	classes = classes;
	inlineStyles = inlineStyles;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵOverlayStyle_BaseFactory = void 0;
		return function OverlayStyle_Factory(__ngFactoryType__) {
			return (ɵOverlayStyle_BaseFactory || (ɵOverlayStyle_BaseFactory = ɵɵgetInheritedFactory(OverlayStyle)))(__ngFactoryType__ || OverlayStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: OverlayStyle,
		factory: OverlayStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OverlayStyle, [{ type: Injectable }], null, null);
})();
var OVERLAY_INSTANCE = new InjectionToken("OVERLAY_INSTANCE");
var Overlay = class Overlay extends BaseComponent {
	componentName = "Overlay";
	$pcOverlay = inject(OVERLAY_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	hostName = input("", ...ngDevMode ? [{ debugName: "hostName" }] : /* istanbul ignore next */ []);
	visible = model(false, ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	style = input(...ngDevMode ? [void 0, { debugName: "style" }] : /* istanbul ignore next */ []);
	styleClass = input(...ngDevMode ? [void 0, { debugName: "styleClass" }] : /* istanbul ignore next */ []);
	contentStyle = input(...ngDevMode ? [void 0, { debugName: "contentStyle" }] : /* istanbul ignore next */ []);
	contentStyleClass = input(...ngDevMode ? [void 0, { debugName: "contentStyleClass" }] : /* istanbul ignore next */ []);
	target = input(...ngDevMode ? [void 0, { debugName: "target" }] : /* istanbul ignore next */ []);
	autoZIndex = input(...ngDevMode ? [void 0, { debugName: "autoZIndex" }] : /* istanbul ignore next */ []);
	baseZIndex = input(...ngDevMode ? [void 0, { debugName: "baseZIndex" }] : /* istanbul ignore next */ []);
	listener = input(...ngDevMode ? [void 0, { debugName: "listener" }] : /* istanbul ignore next */ []);
	responsive = input(...ngDevMode ? [void 0, { debugName: "responsive" }] : /* istanbul ignore next */ []);
	options = input(...ngDevMode ? [void 0, { debugName: "options" }] : /* istanbul ignore next */ []);
	appendTo = input(void 0, ...ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []);
	inline = input(false, ...ngDevMode ? [{ debugName: "inline" }] : /* istanbul ignore next */ []);
	motionOptions = input(void 0, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	onBeforeShow = output();
	onShow = output();
	onBeforeHide = output();
	onHide = output();
	onAnimationStart = output();
	onAnimationDone = output();
	onBeforeEnter = output();
	onEnter = output();
	onAfterEnter = output();
	onBeforeLeave = output();
	onLeave = output();
	onAfterLeave = output();
	overlayViewChild = viewChild("overlay", ...ngDevMode ? [{ debugName: "overlayViewChild" }] : /* istanbul ignore next */ []);
	contentViewChild = viewChild("content", ...ngDevMode ? [{ debugName: "contentViewChild" }] : /* istanbul ignore next */ []);
	contentTemplate = contentChild("content", {
		...ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	hostAttrSelector = input(...ngDevMode ? [void 0, { debugName: "hostAttrSelector" }] : /* istanbul ignore next */ []);
	$appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []);
	$overlayOptions = computed(() => ({
		...this.config?.overlayOptions,
		...this.options()
	}), ...ngDevMode ? [{ debugName: "$overlayOptions" }] : /* istanbul ignore next */ []);
	$overlayResponsiveOptions = computed(() => ({
		...this.$overlayOptions()?.responsive,
		...this.responsive()
	}), ...ngDevMode ? [{ debugName: "$overlayResponsiveOptions" }] : /* istanbul ignore next */ []);
	overlayResponsiveDirection = computed(() => this.$overlayResponsiveOptions()?.direction || "center", ...ngDevMode ? [{ debugName: "overlayResponsiveDirection" }] : /* istanbul ignore next */ []);
	$mode = computed(() => this.mode() || this.$overlayOptions()?.mode, ...ngDevMode ? [{ debugName: "$mode" }] : /* istanbul ignore next */ []);
	mergedStyleClass = computed(() => this.cn(this.styleClass(), this.modal() ? this.$overlayResponsiveOptions()?.styleClass : this.$overlayOptions()?.styleClass), ...ngDevMode ? [{ debugName: "mergedStyleClass" }] : /* istanbul ignore next */ []);
	mergedContentStyleClass = computed(() => this.cn(this.contentStyleClass(), this.modal() ? this.$overlayResponsiveOptions()?.contentStyleClass : this.$overlayOptions()?.contentStyleClass), ...ngDevMode ? [{ debugName: "mergedContentStyleClass" }] : /* istanbul ignore next */ []);
	$target = computed(() => {
		const value = this.target() || this.$overlayOptions()?.target;
		return value === void 0 ? "@prev" : value;
	}, ...ngDevMode ? [{ debugName: "$target" }] : /* istanbul ignore next */ []);
	$autoZIndex = computed(() => {
		const value = this.autoZIndex() || this.$overlayOptions()?.autoZIndex;
		return value === void 0 ? true : value;
	}, ...ngDevMode ? [{ debugName: "$autoZIndex" }] : /* istanbul ignore next */ []);
	$baseZIndex = computed(() => {
		const value = this.baseZIndex() || this.$overlayOptions()?.baseZIndex;
		return value === void 0 ? 0 : value;
	}, ...ngDevMode ? [{ debugName: "$baseZIndex" }] : /* istanbul ignore next */ []);
	$listener = computed(() => this.listener() || this.$overlayOptions()?.listener, ...ngDevMode ? [{ debugName: "$listener" }] : /* istanbul ignore next */ []);
	modal = computed(() => {
		if (isPlatformBrowser(this.platformId)) return this.$mode() === "modal" || this.$overlayResponsiveOptions() && this.document.defaultView?.matchMedia(this.$overlayResponsiveOptions().media?.replace("@media", "") || `(max-width: ${this.$overlayResponsiveOptions().breakpoint})`).matches;
	}, ...ngDevMode ? [{ debugName: "modal" }] : /* istanbul ignore next */ []);
	overlayMode = computed(() => this.$mode() || (this.modal() ? "modal" : "overlay"), ...ngDevMode ? [{ debugName: "overlayMode" }] : /* istanbul ignore next */ []);
	overlayEl = computed(() => this.overlayViewChild()?.nativeElement, ...ngDevMode ? [{ debugName: "overlayEl" }] : /* istanbul ignore next */ []);
	contentEl = computed(() => this.contentViewChild()?.nativeElement, ...ngDevMode ? [{ debugName: "contentEl" }] : /* istanbul ignore next */ []);
	targetEl = computed(() => Y(this.$target(), this.el?.nativeElement), ...ngDevMode ? [{ debugName: "targetEl" }] : /* istanbul ignore next */ []);
	computedMotionOptions = computed(() => ({
		...this.ptm("motion"),
		...this.motionOptions() || this.$overlayOptions()?.motionOptions
	}), ...ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []);
	modalVisible = signal(false, ...ngDevMode ? [{ debugName: "modalVisible" }] : /* istanbul ignore next */ []);
	isOverlayClicked = false;
	isOverlayContentClicked = false;
	scrollHandler;
	documentClickListener;
	documentResizeListener;
	_componentStyle = inject(OverlayStyle);
	bindDirectiveInstance = inject(Bind, { self: true });
	documentKeyboardListener;
	parentDragSubscription = null;
	transformOptions = {
		default: "scaleY(0.8)",
		center: "scale(0.7)",
		top: "translate3d(0px, -100%, 0px)",
		"top-start": "translate3d(0px, -100%, 0px)",
		"top-end": "translate3d(0px, -100%, 0px)",
		bottom: "translate3d(0px, 100%, 0px)",
		"bottom-start": "translate3d(0px, 100%, 0px)",
		"bottom-end": "translate3d(0px, 100%, 0px)",
		left: "translate3d(-100%, 0px, 0px)",
		"left-start": "translate3d(-100%, 0px, 0px)",
		"left-end": "translate3d(-100%, 0px, 0px)",
		right: "translate3d(100%, 0px, 0px)",
		"right-start": "translate3d(100%, 0px, 0px)",
		"right-end": "translate3d(100%, 0px, 0px)"
	};
	overlayService = inject(OverlayService);
	constructor() {
		super();
		effect(() => {
			if (this.visible() && !this.modalVisible()) this.modalVisible.set(true);
		});
	}
	container = signal(void 0, ...ngDevMode ? [{ debugName: "container" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptm("host"));
	}
	show(overlay, isFocus = false) {
		this.onVisibleChange(true);
		this.handleEvents("onShow", {
			overlay: overlay || this.overlayEl(),
			target: this.targetEl(),
			mode: this.overlayMode()
		});
		if (isFocus) Wt(this.targetEl());
		if (this.modal()) this.$blockBodyScroll();
	}
	hide(overlay, isFocus = false) {
		if (!this.visible()) return;
		else {
			this.onVisibleChange(false);
			this.handleEvents("onHide", {
				overlay: overlay || this.overlayEl(),
				target: this.targetEl(),
				mode: this.overlayMode()
			});
			if (isFocus) Wt(this.targetEl());
			if (this.modal()) this.$unblockBodyScroll();
		}
	}
	onVisibleChange(visible) {
		this.visible.set(visible);
	}
	onOverlayClick() {
		this.isOverlayClicked = true;
	}
	onOverlayContentClick(event) {
		this.overlayService.add({
			originalEvent: event,
			target: this.targetEl()
		});
		this.isOverlayContentClicked = true;
	}
	onOverlayBeforeEnter(event) {
		event.element.style.removeProperty("pointer-events");
		this.handleEvents("onBeforeShow", {
			overlay: this.overlayEl(),
			target: this.targetEl(),
			mode: this.overlayMode()
		});
		this.container.set(this.overlayEl() || event.element);
		this.show(this.overlayEl(), true);
		markInstance(this.overlayEl(), this.hostAttrSelector());
		this.appendOverlay();
		this.alignOverlay();
		this.bindParentDragListener();
		this.setZIndex();
		this.handleEvents("onBeforeEnter", event);
	}
	onOverlayEnter(event) {
		this.handleEvents("onEnter", event);
	}
	onOverlayAfterEnter(event) {
		this.bindListeners();
		this.handleEvents("onAfterEnter", event);
	}
	onOverlayBeforeLeave(event) {
		event.element.style.pointerEvents = "none";
		this.handleEvents("onBeforeHide", {
			overlay: this.overlayEl(),
			target: this.targetEl(),
			mode: this.overlayMode()
		});
		this.handleEvents("onBeforeLeave", event);
	}
	onOverlayLeave(event) {
		this.handleEvents("onLeave", event);
	}
	onOverlayAfterLeave(event) {
		this.hide(this.overlayEl(), true);
		this.container.set(null);
		this.unbindListeners();
		this.appendOverlay();
		zindexutils_default.clear(this.overlayEl());
		this.modalVisible.set(false);
		this.cd.markForCheck();
		this.handleEvents("onAfterLeave", event);
	}
	handleEvents(name, params) {
		this[name].emit(params);
		const opts = this.options();
		if (opts && opts[name]) opts[name](params);
		if (this.config?.overlayOptions && (this.config?.overlayOptions)[name]) (this.config?.overlayOptions)[name](params);
	}
	setZIndex() {
		if (this.$autoZIndex()) zindexutils_default.set(this.overlayMode(), this.overlayEl(), this.$baseZIndex() + this.config?.zIndex[this.overlayMode()]);
	}
	appendOverlay() {
		if (this.$appendTo() && this.$appendTo() !== "self") {
			if (this.$appendTo() === "body") Ct(this.$overlayParent(this.document.body, this.overlayEl()), this.overlayEl());
			else Ct(this.$overlayParent(this.$appendTo(), this.overlayEl()), this.overlayEl());
		}
	}
	alignOverlay() {
		if (!this.modal()) {
			if (this.overlayEl() && this.targetEl()) {
				this.overlayEl().style.minWidth = L(this.targetEl()) + "px";
				if (this.$appendTo() === "self") G(this.overlayEl(), this.targetEl());
				else z(this.overlayEl(), this.targetEl());
			}
		}
	}
	bindListeners() {
		this.bindScrollListener();
		this.bindDocumentClickListener();
		this.bindDocumentResizeListener();
		this.bindDocumentKeyboardListener();
	}
	unbindListeners() {
		this.unbindScrollListener();
		this.unbindDocumentClickListener();
		this.unbindDocumentResizeListener();
		this.unbindDocumentKeyboardListener();
		this.unbindParentDragListener();
	}
	bindParentDragListener() {
		if (!this.parentDragSubscription && this.$appendTo() !== "self" && this.targetEl) this.parentDragSubscription = this.overlayService.parentDragObservable.subscribe((container) => {
			if (container.contains(this.targetEl())) this.hide(this.overlayEl(), true);
		});
	}
	unbindParentDragListener() {
		if (this.parentDragSubscription) {
			this.parentDragSubscription.unsubscribe();
			this.parentDragSubscription = null;
		}
	}
	bindScrollListener() {
		if (!this.scrollHandler) this.scrollHandler = new ConnectedOverlayScrollHandler(this.targetEl(), (event) => {
			if (this.$listener() ? this.$listener()(event, {
				type: "scroll",
				mode: this.overlayMode(),
				valid: true
			}) : true) this.hide(event, true);
		});
		this.scrollHandler.bindScrollListener();
	}
	unbindScrollListener() {
		if (this.scrollHandler) this.scrollHandler.unbindScrollListener();
	}
	bindDocumentClickListener() {
		if (!this.documentClickListener) this.documentClickListener = this.renderer.listen(this.document, "click", (event) => {
			const node = getEventTarget(event, this.targetEl());
			const isOutsideClicked = !(this.targetEl() && (this.targetEl().isSameNode(node) || !this.isOverlayClicked && this.targetEl().contains(node))) && !this.isOverlayContentClicked;
			if (this.$listener() ? this.$listener()(event, {
				type: "outside",
				mode: this.overlayMode(),
				valid: event.which !== 3 && isOutsideClicked
			}) : isOutsideClicked) this.hide(event);
			this.isOverlayClicked = this.isOverlayContentClicked = false;
		});
	}
	unbindDocumentClickListener() {
		if (this.documentClickListener) {
			this.documentClickListener();
			this.documentClickListener = null;
		}
	}
	bindDocumentResizeListener() {
		if (!this.documentResizeListener) this.documentResizeListener = this.renderer.listen(this.document.defaultView, "resize", (event) => {
			if (this.$listener() ? this.$listener()(event, {
				type: "resize",
				mode: this.overlayMode(),
				valid: !fe()
			}) : !fe()) this.hide(event, true);
		});
	}
	unbindDocumentResizeListener() {
		if (this.documentResizeListener) {
			this.documentResizeListener();
			this.documentResizeListener = null;
		}
	}
	bindDocumentKeyboardListener() {
		if (this.documentKeyboardListener) return;
		this.documentKeyboardListener = this.renderer.listen(this.document.defaultView, "keydown", (event) => {
			if (this.$overlayOptions().hideOnEscape === false || event.code !== "Escape") return;
			if (this.$listener() ? this.$listener()(event, {
				type: "keydown",
				mode: this.overlayMode(),
				valid: !fe()
			}) : !fe()) this.hide(event, true);
		});
	}
	unbindDocumentKeyboardListener() {
		if (this.documentKeyboardListener) {
			this.documentKeyboardListener();
			this.documentKeyboardListener = null;
		}
	}
	onDestroy() {
		this.hide(this.overlayEl(), true);
		if (this.overlayEl() && this.$appendTo() !== "self") {
			this.renderer.appendChild(this.el.nativeElement, this.overlayEl());
			zindexutils_default.clear(this.overlayEl());
		}
		if (this.scrollHandler) {
			this.scrollHandler.destroy();
			this.scrollHandler = null;
		}
		this.unbindListeners();
	}
	static ɵfac = function Overlay_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Overlay)();
	};
	static ɵcmp = (function() {
		const _c0 = ["content"];
		const _c1 = ["overlay"];
		const _c2 = ["*", "*"];
		const _c3 = () => ({ mode: null });
		const _c4 = (a0) => ({ $implicit: a0 });
		const _c5 = (a0) => ({ mode: a0 });
		function Overlay_Conditional_0_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Overlay_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵprojection(0);
				ɵɵtemplate(1, Overlay_Conditional_0_ng_container_1_Template, 1, 0, "ng-container", 2);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r0.contentTemplate())("ngTemplateOutletContext", ɵɵpureFunction1(3, _c4, ɵɵpureFunction0(2, _c3)));
			}
		}
		function Overlay_Conditional_1_Conditional_0_ng_container_6_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Overlay_Conditional_1_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r2 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "div", 4, 0);
				ɵɵlistener("click", function Overlay_Conditional_1_Conditional_0_Template_div_click_0_listener() {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayClick());
				});
				ɵɵelementStart(2, "p-motion", 5);
				ɵɵlistener("onBeforeEnter", function Overlay_Conditional_1_Conditional_0_Template_p_motion_onBeforeEnter_2_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayBeforeEnter($event));
				})("onEnter", function Overlay_Conditional_1_Conditional_0_Template_p_motion_onEnter_2_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayEnter($event));
				})("onAfterEnter", function Overlay_Conditional_1_Conditional_0_Template_p_motion_onAfterEnter_2_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayAfterEnter($event));
				})("onBeforeLeave", function Overlay_Conditional_1_Conditional_0_Template_p_motion_onBeforeLeave_2_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayBeforeLeave($event));
				})("onLeave", function Overlay_Conditional_1_Conditional_0_Template_p_motion_onLeave_2_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayLeave($event));
				})("onAfterLeave", function Overlay_Conditional_1_Conditional_0_Template_p_motion_onAfterLeave_2_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayAfterLeave($event));
				});
				ɵɵelementStart(3, "div", 4, 1);
				ɵɵlistener("click", function Overlay_Conditional_1_Conditional_0_Template_div_click_3_listener($event) {
					ɵɵrestoreView(_r2);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.onOverlayContentClick($event));
				});
				ɵɵprojection(5, 1);
				ɵɵtemplate(6, Overlay_Conditional_1_Conditional_0_ng_container_6_Template, 1, 0, "ng-container", 2);
				ɵɵelementEnd()()();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r0.sx("root"));
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("root"), ctx_r0.mergedStyleClass()));
				ɵɵproperty("pBind", ctx_r0.ptm("root"));
				ɵɵadvance(2);
				ɵɵproperty("visible", ctx_r0.visible())("name", ctx_r0.pcn("p-anchored-overlay"))("appear", true)("options", ctx_r0.computedMotionOptions());
				ɵɵadvance();
				ɵɵstyleMap(ctx_r0.sx("content"));
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("content"), ctx_r0.mergedContentStyleClass()));
				ɵɵproperty("pBind", ctx_r0.ptm("content"));
				ɵɵadvance(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.contentTemplate())("ngTemplateOutletContext", ɵɵpureFunction1(18, _c4, ɵɵpureFunction1(16, _c5, ctx_r0.overlayMode())));
			}
		}
		function Overlay_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Overlay_Conditional_1_Conditional_0_Template, 7, 20, "div", 3);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(ctx_r0.modalVisible() ? 0 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Overlay,
			selectors: [["p-overlay"]],
			contentQueries: function Overlay_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.contentTemplate, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			viewQuery: function Overlay_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.overlayViewChild, _c1, 5)(ctx.contentViewChild, _c0, 5);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			inputs: {
				hostName: [1, "hostName"],
				visible: [1, "visible"],
				mode: [1, "mode"],
				style: [1, "style"],
				styleClass: [1, "styleClass"],
				contentStyle: [1, "contentStyle"],
				contentStyleClass: [1, "contentStyleClass"],
				target: [1, "target"],
				autoZIndex: [1, "autoZIndex"],
				baseZIndex: [1, "baseZIndex"],
				listener: [1, "listener"],
				responsive: [1, "responsive"],
				options: [1, "options"],
				appendTo: [1, "appendTo"],
				inline: [1, "inline"],
				motionOptions: [1, "motionOptions"],
				hostAttrSelector: [1, "hostAttrSelector"]
			},
			outputs: {
				visible: "visibleChange",
				onBeforeShow: "onBeforeShow",
				onShow: "onShow",
				onBeforeHide: "onBeforeHide",
				onHide: "onHide",
				onAnimationStart: "onAnimationStart",
				onAnimationDone: "onAnimationDone",
				onBeforeEnter: "onBeforeEnter",
				onEnter: "onEnter",
				onAfterEnter: "onAfterEnter",
				onBeforeLeave: "onBeforeLeave",
				onLeave: "onLeave",
				onAfterLeave: "onAfterLeave"
			},
			features: [
				ɵɵProvidersFeature([
					OverlayStyle,
					{
						provide: OVERLAY_INSTANCE,
						useExisting: Overlay
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Overlay
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: _c2,
			decls: 2,
			vars: 1,
			consts: [
				["overlay", ""],
				["content", ""],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				],
				[
					3,
					"class",
					"style",
					"pBind"
				],
				[
					3,
					"click",
					"pBind"
				],
				[
					3,
					"onBeforeEnter",
					"onEnter",
					"onAfterEnter",
					"onBeforeLeave",
					"onLeave",
					"onAfterLeave",
					"visible",
					"name",
					"appear",
					"options"
				]
			],
			template: function Overlay_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef(_c2);
					ɵɵconditionalCreate(0, Overlay_Conditional_0_Template, 2, 5)(1, Overlay_Conditional_1_Template, 1, 1);
				}
				if (rf & 2) ɵɵconditional(ctx.inline() ? 0 : 1);
			},
			dependencies: [
				NgTemplateOutlet,
				SharedModule,
				Bind,
				MotionModule,
				Motion
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Overlay, [{
		type: Component,
		args: [{
			selector: "p-overlay",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				SharedModule,
				Bind,
				MotionModule
			],
			hostDirectives: [Bind],
			template: `
        @if (inline()) {
            <ng-content />
            <ng-container *ngTemplateOutlet="contentTemplate(); context: { $implicit: { mode: null } }" />
        } @else {
            @if (modalVisible()) {
                <div #overlay [class]="cn(cx('root'), mergedStyleClass())" [style]="sx('root')" [pBind]="ptm('root')" (click)="onOverlayClick()">
                    <p-motion
                        [visible]="visible()"
                        [name]="pcn('p-anchored-overlay')"
                        [appear]="true"
                        [options]="computedMotionOptions()"
                        (onBeforeEnter)="onOverlayBeforeEnter($event)"
                        (onEnter)="onOverlayEnter($event)"
                        (onAfterEnter)="onOverlayAfterEnter($event)"
                        (onBeforeLeave)="onOverlayBeforeLeave($event)"
                        (onLeave)="onOverlayLeave($event)"
                        (onAfterLeave)="onOverlayAfterLeave($event)"
                    >
                        <div #content [class]="cn(cx('content'), mergedContentStyleClass())" [style]="sx('content')" [pBind]="ptm('content')" (click)="onOverlayContentClick($event)">
                            <ng-content />
                            <ng-container *ngTemplateOutlet="contentTemplate(); context: { $implicit: { mode: overlayMode() } }" />
                        </div>
                    </p-motion>
                </div>
            }
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				OverlayStyle,
				{
					provide: OVERLAY_INSTANCE,
					useExisting: Overlay
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Overlay
				}
			]
		}]
	}], () => [], {
		hostName: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "hostName",
				required: false
			}]
		}],
		visible: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}, {
			type: Output,
			args: ["visibleChange"]
		}],
		mode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		style: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "style",
				required: false
			}]
		}],
		styleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "styleClass",
				required: false
			}]
		}],
		contentStyle: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "contentStyle",
				required: false
			}]
		}],
		contentStyleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "contentStyleClass",
				required: false
			}]
		}],
		target: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		autoZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoZIndex",
				required: false
			}]
		}],
		baseZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "baseZIndex",
				required: false
			}]
		}],
		listener: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "listener",
				required: false
			}]
		}],
		responsive: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "responsive",
				required: false
			}]
		}],
		options: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		appendTo: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "appendTo",
				required: false
			}]
		}],
		inline: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inline",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		onBeforeShow: [{
			type: Output,
			args: ["onBeforeShow"]
		}],
		onShow: [{
			type: Output,
			args: ["onShow"]
		}],
		onBeforeHide: [{
			type: Output,
			args: ["onBeforeHide"]
		}],
		onHide: [{
			type: Output,
			args: ["onHide"]
		}],
		onAnimationStart: [{
			type: Output,
			args: ["onAnimationStart"]
		}],
		onAnimationDone: [{
			type: Output,
			args: ["onAnimationDone"]
		}],
		onBeforeEnter: [{
			type: Output,
			args: ["onBeforeEnter"]
		}],
		onEnter: [{
			type: Output,
			args: ["onEnter"]
		}],
		onAfterEnter: [{
			type: Output,
			args: ["onAfterEnter"]
		}],
		onBeforeLeave: [{
			type: Output,
			args: ["onBeforeLeave"]
		}],
		onLeave: [{
			type: Output,
			args: ["onLeave"]
		}],
		onAfterLeave: [{
			type: Output,
			args: ["onAfterLeave"]
		}],
		overlayViewChild: [{
			type: ViewChild,
			args: ["overlay", { isSignal: true }]
		}],
		contentViewChild: [{
			type: ViewChild,
			args: ["content", { isSignal: true }]
		}],
		contentTemplate: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}],
		hostAttrSelector: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "hostAttrSelector",
				required: false
			}]
		}]
	});
})();
var OverlayModule = class OverlayModule {
	static ɵfac = function OverlayModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || OverlayModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: OverlayModule,
		imports: [Overlay, SharedModule],
		exports: [Overlay, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Overlay,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OverlayModule, [{
		type: NgModule,
		args: [{
			imports: [Overlay, SharedModule],
			exports: [Overlay, SharedModule]
		}]
	}], null, null);
})();
export { Overlay as t };
