import { ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { u as isPlatformBrowser } from "./common-D_MNYFJX.js";
import { Ai as setClassMetadata, Ga as ɵɵdefineNgModule, Ji as ɵɵInheritDefinitionFeature, Nn as NgModule, O as booleanAttribute, Sn as Input, Wa as ɵɵdefineDirective, X as input, _o as ɵɵgetInheritedFactory, fn as ElementRef, un as Directive } from "./core-BenYQOr3.js";
import { i as DomHandler, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
// node_modules/primeng/fesm2022/primeng-autofocus.mjs
var AutoFocus = class AutoFocus extends BaseComponent {
	autofocus = input(false, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		alias: "pAutoFocus",
		transform: booleanAttribute
	});
	focused = false;
	host = inject(ElementRef);
	onAfterContentChecked() {
		if (this.autofocus() === false) this.host.nativeElement.removeAttribute("autofocus");
		else this.host.nativeElement.setAttribute("autofocus", true);
		if (!this.focused) this.autoFocus();
	}
	onAfterViewChecked() {
		if (!this.focused) this.autoFocus();
	}
	autoFocus() {
		if (isPlatformBrowser(this.platformId) && this.autofocus()) setTimeout(() => {
			const focusableElements = DomHandler.getFocusableElements(this.host?.nativeElement);
			if (focusableElements.length === 0) this.host.nativeElement.focus();
			if (focusableElements.length > 0) focusableElements[0].focus();
			this.focused = true;
		});
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵAutoFocus_BaseFactory = void 0;
		return function AutoFocus_Factory(__ngFactoryType__) {
			return (ɵAutoFocus_BaseFactory || (ɵAutoFocus_BaseFactory = ɵɵgetInheritedFactory(AutoFocus)))(__ngFactoryType__ || AutoFocus);
		};
	})();
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: AutoFocus,
		selectors: [[
			"",
			"pAutoFocus",
			""
		]],
		inputs: { autofocus: [
			1,
			"pAutoFocus",
			"autofocus"
		] },
		features: [ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AutoFocus, [{
		type: Directive,
		args: [{
			selector: "[pAutoFocus]",
			standalone: true
		}]
	}], null, { autofocus: [{
		type: Input,
		args: [{
			isSignal: true,
			alias: "pAutoFocus",
			required: false
		}]
	}] });
})();
var AutoFocusModule = class AutoFocusModule {
	static ɵfac = function AutoFocusModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || AutoFocusModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: AutoFocusModule,
		imports: [AutoFocus],
		exports: [AutoFocus]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AutoFocusModule, [{
		type: NgModule,
		args: [{
			imports: [AutoFocus],
			exports: [AutoFocus]
		}]
	}], null, null);
})();
export { AutoFocusModule as n, AutoFocus as t };
