import { A as createOverlayRef, C as ScrollStrategyOptions, D as createFlexibleConnectedPositionStrategy, E as createCloseScrollStrategy, M as validateHorizontalPosition, N as validateVerticalPosition, O as createGlobalPositionStrategy, S as STANDARD_DROPDOWN_BELOW_POSITIONS, T as createBlockScrollStrategy, _ as OverlayOutsideClickDispatcher, a as CloseScrollStrategy, b as RepositionScrollStrategy, c as FlexibleConnectedPositionStrategy, d as OVERLAY_DEFAULT_CONFIG, f as Overlay, g as OverlayModule, h as OverlayKeyboardDispatcher, i as CdkOverlayOrigin, j as createRepositionScrollStrategy, k as createNoopScrollStrategy, l as GlobalPositionStrategy, m as OverlayContainer, n as CDK_CONNECTED_OVERLAY_DEFAULT_CONFIG, o as ConnectedOverlayPositionChange, p as OverlayConfig, r as CdkConnectedOverlay, s as ConnectionPositionPair, t as BlockScrollStrategy, u as NoopScrollStrategy, v as OverlayPositionBuilder, w as ScrollingVisibility, x as STANDARD_DROPDOWN_ADJACENT_POSITIONS, y as OverlayRef } from "./_overlay-module-chunk-C1I0eHx4.js";
import { a as CdkVirtualScrollViewport, c as ScrollDispatcher, f as Dir, i as CdkVirtualForOf, n as CdkScrollable, o as CdkVirtualScrollableElement, r as CdkScrollableModule, s as CdkVirtualScrollableWindow, t as CdkFixedSizeVirtualScroll, u as ViewportRuler } from "./scrolling-cY6EEIaN.js";
import { wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Gn as RendererFactory2, Zn as Service, qa as ɵɵdefineService } from "./core-BenYQOr3.js";
// node_modules/@angular/cdk/fesm2022/overlay.mjs
var FullscreenOverlayContainer = class FullscreenOverlayContainer extends OverlayContainer {
	_renderer = inject(RendererFactory2).createRenderer(null, null);
	_fullScreenEventName;
	_cleanupFullScreenListener;
	ngOnDestroy() {
		super.ngOnDestroy();
		this._cleanupFullScreenListener?.();
	}
	_createContainer() {
		const eventName = this._getEventName();
		super._createContainer();
		this._adjustParentForFullscreenChange();
		if (eventName) {
			this._cleanupFullScreenListener?.();
			this._cleanupFullScreenListener = this._renderer.listen("document", eventName, () => {
				this._adjustParentForFullscreenChange();
			});
		}
	}
	_adjustParentForFullscreenChange() {
		if (this._containerElement) (this.getFullscreenElement() || this._document.body).appendChild(this._containerElement);
	}
	_getEventName() {
		if (!this._fullScreenEventName) {
			const _document = this._document;
			if (_document.fullscreenEnabled) this._fullScreenEventName = "fullscreenchange";
			else if (_document.webkitFullscreenEnabled) this._fullScreenEventName = "webkitfullscreenchange";
		}
		return this._fullScreenEventName;
	}
	getFullscreenElement() {
		const _document = this._document;
		return _document.fullscreenElement || _document.webkitFullscreenElement || null;
	}
	static ɵfac = function FullscreenOverlayContainer_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || FullscreenOverlayContainer)();
	};
	static ɵprov = /*@__PURE__*/ ɵɵdefineService({
		token: FullscreenOverlayContainer,
		factory: FullscreenOverlayContainer.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FullscreenOverlayContainer, [{ type: Service }], null, null);
})();
export { BlockScrollStrategy, CDK_CONNECTED_OVERLAY_DEFAULT_CONFIG, CdkConnectedOverlay, CdkOverlayOrigin, CdkScrollable, CloseScrollStrategy, ConnectedOverlayPositionChange, ConnectionPositionPair, FlexibleConnectedPositionStrategy, FullscreenOverlayContainer, GlobalPositionStrategy, NoopScrollStrategy, OVERLAY_DEFAULT_CONFIG, Overlay, OverlayConfig, OverlayContainer, OverlayKeyboardDispatcher, OverlayModule, OverlayOutsideClickDispatcher, OverlayPositionBuilder, OverlayRef, RepositionScrollStrategy, STANDARD_DROPDOWN_ADJACENT_POSITIONS, STANDARD_DROPDOWN_BELOW_POSITIONS, ScrollDispatcher, ScrollStrategyOptions, ScrollingVisibility, ViewportRuler, createBlockScrollStrategy, createCloseScrollStrategy, createFlexibleConnectedPositionStrategy, createGlobalPositionStrategy, createNoopScrollStrategy, createOverlayRef, createRepositionScrollStrategy, validateHorizontalPosition, validateVerticalPosition, CdkFixedSizeVirtualScroll as ɵɵCdkFixedSizeVirtualScroll, CdkScrollableModule as ɵɵCdkScrollableModule, CdkVirtualForOf as ɵɵCdkVirtualForOf, CdkVirtualScrollViewport as ɵɵCdkVirtualScrollViewport, CdkVirtualScrollableElement as ɵɵCdkVirtualScrollableElement, CdkVirtualScrollableWindow as ɵɵCdkVirtualScrollableWindow, Dir as ɵɵDir };
