import { Fn as forwardRef, U as InjectionToken, Ui as signal, _ as untracked, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, xn as effect, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Fs as ɵɵtextInterpolate1, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Ms as ɵɵtemplateRefExtractor, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Qo as ɵɵpureFunction2, Ro as ɵɵlistener, S as ViewChild, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, Zo as ɵɵpureFunction1, Zs as ɵɵviewQuerySignal, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, ds as ɵɵrepeaterCreate, go as ɵɵgetCurrentView, gt as viewChild, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, rt as numberAttribute, us as ɵɵrepeater, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { NG_VALUE_ACCESSOR } from "./@angular_forms.js";
import { F as Vt, L as Wt, _ as Bt, ct as x } from "./primeng-utils-CHKSviI4.js";
import { t as ChevronDown } from "./primeicons-angular-chevron-down-Cxy_idKw.js";
import { t as Times } from "./primeicons-angular-times-BxAXRRO6.js";
import { b as l } from "./dist-BRhwYpCB.js";
import { SharedModule } from "./primeng_api.js";
import { t as AutoFocus } from "./primeng-autofocus-C_rkAfz2.js";
import { n as PARENT_INSTANCE } from "./primeng-basecomponent-cJWiv26K.js";
import { t as BaseEditableHolder } from "./primeng-baseeditableholder-joFSbzas.js";
import { Bind } from "./primeng_bind.js";
import { t as Chip } from "./primeng-chip-CQTgSJHN.js";
import { t as Fluid } from "./primeng-fluid-DG0dbSem.js";
import { t as Overlay } from "./primeng-overlay-CukFCujH.js";
import { t as Tree } from "./primeng-tree-DMqXSzzC.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeuix/styles/dist/treeselect/index.mjs
var style = "\n    .p-treeselect {\n        display: inline-flex;\n        cursor: pointer;\n        position: relative;\n        user-select: none;\n        background: dt('treeselect.background');\n        border: 1px solid dt('treeselect.border.color');\n        transition:\n            background dt('treeselect.transition.duration'),\n            color dt('treeselect.transition.duration'),\n            border-color dt('treeselect.transition.duration'),\n            outline-color dt('treeselect.transition.duration'),\n            box-shadow dt('treeselect.transition.duration');\n        border-radius: dt('treeselect.border.radius');\n        outline-color: transparent;\n        box-shadow: dt('treeselect.shadow');\n    }\n\n    .p-treeselect:not(.p-disabled):hover {\n        border-color: dt('treeselect.hover.border.color');\n    }\n\n    .p-treeselect:not(.p-disabled).p-focus {\n        border-color: dt('treeselect.focus.border.color');\n        box-shadow: dt('treeselect.focus.ring.shadow');\n        outline: dt('treeselect.focus.ring.width') dt('treeselect.focus.ring.style') dt('treeselect.focus.ring.color');\n        outline-offset: dt('treeselect.focus.ring.offset');\n    }\n\n    .p-treeselect.p-variant-filled {\n        background: dt('treeselect.filled.background');\n    }\n\n    .p-treeselect.p-variant-filled:not(.p-disabled):hover {\n        background: dt('treeselect.filled.hover.background');\n    }\n\n    .p-treeselect.p-variant-filled.p-focus {\n        background: dt('treeselect.filled.focus.background');\n    }\n\n    .p-treeselect.p-invalid {\n        border-color: dt('treeselect.invalid.border.color');\n    }\n\n    .p-treeselect.p-disabled {\n        opacity: 1;\n        background: dt('treeselect.disabled.background');\n    }\n\n    .p-treeselect-clear-icon {\n        align-self: center;\n        color: dt('treeselect.clear.icon.color');\n        inset-inline-end: dt('treeselect.dropdown.width');\n        flex-shrink: 0;\n    }\n\n    .p-treeselect-dropdown {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        flex-shrink: 0;\n        background: transparent;\n        color: dt('treeselect.dropdown.color');\n        width: dt('treeselect.dropdown.width');\n        border-start-end-radius: dt('border.radius.md');\n        border-end-end-radius: dt('border.radius.md');\n    }\n\n    .p-treeselect-label-container {\n        overflow: hidden;\n        flex: 1 1 auto;\n        cursor: pointer;\n    }\n\n    .p-treeselect-label {\n        display: flex;\n        align-items: center;\n        gap: calc(dt('treeselect.padding.y') / 2);\n        white-space: nowrap;\n        cursor: pointer;\n        overflow: hidden;\n        text-overflow: ellipsis;\n        padding: dt('treeselect.padding.y') dt('treeselect.padding.x');\n        min-height: calc(1lh + 2 * dt('treeselect.padding.y'));\n        color: dt('treeselect.color');\n        font-weight: dt('treeselect.font.weight');\n        font-size: dt('treeselect.font.size');\n    }\n\n    .p-treeselect-label.p-placeholder {\n        color: dt('treeselect.placeholder.color');\n    }\n\n    .p-treeselect.p-invalid .p-treeselect-label.p-placeholder {\n        color: dt('treeselect.invalid.placeholder.color');\n    }\n\n    .p-treeselect:has(.p-select-clear-icon) .p-treeselect-label {\n        padding-inline-end: dt('treeselect.padding.x');\n    }\n\n    .p-treeselect.p-disabled .p-treeselect-label {\n        color: dt('treeselect.disabled.color');\n    }\n\n    .p-treeselect-label-empty {\n        overflow: hidden;\n        visibility: hidden;\n        font-weight: dt('treeselect.font.weight');\n        font-size: dt('treeselect.font.size');\n    }\n\n    .p-treeselect-overlay {\n        position: absolute;\n        top: 0;\n        left: 0;\n        background: dt('treeselect.overlay.background');\n        color: dt('treeselect.overlay.color');\n        border: 1px solid dt('treeselect.overlay.border.color');\n        border-radius: dt('treeselect.overlay.border.radius');\n        box-shadow: dt('treeselect.overlay.shadow');\n        overflow: hidden;\n        min-width: 100%;\n        will-change: transform;\n    }\n\n    .p-treeselect-tree-container {\n        overflow: auto;\n    }\n\n    .p-treeselect-empty-message {\n        padding: dt('treeselect.empty.message.padding');\n        background: transparent;\n    }\n\n    .p-treeselect-fluid {\n        display: flex;\n    }\n\n    .p-treeselect-overlay .p-tree {\n        padding: dt('treeselect.tree.padding');\n    }\n\n    .p-treeselect-overlay .p-tree-loading {\n        min-height: 3rem;\n    }\n\n    .p-treeselect-label .p-chip {\n        border-radius: dt('treeselect.chip.border.radius');\n        line-height: 1;\n    }\n\n    .p-treeselect-label:has(.p-chip) {\n        padding: calc(dt('treeselect.padding.y') / 2) calc(dt('treeselect.padding.x') / 2);\n    }\n\n    .p-treeselect-sm .p-treeselect-label {\n        font-size: dt('treeselect.sm.font.size');\n        padding-block: dt('treeselect.sm.padding.y');\n        padding-inline: dt('treeselect.sm.padding.x');\n        min-height: calc(1lh + 2 * dt('treeselect.sm.padding.y'));\n    }\n\n    .p-treeselect-sm .p-treeselect-label:has(.p-chip) {\n        padding: calc(dt('treeselect.sm.padding.y') / 2) calc(dt('treeselect.sm.padding.x') / 2);\n    }\n\n    .p-treeselect-sm .p-treeselect-dropdown .p-icon {\n        font-size: dt('treeselect.sm.font.size');\n        width: dt('treeselect.sm.font.size');\n        height: dt('treeselect.sm.font.size');\n    }\n\n    .p-treeselect-lg .p-treeselect-label {\n        font-size: dt('treeselect.lg.font.size');\n        padding-block: dt('treeselect.lg.padding.y');\n        padding-inline: dt('treeselect.lg.padding.x');\n        min-height: calc(1lh + 2 * dt('treeselect.lg.padding.y'));\n    }\n\n    .p-treeselect-lg .p-treeselect-label:has(.p-chip) {\n        padding: calc(dt('treeselect.lg.padding.y') / 2) calc(dt('treeselect.lg.padding.x') / 2);\n    }\n\n    .p-treeselect-lg .p-treeselect-dropdown .p-icon {\n        font-size: dt('treeselect.lg.font.size');\n        width: dt('treeselect.lg.font.size');\n        height: dt('treeselect.lg.font.size');\n    }\n";
// node_modules/primeng/fesm2022/primeng-treeselect.mjs
var inlineStyles = { root: ({ instance }) => ({ position: instance.$appendTo() === "self" ? "relative" : void 0 }) };
var classes = {
	root: ({ instance }) => ["p-treeselect p-component p-inputwrapper", {
		"p-treeselect-display-chip": instance.display() === "chip",
		"p-disabled": instance.$disabled(),
		"p-invalid": instance.invalid(),
		"p-focus": instance.focused(),
		"p-variant-filled": instance.$variant() === "filled",
		"p-inputwrapper-filled": !instance.emptyValue(),
		"p-inputwrapper-focus": instance.focused() || instance.overlayVisible(),
		"p-treeselect-open": instance.overlayVisible(),
		"p-treeselect-fluid": instance.hasFluid,
		"p-treeselect-sm p-inputfield-sm": instance.size() === "small",
		"p-treeselect-lg p-inputfield-lg": instance.size() === "large"
	}],
	labelContainer: "p-treeselect-label-container",
	label: ({ instance }) => ["p-treeselect-label", {
		"p-placeholder": instance.label() === instance.placeholder(),
		"p-treeselect-label-empty": !instance.placeholder() && instance.emptyValue()
	}],
	clearIcon: "p-treeselect-clear-icon",
	chip: "p-treeselect-chip-item",
	pcChip: "p-treeselect-chip",
	dropdown: "p-treeselect-dropdown",
	dropdownIcon: "p-treeselect-dropdown-icon",
	panel: "p-treeselect-overlay p-component-overlay p-component",
	treeContainer: "p-treeselect-tree-container",
	emptyMessage: "p-treeselect-empty-message"
};
var TreeSelectStyle = class TreeSelectStyle extends BaseStyle {
	name = "treeselect";
	style = style;
	classes = classes;
	inlineStyles = inlineStyles;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTreeSelectStyle_BaseFactory = void 0;
		return function TreeSelectStyle_Factory(__ngFactoryType__) {
			return (ɵTreeSelectStyle_BaseFactory || (ɵTreeSelectStyle_BaseFactory = ɵɵgetInheritedFactory(TreeSelectStyle)))(__ngFactoryType__ || TreeSelectStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TreeSelectStyle,
		factory: TreeSelectStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TreeSelectStyle, [{ type: Injectable }], null, null);
})();
var TreeSelectClasses;
(function(TreeSelectClasses) {
	TreeSelectClasses["root"] = "p-treeselect";
	TreeSelectClasses["labelContainer"] = "p-treeselect-label-container";
	TreeSelectClasses["label"] = "p-treeselect-label";
	TreeSelectClasses["chipItem"] = "p-treeselect-chip-item";
	TreeSelectClasses["clearIcon"] = "p-treeselect-clear-icon";
	TreeSelectClasses["pcChip"] = "p-treeselect-chip";
	TreeSelectClasses["dropdown"] = "p-treeselect-dropdown";
	TreeSelectClasses["dropdownIcon"] = "p-treeselect-dropdown-icon";
	TreeSelectClasses["panel"] = "p-treeselect-overlay";
	TreeSelectClasses["treeContainer"] = "p-treeselect-tree-container";
	TreeSelectClasses["emptyMessage"] = "p-treeselect-empty-message";
})(TreeSelectClasses || (TreeSelectClasses = {}));
var TREESELECT_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => TreeSelect),
	multi: true
};
var TREESELECT_INSTANCE = new InjectionToken("TREESELECT_INSTANCE");
var TreeSelect = class TreeSelect extends BaseEditableHolder {
	componentName = "TreeSelect";
	$pcTreeSelect = inject(TREESELECT_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	_componentStyle = inject(TreeSelectStyle);
	inputId = input(...ngDevMode ? [void 0, { debugName: "inputId" }] : /* istanbul ignore next */ []);
	scrollHeight = input("400px", ...ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []);
	metaKeySelection = input(false, {
		...ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	display = input("comma", ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	selectionMode = input("single", ...ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	tabindex = input("0", ...ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	placeholder = input(...ngDevMode ? [void 0, { debugName: "placeholder" }] : /* istanbul ignore next */ []);
	panelClass = input(...ngDevMode ? [void 0, { debugName: "panelClass" }] : /* istanbul ignore next */ []);
	panelStyle = input(...ngDevMode ? [void 0, { debugName: "panelStyle" }] : /* istanbul ignore next */ []);
	panelStyleClass = input(...ngDevMode ? [void 0, { debugName: "panelStyleClass" }] : /* istanbul ignore next */ []);
	labelStyle = input(...ngDevMode ? [void 0, { debugName: "labelStyle" }] : /* istanbul ignore next */ []);
	labelStyleClass = input(...ngDevMode ? [void 0, { debugName: "labelStyleClass" }] : /* istanbul ignore next */ []);
	overlayOptions = input(...ngDevMode ? [void 0, { debugName: "overlayOptions" }] : /* istanbul ignore next */ []);
	emptyMessage = input("", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	filter = input(false, {
		...ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filterBy = input("label", ...ngDevMode ? [{ debugName: "filterBy" }] : /* istanbul ignore next */ []);
	filterMode = input("lenient", ...ngDevMode ? [{ debugName: "filterMode" }] : /* istanbul ignore next */ []);
	filterPlaceholder = input(...ngDevMode ? [void 0, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []);
	filterLocale = input(...ngDevMode ? [void 0, { debugName: "filterLocale" }] : /* istanbul ignore next */ []);
	filterInputAutoFocus = input(true, {
		...ngDevMode ? { debugName: "filterInputAutoFocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	propagateSelectionDown = input(true, {
		...ngDevMode ? { debugName: "propagateSelectionDown" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	propagateSelectionUp = input(true, {
		...ngDevMode ? { debugName: "propagateSelectionUp" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showClear = input(false, {
		...ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	resetFilterOnHide = input(true, {
		...ngDevMode ? { debugName: "resetFilterOnHide" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	virtualScroll = input(void 0, {
		...ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	virtualScrollItemSize = input(void 0, {
		...ngDevMode ? { debugName: "virtualScrollItemSize" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	virtualScrollOptions = input(...ngDevMode ? [void 0, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []);
	autofocus = input(void 0, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	options = input(...ngDevMode ? [void 0, { debugName: "options" }] : /* istanbul ignore next */ []);
	loading = input(void 0, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loadingMode = input("mask", ...ngDevMode ? [{ debugName: "loadingMode" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	fluid = input(void 0, {
		...ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	appendTo = input(void 0, ...ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []);
	motionOptions = input(void 0, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	onNodeExpand = output();
	onNodeCollapse = output();
	onShow = output();
	onHide = output();
	onClear = output();
	onFilter = output();
	onFocus = output();
	onBlur = output();
	onNodeUnselect = output();
	onNodeSelect = output();
	$appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []);
	focusInputViewChild = viewChild("focusInput", ...ngDevMode ? [{ debugName: "focusInputViewChild" }] : /* istanbul ignore next */ []);
	filterViewChild = viewChild("filter", ...ngDevMode ? [{ debugName: "filterViewChild" }] : /* istanbul ignore next */ []);
	treeViewChild = viewChild("tree", ...ngDevMode ? [{ debugName: "treeViewChild" }] : /* istanbul ignore next */ []);
	panelEl = viewChild("panel", ...ngDevMode ? [{ debugName: "panelEl" }] : /* istanbul ignore next */ []);
	overlayViewChild = viewChild("overlay", ...ngDevMode ? [{ debugName: "overlayViewChild" }] : /* istanbul ignore next */ []);
	firstHiddenFocusableElementOnOverlay = viewChild("firstHiddenFocusableEl", ...ngDevMode ? [{ debugName: "firstHiddenFocusableElementOnOverlay" }] : /* istanbul ignore next */ []);
	lastHiddenFocusableElementOnOverlay = viewChild("lastHiddenFocusableEl", ...ngDevMode ? [{ debugName: "lastHiddenFocusableElementOnOverlay" }] : /* istanbul ignore next */ []);
	$variant = computed(() => this.variant() || this.config.inputVariant() || void 0, ...ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []);
	pcFluid = inject(Fluid, {
		optional: true,
		host: true,
		skipSelf: true
	});
	get hasFluid() {
		return this.fluid() ?? !!this.pcFluid;
	}
	filteredNodes;
	filterValue = null;
	serializedValue;
	valueTemplate = contentChild("value", {
		...ngDevMode ? { debugName: "valueTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	headerTemplate = contentChild("header", {
		...ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	emptyTemplate = contentChild("empty", {
		...ngDevMode ? { debugName: "emptyTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	footerTemplate = contentChild("footer", {
		...ngDevMode ? { debugName: "footerTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	clearIconTemplate = contentChild("clearicon", {
		...ngDevMode ? { debugName: "clearIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	triggerIconTemplate = contentChild("triggericon", {
		...ngDevMode ? { debugName: "triggerIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	dropdownIconTemplate = contentChild("dropdownicon", {
		...ngDevMode ? { debugName: "dropdownIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	filterIconTemplate = contentChild("filtericon", {
		...ngDevMode ? { debugName: "filterIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	closeIconTemplate = contentChild("closeicon", {
		...ngDevMode ? { debugName: "closeIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemTogglerIconTemplate = contentChild("itemtogglericon", {
		...ngDevMode ? { debugName: "itemTogglerIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemCheckboxIconTemplate = contentChild("itemcheckboxicon", {
		...ngDevMode ? { debugName: "itemCheckboxIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemLoadingIconTemplate = contentChild("itemloadingicon", {
		...ngDevMode ? { debugName: "itemLoadingIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	nodeTemplate = contentChild("node", {
		...ngDevMode ? { debugName: "nodeTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	focused = signal(false, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	overlayVisible = signal(false, ...ngDevMode ? [{ debugName: "overlayVisible" }] : /* istanbul ignore next */ []);
	_value = signal(void 0, ...ngDevMode ? [{ debugName: "_value" }] : /* istanbul ignore next */ []);
	expandedNodes = [];
	_options = signal(void 0, ...ngDevMode ? [{ debugName: "_options" }] : /* istanbul ignore next */ []);
	listId = "";
	valueTemplateContext = computed(() => ({
		$implicit: this._value(),
		placeholder: this.placeholder()
	}), ...ngDevMode ? [{ debugName: "valueTemplateContext" }] : /* istanbul ignore next */ []);
	headerTemplateContext = computed(() => ({
		$implicit: this._value(),
		options: this._options()
	}), ...ngDevMode ? [{ debugName: "headerTemplateContext" }] : /* istanbul ignore next */ []);
	footerTemplateContext = computed(() => ({
		$implicit: this._value(),
		options: this._options()
	}), ...ngDevMode ? [{ debugName: "footerTemplateContext" }] : /* istanbul ignore next */ []);
	label = computed(() => {
		const value = this._value() || [];
		return value.length ? value.map((node) => node.label).join(", ") : this.selectionMode() === "single" && this._value() ? this._value().label : this.placeholder();
	}, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	emptyValue = computed(() => !this._value() || Object.keys(this._value()).length === 0, ...ngDevMode ? [{ debugName: "emptyValue" }] : /* istanbul ignore next */ []);
	emptyOptions = computed(() => !this._options() || this._options().length === 0, ...ngDevMode ? [{ debugName: "emptyOptions" }] : /* istanbul ignore next */ []);
	$inputDisabledAttr = computed(() => this.$disabled() ? "" : void 0, ...ngDevMode ? [{ debugName: "$inputDisabledAttr" }] : /* istanbul ignore next */ []);
	$inputTabindex = computed(() => !this.$disabled() ? this.tabindex() : "-1", ...ngDevMode ? [{ debugName: "$inputTabindex" }] : /* istanbul ignore next */ []);
	$ariaControls = computed(() => this.overlayVisible() ? this.listId : null, ...ngDevMode ? [{ debugName: "$ariaControls" }] : /* istanbul ignore next */ []);
	$ariaExpanded = computed(() => this.overlayVisible() ?? false, ...ngDevMode ? [{ debugName: "$ariaExpanded" }] : /* istanbul ignore next */ []);
	$inputAriaLabel = computed(() => {
		const ariaLabel = this.ariaLabel();
		const label = this.label();
		return ariaLabel || (label === "p-emptylabel" ? void 0 : label);
	}, ...ngDevMode ? [{ debugName: "$inputAriaLabel" }] : /* istanbul ignore next */ []);
	$showClearIcon = computed(() => this.checkValue() && !this.$disabled() && this.showClear(), ...ngDevMode ? [{ debugName: "$showClearIcon" }] : /* istanbul ignore next */ []);
	$showDefaultDropdownIcon = computed(() => !this.triggerIconTemplate() && !this.dropdownIconTemplate(), ...ngDevMode ? [{ debugName: "$showDefaultDropdownIcon" }] : /* istanbul ignore next */ []);
	$dropdownIconTemplate = computed(() => this.triggerIconTemplate() || this.dropdownIconTemplate(), ...ngDevMode ? [{ debugName: "$dropdownIconTemplate" }] : /* istanbul ignore next */ []);
	$labelText = computed(() => this.label() || "empty", ...ngDevMode ? [{ debugName: "$labelText" }] : /* istanbul ignore next */ []);
	$placeholderText = computed(() => this.placeholder() || "empty", ...ngDevMode ? [{ debugName: "$placeholderText" }] : /* istanbul ignore next */ []);
	$treeContainerStyle = computed(() => {
		if (!this.virtualScroll()) return { "max-height": this.scrollHeight() };
		const height = this.virtualScrollOptions()?.scrollHeight ?? this.scrollHeight();
		return {
			height,
			"max-height": height,
			overflow: "hidden"
		};
	}, ...ngDevMode ? [{ debugName: "$treeContainerStyle" }] : /* istanbul ignore next */ []);
	constructor() {
		super();
		effect(() => {
			const opts = this.options();
			untracked(() => {
				this._options.set(opts);
				this.updateTreeState();
			});
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onInit() {
		this.listId = this.$useId.next("pn_id_") + "_list";
		this.updateTreeState();
	}
	onOverlayBeforeEnter() {
		if (this.filter()) {
			if (l(this.filterValue)) this.treeViewChild()?._filter(this.filterValue);
			if (this.filterInputAutoFocus()) this.filterViewChild()?.nativeElement.focus();
		} else {
			let focusableElements = x(this.panelEl()?.nativeElement);
			if (focusableElements && focusableElements.length > 0) focusableElements[0].focus();
		}
	}
	onOverlayBeforeHide() {
		let focusableElements = x(this.el.nativeElement);
		if (focusableElements && focusableElements.length > 0) focusableElements[0].focus();
	}
	onSelectionChange(event) {
		this._value.set(event);
		this.onModelChange(this._value());
	}
	onClick(event) {
		if (this.$disabled()) return;
		const section = event.target?.getAttribute?.("data-pc-section");
		if (event.target?.closest?.("[data-pc-section=\"clearicon\"]")) return;
		if (!this.overlayViewChild()?.el?.nativeElement?.contains(event.target) && section !== "box" && section !== "icon") {
			if (this.overlayVisible()) this.hide();
			else this.show();
			this.focusInputViewChild()?.nativeElement.focus();
		}
	}
	onKeyDown(event) {
		switch (event.code) {
			case "ArrowDown":
				if (!this.overlayVisible()) {
					this.show();
					event.preventDefault();
				}
				this.onArrowDown(event);
				event.preventDefault();
				break;
			case "Space":
			case "Enter":
				if (!this.overlayVisible()) {
					this.show();
					event.preventDefault();
				}
				break;
			case "Escape":
				if (this.overlayVisible()) {
					this.hide();
					this.focusInputViewChild()?.nativeElement.focus();
					event.preventDefault();
				}
				break;
			case "Tab": this.onTabKey(event);
		}
	}
	onFilterInput(event) {
		this.filterValue = event.target.value;
		this.treeViewChild()?._filter(this.filterValue);
		this.onFilter.emit({
			filter: this.filterValue,
			filteredValue: this.treeViewChild()?.filteredNodes()
		});
		setTimeout(() => {
			this.overlayViewChild()?.alignOverlay();
		});
	}
	onArrowDown(event) {
		if (this.overlayVisible() && this.panelEl()?.nativeElement) {
			let focusableElements = x(this.panelEl().nativeElement, "[data-pc-section=\"node\"]");
			if (focusableElements && focusableElements.length > 0) focusableElements[0].focus();
			event.preventDefault();
		}
	}
	onFirstHiddenFocus(event) {
		const focusableEl = event.relatedTarget === this.focusInputViewChild()?.nativeElement ? Bt(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ":not([data-p-hidden-focusable=\"true\"])") : this.focusInputViewChild()?.nativeElement;
		Wt(focusableEl);
	}
	onLastHiddenFocus(event) {
		const focusableEl = event.relatedTarget === this.focusInputViewChild()?.nativeElement ? Vt(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ":not([data-p-hidden-focusable=\"true\"])") : this.focusInputViewChild()?.nativeElement;
		Wt(focusableEl);
	}
	show() {
		this.overlayVisible.set(true);
	}
	hide(event) {
		this.overlayVisible.set(false);
		this.resetFilter();
		this.onHide.emit(event);
	}
	clear(event) {
		this._value.set(null);
		this.resetExpandedNodes();
		this.resetPartialSelected();
		this.onModelChange(this._value());
		this.onClear.emit(null);
		event.stopPropagation();
	}
	checkValue() {
		return this._value() !== null && l(this._value());
	}
	onTabKey(event, pressedInInputText = false) {
		if (!pressedInInputText) {
			if (this.overlayVisible() && this.hasFocusableElements()) {
				Wt(event.shiftKey ? this.lastHiddenFocusableElementOnOverlay()?.nativeElement : this.firstHiddenFocusableElementOnOverlay()?.nativeElement);
				event.preventDefault();
			} else if (this.overlayVisible()) this.hide(this.filter());
		}
	}
	hasFocusableElements() {
		return x(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ":not([data-p-hidden-focusable=\"true\"])").length > 0;
	}
	resetFilter() {
		if (this.filter() && !this.resetFilterOnHide()) {
			this.filteredNodes = this.treeViewChild()?.filteredNodes();
			this.treeViewChild()?.resetFilter();
		} else this.filterValue = null;
	}
	updateTreeState() {
		if (this._value()) {
			let selectedNodes = this.selectionMode() === "single" ? [this._value()] : [...this._value()];
			this.resetExpandedNodes();
			this.resetPartialSelected();
			if (selectedNodes && this._options()) this.updateTreeBranchState(null, null, selectedNodes);
		}
	}
	updateTreeBranchState(node, path, selectedNodes) {
		if (node) {
			if (this.isSelected(node)) {
				this.expandPath(path);
				selectedNodes.splice(selectedNodes.indexOf(node), 1);
			}
			if (selectedNodes.length > 0 && node.children) for (let childNode of node.children) this.updateTreeBranchState(childNode, [...path, node], selectedNodes);
		} else for (let childNode of this._options()) this.updateTreeBranchState(childNode, [], selectedNodes);
	}
	expandPath(expandedNodes) {
		for (let node of expandedNodes) node.expanded = true;
		this.expandedNodes = [...expandedNodes];
	}
	nodeExpand(event) {
		this.onNodeExpand.emit(event);
		this.expandedNodes.push(event.node);
		setTimeout(() => {
			this.overlayViewChild()?.alignOverlay();
		});
	}
	nodeCollapse(event) {
		this.onNodeCollapse.emit(event);
		this.expandedNodes.splice(this.expandedNodes.indexOf(event.node), 1);
		setTimeout(() => {
			this.overlayViewChild()?.alignOverlay();
		});
	}
	resetExpandedNodes() {
		for (let node of this.expandedNodes) node.expanded = false;
		this.expandedNodes = [];
	}
	resetPartialSelected(nodes = this._options()) {
		if (!nodes) return;
		for (let node of nodes) {
			node.partialSelected = false;
			if (node.children && node.children?.length > 0) this.resetPartialSelected(node.children);
		}
	}
	findSelectedNodes(node, keys, selectedNodes) {
		if (node) {
			if (this.isSelected(node)) {
				selectedNodes.push(node);
				delete keys[node.key];
			}
			if (Object.keys(keys).length && node.children) for (let childNode of node.children) this.findSelectedNodes(childNode, keys, selectedNodes);
		} else for (let childNode of this._options()) this.findSelectedNodes(childNode, keys, selectedNodes);
	}
	isSelected(node) {
		return this.findIndexInSelection(node) != -1;
	}
	findIndexInSelection(node) {
		let index = -1;
		const value = this._value();
		if (value) {
			if (this.selectionMode() === "single") index = value.key && value.key === node.key || value == node ? 0 : -1;
			else for (let i = 0; i < value.length; i++) {
				let selectedNode = value[i];
				if (selectedNode.key && selectedNode.key === node.key || selectedNode == node) {
					index = i;
					break;
				}
			}
		}
		return index;
	}
	onSelect(event) {
		this.onNodeSelect.emit(event);
		if (this.selectionMode() === "single") {
			this.hide();
			this.focusInputViewChild()?.nativeElement.focus();
		}
	}
	onUnselect(event) {
		this.onNodeUnselect.emit(event);
	}
	onInputFocus(event) {
		if (this.$disabled()) return;
		this.focused.set(true);
		this.onFocus.emit(event);
	}
	onInputBlur(event) {
		this.focused.set(false);
		this.onBlur.emit(event);
		this.onModelTouched();
	}
	writeControlValue(value) {
		this._value.set(value);
		this.updateTreeState();
	}
	static ɵfac = function TreeSelect_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TreeSelect)();
	};
	static ɵcmp = (function() {
		const _c0 = ["value"];
		const _c1 = ["header"];
		const _c2 = ["empty"];
		const _c3 = ["footer"];
		const _c4 = ["clearicon"];
		const _c5 = ["triggericon"];
		const _c6 = ["dropdownicon"];
		const _c7 = ["filtericon"];
		const _c8 = ["closeicon"];
		const _c9 = ["itemtogglericon"];
		const _c10 = ["itemcheckboxicon"];
		const _c11 = ["itemloadingicon"];
		const _c12 = ["node"];
		const _c13 = ["focusInput"];
		const _c14 = ["filter"];
		const _c15 = ["tree"];
		const _c16 = ["panel"];
		const _c17 = ["overlay"];
		const _c18 = ["firstHiddenFocusableEl"];
		const _c19 = ["lastHiddenFocusableEl"];
		const _c20 = (a0) => ({ $implicit: a0 });
		const _c21 = (a0, a1) => ({
			$implicit: a0,
			partialSelected: a1
		});
		const _forTrack0 = ($index, $item) => $item.key || $index;
		function TreeSelect_Conditional_5_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_Conditional_5_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_Conditional_5_ng_container_0_Template, 1, 0, "ng-container", 19);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵproperty("ngTemplateOutlet", ctx_r0.valueTemplate())("ngTemplateOutletContext", ctx_r0.valueTemplateContext());
			}
		}
		function TreeSelect_Conditional_6_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtext(0);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵtextInterpolate1(" ", ctx_r0.$labelText(), " ");
			}
		}
		function TreeSelect_Conditional_6_Conditional_1_For_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "div", 13);
				ɵɵelement(1, "p-chip", 20);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const node_r2 = ctx.$implicit;
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r0.cx("chipItem"));
				ɵɵproperty("pBind", ctx_r0.ptm("chipItem"));
				ɵɵadvance();
				ɵɵclassMap(ctx_r0.cx("pcChip"));
				ɵɵproperty("unstyled", ctx_r0.unstyled())("label", node_r2.label)("pt", ctx_r0.ptm("pcChip"));
			}
		}
		function TreeSelect_Conditional_6_Conditional_1_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵtext(0);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵtextInterpolate1(" ", ctx_r0.$placeholderText(), " ");
			}
		}
		function TreeSelect_Conditional_6_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵrepeaterCreate(0, TreeSelect_Conditional_6_Conditional_1_For_1_Template, 2, 8, "div", 17, _forTrack0);
				ɵɵconditionalCreate(2, TreeSelect_Conditional_6_Conditional_1_Conditional_2_Template, 1, 1);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵrepeater(ctx_r0._value());
				ɵɵadvance(2);
				ɵɵconditional(ctx_r0.emptyValue() ? 2 : -1);
			}
		}
		function TreeSelect_Conditional_6_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, TreeSelect_Conditional_6_Conditional_0_Template, 1, 1)(1, TreeSelect_Conditional_6_Conditional_1_Template, 3, 1);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(ctx_r0.display() === "comma" ? 0 : 1);
			}
		}
		function TreeSelect_Conditional_7_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r3 = ɵɵgetCurrentView();
				ɵɵnamespaceSVG();
				ɵɵelementStart(0, "svg", 22);
				ɵɵlistener("click", function TreeSelect_Conditional_7_Conditional_0_Template_svg_click_0_listener($event) {
					ɵɵrestoreView(_r3);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.clear($event));
				});
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r0.cx("clearIcon"));
				ɵɵproperty("pBind", ctx_r0.ptm("clearIcon"));
				ɵɵattribute("data-pc-section", "clearicon");
			}
		}
		function TreeSelect_Conditional_7_Conditional_1_1_ng_template_0_Template(rf, ctx) {}
		function TreeSelect_Conditional_7_Conditional_1_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_Conditional_7_Conditional_1_1_ng_template_0_Template, 0, 0, "ng-template");
		}
		function TreeSelect_Conditional_7_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r4 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "span", 23);
				ɵɵlistener("click", function TreeSelect_Conditional_7_Conditional_1_Template_span_click_0_listener($event) {
					ɵɵrestoreView(_r4);
					const ctx_r0 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r0.clear($event));
				});
				ɵɵtemplate(1, TreeSelect_Conditional_7_Conditional_1_1_Template, 1, 0, null, 24);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r0.cx("clearIcon"));
				ɵɵproperty("pBind", ctx_r0.ptm("clearIcon"));
				ɵɵattribute("data-pc-section", "clearicon");
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r0.clearIconTemplate());
			}
		}
		function TreeSelect_Conditional_7_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, TreeSelect_Conditional_7_Conditional_0_Template, 1, 4, "svg", 21)(1, TreeSelect_Conditional_7_Conditional_1_Template, 2, 5, "span", 17);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(!ctx_r0.clearIconTemplate() ? 0 : 1);
			}
		}
		function TreeSelect_Conditional_9_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 25);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵclassMap(ctx_r0.cx("dropdownIcon"));
				ɵɵproperty("pBind", ctx_r0.ptm("dropdownIcon"));
			}
		}
		function TreeSelect_Conditional_10_1_ng_template_0_Template(rf, ctx) {}
		function TreeSelect_Conditional_10_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_Conditional_10_1_ng_template_0_Template, 0, 0, "ng-template");
		}
		function TreeSelect_Conditional_10_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 13);
				ɵɵtemplate(1, TreeSelect_Conditional_10_1_Template, 1, 0, null, 24);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵclassMap(ctx_r0.cx("dropdownIcon"));
				ɵɵproperty("pBind", ctx_r0.ptm("dropdownIcon"));
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r0.$dropdownIconTemplate());
			}
		}
		function TreeSelect_ng_template_13_Conditional_4_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_4_ng_container_0_Template, 1, 0, "ng-container", 19);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.headerTemplate())("ngTemplateOutletContext", ctx_r0.headerTemplateContext());
			}
		}
		function TreeSelect_ng_template_13_Conditional_8_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_8_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_8_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 24);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.emptyTemplate());
			}
		}
		function TreeSelect_ng_template_13_Conditional_8_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_8_ng_template_0_Template, 1, 1, "ng-template", null, 7, ɵɵtemplateRefExtractor);
		}
		function TreeSelect_ng_template_13_Conditional_9_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_9_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_9_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 19);
			if (rf & 2) {
				const node_r6 = ctx.$implicit;
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.nodeTemplate())("ngTemplateOutletContext", ɵɵpureFunction1(2, _c20, node_r6));
			}
		}
		function TreeSelect_ng_template_13_Conditional_9_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_9_ng_template_0_Template, 1, 4, "ng-template", null, 8, ɵɵtemplateRefExtractor);
		}
		function TreeSelect_ng_template_13_Conditional_10_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_10_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_10_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 19);
			if (rf & 2) {
				const expanded_r7 = ctx.$implicit;
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.itemTogglerIconTemplate())("ngTemplateOutletContext", ɵɵpureFunction1(2, _c20, expanded_r7));
			}
		}
		function TreeSelect_ng_template_13_Conditional_10_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_10_ng_template_0_Template, 1, 4, "ng-template", null, 9, ɵɵtemplateRefExtractor);
		}
		function TreeSelect_ng_template_13_Conditional_11_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_11_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_11_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 19);
			if (rf & 2) {
				const selected_r8 = ctx.$implicit;
				const partialSelected_r9 = ctx.partialSelected;
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.itemCheckboxIconTemplate())("ngTemplateOutletContext", ɵɵpureFunction2(2, _c21, selected_r8, partialSelected_r9));
			}
		}
		function TreeSelect_ng_template_13_Conditional_11_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_11_ng_template_0_Template, 1, 5, "ng-template", null, 10, ɵɵtemplateRefExtractor);
		}
		function TreeSelect_ng_template_13_Conditional_12_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_12_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_12_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 24);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.itemLoadingIconTemplate());
			}
		}
		function TreeSelect_ng_template_13_Conditional_12_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_12_ng_template_0_Template, 1, 1, "ng-template", null, 11, ɵɵtemplateRefExtractor);
		}
		function TreeSelect_ng_template_13_Conditional_13_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_13_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_13_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 24);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.filterIconTemplate());
			}
		}
		function TreeSelect_ng_template_13_Conditional_13_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_13_ng_template_0_Template, 1, 1, "ng-template", null, 12, ɵɵtemplateRefExtractor);
		}
		function TreeSelect_ng_template_13_Conditional_14_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TreeSelect_ng_template_13_Conditional_14_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TreeSelect_ng_template_13_Conditional_14_ng_container_0_Template, 1, 0, "ng-container", 19);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r0.footerTemplate())("ngTemplateOutletContext", ctx_r0.footerTemplateContext());
			}
		}
		function TreeSelect_ng_template_13_Template(rf, ctx) {
			if (rf & 1) {
				const _r5 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "div", 13, 3)(2, "span", 26, 4);
				ɵɵlistener("focus", function TreeSelect_ng_template_13_Template_span_focus_2_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.onFirstHiddenFocus($event));
				});
				ɵɵelementEnd();
				ɵɵconditionalCreate(4, TreeSelect_ng_template_13_Conditional_4_Template, 1, 2, "ng-container");
				ɵɵelementStart(5, "div", 13)(6, "p-tree", 27, 5);
				ɵɵlistener("selectionChange", function TreeSelect_ng_template_13_Template_p_tree_selectionChange_6_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.onSelectionChange($event));
				})("onNodeExpand", function TreeSelect_ng_template_13_Template_p_tree_onNodeExpand_6_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.nodeExpand($event));
				})("onNodeCollapse", function TreeSelect_ng_template_13_Template_p_tree_onNodeCollapse_6_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.nodeCollapse($event));
				})("onNodeSelect", function TreeSelect_ng_template_13_Template_p_tree_onNodeSelect_6_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.onSelect($event));
				})("onNodeUnselect", function TreeSelect_ng_template_13_Template_p_tree_onNodeUnselect_6_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.onUnselect($event));
				});
				ɵɵconditionalCreate(8, TreeSelect_ng_template_13_Conditional_8_Template, 2, 0);
				ɵɵconditionalCreate(9, TreeSelect_ng_template_13_Conditional_9_Template, 2, 0);
				ɵɵconditionalCreate(10, TreeSelect_ng_template_13_Conditional_10_Template, 2, 0);
				ɵɵconditionalCreate(11, TreeSelect_ng_template_13_Conditional_11_Template, 2, 0);
				ɵɵconditionalCreate(12, TreeSelect_ng_template_13_Conditional_12_Template, 2, 0);
				ɵɵconditionalCreate(13, TreeSelect_ng_template_13_Conditional_13_Template, 2, 0);
				ɵɵelementEnd()();
				ɵɵconditionalCreate(14, TreeSelect_ng_template_13_Conditional_14_Template, 1, 2, "ng-container");
				ɵɵelementStart(15, "span", 26, 6);
				ɵɵlistener("focus", function TreeSelect_ng_template_13_Template_span_focus_15_listener($event) {
					ɵɵrestoreView(_r5);
					const ctx_r0 = ɵɵnextContext();
					return ɵɵresetView(ctx_r0.onLastHiddenFocus($event));
				});
				ɵɵelementEnd()();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵstyleMap(ctx_r0.panelStyle());
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("panel"), ctx_r0.panelStyleClass(), ctx_r0.panelClass()));
				ɵɵproperty("pBind", ctx_r0.ptm("panel"));
				ɵɵattribute("id", ctx_r0.listId);
				ɵɵadvance(2);
				ɵɵclassMap(ctx_r0.pcn("p-hidden-accessible p-hidden-focusable"));
				ɵɵproperty("pBind", ctx_r0.ptm("hiddenFirstFocusableEl"));
				ɵɵattribute("tabindex", 0)("data-p-hidden-accessible", true)("data-p-hidden-focusable", true);
				ɵɵadvance(2);
				ɵɵconditional(ctx_r0.headerTemplate() ? 4 : -1);
				ɵɵadvance();
				ɵɵstyleMap(ctx_r0.$treeContainerStyle());
				ɵɵclassMap(ctx_r0.cx("treeContainer"));
				ɵɵproperty("pBind", ctx_r0.ptm("treeContainer"));
				ɵɵadvance();
				ɵɵproperty("value", ctx_r0._options())("propagateSelectionDown", ctx_r0.propagateSelectionDown())("propagateSelectionUp", ctx_r0.propagateSelectionUp())("selectionMode", ctx_r0.selectionMode())("selection", ctx_r0._value())("metaKeySelection", ctx_r0.metaKeySelection())("emptyMessage", ctx_r0.emptyMessage())("filter", ctx_r0.filter())("filterBy", ctx_r0.filterBy())("filterMode", ctx_r0.filterMode())("filterPlaceholder", ctx_r0.filterPlaceholder())("filterLocale", ctx_r0.filterLocale())("filteredNodes", ctx_r0.filteredNodes)("virtualScroll", ctx_r0.virtualScroll())("virtualScrollItemSize", ctx_r0.virtualScrollItemSize())("virtualScrollOptions", ctx_r0.virtualScrollOptions())("loading", ctx_r0.loading())("filterInputAutoFocus", ctx_r0.filterInputAutoFocus())("loadingMode", ctx_r0.loadingMode())("pt", ctx_r0.ptm("pcTree"))("unstyled", ctx_r0.unstyled());
				ɵɵadvance(2);
				ɵɵconditional(ctx_r0.emptyTemplate() ? 8 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0.nodeTemplate() ? 9 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0.itemTogglerIconTemplate() ? 10 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0.itemCheckboxIconTemplate() ? 11 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0.itemLoadingIconTemplate() ? 12 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0.filterIconTemplate() ? 13 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0.footerTemplate() ? 14 : -1);
				ɵɵadvance();
				ɵɵclassMap(ctx_r0.pcn("p-hidden-accessible p-hidden-focusable"));
				ɵɵproperty("pBind", ctx_r0.ptm("hiddenLastFocusableEl"));
				ɵɵattribute("tabindex", 0)("data-p-hidden-accessible", true)("data-p-hidden-focusable", true);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: TreeSelect,
			selectors: [["p-tree-select"], ["p-treeselect"]],
			contentQueries: function TreeSelect_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.valueTemplate, _c0, 4)(dirIndex, ctx.headerTemplate, _c1, 4)(dirIndex, ctx.emptyTemplate, _c2, 4)(dirIndex, ctx.footerTemplate, _c3, 4)(dirIndex, ctx.clearIconTemplate, _c4, 4)(dirIndex, ctx.triggerIconTemplate, _c5, 4)(dirIndex, ctx.dropdownIconTemplate, _c6, 4)(dirIndex, ctx.filterIconTemplate, _c7, 4)(dirIndex, ctx.closeIconTemplate, _c8, 4)(dirIndex, ctx.itemTogglerIconTemplate, _c9, 4)(dirIndex, ctx.itemCheckboxIconTemplate, _c10, 4)(dirIndex, ctx.itemLoadingIconTemplate, _c11, 4)(dirIndex, ctx.nodeTemplate, _c12, 4);
				if (rf & 2) ɵɵqueryAdvance(13);
			},
			viewQuery: function TreeSelect_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.focusInputViewChild, _c13, 5)(ctx.filterViewChild, _c14, 5)(ctx.treeViewChild, _c15, 5)(ctx.panelEl, _c16, 5)(ctx.overlayViewChild, _c17, 5)(ctx.firstHiddenFocusableElementOnOverlay, _c18, 5)(ctx.lastHiddenFocusableElementOnOverlay, _c19, 5);
				if (rf & 2) ɵɵqueryAdvance(7);
			},
			hostVars: 4,
			hostBindings: function TreeSelect_HostBindings(rf, ctx) {
				if (rf & 1) ɵɵlistener("mousedown", function TreeSelect_mousedown_HostBindingHandler($event) {
					return ctx.onClick($event);
				});
				if (rf & 2) {
					ɵɵstyleMap(ctx.sx("root"));
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				inputId: [1, "inputId"],
				scrollHeight: [1, "scrollHeight"],
				metaKeySelection: [1, "metaKeySelection"],
				display: [1, "display"],
				selectionMode: [1, "selectionMode"],
				tabindex: [1, "tabindex"],
				ariaLabel: [1, "ariaLabel"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				placeholder: [1, "placeholder"],
				panelClass: [1, "panelClass"],
				panelStyle: [1, "panelStyle"],
				panelStyleClass: [1, "panelStyleClass"],
				labelStyle: [1, "labelStyle"],
				labelStyleClass: [1, "labelStyleClass"],
				overlayOptions: [1, "overlayOptions"],
				emptyMessage: [1, "emptyMessage"],
				filter: [1, "filter"],
				filterBy: [1, "filterBy"],
				filterMode: [1, "filterMode"],
				filterPlaceholder: [1, "filterPlaceholder"],
				filterLocale: [1, "filterLocale"],
				filterInputAutoFocus: [1, "filterInputAutoFocus"],
				propagateSelectionDown: [1, "propagateSelectionDown"],
				propagateSelectionUp: [1, "propagateSelectionUp"],
				showClear: [1, "showClear"],
				resetFilterOnHide: [1, "resetFilterOnHide"],
				virtualScroll: [1, "virtualScroll"],
				virtualScrollItemSize: [1, "virtualScrollItemSize"],
				virtualScrollOptions: [1, "virtualScrollOptions"],
				autofocus: [1, "autofocus"],
				options: [1, "options"],
				loading: [1, "loading"],
				loadingMode: [1, "loadingMode"],
				size: [1, "size"],
				variant: [1, "variant"],
				fluid: [1, "fluid"],
				appendTo: [1, "appendTo"],
				motionOptions: [1, "motionOptions"]
			},
			outputs: {
				onNodeExpand: "onNodeExpand",
				onNodeCollapse: "onNodeCollapse",
				onShow: "onShow",
				onHide: "onHide",
				onClear: "onClear",
				onFilter: "onFilter",
				onFocus: "onFocus",
				onBlur: "onBlur",
				onNodeUnselect: "onNodeUnselect",
				onNodeSelect: "onNodeSelect"
			},
			features: [
				ɵɵProvidersFeature([
					TREESELECT_VALUE_ACCESSOR,
					TreeSelectStyle,
					{
						provide: TREESELECT_INSTANCE,
						useExisting: TreeSelect
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: TreeSelect
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 15,
			vars: 38,
			consts: [
				["focusInput", ""],
				["overlay", ""],
				["content", ""],
				["panel", ""],
				["firstHiddenFocusableEl", ""],
				["tree", ""],
				["lastHiddenFocusableEl", ""],
				["empty", ""],
				["node", ""],
				["togglericon", ""],
				["checkboxicon", ""],
				["loadingicon", ""],
				["filtericon", ""],
				[3, "pBind"],
				[
					"type",
					"text",
					"role",
					"combobox",
					"readonly",
					"",
					3,
					"focus",
					"blur",
					"keydown",
					"pAutoFocus",
					"pBind"
				],
				[
					"role",
					"button",
					"aria-haspopup",
					"tree",
					3,
					"pBind"
				],
				[
					"data-p-icon",
					"chevron-down",
					3,
					"class",
					"pBind"
				],
				[
					3,
					"class",
					"pBind"
				],
				[
					3,
					"visibleChange",
					"onBeforeEnter",
					"onBeforeHide",
					"onShow",
					"onHide",
					"hostAttrSelector",
					"visible",
					"options",
					"target",
					"appendTo",
					"unstyled",
					"pt",
					"motionOptions"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				],
				[
					3,
					"unstyled",
					"label",
					"pt"
				],
				[
					"data-p-icon",
					"times",
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"times",
					3,
					"click",
					"pBind"
				],
				[
					3,
					"click",
					"pBind"
				],
				[4, "ngTemplateOutlet"],
				[
					"data-p-icon",
					"chevron-down",
					3,
					"pBind"
				],
				[
					"role",
					"presentation",
					3,
					"focus",
					"pBind"
				],
				[
					3,
					"selectionChange",
					"onNodeExpand",
					"onNodeCollapse",
					"onNodeSelect",
					"onNodeUnselect",
					"value",
					"propagateSelectionDown",
					"propagateSelectionUp",
					"selectionMode",
					"selection",
					"metaKeySelection",
					"emptyMessage",
					"filter",
					"filterBy",
					"filterMode",
					"filterPlaceholder",
					"filterLocale",
					"filteredNodes",
					"virtualScroll",
					"virtualScrollItemSize",
					"virtualScrollOptions",
					"loading",
					"filterInputAutoFocus",
					"loadingMode",
					"pt",
					"unstyled"
				]
			],
			template: function TreeSelect_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵelementStart(0, "div", 13)(1, "input", 14, 0);
					ɵɵlistener("focus", function TreeSelect_Template_input_focus_1_listener($event) {
						return ctx.onInputFocus($event);
					})("blur", function TreeSelect_Template_input_blur_1_listener($event) {
						return ctx.onInputBlur($event);
					})("keydown", function TreeSelect_Template_input_keydown_1_listener($event) {
						return ctx.onKeyDown($event);
					});
					ɵɵelementEnd()();
					ɵɵelementStart(3, "div", 13)(4, "div", 13);
					ɵɵconditionalCreate(5, TreeSelect_Conditional_5_Template, 1, 2, "ng-container")(6, TreeSelect_Conditional_6_Template, 2, 1);
					ɵɵelementEnd()();
					ɵɵconditionalCreate(7, TreeSelect_Conditional_7_Template, 2, 1);
					ɵɵelementStart(8, "div", 15);
					ɵɵconditionalCreate(9, TreeSelect_Conditional_9_Template, 1, 3, "svg", 16)(10, TreeSelect_Conditional_10_Template, 2, 4, "span", 17);
					ɵɵelementEnd();
					ɵɵelementStart(11, "p-overlay", 18, 1);
					ɵɵlistener("visibleChange", function TreeSelect_Template_p_overlay_visibleChange_11_listener($event) {
						return ctx.overlayVisible.set($event);
					})("onBeforeEnter", function TreeSelect_Template_p_overlay_onBeforeEnter_11_listener() {
						return ctx.onOverlayBeforeEnter();
					})("onBeforeHide", function TreeSelect_Template_p_overlay_onBeforeHide_11_listener() {
						return ctx.onOverlayBeforeHide();
					})("onShow", function TreeSelect_Template_p_overlay_onShow_11_listener($event) {
						return ctx.onShow.emit($event);
					})("onHide", function TreeSelect_Template_p_overlay_onHide_11_listener($event) {
						return ctx.hide($event);
					});
					ɵɵtemplate(13, TreeSelect_ng_template_13_Template, 17, 52, "ng-template", null, 2, ɵɵtemplateRefExtractor);
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵclassMap(ctx.pcn("p-hidden-accessible"));
					ɵɵproperty("pBind", ctx.ptm("hiddenInputContainer"));
					ɵɵattribute("data-p-hidden-accessible", true);
					ɵɵadvance();
					ɵɵproperty("pAutoFocus", ctx.autofocus())("pBind", ctx.ptm("hiddenInput"));
					ɵɵattribute("id", ctx.inputId())("disabled", ctx.$inputDisabledAttr())("tabindex", ctx.$inputTabindex())("aria-controls", ctx.$ariaControls())("aria-haspopup", "tree")("aria-expanded", ctx.$ariaExpanded())("aria-labelledby", ctx.ariaLabelledBy())("aria-label", ctx.$inputAriaLabel());
					ɵɵadvance(2);
					ɵɵclassMap(ctx.cx("labelContainer"));
					ɵɵproperty("pBind", ctx.ptm("labelContainer"));
					ɵɵadvance();
					ɵɵstyleMap(ctx.labelStyle());
					ɵɵclassMap(ctx.cn(ctx.cx("label"), ctx.labelStyleClass()));
					ɵɵproperty("pBind", ctx.ptm("label"));
					ɵɵadvance();
					ɵɵconditional(ctx.valueTemplate() ? 5 : 6);
					ɵɵadvance(2);
					ɵɵconditional(ctx.$showClearIcon() ? 7 : -1);
					ɵɵadvance();
					ɵɵclassMap(ctx.cx("dropdown"));
					ɵɵproperty("pBind", ctx.ptm("dropdown"));
					ɵɵattribute("aria-expanded", ctx.$ariaExpanded())("aria-label", "treeselect trigger");
					ɵɵadvance();
					ɵɵconditional(ctx.$showDefaultDropdownIcon() ? 9 : 10);
					ɵɵadvance(2);
					ɵɵproperty("hostAttrSelector", ctx.$attrSelector)("visible", ctx.overlayVisible())("options", ctx.overlayOptions())("target", "@parent")("appendTo", ctx.$appendTo())("unstyled", ctx.unstyled())("pt", ctx.ptm("pcOverlay"))("motionOptions", ctx.motionOptions());
				}
			},
			dependencies: [
				NgTemplateOutlet,
				Overlay,
				SharedModule,
				Tree,
				AutoFocus,
				Times,
				ChevronDown,
				Chip,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TreeSelect, [{
		type: Component,
		args: [{
			selector: "p-tree-select, p-treeselect",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				Overlay,
				SharedModule,
				Tree,
				AutoFocus,
				Times,
				ChevronDown,
				Chip,
				Bind
			],
			hostDirectives: [Bind],
			template: `
        <div [class]="pcn('p-hidden-accessible')" [pBind]="ptm('hiddenInputContainer')" [attr.data-p-hidden-accessible]="true">
            <input
                #focusInput
                type="text"
                role="combobox"
                [attr.id]="inputId()"
                readonly
                [attr.disabled]="$inputDisabledAttr()"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onKeyDown($event)"
                [attr.tabindex]="$inputTabindex()"
                [attr.aria-controls]="$ariaControls()"
                [attr.aria-haspopup]="'tree'"
                [attr.aria-expanded]="$ariaExpanded()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-label]="$inputAriaLabel()"
                [pAutoFocus]="autofocus()"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <div [class]="cx('labelContainer')" [pBind]="ptm('labelContainer')">
            <div [class]="cn(cx('label'), labelStyleClass())" [style]="labelStyle()" [pBind]="ptm('label')">
                @if (valueTemplate()) {
                    <ng-container *ngTemplateOutlet="valueTemplate(); context: valueTemplateContext()"></ng-container>
                } @else {
                    @if (display() === 'comma') {
                        {{ $labelText() }}
                    } @else {
                        @for (node of _value(); track node.key || $index) {
                            <div [class]="cx('chipItem')" [pBind]="ptm('chipItem')">
                                <p-chip [unstyled]="unstyled()" [label]="node.label" [class]="cx('pcChip')" [pt]="ptm('pcChip')" />
                            </div>
                        }
                        @if (emptyValue()) {
                            {{ $placeholderText() }}
                        }
                    }
                }
            </div>
        </div>
        @if ($showClearIcon()) {
            @if (!clearIconTemplate()) {
                <svg data-p-icon="times" [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" [attr.data-pc-section]="'clearicon'" />
            } @else {
                <span [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" [attr.data-pc-section]="'clearicon'">
                    <ng-template *ngTemplateOutlet="clearIconTemplate()"></ng-template>
                </span>
            }
        }
        <div [class]="cx('dropdown')" role="button" aria-haspopup="tree" [attr.aria-expanded]="$ariaExpanded()" [attr.aria-label]="'treeselect trigger'" [pBind]="ptm('dropdown')">
            @if ($showDefaultDropdownIcon()) {
                <svg data-p-icon="chevron-down" [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')" />
            } @else {
                <span [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')">
                    <ng-template *ngTemplateOutlet="$dropdownIconTemplate()"></ng-template>
                </span>
            }
        </div>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [visible]="overlayVisible()"
            (visibleChange)="overlayVisible.set($event)"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter()"
            (onBeforeHide)="onOverlayBeforeHide()"
            (onShow)="onShow.emit($event)"
            (onHide)="hide($event)"
        >
            <ng-template #content>
                <div #panel [attr.id]="listId" [class]="cn(cx('panel'), panelStyleClass(), panelClass())" [style]="panelStyle()" [pBind]="ptm('panel')">
                    <span
                        #firstHiddenFocusableEl
                        role="presentation"
                        [class]="pcn('p-hidden-accessible p-hidden-focusable')"
                        [attr.tabindex]="0"
                        (focus)="onFirstHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('hiddenFirstFocusableEl')"
                    >
                    </span>
                    @if (headerTemplate()) {
                        <ng-container *ngTemplateOutlet="headerTemplate(); context: headerTemplateContext()"></ng-container>
                    }
                    <div [class]="cx('treeContainer')" [style]="$treeContainerStyle()" [pBind]="ptm('treeContainer')">
                        <p-tree
                            #tree
                            [value]="_options()"
                            [propagateSelectionDown]="propagateSelectionDown()"
                            [propagateSelectionUp]="propagateSelectionUp()"
                            [selectionMode]="selectionMode()"
                            (selectionChange)="onSelectionChange($event)"
                            [selection]="_value()"
                            [metaKeySelection]="metaKeySelection()"
                            (onNodeExpand)="nodeExpand($event)"
                            (onNodeCollapse)="nodeCollapse($event)"
                            (onNodeSelect)="onSelect($event)"
                            [emptyMessage]="emptyMessage()"
                            (onNodeUnselect)="onUnselect($event)"
                            [filter]="filter()"
                            [filterBy]="filterBy()"
                            [filterMode]="filterMode()"
                            [filterPlaceholder]="filterPlaceholder()"
                            [filterLocale]="filterLocale()"
                            [filteredNodes]="filteredNodes"
                            [virtualScroll]="virtualScroll()"
                            [virtualScrollItemSize]="virtualScrollItemSize()"
                            [virtualScrollOptions]="virtualScrollOptions()"
                            [loading]="loading()"
                            [filterInputAutoFocus]="filterInputAutoFocus()"
                            [loadingMode]="loadingMode()"
                            [pt]="ptm('pcTree')"
                            [unstyled]="unstyled()"
                        >
                            @if (emptyTemplate()) {
                                <ng-template #empty>
                                    <ng-container *ngTemplateOutlet="emptyTemplate()"></ng-container>
                                </ng-template>
                            }
                            @if (nodeTemplate()) {
                                <ng-template #node let-node>
                                    <ng-container *ngTemplateOutlet="nodeTemplate(); context: { $implicit: node }"></ng-container>
                                </ng-template>
                            }
                            @if (itemTogglerIconTemplate()) {
                                <ng-template #togglericon let-expanded>
                                    <ng-container *ngTemplateOutlet="itemTogglerIconTemplate(); context: { $implicit: expanded }"></ng-container>
                                </ng-template>
                            }
                            @if (itemCheckboxIconTemplate()) {
                                <ng-template #checkboxicon let-selected let-partialSelected="partialSelected">
                                    <ng-container *ngTemplateOutlet="itemCheckboxIconTemplate(); context: { $implicit: selected, partialSelected: partialSelected }"></ng-container>
                                </ng-template>
                            }
                            @if (itemLoadingIconTemplate()) {
                                <ng-template #loadingicon>
                                    <ng-container *ngTemplateOutlet="itemLoadingIconTemplate()"></ng-container>
                                </ng-template>
                            }
                            @if (filterIconTemplate()) {
                                <ng-template #filtericon>
                                    <ng-container *ngTemplateOutlet="filterIconTemplate()"></ng-container>
                                </ng-template>
                            }
                        </p-tree>
                    </div>
                    @if (footerTemplate()) {
                        <ng-container *ngTemplateOutlet="footerTemplate(); context: footerTemplateContext()"></ng-container>
                    }
                    <span
                        #lastHiddenFocusableEl
                        role="presentation"
                        [class]="pcn('p-hidden-accessible p-hidden-focusable')"
                        [attr.tabindex]="0"
                        (focus)="onLastHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('hiddenLastFocusableEl')"
                    ></span>
                </div>
            </ng-template>
        </p-overlay>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				TREESELECT_VALUE_ACCESSOR,
				TreeSelectStyle,
				{
					provide: TREESELECT_INSTANCE,
					useExisting: TreeSelect
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: TreeSelect
				}
			],
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx('root')",
				"[style]": "sx('root')",
				"(mousedown)": "onClick($event)"
			}
		}]
	}], () => [], {
		inputId: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inputId",
				required: false
			}]
		}],
		scrollHeight: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "scrollHeight",
				required: false
			}]
		}],
		metaKeySelection: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "metaKeySelection",
				required: false
			}]
		}],
		display: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		selectionMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		placeholder: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		panelClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "panelClass",
				required: false
			}]
		}],
		panelStyle: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "panelStyle",
				required: false
			}]
		}],
		panelStyleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "panelStyleClass",
				required: false
			}]
		}],
		labelStyle: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "labelStyle",
				required: false
			}]
		}],
		labelStyleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "labelStyleClass",
				required: false
			}]
		}],
		overlayOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "overlayOptions",
				required: false
			}]
		}],
		emptyMessage: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "emptyMessage",
				required: false
			}]
		}],
		filter: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}],
		filterBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterBy",
				required: false
			}]
		}],
		filterMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterMode",
				required: false
			}]
		}],
		filterPlaceholder: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterPlaceholder",
				required: false
			}]
		}],
		filterLocale: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterLocale",
				required: false
			}]
		}],
		filterInputAutoFocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterInputAutoFocus",
				required: false
			}]
		}],
		propagateSelectionDown: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "propagateSelectionDown",
				required: false
			}]
		}],
		propagateSelectionUp: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "propagateSelectionUp",
				required: false
			}]
		}],
		showClear: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "showClear",
				required: false
			}]
		}],
		resetFilterOnHide: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "resetFilterOnHide",
				required: false
			}]
		}],
		virtualScroll: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "virtualScroll",
				required: false
			}]
		}],
		virtualScrollItemSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "virtualScrollItemSize",
				required: false
			}]
		}],
		virtualScrollOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "virtualScrollOptions",
				required: false
			}]
		}],
		autofocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		options: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		loading: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		loadingMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loadingMode",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		variant: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		fluid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "fluid",
				required: false
			}]
		}],
		appendTo: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "appendTo",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		onNodeExpand: [{
			type: Output,
			args: ["onNodeExpand"]
		}],
		onNodeCollapse: [{
			type: Output,
			args: ["onNodeCollapse"]
		}],
		onShow: [{
			type: Output,
			args: ["onShow"]
		}],
		onHide: [{
			type: Output,
			args: ["onHide"]
		}],
		onClear: [{
			type: Output,
			args: ["onClear"]
		}],
		onFilter: [{
			type: Output,
			args: ["onFilter"]
		}],
		onFocus: [{
			type: Output,
			args: ["onFocus"]
		}],
		onBlur: [{
			type: Output,
			args: ["onBlur"]
		}],
		onNodeUnselect: [{
			type: Output,
			args: ["onNodeUnselect"]
		}],
		onNodeSelect: [{
			type: Output,
			args: ["onNodeSelect"]
		}],
		focusInputViewChild: [{
			type: ViewChild,
			args: ["focusInput", { isSignal: true }]
		}],
		filterViewChild: [{
			type: ViewChild,
			args: ["filter", { isSignal: true }]
		}],
		treeViewChild: [{
			type: ViewChild,
			args: ["tree", { isSignal: true }]
		}],
		panelEl: [{
			type: ViewChild,
			args: ["panel", { isSignal: true }]
		}],
		overlayViewChild: [{
			type: ViewChild,
			args: ["overlay", { isSignal: true }]
		}],
		firstHiddenFocusableElementOnOverlay: [{
			type: ViewChild,
			args: ["firstHiddenFocusableEl", { isSignal: true }]
		}],
		lastHiddenFocusableElementOnOverlay: [{
			type: ViewChild,
			args: ["lastHiddenFocusableEl", { isSignal: true }]
		}],
		valueTemplate: [{
			type: ContentChild,
			args: ["value", {
				descendants: false,
				isSignal: true
			}]
		}],
		headerTemplate: [{
			type: ContentChild,
			args: ["header", {
				descendants: false,
				isSignal: true
			}]
		}],
		emptyTemplate: [{
			type: ContentChild,
			args: ["empty", {
				descendants: false,
				isSignal: true
			}]
		}],
		footerTemplate: [{
			type: ContentChild,
			args: ["footer", {
				descendants: false,
				isSignal: true
			}]
		}],
		clearIconTemplate: [{
			type: ContentChild,
			args: ["clearicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		triggerIconTemplate: [{
			type: ContentChild,
			args: ["triggericon", {
				descendants: false,
				isSignal: true
			}]
		}],
		dropdownIconTemplate: [{
			type: ContentChild,
			args: ["dropdownicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		filterIconTemplate: [{
			type: ContentChild,
			args: ["filtericon", {
				descendants: false,
				isSignal: true
			}]
		}],
		closeIconTemplate: [{
			type: ContentChild,
			args: ["closeicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		itemTogglerIconTemplate: [{
			type: ContentChild,
			args: ["itemtogglericon", {
				descendants: false,
				isSignal: true
			}]
		}],
		itemCheckboxIconTemplate: [{
			type: ContentChild,
			args: ["itemcheckboxicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		itemLoadingIconTemplate: [{
			type: ContentChild,
			args: ["itemloadingicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		nodeTemplate: [{
			type: ContentChild,
			args: ["node", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var TreeSelectModule = class TreeSelectModule {
	static ɵfac = function TreeSelectModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TreeSelectModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: TreeSelectModule,
		imports: [TreeSelect, SharedModule],
		exports: [TreeSelect, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		TreeSelect,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TreeSelectModule, [{
		type: NgModule,
		args: [{
			imports: [TreeSelect, SharedModule],
			exports: [TreeSelect, SharedModule]
		}]
	}], null, null);
})();
export { TREESELECT_VALUE_ACCESSOR, TreeSelect, TreeSelectClasses, TreeSelectModule, TreeSelectStyle };
