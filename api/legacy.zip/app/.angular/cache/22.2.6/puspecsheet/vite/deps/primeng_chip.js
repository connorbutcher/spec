import "./primeng_bind.js";
export { t as Chip, n as ChipClasses, r as ChipModule, i as ChipStyle } from "./primeng-chip-CQTgSJHN.js";
