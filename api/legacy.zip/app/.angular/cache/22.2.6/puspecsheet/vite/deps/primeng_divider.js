import { U as InjectionToken, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jo as ɵɵprojectionDef, Jt as Component, Nn as NgModule, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ca as ɵɵclassMap, co as ɵɵelementEnd, lo as ɵɵelementStart, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, qo as ɵɵprojection, xn as Injectable } from "./core-BenYQOr3.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeuix/styles/dist/divider/index.mjs
var style = "\n    .p-divider-horizontal {\n        display: flex;\n        width: 100%;\n        position: relative;\n        align-items: center;\n        margin: dt('divider.horizontal.margin');\n        padding: dt('divider.horizontal.padding');\n    }\n\n    .p-divider-horizontal:before {\n        position: absolute;\n        display: block;\n        inset-block-start: 50%;\n        inset-inline-start: 0;\n        width: 100%;\n        content: '';\n        border-block-start: 1px solid dt('divider.border.color');\n    }\n\n    .p-divider-horizontal .p-divider-content {\n        padding: dt('divider.horizontal.content.padding');\n    }\n\n    .p-divider-vertical {\n        min-height: 100%;\n        display: flex;\n        position: relative;\n        justify-content: center;\n        margin: dt('divider.vertical.margin');\n        padding: dt('divider.vertical.padding');\n    }\n\n    .p-divider-vertical:before {\n        position: absolute;\n        display: block;\n        inset-block-start: 0;\n        inset-inline-start: 50%;\n        height: 100%;\n        content: '';\n        border-inline-start: 1px solid dt('divider.border.color');\n    }\n\n    .p-divider.p-divider-vertical .p-divider-content {\n        padding: dt('divider.vertical.content.padding');\n    }\n\n    .p-divider-content {\n        z-index: 1;\n        background: dt('divider.content.background');\n        color: dt('divider.content.color');\n    }\n\n    .p-divider-solid.p-divider-horizontal:before {\n        border-block-start-style: solid;\n    }\n\n    .p-divider-solid.p-divider-vertical:before {\n        border-inline-start-style: solid;\n    }\n\n    .p-divider-dashed.p-divider-horizontal:before {\n        border-block-start-style: dashed;\n    }\n\n    .p-divider-dashed.p-divider-vertical:before {\n        border-inline-start-style: dashed;\n    }\n\n    .p-divider-dotted.p-divider-horizontal:before {\n        border-block-start-style: dotted;\n    }\n\n    .p-divider-dotted.p-divider-vertical:before {\n        border-inline-start-style: dotted;\n    }\n\n    .p-divider-left:dir(rtl),\n    .p-divider-right:dir(rtl) {\n        flex-direction: row-reverse;\n    }\n";
// node_modules/primeng/fesm2022/primeng-divider.mjs
var inlineStyles = { root: ({ instance }) => {
	const layout = instance.layout();
	const align = instance.align();
	return {
		justifyContent: layout === "horizontal" ? align === "center" || align == null ? "center" : align === "left" ? "flex-start" : align === "right" ? "flex-end" : null : null,
		alignItems: layout === "vertical" ? align === "center" || align == null ? "center" : align === "top" ? "flex-start" : align === "bottom" ? "flex-end" : null : null
	};
} };
var classes = {
	root: ({ instance }) => {
		const layout = instance.layout();
		const type = instance.type();
		const align = instance.align();
		return [
			"p-divider p-component",
			"p-divider-" + layout,
			"p-divider-" + type,
			{ "p-divider-left": layout === "horizontal" && (!align || align === "left") },
			{ "p-divider-center": layout === "horizontal" && align === "center" },
			{ "p-divider-right": layout === "horizontal" && align === "right" },
			{ "p-divider-top": layout === "vertical" && align === "top" },
			{ "p-divider-center": layout === "vertical" && (!align || align === "center") },
			{ "p-divider-bottom": layout === "vertical" && align === "bottom" }
		];
	},
	content: "p-divider-content"
};
var DividerStyle = class DividerStyle extends BaseStyle {
	name = "divider";
	style = style;
	classes = classes;
	inlineStyles = inlineStyles;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵDividerStyle_BaseFactory = void 0;
		return function DividerStyle_Factory(__ngFactoryType__) {
			return (ɵDividerStyle_BaseFactory || (ɵDividerStyle_BaseFactory = ɵɵgetInheritedFactory(DividerStyle)))(__ngFactoryType__ || DividerStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: DividerStyle,
		factory: DividerStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DividerStyle, [{ type: Injectable }], null, null);
})();
var DividerClasses;
(function(DividerClasses) {
	DividerClasses["root"] = "p-divider";
	DividerClasses["content"] = "p-divider-content";
})(DividerClasses || (DividerClasses = {}));
var DIVIDER_INSTANCE = new InjectionToken("DIVIDER_INSTANCE");
var Divider = class Divider extends BaseComponent {
	componentName = "Divider";
	$pcDivider = inject(DIVIDER_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	layout = input("horizontal", ...ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []);
	type = input("solid", ...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	align = input(...ngDevMode ? [void 0, { debugName: "align" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(DividerStyle);
	dataP = computed(() => this.cn({
		[this.align()]: this.align(),
		[this.layout()]: this.layout(),
		[this.type()]: this.type()
	}), ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵDivider_BaseFactory = void 0;
		return function Divider_Factory(__ngFactoryType__) {
			return (ɵDivider_BaseFactory || (ɵDivider_BaseFactory = ɵɵgetInheritedFactory(Divider)))(__ngFactoryType__ || Divider);
		};
	})();
	static ɵcmp = (function() {
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Divider,
			selectors: [["p-divider"]],
			hostAttrs: ["role", "separator"],
			hostVars: 6,
			hostBindings: function Divider_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("aria-orientation", ctx.layout())("data-p", ctx.dataP());
					ɵɵstyleMap(ctx.sx("root"));
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				layout: [1, "layout"],
				type: [1, "type"],
				align: [1, "align"]
			},
			features: [
				ɵɵProvidersFeature([
					DividerStyle,
					{
						provide: DIVIDER_INSTANCE,
						useExisting: Divider
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Divider
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			ngContentSelectors: ["*"],
			decls: 2,
			vars: 3,
			consts: [[3, "pBind"]],
			template: function Divider_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵprojectionDef();
					ɵɵelementStart(0, "div", 0);
					ɵɵprojection(1);
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵclassMap(ctx.cx("content"));
					ɵɵproperty("pBind", ctx.ptm("content"));
				}
			},
			dependencies: [
				SharedModule,
				BindModule,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Divider, [{
		type: Component,
		args: [{
			selector: "p-divider",
			standalone: true,
			imports: [SharedModule, BindModule],
			template: `
        <div [pBind]="ptm('content')" [class]="cx('content')">
            <ng-content></ng-content>
        </div>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[attr.aria-orientation]": "layout()",
				role: "separator",
				"[class]": "cx('root')",
				"[style]": "sx('root')",
				"[attr.data-p]": "dataP()"
			},
			providers: [
				DividerStyle,
				{
					provide: DIVIDER_INSTANCE,
					useExisting: Divider
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Divider
				}
			],
			hostDirectives: [Bind]
		}]
	}], null, {
		layout: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "layout",
				required: false
			}]
		}],
		type: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "type",
				required: false
			}]
		}],
		align: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "align",
				required: false
			}]
		}]
	});
})();
var DividerModule = class DividerModule {
	static ɵfac = function DividerModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || DividerModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: DividerModule,
		imports: [Divider, BindModule],
		exports: [Divider, BindModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Divider,
		BindModule,
		BindModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DividerModule, [{
		type: NgModule,
		args: [{
			imports: [Divider, BindModule],
			exports: [Divider, BindModule]
		}]
	}], null, null);
})();
export { Divider, DividerClasses, DividerModule, DividerStyle };
