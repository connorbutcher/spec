import "./@angular_forms.js";
import "./primeng_bind.js";
export { t as SELECT_VALUE_ACCESSOR, n as Select, r as SelectClasses, i as SelectModule, a as SelectStyle } from "./primeng-select-B-os1jk6.js";
