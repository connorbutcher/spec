import { Fn as forwardRef, U as InjectionToken, Ui as signal, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, wr as inject, xn as effect } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Nn as NgModule, O as booleanAttribute, Ro as ɵɵlistener, S as ViewChild, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Ya as ɵɵdomElement, Yo as ɵɵproperty, Zi as ɵɵadvance, Zs as ɵɵviewQuerySignal, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, ds as ɵɵrepeaterCreate, gt as viewChild, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, us as ɵɵrepeater, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { NG_VALUE_ACCESSOR, NgControl } from "./@angular_forms.js";
import { h as b, p as _ } from "./dist-BRhwYpCB.js";
import { SharedModule } from "./primeng_api.js";
import { n as PARENT_INSTANCE } from "./primeng-basecomponent-cJWiv26K.js";
import { t as BaseEditableHolder } from "./primeng-baseeditableholder-joFSbzas.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { t as Check } from "./primeicons-angular-check-CmXzBfwi.js";
import { t as CoreIcon } from "./primeicons-angular-core-Z_0bnZZa.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
// node_modules/@primeicons/core/dist/esm/icons/minus.mjs
var e = {
	name: "minus",
	meta: { tags: [
		"minus",
		"remove",
		"subtract",
		"decrease",
		"less"
	] },
	svg: {
		xmlns: "http://www.w3.org/2000/svg",
		width: 20,
		height: 20,
		viewBox: "0 0 20 20",
		fill: "none"
	},
	nodes: [["path", {
		d: "M17 9.25C17.4142 9.25 17.75 9.58579 17.75 10C17.75 10.4142 17.4142 10.75 17 10.75H3C2.58579 10.75 2.25 10.4142 2.25 10C2.25 9.58579 2.58579 9.25 3 9.25H17Z",
		fill: "currentColor",
		key: "iu8x2q"
	}]]
};
// node_modules/@primeicons/angular/fesm2022/primeicons-angular-minus.mjs
var Minus = class Minus extends CoreIcon {
	constructor() {
		super();
		this._icon = e;
	}
	static ɵfac = function Minus_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Minus)();
	};
	static ɵcmp = (function() {
		const _forTrack0 = ($index, $item) => $item[1]["key"] || $index;
		function Minus_For_1_Case_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "path");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("d", node_r1[1]["d"])("fill", node_r1[1]["fill"])("fill-opacity", node_r1[1]["fillOpacity"])("fill-rule", node_r1[1]["fillRule"])("clip-rule", node_r1[1]["clipRule"])("stroke", node_r1[1]["stroke"])("stroke-width", node_r1[1]["strokeWidth"])("stroke-opacity", node_r1[1]["strokeOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Case_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "circle");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("cx", node_r1[1]["cx"])("cy", node_r1[1]["cy"])("r", node_r1[1]["r"])("fill", node_r1[1]["fill"])("fill-opacity", node_r1[1]["fillOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Case_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "rect");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("x", node_r1[1]["x"])("y", node_r1[1]["y"])("width", node_r1[1]["width"])("height", node_r1[1]["height"])("rx", node_r1[1]["rx"])("ry", node_r1[1]["ry"])("fill", node_r1[1]["fill"])("fill-opacity", node_r1[1]["fillOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Case_3_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "line");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("x1", node_r1[1]["x1"])("y1", node_r1[1]["y1"])("x2", node_r1[1]["x2"])("y2", node_r1[1]["y2"])("stroke", node_r1[1]["stroke"])("stroke-opacity", node_r1[1]["strokeOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Case_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "polyline");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("points", node_r1[1]["points"])("fill", node_r1[1]["fill"])("fill-opacity", node_r1[1]["fillOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Case_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "polygon");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("points", node_r1[1]["points"])("fill", node_r1[1]["fill"])("fill-opacity", node_r1[1]["fillOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Case_6_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵdomElement(0, "ellipse");
			}
			if (rf & 2) {
				const node_r1 = ɵɵnextContext().$implicit;
				ɵɵattribute("cx", node_r1[1]["cx"])("cy", node_r1[1]["cy"])("rx", node_r1[1]["rx"])("ry", node_r1[1]["ry"])("fill", node_r1[1]["fill"])("fill-opacity", node_r1[1]["fillOpacity"])("opacity", node_r1[1]["opacity"]);
			}
		}
		function Minus_For_1_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Minus_For_1_Case_0_Template, 1, 9, "path")(1, Minus_For_1_Case_1_Template, 1, 6, "circle")(2, Minus_For_1_Case_2_Template, 1, 9, "rect")(3, Minus_For_1_Case_3_Template, 1, 7, "line")(4, Minus_For_1_Case_4_Template, 1, 4, "polyline")(5, Minus_For_1_Case_5_Template, 1, 4, "polygon")(6, Minus_For_1_Case_6_Template, 1, 7, "ellipse");
			if (rf & 2) {
				let tmp_10_0 = void 0;
				const node_r1 = ctx.$implicit;
				ɵɵconditional((tmp_10_0 = node_r1[0]) === "path" ? 0 : tmp_10_0 === "circle" ? 1 : tmp_10_0 === "rect" ? 2 : tmp_10_0 === "line" ? 3 : tmp_10_0 === "polyline" ? 4 : tmp_10_0 === "polygon" ? 5 : tmp_10_0 === "ellipse" ? 6 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Minus,
			selectors: [[
				"svg",
				"data-p-icon",
				"minus"
			]],
			features: [ɵɵInheritDefinitionFeature],
			decls: 2,
			vars: 0,
			template: function Minus_Template(rf, ctx) {
				if (rf & 1) ɵɵrepeaterCreate(0, Minus_For_1_Template, 7, 1, null, null, _forTrack0);
				if (rf & 2) ɵɵrepeater(ctx.iconNodes());
			},
			encapsulation: 2,
			changeDetection: 1
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Minus, [{
		type: Component,
		args: [{
			selector: "svg[data-p-icon=\"minus\"]",
			standalone: true,
			template: "\n        @for (node of iconNodes(); track node[1]['key'] || $index) {\n            @switch (node[0]) {\n                @case ('path') {\n                    <svg:path\n                        [attr.d]=\"node[1]['d']\"\n                        [attr.fill]=\"node[1]['fill']\"\n                        [attr.fill-opacity]=\"node[1]['fillOpacity']\"\n                        [attr.fill-rule]=\"node[1]['fillRule']\"\n                        [attr.clip-rule]=\"node[1]['clipRule']\"\n                        [attr.stroke]=\"node[1]['stroke']\"\n                        [attr.stroke-width]=\"node[1]['strokeWidth']\"\n                        [attr.stroke-opacity]=\"node[1]['strokeOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n                @case ('circle') {\n                    <svg:circle\n                        [attr.cx]=\"node[1]['cx']\"\n                        [attr.cy]=\"node[1]['cy']\"\n                        [attr.r]=\"node[1]['r']\"\n                        [attr.fill]=\"node[1]['fill']\"\n                        [attr.fill-opacity]=\"node[1]['fillOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n                @case ('rect') {\n                    <svg:rect\n                        [attr.x]=\"node[1]['x']\"\n                        [attr.y]=\"node[1]['y']\"\n                        [attr.width]=\"node[1]['width']\"\n                        [attr.height]=\"node[1]['height']\"\n                        [attr.rx]=\"node[1]['rx']\"\n                        [attr.ry]=\"node[1]['ry']\"\n                        [attr.fill]=\"node[1]['fill']\"\n                        [attr.fill-opacity]=\"node[1]['fillOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n                @case ('line') {\n                    <svg:line\n                        [attr.x1]=\"node[1]['x1']\"\n                        [attr.y1]=\"node[1]['y1']\"\n                        [attr.x2]=\"node[1]['x2']\"\n                        [attr.y2]=\"node[1]['y2']\"\n                        [attr.stroke]=\"node[1]['stroke']\"\n                        [attr.stroke-opacity]=\"node[1]['strokeOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n                @case ('polyline') {\n                    <svg:polyline\n                        [attr.points]=\"node[1]['points']\"\n                        [attr.fill]=\"node[1]['fill']\"\n                        [attr.fill-opacity]=\"node[1]['fillOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n                @case ('polygon') {\n                    <svg:polygon\n                        [attr.points]=\"node[1]['points']\"\n                        [attr.fill]=\"node[1]['fill']\"\n                        [attr.fill-opacity]=\"node[1]['fillOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n                @case ('ellipse') {\n                    <svg:ellipse\n                        [attr.cx]=\"node[1]['cx']\"\n                        [attr.cy]=\"node[1]['cy']\"\n                        [attr.rx]=\"node[1]['rx']\"\n                        [attr.ry]=\"node[1]['ry']\"\n                        [attr.fill]=\"node[1]['fill']\"\n                        [attr.fill-opacity]=\"node[1]['fillOpacity']\"\n                        [attr.opacity]=\"node[1]['opacity']\"\n                    />\n                }\n            }\n        }\n"
		}]
	}], () => [], null);
})();
// node_modules/@primeuix/styles/dist/checkbox/index.mjs
var style = "\n    .p-checkbox {\n        position: relative;\n        display: inline-flex;\n        user-select: none;\n        vertical-align: bottom;\n        width: dt('checkbox.width');\n        height: dt('checkbox.height');\n    }\n\n    .p-checkbox-input {\n        cursor: pointer;\n        appearance: none;\n        position: absolute;\n        inset-block-start: 0;\n        inset-inline-start: 0;\n        width: 100%;\n        height: 100%;\n        padding: 0;\n        margin: 0;\n        opacity: 0;\n        z-index: 1;\n        outline: 0 none;\n        border: 1px solid transparent;\n        border-radius: dt('checkbox.border.radius');\n    }\n\n    .p-checkbox-box {\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        border-radius: dt('checkbox.border.radius');\n        border: 1px solid dt('checkbox.border.color');\n        background: dt('checkbox.background');\n        color: dt('checkbox.icon.color');\n        width: dt('checkbox.width');\n        height: dt('checkbox.height');\n        transition:\n            background dt('checkbox.transition.duration'),\n            border-color dt('checkbox.transition.duration'),\n            box-shadow dt('checkbox.transition.duration'),\n            outline-color dt('checkbox.transition.duration');\n        outline-color: transparent;\n        box-shadow: dt('checkbox.shadow');\n    }\n\n    .p-checkbox-indicator {\n        display: flex;\n        justify-content: center;\n        align-items: center;\n    }\n\n    .p-checkbox-icon,\n    .p-checkbox-indicator svg,\n    .p-checkbox-indicator i {\n        width: dt('checkbox.icon.size');\n        height: dt('checkbox.icon.size');\n        font-size: dt('checkbox.icon.size');\n        transition-duration: dt('checkbox.transition.duration');\n    }\n\n    .p-checkbox:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {\n        border-color: dt('checkbox.hover.border.color');\n    }\n\n    .p-checkbox-checked .p-checkbox-box {\n        border-color: dt('checkbox.checked.border.color');\n        background: dt('checkbox.checked.background');\n        color: dt('checkbox.icon.checked.color');\n    }\n\n    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {\n        background: dt('checkbox.checked.hover.background');\n        border-color: dt('checkbox.checked.hover.border.color');\n        color: dt('checkbox.icon.checked.hover.color');\n    }\n\n    .p-checkbox:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {\n        border-color: dt('checkbox.focus.border.color');\n        box-shadow: dt('checkbox.focus.ring.shadow');\n        outline: dt('checkbox.focus.ring.width') dt('checkbox.focus.ring.style') dt('checkbox.focus.ring.color');\n        outline-offset: dt('checkbox.focus.ring.offset');\n    }\n\n    .p-checkbox-checked:not(.p-disabled):has(.p-checkbox-input:focus-visible) .p-checkbox-box {\n        border-color: dt('checkbox.checked.focus.border.color');\n    }\n\n    .p-checkbox.p-invalid > .p-checkbox-box {\n        border-color: dt('checkbox.invalid.border.color');\n    }\n\n    .p-checkbox.p-variant-filled .p-checkbox-box {\n        background: dt('checkbox.filled.background');\n    }\n\n    .p-checkbox-checked.p-variant-filled .p-checkbox-box {\n        background: dt('checkbox.checked.background');\n    }\n\n    .p-checkbox-checked.p-variant-filled:not(.p-disabled):has(.p-checkbox-input:hover) .p-checkbox-box {\n        background: dt('checkbox.checked.hover.background');\n    }\n\n    .p-checkbox.p-disabled {\n        opacity: 1;\n    }\n\n    .p-checkbox.p-disabled .p-checkbox-box {\n        background: dt('checkbox.disabled.background');\n        border-color: dt('checkbox.checked.disabled.border.color');\n        color: dt('checkbox.icon.disabled.color');\n    }\n\n    .p-checkbox-sm,\n    .p-checkbox-sm .p-checkbox-box {\n        width: dt('checkbox.sm.width');\n        height: dt('checkbox.sm.height');\n    }\n\n    .p-checkbox-sm .p-checkbox-icon,\n    .p-checkbox-sm .p-checkbox-indicator svg,\n    .p-checkbox-sm .p-checkbox-indicator i {\n        font-size: dt('checkbox.icon.sm.size');\n        width: dt('checkbox.icon.sm.size');\n        height: dt('checkbox.icon.sm.size');\n    }\n\n    .p-checkbox-lg,\n    .p-checkbox-lg .p-checkbox-box {\n        width: dt('checkbox.lg.width');\n        height: dt('checkbox.lg.height');\n    }\n\n    .p-checkbox-lg .p-checkbox-icon,\n    .p-checkbox-lg .p-checkbox-indicator svg,\n    .p-checkbox-lg .p-checkbox-indicator i {\n        font-size: dt('checkbox.icon.lg.size');\n        width: dt('checkbox.icon.lg.size');\n        height: dt('checkbox.icon.lg.size');\n    }\n";
// node_modules/primeng/fesm2022/primeng-checkbox.mjs
var classes = {
	root: ({ instance }) => ["p-checkbox p-component", {
		"p-checkbox-checked": instance.checked(),
		"p-disabled": instance.$disabled(),
		"p-invalid": instance.invalid(),
		"p-variant-filled": instance.$variant() === "filled",
		"p-checkbox-sm p-inputfield-sm": instance.size() === "small",
		"p-checkbox-lg p-inputfield-lg": instance.size() === "large"
	}],
	box: "p-checkbox-box",
	input: "p-checkbox-input",
	indicator: "p-checkbox-indicator",
	icon: "p-checkbox-icon"
};
var CheckboxStyle = class CheckboxStyle extends BaseStyle {
	name = "checkbox";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵCheckboxStyle_BaseFactory = void 0;
		return function CheckboxStyle_Factory(__ngFactoryType__) {
			return (ɵCheckboxStyle_BaseFactory || (ɵCheckboxStyle_BaseFactory = ɵɵgetInheritedFactory(CheckboxStyle)))(__ngFactoryType__ || CheckboxStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: CheckboxStyle,
		factory: CheckboxStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CheckboxStyle, [{ type: Injectable }], null, null);
})();
var CheckboxClasses;
(function(CheckboxClasses) {
	CheckboxClasses["root"] = "p-checkbox";
	CheckboxClasses["box"] = "p-checkbox-box";
	CheckboxClasses["input"] = "p-checkbox-input";
	CheckboxClasses["indicator"] = "p-checkbox-indicator";
	CheckboxClasses["icon"] = "p-checkbox-icon";
})(CheckboxClasses || (CheckboxClasses = {}));
var CHECKBOX_INSTANCE = new InjectionToken("CHECKBOX_INSTANCE");
var CHECKBOX_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => Checkbox),
	multi: true
};
var Checkbox = class Checkbox extends BaseEditableHolder {
	componentName = "Checkbox";
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	binary = input(false, {
		...ngDevMode ? { debugName: "binary" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	tabindex = input(...ngDevMode ? [void 0, { debugName: "tabindex" }] : /* istanbul ignore next */ []);
	inputId = input(...ngDevMode ? [void 0, { debugName: "inputId" }] : /* istanbul ignore next */ []);
	inputStyle = input(...ngDevMode ? [void 0, { debugName: "inputStyle" }] : /* istanbul ignore next */ []);
	inputClass = input(...ngDevMode ? [void 0, { debugName: "inputClass" }] : /* istanbul ignore next */ []);
	indeterminate = input(false, {
		...ngDevMode ? { debugName: "indeterminate" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	formControl = input(...ngDevMode ? [void 0, { debugName: "formControl" }] : /* istanbul ignore next */ []);
	checkboxIcon = input(...ngDevMode ? [void 0, { debugName: "checkboxIcon" }] : /* istanbul ignore next */ []);
	readonly = input(false, {
		...ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	autofocus = input(false, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	trueValue = input(true, ...ngDevMode ? [{ debugName: "trueValue" }] : /* istanbul ignore next */ []);
	falseValue = input(false, ...ngDevMode ? [{ debugName: "falseValue" }] : /* istanbul ignore next */ []);
	variant = input(...ngDevMode ? [void 0, { debugName: "variant" }] : /* istanbul ignore next */ []);
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	onChange = output();
	onFocus = output();
	onBlur = output();
	inputViewChild = viewChild("input", ...ngDevMode ? [{ debugName: "inputViewChild" }] : /* istanbul ignore next */ []);
	iconTemplate = contentChild("icon", {
		...ngDevMode ? { debugName: "iconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	_indeterminate = signal(false, ...ngDevMode ? [{ debugName: "_indeterminate" }] : /* istanbul ignore next */ []);
	focused = signal(false, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(CheckboxStyle);
	bindDirectiveInstance = inject(Bind, { self: true });
	$pcCheckbox = inject(CHECKBOX_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	$variant = computed(() => this.variant() || this.config.inputVariant() || void 0, ...ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []);
	requiredAttr = computed(() => this.required() ? "" : void 0, ...ngDevMode ? [{ debugName: "requiredAttr" }] : /* istanbul ignore next */ []);
	readonlyAttr = computed(() => this.readonly() ? "" : void 0, ...ngDevMode ? [{ debugName: "readonlyAttr" }] : /* istanbul ignore next */ []);
	disabledAttr = computed(() => this.$disabled() ? "" : void 0, ...ngDevMode ? [{ debugName: "disabledAttr" }] : /* istanbul ignore next */ []);
	checked = computed(() => {
		if (this._indeterminate()) return false;
		return this.binary() ? this.modelValue() === this.trueValue() : _(this.value(), this.modelValue());
	}, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	iconTemplateContext = computed(() => ({
		checked: this.checked(),
		class: this.cx("icon"),
		dataP: this.dataP()
	}), ...ngDevMode ? [{ debugName: "iconTemplateContext" }] : /* istanbul ignore next */ []);
	dataP = computed(() => this.cn({
		invalid: this.invalid(),
		checked: this.checked(),
		disabled: this.$disabled(),
		filled: this.$variant() === "filled",
		[this.size()]: this.size()
	}), ...ngDevMode ? [{ debugName: "dataP" }] : /* istanbul ignore next */ []);
	constructor() {
		super();
		effect(() => {
			const indeterminate = this.indeterminate();
			this._indeterminate.set(indeterminate);
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	updateModel(event) {
		let newModelValue;
		const selfControl = this.injector.get(NgControl, null, {
			optional: true,
			self: true
		});
		const currentModelValue = selfControl && !this.formControl() ? selfControl.value : this.modelValue();
		if (!this.binary()) {
			if (this.checked() || this._indeterminate()) newModelValue = currentModelValue.filter((val) => !b(val, this.value()));
			else newModelValue = currentModelValue ? [...currentModelValue, this.value()] : [this.value()];
			this.onModelChange(newModelValue);
			this.writeModelValue(newModelValue);
			const formControl = this.formControl();
			if (formControl) formControl.setValue(newModelValue);
		} else {
			newModelValue = this._indeterminate() ? this.trueValue() : this.checked() ? this.falseValue() : this.trueValue();
			this.writeModelValue(newModelValue);
			this.onModelChange(newModelValue);
		}
		if (this._indeterminate()) this._indeterminate.set(false);
		this.onChange.emit({
			checked: newModelValue,
			originalEvent: event
		});
	}
	handleChange(event) {
		if (!this.readonly()) this.updateModel(event);
	}
	onInputFocus(event) {
		this.focused.set(true);
		this.onFocus.emit(event);
	}
	onInputBlur(event) {
		this.focused.set(false);
		this.onBlur.emit(event);
		this.onModelTouched();
	}
	focus() {
		this.inputViewChild()?.nativeElement.focus();
	}
	writeControlValue(value, setModelValue) {
		setModelValue(value);
	}
	static ɵfac = function Checkbox_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Checkbox)();
	};
	static ɵcmp = (function() {
		const _c0 = ["icon"];
		const _c1 = ["input"];
		function Checkbox_Conditional_3_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 2);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r0.cn(ctx_r0.cx("icon"), ctx_r0.checkboxIcon()));
				ɵɵproperty("pBind", ctx_r0.ptm("icon"));
				ɵɵattribute("data-p", ctx_r0.dataP());
			}
		}
		function Checkbox_Conditional_3_Conditional_0_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 5);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r0.cx("icon"));
				ɵɵproperty("pBind", ctx_r0.ptm("icon"));
				ɵɵattribute("data-p", ctx_r0.dataP());
			}
		}
		function Checkbox_Conditional_3_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 2);
				ɵɵconditionalCreate(1, Checkbox_Conditional_3_Conditional_0_Conditional_1_Template, 1, 4, "span", 3)(2, Checkbox_Conditional_3_Conditional_0_Conditional_2_Template, 1, 4, "svg", 4);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r0.cx("indicator"));
				ɵɵproperty("pBind", ctx_r0.ptm("indicator"));
				ɵɵadvance();
				ɵɵconditional(ctx_r0.checkboxIcon() ? 1 : 2);
			}
		}
		function Checkbox_Conditional_3_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 2);
				ɵɵnamespaceSVG();
				ɵɵelement(1, "svg", 6);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r0.cx("indicator"));
				ɵɵproperty("pBind", ctx_r0.ptm("indicator"));
				ɵɵadvance();
				ɵɵclassMap(ctx_r0.cx("icon"));
				ɵɵproperty("pBind", ctx_r0.ptm("icon"));
				ɵɵattribute("data-p", ctx_r0.dataP());
			}
		}
		function Checkbox_Conditional_3_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, Checkbox_Conditional_3_Conditional_0_Template, 3, 4, "span", 3);
				ɵɵconditionalCreate(1, Checkbox_Conditional_3_Conditional_1_Template, 2, 7, "span", 3);
			}
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵconditional(ctx_r0.checked() ? 0 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r0._indeterminate() ? 1 : -1);
			}
		}
		function Checkbox_Conditional_4_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Checkbox_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Checkbox_Conditional_4_ng_container_0_Template, 1, 0, "ng-container", 7);
			if (rf & 2) {
				const ctx_r0 = ɵɵnextContext();
				ɵɵproperty("ngTemplateOutlet", ctx_r0.iconTemplate())("ngTemplateOutletContext", ctx_r0.iconTemplateContext());
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Checkbox,
			selectors: [["p-checkbox"], ["p-check-box"]],
			contentQueries: function Checkbox_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.iconTemplate, _c0, 4);
				if (rf & 2) ɵɵqueryAdvance();
			},
			viewQuery: function Checkbox_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.inputViewChild, _c1, 5);
				if (rf & 2) ɵɵqueryAdvance();
			},
			hostVars: 6,
			hostBindings: function Checkbox_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("data-p-highlight", ctx.checked())("data-p-checked", ctx.checked())("data-p-disabled", ctx.$disabled())("data-p", ctx.dataP());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				value: [1, "value"],
				binary: [1, "binary"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				ariaLabel: [1, "ariaLabel"],
				tabindex: [1, "tabindex"],
				inputId: [1, "inputId"],
				inputStyle: [1, "inputStyle"],
				inputClass: [1, "inputClass"],
				indeterminate: [1, "indeterminate"],
				formControl: [1, "formControl"],
				checkboxIcon: [1, "checkboxIcon"],
				readonly: [1, "readonly"],
				autofocus: [1, "autofocus"],
				trueValue: [1, "trueValue"],
				falseValue: [1, "falseValue"],
				variant: [1, "variant"],
				size: [1, "size"]
			},
			outputs: {
				onChange: "onChange",
				onFocus: "onFocus",
				onBlur: "onBlur"
			},
			features: [
				ɵɵProvidersFeature([
					CHECKBOX_VALUE_ACCESSOR,
					CheckboxStyle,
					{
						provide: CHECKBOX_INSTANCE,
						useExisting: Checkbox
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Checkbox
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 5,
			vars: 20,
			consts: [
				["input", ""],
				[
					"type",
					"checkbox",
					3,
					"focus",
					"blur",
					"change",
					"checked",
					"pBind"
				],
				[3, "pBind"],
				[
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"check",
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"check",
					3,
					"pBind"
				],
				[
					"data-p-icon",
					"minus",
					3,
					"pBind"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				]
			],
			template: function Checkbox_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵelementStart(0, "input", 1, 0);
					ɵɵlistener("focus", function Checkbox_Template_input_focus_0_listener($event) {
						return ctx.onInputFocus($event);
					})("blur", function Checkbox_Template_input_blur_0_listener($event) {
						return ctx.onInputBlur($event);
					})("change", function Checkbox_Template_input_change_0_listener($event) {
						return ctx.handleChange($event);
					});
					ɵɵelementEnd();
					ɵɵelementStart(2, "div", 2);
					ɵɵconditionalCreate(3, Checkbox_Conditional_3_Template, 2, 2)(4, Checkbox_Conditional_4_Template, 1, 2, "ng-container");
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵstyleMap(ctx.inputStyle());
					ɵɵclassMap(ctx.cn(ctx.cx("input"), ctx.inputClass()));
					ɵɵproperty("checked", ctx.checked())("pBind", ctx.ptm("input"));
					ɵɵattribute("id", ctx.inputId())("value", ctx.value())("name", ctx.name())("tabindex", ctx.tabindex())("required", ctx.requiredAttr())("readonly", ctx.readonlyAttr())("disabled", ctx.disabledAttr())("aria-labelledby", ctx.ariaLabelledBy())("aria-label", ctx.ariaLabel());
					ɵɵadvance(2);
					ɵɵclassMap(ctx.cx("box"));
					ɵɵproperty("pBind", ctx.ptm("box"));
					ɵɵattribute("data-p", ctx.dataP());
					ɵɵadvance();
					ɵɵconditional(!ctx.iconTemplate() ? 3 : 4);
				}
			},
			dependencies: [
				NgTemplateOutlet,
				SharedModule,
				Check,
				Minus,
				BindModule,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Checkbox, [{
		type: Component,
		args: [{
			selector: "p-checkbox, p-check-box",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				SharedModule,
				Check,
				Minus,
				BindModule
			],
			template: `
        <input
            #input
            [attr.id]="inputId()"
            type="checkbox"
            [attr.value]="value()"
            [attr.name]="name()"
            [checked]="checked()"
            [attr.tabindex]="tabindex()"
            [attr.required]="requiredAttr()"
            [attr.readonly]="readonlyAttr()"
            [attr.disabled]="disabledAttr()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.aria-label]="ariaLabel()"
            [style]="inputStyle()"
            [class]="cn(cx('input'), inputClass())"
            [pBind]="ptm('input')"
            (focus)="onInputFocus($event)"
            (blur)="onInputBlur($event)"
            (change)="handleChange($event)"
        />
        <div [class]="cx('box')" [pBind]="ptm('box')" [attr.data-p]="dataP()">
            @if (!iconTemplate()) {
                @if (checked()) {
                    <span [class]="cx('indicator')" [pBind]="ptm('indicator')">
                        @if (checkboxIcon()) {
                            <span [class]="cn(cx('icon'), checkboxIcon())" [pBind]="ptm('icon')" [attr.data-p]="dataP()"></span>
                        } @else {
                            <svg data-p-icon="check" [class]="cx('icon')" [pBind]="ptm('icon')" [attr.data-p]="dataP()" />
                        }
                    </span>
                }
                @if (_indeterminate()) {
                    <span [class]="cx('indicator')" [pBind]="ptm('indicator')">
                        <svg data-p-icon="minus" [class]="cx('icon')" [pBind]="ptm('icon')" [attr.data-p]="dataP()" />
                    </span>
                }
            } @else {
                <ng-container *ngTemplateOutlet="iconTemplate(); context: iconTemplateContext()"></ng-container>
            }
        </div>
    `,
			providers: [
				CHECKBOX_VALUE_ACCESSOR,
				CheckboxStyle,
				{
					provide: CHECKBOX_INSTANCE,
					useExisting: Checkbox
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Checkbox
				}
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx('root')",
				"[attr.data-p-highlight]": "checked()",
				"[attr.data-p-checked]": "checked()",
				"[attr.data-p-disabled]": "$disabled()",
				"[attr.data-p]": "dataP()"
			},
			hostDirectives: [Bind]
		}]
	}], () => [], {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		binary: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "binary",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		inputId: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inputId",
				required: false
			}]
		}],
		inputStyle: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inputStyle",
				required: false
			}]
		}],
		inputClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inputClass",
				required: false
			}]
		}],
		indeterminate: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "indeterminate",
				required: false
			}]
		}],
		formControl: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "formControl",
				required: false
			}]
		}],
		checkboxIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "checkboxIcon",
				required: false
			}]
		}],
		readonly: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "readonly",
				required: false
			}]
		}],
		autofocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		trueValue: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "trueValue",
				required: false
			}]
		}],
		falseValue: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "falseValue",
				required: false
			}]
		}],
		variant: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		onChange: [{
			type: Output,
			args: ["onChange"]
		}],
		onFocus: [{
			type: Output,
			args: ["onFocus"]
		}],
		onBlur: [{
			type: Output,
			args: ["onBlur"]
		}],
		inputViewChild: [{
			type: ViewChild,
			args: ["input", { isSignal: true }]
		}],
		iconTemplate: [{
			type: ContentChild,
			args: ["icon", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var CheckboxModule = class CheckboxModule {
	static ɵfac = function CheckboxModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || CheckboxModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: CheckboxModule,
		imports: [Checkbox, SharedModule],
		exports: [Checkbox, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		Checkbox,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CheckboxModule, [{
		type: NgModule,
		args: [{
			imports: [Checkbox, SharedModule],
			exports: [Checkbox, SharedModule]
		}]
	}], null, null);
})();
export { CheckboxModule as n, Checkbox as t };
