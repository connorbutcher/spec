import { D as DestroyRef, U as InjectionToken, Ui as signal, _ as untracked, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, xn as effect, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Fs as ɵɵtextInterpolate1, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Ms as ɵɵtemplateRefExtractor, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Os as ɵɵstyleProp, Ps as ɵɵtextInterpolate, Qi as ɵɵanimateEnter, Ro as ɵɵlistener, S as ViewChild, Sn as Input, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Xo as ɵɵpureFunction0, Yo as ɵɵproperty, Zi as ɵɵadvance, Zo as ɵɵpureFunction1, Zs as ɵɵviewQuerySignal, _a as ɵɵcontrolCreate, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, ds as ɵɵrepeaterCreate, ea as ɵɵanimateLeave, ga as ɵɵcontrol, go as ɵɵgetCurrentView, gt as viewChild, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, nt as model, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, rt as numberAttribute, us as ɵɵrepeater, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { takeUntilDestroyed } from "./@angular_core_rxjs-interop.js";
import { n as IconField, r as Search, t as InputIcon } from "./primeng-inputicon-8Wj1PMtM.js";
import { L as Wt, O as L, Q as nt, et as ot, j as R } from "./primeng-utils-CHKSviI4.js";
import { t as Spinner } from "./primeicons-angular-spinner-BMRKusn6.js";
import { _ as d, v as ee } from "./dist-BRhwYpCB.js";
import { TranslationKeys, TreeDragDropService } from "./primeng_api.js";
import { n as AutoFocusModule, t as AutoFocus } from "./primeng-autofocus-C_rkAfz2.js";
import { n as PARENT_INSTANCE, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind } from "./primeng_bind.js";
import { t as InputText } from "./primeng-inputtext-DxZm8pYo.js";
import { Scroller } from "./primeng_scroller.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { FormsModule, NgControlStatus, NgModel } from "./@angular_forms.js";
import { t as Checkbox } from "./primeng-checkbox-BCnyl2Ff.js";
import { t as ChevronDown } from "./primeicons-angular-chevron-down-Cxy_idKw.js";
import { t as ChevronRight } from "./primeicons-angular-chevron-right-CLcOcFWl.js";
import { t as Ripple } from "./primeng-ripple-BUHk2LHf.js";
// node_modules/@primeuix/styles/dist/tree/index.mjs
var style = "\n    .p-tree {\n        display: block;\n        background: dt('tree.background');\n        color: dt('tree.color');\n        padding: dt('tree.padding');\n        position: relative;\n    }\n\n    .p-tree-root-children,\n    .p-tree-node-children {\n        display: flex;\n        list-style-type: none;\n        flex-direction: column;\n        margin: 0;\n        gap: dt('tree.gap');\n    }\n\n    .p-tree-root-children {\n        padding: 0;\n        padding-block-start: dt('tree.gap');\n    }\n\n    .p-tree-node-children {\n        padding: 0;\n        padding-block-start: dt('tree.gap');\n        padding-inline-start: dt('tree.indent');\n    }\n\n    .p-tree-node {\n        padding: 0;\n        outline: 0 none;\n    }\n\n    .p-tree-node-content {\n        border-radius: dt('tree.node.border.radius');\n        padding: dt('tree.node.padding');\n        display: flex;\n        align-items: center;\n        outline-color: transparent;\n        color: dt('tree.node.color');\n        gap: dt('tree.node.gap');\n        transition:\n            background dt('tree.transition.duration'),\n            color dt('tree.transition.duration'),\n            outline-color dt('tree.transition.duration'),\n            box-shadow dt('tree.transition.duration');\n    }\n\n    .p-tree-node-content[data-p-dragging] {\n        outline: 1px dashed dt('primary.color');\n        outline-offset: -1px;\n    }\n\n    .p-tree-node-content[data-pc-section=\"drag-image\"] {\n        background: dt('tree.background');\n    }\n\n    .p-tree-node:focus-visible > .p-tree-node-content {\n        box-shadow: dt('tree.node.focus.ring.shadow');\n        outline: dt('tree.node.focus.ring.width') dt('tree.node.focus.ring.style') dt('tree.node.focus.ring.color');\n        outline-offset: dt('tree.node.focus.ring.offset');\n    }\n\n    .p-tree-node-content.p-tree-node-selectable:not(.p-tree-node-selected):hover {\n        background: dt('tree.node.hover.background');\n        color: dt('tree.node.hover.color');\n    }\n\n    .p-tree-node-content.p-tree-node-selectable:not(.p-tree-node-selected):hover .p-tree-node-icon {\n        color: dt('tree.node.icon.hover.color');\n    }\n\n    .p-tree-node-content.p-tree-node-selected {\n        background: dt('tree.node.selected.background');\n        color: dt('tree.node.selected.color');\n    }\n\n    .p-tree-node-content.p-tree-node-selected .p-tree-node-toggle-button {\n        color: inherit;\n    }\n\n    .p-tree-node-content.p-tree-node-dragover {\n        background: dt('tree.node.hover.background');\n        color: dt('tree.node.hover.color');\n    }\n\n    .p-tree-node-content:focus-visible,\n    .p-tree-node-content.p-tree-node-contextmenu-selected {\n        box-shadow: dt('tree.node.focus.ring.shadow');\n        outline: dt('tree.node.focus.ring.width') dt('tree.node.focus.ring.style') dt('tree.node.focus.ring.color');\n        outline-offset: dt('tree.node.focus.ring.offset');\n    }\n\n    .p-tree-node-drop-point {\n		outline: 1px solid dt('primary.color');\n	}\n\n    .p-tree-node-toggle-button {\n        cursor: pointer;\n        user-select: none;\n        display: inline-flex;\n        align-items: center;\n        justify-content: center;\n        overflow: hidden;\n        position: relative;\n        flex-shrink: 0;\n        width: dt('tree.node.toggle.button.size');\n        height: dt('tree.node.toggle.button.size');\n        color: dt('tree.node.toggle.button.color');\n        border: 0 none;\n        background: transparent;\n        border-radius: dt('tree.node.toggle.button.border.radius');\n        transition:\n            background dt('tree.transition.duration'),\n            color dt('tree.transition.duration'),\n            border-color dt('tree.transition.duration'),\n            outline-color dt('tree.transition.duration'),\n            box-shadow dt('tree.transition.duration');\n        outline-color: transparent;\n        padding: 0;\n    }\n\n    .p-tree-node-toggle-button:enabled:hover {\n        background: dt('tree.node.toggle.button.hover.background');\n        color: dt('tree.node.toggle.button.hover.color');\n    }\n\n    .p-tree-node-content.p-tree-node-selected .p-tree-node-toggle-button:hover {\n        background: dt('tree.node.toggle.button.selected.hover.background');\n        color: dt('tree.node.toggle.button.selected.hover.color');\n    }\n\n    .p-tree-root {\n        overflow: auto;\n    }\n\n    .p-tree-node-selectable {\n        cursor: pointer;\n        user-select: none;\n    }\n\n    .p-tree-node-leaf > .p-tree-node-content .p-tree-node-toggle-button {\n        visibility: hidden;\n    }\n\n    .p-tree-node-icon {\n        color: dt('tree.node.icon.color');\n        transition: color dt('tree.transition.duration');\n    }\n\n    .p-tree-node-label {\n        font-weight: dt('tree.node.label.font.weight');\n        font-size: dt('tree.node.label.font.size');\n    }\n\n    .p-tree-node-content.p-tree-node-selected .p-tree-node-icon {\n        color: dt('tree.node.icon.selected.color');\n    }\n\n    .p-tree-node-content.p-tree-node-selected .p-tree-node-label {\n        font-weight: dt('tree.node.label.selected.font.weight');\n    }\n\n    .p-tree-filter {\n        margin: dt('tree.filter.margin');\n    }\n\n    .p-tree-filter-input {\n        width: 100%;\n    }\n\n    .p-tree-loading-icon {\n        font-size: dt('tree.loading.icon.size');\n        width: dt('tree.loading.icon.size');\n        height: dt('tree.loading.icon.size');\n    }\n\n    .p-tree .p-tree-mask {\n        position: absolute;\n        z-index: 1;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n    }\n\n    .p-tree-flex-scrollable {\n        display: flex;\n        flex: 1;\n        height: 100%;\n        flex-direction: column;\n    }\n\n    .p-tree-flex-scrollable .p-tree-root {\n        flex: 1;\n    }\n";
// node_modules/primeng/fesm2022/primeng-tree.mjs
var classes = {
	root: ({ instance }) => ["p-tree p-component", {
		"p-tree-selectable": instance.selectionMode() != null,
		"p-tree-loading": instance.loading(),
		"p-tree-flex-scrollable": instance.scrollHeight() === "flex",
		"p-tree-node-dragover": instance.dragHover
	}],
	mask: "p-tree-mask p-overlay-mask",
	loadingIcon: "p-tree-loading-icon",
	pcFilterInput: "p-tree-filter-input",
	wrapper: "p-tree-root",
	rootChildren: "p-tree-root-children",
	node: ({ instance }) => ({
		"p-tree-node": true,
		"p-tree-node-leaf": instance.isLeaf()
	}),
	nodeContent: ({ instance }) => ({
		"p-tree-node-content": true,
		"p-tree-node-selectable": instance.selectable,
		"p-tree-node-dragover": instance.isNodeDropActive(),
		"p-tree-node-selected": instance.tree.selectionMode() === "checkbox" && instance.tree.highlightOnSelect() ? instance.checked : instance.selected,
		"p-tree-node-contextmenu-selected": instance.isContextMenuSelected()
	}),
	nodeToggleButton: "p-tree-node-toggle-button",
	nodeToggleIcon: "p-tree-node-toggle-icon",
	nodeCheckbox: "p-tree-node-checkbox",
	nodeIcon: "p-tree-node-icon",
	nodeLabel: "p-tree-node-label",
	nodeChildren: "p-tree-node-children",
	emptyMessage: "p-tree-empty-message",
	dropPoint: "p-tree-node-drop-point"
};
var TreeStyle = class TreeStyle extends BaseStyle {
	name = "tree";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTreeStyle_BaseFactory = void 0;
		return function TreeStyle_Factory(__ngFactoryType__) {
			return (ɵTreeStyle_BaseFactory || (ɵTreeStyle_BaseFactory = ɵɵgetInheritedFactory(TreeStyle)))(__ngFactoryType__ || TreeStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TreeStyle,
		factory: TreeStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TreeStyle, [{ type: Injectable }], null, null);
})();
var TreeClasses;
(function(TreeClasses) {
	TreeClasses["root"] = "p-tree";
	TreeClasses["mask"] = "p-tree-mask";
	TreeClasses["loadingIcon"] = "p-tree-loading-icon";
	TreeClasses["pcFilterInput"] = "p-tree-filter-input";
	TreeClasses["wrapper"] = "p-tree-root";
	TreeClasses["rootChildren"] = "p-tree-root-children";
	TreeClasses["node"] = "p-tree-node";
	TreeClasses["nodeContent"] = "p-tree-node-content";
	TreeClasses["nodeToggleButton"] = "p-tree-node-toggle-button";
	TreeClasses["nodeToggleIcon"] = "p-tree-node-toggle-icon";
	TreeClasses["nodeCheckbox"] = "p-tree-node-checkbox";
	TreeClasses["nodeIcon"] = "p-tree-node-icon";
	TreeClasses["nodeLabel"] = "p-tree-node-label";
	TreeClasses["nodeChildren"] = "p-tree-node-children";
	TreeClasses["emptyMessage"] = "p-tree-empty-message";
	TreeClasses["dropPoint"] = "p-tree-node-droppoint";
})(TreeClasses || (TreeClasses = {}));
var TREE_INSTANCE = new InjectionToken("TREE_INSTANCE");
var TREENODE_INSTANCE = new InjectionToken("TREENODE_INSTANCE");
var UITreeNode = class UITreeNode extends BaseComponent {
	static ICON_CLASS = "p-tree-node-icon ";
	$pcTreeNode = inject(TREENODE_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	rowNode = input(...ngDevMode ? [void 0, { debugName: "rowNode" }] : /* istanbul ignore next */ []);
	node = input(...ngDevMode ? [void 0, { debugName: "node" }] : /* istanbul ignore next */ []);
	parentNode = input(...ngDevMode ? [void 0, { debugName: "parentNode" }] : /* istanbul ignore next */ []);
	root = input(false, {
		...ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	index = input(...ngDevMode ? [void 0, { debugName: "index" }] : /* istanbul ignore next */ []);
	firstChild = input(false, {
		...ngDevMode ? { debugName: "firstChild" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	lastChild = input(false, {
		...ngDevMode ? { debugName: "lastChild" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	level = input(...ngDevMode ? [void 0, { debugName: "level" }] : /* istanbul ignore next */ []);
	indentation = input(...ngDevMode ? [void 0, { debugName: "indentation" }] : /* istanbul ignore next */ []);
	itemSize = input(...ngDevMode ? [void 0, { debugName: "itemSize" }] : /* istanbul ignore next */ []);
	loadingMode = input(...ngDevMode ? [void 0, { debugName: "loadingMode" }] : /* istanbul ignore next */ []);
	tree = inject(TREE_INSTANCE);
	timeout;
	isPrevDropPointHovered = signal(false, ...ngDevMode ? [{ debugName: "isPrevDropPointHovered" }] : /* istanbul ignore next */ []);
	isNextDropPointHovered = signal(false, ...ngDevMode ? [{ debugName: "isNextDropPointHovered" }] : /* istanbul ignore next */ []);
	isNodeDropHovered = signal(false, ...ngDevMode ? [{ debugName: "isNodeDropHovered" }] : /* istanbul ignore next */ []);
	isPrevDropPointActive = computed(() => this.isPrevDropPointHovered() && this.isDroppable(), ...ngDevMode ? [{ debugName: "isPrevDropPointActive" }] : /* istanbul ignore next */ []);
	isNextDropPointActive = computed(() => this.isNextDropPointHovered() && this.isDroppable(), ...ngDevMode ? [{ debugName: "isNextDropPointActive" }] : /* istanbul ignore next */ []);
	isNodeDropActive = computed(() => this.isNodeDropHovered() && this.isNodeDroppable(), ...ngDevMode ? [{ debugName: "isNodeDropActive" }] : /* istanbul ignore next */ []);
	dropPosition = computed(() => this.isPrevDropPointActive() ? -1 : this.isNextDropPointActive() ? 1 : 0, ...ngDevMode ? [{ debugName: "dropPosition" }] : /* istanbul ignore next */ []);
	get ariaSetSize() {
		return this.node()?.children?.length ?? 0;
	}
	get ariaExpanded() {
		return this.node()?.expanded;
	}
	ariaPosInSet = computed(() => (this.index() ?? 0) + 1, ...ngDevMode ? [{ debugName: "ariaPosInSet" }] : /* istanbul ignore next */ []);
	ariaLevel = computed(() => (this.level() ?? 0) + 1, ...ngDevMode ? [{ debugName: "ariaLevel" }] : /* istanbul ignore next */ []);
	nodeTabindex = computed(() => this.index() === 0 ? 0 : -1, ...ngDevMode ? [{ debugName: "nodeTabindex" }] : /* istanbul ignore next */ []);
	nodeContentPaddingLeft = computed(() => this.level() * this.indentation() + "rem", ...ngDevMode ? [{ debugName: "nodeContentPaddingLeft" }] : /* istanbul ignore next */ []);
	get hasNodeIcon() {
		return !!(this.node()?.icon || this.node()?.expandedIcon || this.node()?.collapsedIcon);
	}
	get showChildren() {
		return !this.tree.virtualScroll() && !!this.node()?.children && !!this.node()?.expanded;
	}
	get showLoadingSpinner() {
		return this.loadingMode() === "icon" && !!this.node()?.loading;
	}
	checkboxVariant = computed(() => this.tree?.config.inputVariant() || "outlined", ...ngDevMode ? [{ debugName: "checkboxVariant" }] : /* istanbul ignore next */ []);
	get togglerIconContext() {
		return {
			$implicit: this.node()?.expanded,
			loading: this.node()?.loading
		};
	}
	get checkboxIconContext() {
		return {
			$implicit: this.isSelected(),
			partialSelected: this.node()?.partialSelected,
			class: this.cx("nodeCheckbox")
		};
	}
	_componentStyle = inject(TreeStyle);
	_selected = computed(() => {
		this.tree.selection();
		return this.tree.isSelected(this.node());
	}, ...ngDevMode ? [{ debugName: "_selected" }] : /* istanbul ignore next */ []);
	_contextMenuSelected = computed(() => {
		const selection = this.tree.contextMenuSelection();
		const node = this.node();
		if (!selection || !node) return false;
		return selection === node || selection.key && selection.key === node.key;
	}, ...ngDevMode ? [{ debugName: "_contextMenuSelected" }] : /* istanbul ignore next */ []);
	get selected() {
		return this.tree.selectionMode() === "single" || this.tree.selectionMode() === "multiple" ? this._selected() : void 0;
	}
	get checked() {
		return this.tree.selectionMode() === "checkbox" ? this._selected() : void 0;
	}
	get nodeClass() {
		return this.pcn(this.tree._componentStyle.classes.node({ instance: this }));
	}
	get selectable() {
		return this.node()?.selectable === false ? false : this.tree?.selectionMode() != null;
	}
	get subNodes() {
		return this.node()?.parent ? this.node().parent.children : this.tree.value();
	}
	get originalNode() {
		const node = this.node();
		return node && this.tree.getOriginalNode(node);
	}
	get originalSubNodes() {
		const parent = this.node()?.parent;
		return parent ? this.tree.getOriginalNode(parent).children : this.tree.value();
	}
	getPTOptions(key) {
		return this.ptm(key, { context: {
			node: this.node(),
			index: this.index(),
			expanded: this.node()?.expanded,
			selected: this.selected,
			checked: this.checked,
			partialChecked: this.node()?.partialSelected,
			leaf: this.isLeaf()
		} });
	}
	onInit() {
		this.node().parent = this.parentNode();
		const pDialogWrapper = this.tree.el.nativeElement.closest("p-dialog");
		if (this.parentNode() && !pDialogWrapper) {
			this.setAllNodesTabIndexes();
			this.tree.syncNodeOption(this.node(), this.tree.value(), "parent", this.tree.getNodeWithKey(this.parentNode().key, this.tree.value()));
		}
	}
	getIcon() {
		let icon;
		const node = this.node();
		if (node.icon) icon = node.icon;
		else icon = node.expanded && node.children && node.children?.length ? node.expandedIcon : node.collapsedIcon;
		return this.pcn(UITreeNode.ICON_CLASS) + " " + icon + " " + this.pcn("p-tree-node-icon");
	}
	isLeaf() {
		return this.tree.isNodeLeaf(this.node());
	}
	isSelected() {
		return this._selected();
	}
	isContextMenuSelected() {
		return this._contextMenuSelected();
	}
	isSameNode(event) {
		return event.currentTarget && (event.currentTarget.isSameNode(event.target) || event.currentTarget.isSameNode(event.target.closest("[role=\"treeitem\"]")));
	}
	isDraggable() {
		return this.tree.draggableNodes();
	}
	isDroppable() {
		return this.tree.droppableNodes() && this.tree.allowDrop(this.tree.dragNode, this.node(), this.tree.dragNodeScope);
	}
	isNodeDroppable() {
		return this.node()?.droppable !== false && this.isDroppable();
	}
	isNodeDraggable() {
		return this.node()?.draggable !== false && this.isDraggable();
	}
	toggle(event) {
		if (this.node().expanded) this.collapse(event);
		else this.expand(event);
		event.stopPropagation();
	}
	expand(event) {
		this.node().expanded = true;
		this.tree.setNodeCollapsed(this.node(), false);
		if (this.tree.virtualScroll()) {
			this.tree.updateSerializedValue();
			this.focusVirtualNode();
		}
		this.tree.onNodeExpand.emit({
			originalEvent: event,
			node: this.node()
		});
	}
	collapse(event) {
		this.node().expanded = false;
		this.tree.setNodeCollapsed(this.node(), true);
		if (this.tree.virtualScroll()) this.tree.updateSerializedValue();
		this.tree.onNodeCollapse.emit({
			originalEvent: event,
			node: this.node()
		});
		this.focusVirtualNode();
	}
	onNodeClick(event) {
		this.tree.onNodeClick(event, this.node());
	}
	onNodeKeydown(event) {
		if (event.key === "Enter") this.tree.onNodeClick(event, this.node());
	}
	onNodeTouchEnd() {
		this.tree.onNodeTouchEnd();
	}
	onNodeRightClick(event) {
		this.tree.onNodeRightClick(event, this.node());
	}
	onNodeDblClick(event) {
		this.tree.onNodeDblClick(event, this.node());
	}
	insertNodeOnDrop(dragNode, dragNodeSubNodes, position) {
		const dropNode = this.originalNode;
		if (!dropNode || !dragNode || !dragNodeSubNodes) return;
		const subNodes = this.originalSubNodes || [];
		const dragNodeIndex = dragNodeSubNodes.indexOf(dragNode);
		const index = subNodes.indexOf(dropNode);
		const dropIndex = dragNodeSubNodes === subNodes ? dragNodeIndex > index ? index : index - 1 : index;
		if (dragNodeIndex !== -1) dragNodeSubNodes.splice(dragNodeIndex, 1);
		if (position < 0) subNodes.splice(dropIndex, 0, dragNode);
		else if (position > 0) subNodes.splice(dropIndex + 1, 0, dragNode);
		else {
			dropNode.children = dropNode.children || [];
			dropNode.children.push(dragNode);
		}
		this.tree.dragDropService.stopDrag({
			node: dragNode,
			subNodes,
			index: dragNodeIndex
		});
	}
	onNodeDrop(event) {
		event.preventDefault();
		event.stopPropagation();
		if (this.isDroppable()) {
			const { dragNode, dragNodeSubNodes } = this.tree;
			const position = this.dropPosition();
			const isValidDrop = position !== 0 || position === 0 && this.isNodeDroppable();
			const dropPoint = position === 0 ? "node" : "between";
			if (isValidDrop) {
				if (this.tree.validateDrop()) this.tree.onNodeDrop.emit({
					originalEvent: event,
					dragNode,
					dropNode: this.originalNode,
					index: this.index(),
					dropPoint,
					accept: () => {
						this.insertNodeOnDrop(dragNode, dragNodeSubNodes, position);
					}
				});
				else {
					this.insertNodeOnDrop(dragNode, dragNodeSubNodes, position);
					this.tree.onNodeDrop.emit({
						originalEvent: event,
						dragNode,
						dropNode: this.originalNode,
						index: this.index(),
						dropPoint
					});
				}
			}
		}
		this.isPrevDropPointHovered.set(false);
		this.isNextDropPointHovered.set(false);
		this.isNodeDropHovered.set(false);
	}
	onNodeDragStart(event) {
		if (this.isNodeDraggable()) {
			event.dataTransfer.effectAllowed = "all";
			event.dataTransfer?.setData("text", "data");
			const target = event.currentTarget;
			const dragEl = target.cloneNode(true);
			const toggler = dragEl.querySelector("[data-pc-section=\"nodetogglebutton\"]");
			const checkbox = dragEl.querySelector("[data-pc-name=\"pcnodecheckbox\"]");
			target.setAttribute("data-p-dragging", "true");
			dragEl.style.width = L(target) + "px";
			dragEl.style.height = R(target) + "px";
			dragEl.setAttribute("data-pc-section", "drag-image");
			toggler.style.visibility = "hidden";
			checkbox?.remove();
			this.$overlayParent(this.document.body, dragEl).appendChild(dragEl);
			event.dataTransfer?.setDragImage(dragEl, 0, 0);
			setTimeout(() => dragEl.remove(), 0);
			this.tree.dragDropService.startDrag({
				tree: this,
				node: this.originalNode,
				subNodes: this.originalSubNodes,
				index: this.index(),
				scope: this.tree.draggableScope()
			});
		} else event.preventDefault();
	}
	onNodeDragOver(event) {
		if (this.isDroppable()) {
			event.dataTransfer.dropEffect = "copy";
			const rect = event.currentTarget.getBoundingClientRect();
			const y = event.clientY - parseInt(rect.top);
			this.isPrevDropPointHovered.set(false);
			this.isNextDropPointHovered.set(false);
			this.isNodeDropHovered.set(false);
			if (y < rect.height * .25) this.isPrevDropPointHovered.set(true);
			else if (y > rect.height * .75) this.isNextDropPointHovered.set(true);
			else if (this.isNodeDroppable()) this.isNodeDropHovered.set(true);
		} else event.dataTransfer.dropEffect = "none";
		if (this.tree.droppableNodes()) {
			event.preventDefault();
			event.stopPropagation();
		}
	}
	onNodeDragLeave() {
		this.isPrevDropPointHovered.set(false);
		this.isNextDropPointHovered.set(false);
		this.isNodeDropHovered.set(false);
	}
	onNodeDragEnd(event) {
		event.currentTarget?.removeAttribute("data-p-dragging");
		this.tree.dragDropService.stopDrag({
			node: this.originalNode,
			subNodes: this.originalSubNodes,
			index: this.index()
		});
	}
	onKeyDown(event) {
		if (!this.isSameNode(event) || this.tree.contextMenu() && this.tree.contextMenu().containerViewChild?.nativeElement.style.display === "block") return;
		switch (event.code) {
			case "ArrowDown":
				this.onArrowDown(event);
				break;
			case "ArrowUp":
				this.onArrowUp(event);
				break;
			case "ArrowRight":
				this.onArrowRight(event);
				break;
			case "ArrowLeft":
				this.onArrowLeft(event);
				break;
			case "Enter":
			case "Space":
			case "NumpadEnter":
				this.onEnter(event);
				break;
			case "Tab": this.setAllNodesTabIndexes();
		}
	}
	onArrowUp(event) {
		const nodeElement = event.target.getAttribute("data-pc-section") === "nodetogglebutton" ? event.target.closest("[role=\"treeitem\"]") : event.target.parentElement;
		if (nodeElement?.previousElementSibling) this.focusRowChange(nodeElement, nodeElement.previousElementSibling, this.findLastVisibleDescendant(nodeElement.previousElementSibling));
		else {
			let parentNodeElement = this.getParentNodeElement(nodeElement);
			if (parentNodeElement) this.focusRowChange(nodeElement, parentNodeElement);
		}
		event.preventDefault();
	}
	onArrowDown(event) {
		const nodeElement = event.target.getAttribute("data-pc-section") === "nodetogglebutton" ? event.target.closest("[role=\"treeitem\"]") : event.target;
		const listElement = nodeElement?.children[1];
		if (listElement && listElement.children.length > 0) this.focusRowChange(nodeElement, listElement.children[0]);
		else if (nodeElement?.parentElement?.nextElementSibling) this.focusRowChange(nodeElement, nodeElement.parentElement.nextElementSibling);
		else {
			let nextSiblingAncestor = this.findNextSiblingOfAncestor(nodeElement?.parentElement);
			if (nextSiblingAncestor) this.focusRowChange(nodeElement, nextSiblingAncestor);
		}
		event.preventDefault();
	}
	onArrowRight(event) {
		if (!this.node()?.expanded && !this.tree.isNodeLeaf(this.node())) {
			this.expand(event);
			event.currentTarget.tabIndex = -1;
			setTimeout(() => {
				this.onArrowDown(event);
			}, 1);
		}
		event.preventDefault();
	}
	onArrowLeft(event) {
		const nodeElement = event.target.getAttribute("data-pc-section") === "nodetogglebutton" ? event.target.closest("[role=\"treeitem\"]") : event.target;
		if (this.level() === 0 && !this.node()?.expanded) return false;
		if (this.node()?.expanded) {
			this.collapse(event);
			return;
		}
		let parentNodeElement = this.getParentNodeElement(nodeElement?.parentElement);
		if (parentNodeElement) this.focusRowChange(event.currentTarget, parentNodeElement);
		event.preventDefault();
	}
	onEnter(event) {
		this.tree.onNodeClick(event, this.node());
		this.setTabIndexForSelectionMode(event, this.tree.nodeTouched);
		event.preventDefault();
	}
	setAllNodesTabIndexes() {
		const nodes = ot(this.tree.el.nativeElement, "[data-pc-section=\"node\"]");
		const hasSelectedNode = [...nodes].some((node) => node.getAttribute("aria-selected") === "true" || node.getAttribute("aria-checked") === "true");
		[...nodes].forEach((node) => {
			node.tabIndex = -1;
		});
		if (hasSelectedNode) {
			const selectedNodes = [...nodes].filter((node) => node.getAttribute("aria-selected") === "true" || node.getAttribute("aria-checked") === "true");
			selectedNodes[0].tabIndex = 0;
			return;
		}
		if (nodes.length) [...nodes][0].tabIndex = 0;
	}
	setTabIndexForSelectionMode(event, nodeTouched) {
		if (this.tree.selectionMode() !== null) {
			const elements = [...ot(this.tree.el.nativeElement, "[role=\"treeitem\"]")];
			event.currentTarget.tabIndex = nodeTouched === false ? -1 : 0;
			if (elements.every((element) => element.tabIndex === -1)) elements[0].tabIndex = 0;
		}
	}
	findNextSiblingOfAncestor(nodeElement) {
		let parentNodeElement = this.getParentNodeElement(nodeElement);
		if (parentNodeElement) {
			if (parentNodeElement.nextElementSibling) return parentNodeElement.nextElementSibling;
			else return this.findNextSiblingOfAncestor(parentNodeElement);
		} else return null;
	}
	findLastVisibleDescendant(nodeElement) {
		const childrenListElement = Array.from(nodeElement.children).find((el) => el.getAttribute("data-pc-section") === "node")?.children[1];
		if (childrenListElement && childrenListElement.children.length > 0) {
			const lastChildElement = childrenListElement.children[childrenListElement.children.length - 1];
			return this.findLastVisibleDescendant(lastChildElement);
		} else return nodeElement;
	}
	getParentNodeElement(nodeElement) {
		const parentNodeElement = nodeElement?.parentElement?.parentElement?.parentElement;
		return parentNodeElement?.tagName === "P-TREENODE" ? parentNodeElement : null;
	}
	focusNode(element) {
		element.children[0].focus();
	}
	focusRowChange(firstFocusableRow, currentFocusedRow, lastVisibleDescendant) {
		firstFocusableRow.tabIndex = "-1";
		currentFocusedRow.children[0].tabIndex = "0";
		this.focusNode(lastVisibleDescendant || currentFocusedRow);
	}
	focusVirtualNode() {
		this.timeout = setTimeout(() => {
			let node = nt(this.tree?.contentViewChild()?.nativeElement, `[data-id="${this.node()?.key ?? this.node()?.data}"]`);
			Wt(node);
		}, 1);
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵUITreeNode_BaseFactory = void 0;
		return function UITreeNode_Factory(__ngFactoryType__) {
			return (ɵUITreeNode_BaseFactory || (ɵUITreeNode_BaseFactory = ɵɵgetInheritedFactory(UITreeNode)))(__ngFactoryType__ || UITreeNode);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = (a0) => ({ $implicit: a0 });
		const _c1 = () => ({ next: true });
		function _forTrack0($index, $item) {
			return this.tree.trackBy()($index, $item);
		}
		function UITreeNode_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "div", 7);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("dropPoint"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("dropPoint"));
				ɵɵattribute("aria-hidden", true);
			}
		}
		function UITreeNode_Conditional_0_Conditional_4_Conditional_0_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 12);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(4);
				ɵɵclassMap(ctx_r1.cx("nodeToggleIcon"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("nodeToggleIcon"));
			}
		}
		function UITreeNode_Conditional_0_Conditional_4_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 13);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(4);
				ɵɵclassMap(ctx_r1.cx("nodeToggleIcon"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("nodeToggleIcon"));
			}
		}
		function UITreeNode_Conditional_0_Conditional_4_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, UITreeNode_Conditional_0_Conditional_4_Conditional_0_Conditional_0_Template, 1, 3, "svg", 10);
				ɵɵconditionalCreate(1, UITreeNode_Conditional_0_Conditional_4_Conditional_0_Conditional_1_Template, 1, 3, "svg", 11);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵconditional(!ctx_r1.node().expanded ? 0 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.node().expanded ? 1 : -1);
			}
		}
		function UITreeNode_Conditional_0_Conditional_4_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 14);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("nodeToggleIcon"));
				ɵɵproperty("spin", true)("pBind", ctx_r1.getPTOptions("nodeToggleIcon"));
			}
		}
		function UITreeNode_Conditional_0_Conditional_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, UITreeNode_Conditional_0_Conditional_4_Conditional_0_Template, 2, 2);
				ɵɵconditionalCreate(1, UITreeNode_Conditional_0_Conditional_4_Conditional_1_Template, 1, 4, "svg", 9);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵconditional(!ctx_r1.node().loading ? 0 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.showLoadingSpinner ? 1 : -1);
			}
		}
		function UITreeNode_Conditional_0_Conditional_5_1_ng_template_0_Template(rf, ctx) {}
		function UITreeNode_Conditional_0_Conditional_5_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, UITreeNode_Conditional_0_Conditional_5_1_ng_template_0_Template, 0, 0, "ng-template");
		}
		function UITreeNode_Conditional_0_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 7);
				ɵɵtemplate(1, UITreeNode_Conditional_0_Conditional_5_1_Template, 1, 0, null, 15);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("nodeToggleIcon"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("nodeToggleIcon"));
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.tree.togglerIconTemplate())("ngTemplateOutletContext", ctx_r1.togglerIconContext);
			}
		}
		function UITreeNode_Conditional_0_Conditional_6_Conditional_1_ng_template_0_0_ng_template_0_Template(rf, ctx) {}
		function UITreeNode_Conditional_0_Conditional_6_Conditional_1_ng_template_0_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, UITreeNode_Conditional_0_Conditional_6_Conditional_1_ng_template_0_0_ng_template_0_Template, 0, 0, "ng-template");
		}
		function UITreeNode_Conditional_0_Conditional_6_Conditional_1_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, UITreeNode_Conditional_0_Conditional_6_Conditional_1_ng_template_0_0_Template, 1, 0, null, 15);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(4);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.tree.checkboxIconTemplate())("ngTemplateOutletContext", ctx_r1.checkboxIconContext);
			}
		}
		function UITreeNode_Conditional_0_Conditional_6_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, UITreeNode_Conditional_0_Conditional_6_Conditional_1_ng_template_0_Template, 1, 2, "ng-template", null, 0, ɵɵtemplateRefExtractor);
		}
		function UITreeNode_Conditional_0_Conditional_6_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "p-checkbox", 16);
				ɵɵcontrolCreate();
				ɵɵlistener("click", function UITreeNode_Conditional_0_Conditional_6_Template_p_checkbox_click_0_listener($event) {
					return $event.preventDefault();
				});
				ɵɵconditionalCreate(1, UITreeNode_Conditional_0_Conditional_6_Conditional_1_Template, 2, 0);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("nodeCheckbox"));
				ɵɵproperty("ngModel", ctx_r1.isSelected())("binary", true)("indeterminate", ctx_r1.node().partialSelected)("disabled", ctx_r1.node().selectable === false)("variant", ctx_r1.checkboxVariant())("tabindex", -1)("pt", ctx_r1.getPTOptions("pcNodeCheckbox"))("unstyled", ctx_r1.unstyled());
				ɵɵattribute("data-p-partialchecked", ctx_r1.node().partialSelected);
				ɵɵcontrol();
				ɵɵadvance();
				ɵɵconditional(ctx_r1.tree.checkboxIconTemplate() ? 1 : -1);
			}
		}
		function UITreeNode_Conditional_0_Conditional_7_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 7);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.getIcon());
				ɵɵproperty("pBind", ctx_r1.getPTOptions("nodeIcon"));
			}
		}
		function UITreeNode_Conditional_0_Conditional_9_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span");
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1.node().label);
			}
		}
		function UITreeNode_Conditional_0_Conditional_10_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function UITreeNode_Conditional_0_Conditional_10_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span");
				ɵɵtemplate(1, UITreeNode_Conditional_0_Conditional_10_ng_container_1_Template, 1, 0, "ng-container", 15);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.tree.getTemplateForNode(ctx_r1.node()))("ngTemplateOutletContext", ɵɵpureFunction1(2, _c0, ctx_r1.node()));
			}
		}
		function UITreeNode_Conditional_0_Conditional_11_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "div", 7);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("dropPoint", ɵɵpureFunction0(4, _c1)));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("dropPoint"));
				ɵɵattribute("aria-hidden", true);
			}
		}
		function UITreeNode_Conditional_0_Conditional_12_For_2_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-treenode", 18);
			if (rf & 2) {
				const childNode_r3 = ctx.$implicit;
				const ɵ$index_61_r4 = ctx.$index;
				const ɵ$count_61_r5 = ctx.$count;
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵproperty("node", childNode_r3)("parentNode", ctx_r1.node())("firstChild", ɵ$index_61_r4 === 0)("lastChild", ɵ$index_61_r4 === ɵ$count_61_r5 - 1)("index", ɵ$index_61_r4)("itemSize", ctx_r1.itemSize())("level", ctx_r1.level() + 1)("loadingMode", ctx_r1.loadingMode())("pt", ctx_r1.pt())("unstyled", ctx_r1.unstyled());
			}
		}
		function UITreeNode_Conditional_0_Conditional_12_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "ul", 17);
				ɵɵrepeaterCreate(1, UITreeNode_Conditional_0_Conditional_12_For_2_Template, 1, 10, "p-treenode", 18, _forTrack0, true);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("nodeChildren"));
				ɵɵproperty("pBind", ctx_r1.ptm("nodeChildren"));
				ɵɵadvance();
				ɵɵrepeater(ctx_r1.node().children);
			}
		}
		function UITreeNode_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "li", 2);
				ɵɵlistener("keydown", function UITreeNode_Conditional_0_Template_li_keydown_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onKeyDown($event));
				});
				ɵɵconditionalCreate(1, UITreeNode_Conditional_0_Conditional_1_Template, 1, 4, "div", 3);
				ɵɵelementStart(2, "div", 4);
				ɵɵlistener("click", function UITreeNode_Conditional_0_Template_div_click_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeClick($event));
				})("contextmenu", function UITreeNode_Conditional_0_Template_div_contextmenu_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeRightClick($event));
				})("dblclick", function UITreeNode_Conditional_0_Template_div_dblclick_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeDblClick($event));
				})("touchend", function UITreeNode_Conditional_0_Template_div_touchend_2_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeTouchEnd());
				})("drop", function UITreeNode_Conditional_0_Template_div_drop_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeDrop($event));
				})("dragstart", function UITreeNode_Conditional_0_Template_div_dragstart_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeDragStart($event));
				})("dragover", function UITreeNode_Conditional_0_Template_div_dragover_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeDragOver($event));
				})("dragleave", function UITreeNode_Conditional_0_Template_div_dragleave_2_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeDragLeave());
				})("dragend", function UITreeNode_Conditional_0_Template_div_dragend_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onNodeDragEnd($event));
				});
				ɵɵelementStart(3, "button", 5);
				ɵɵlistener("click", function UITreeNode_Conditional_0_Template_button_click_3_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.toggle($event));
				});
				ɵɵconditionalCreate(4, UITreeNode_Conditional_0_Conditional_4_Template, 2, 2);
				ɵɵconditionalCreate(5, UITreeNode_Conditional_0_Conditional_5_Template, 2, 5, "span", 3);
				ɵɵelementEnd();
				ɵɵconditionalCreate(6, UITreeNode_Conditional_0_Conditional_6_Template, 2, 12, "p-checkbox", 6);
				ɵɵconditionalCreate(7, UITreeNode_Conditional_0_Conditional_7_Template, 1, 3, "span", 3);
				ɵɵelementStart(8, "span", 7);
				ɵɵconditionalCreate(9, UITreeNode_Conditional_0_Conditional_9_Template, 2, 1, "span");
				ɵɵconditionalCreate(10, UITreeNode_Conditional_0_Conditional_10_Template, 2, 4, "span");
				ɵɵelementEnd()();
				ɵɵconditionalCreate(11, UITreeNode_Conditional_0_Conditional_11_Template, 1, 5, "div", 3);
				ɵɵconditionalCreate(12, UITreeNode_Conditional_0_Conditional_12_Template, 3, 3, "ul", 8);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵstyleMap(ctx_r1.node().style);
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("node"), ctx_r1.node().styleClass));
				ɵɵstyleProp("height", ctx_r1.itemSize(), "px");
				ɵɵproperty("pBind", ctx_r1.getPTOptions("node"));
				ɵɵattribute("aria-label", ctx_r1.node().label)("aria-checked", ctx_r1.checked)("aria-setsize", ctx_r1.ariaSetSize)("aria-selected", ctx_r1.selected)("aria-expanded", ctx_r1.ariaExpanded)("aria-posinset", ctx_r1.ariaPosInSet())("aria-level", ctx_r1.ariaLevel())("tabindex", ctx_r1.nodeTabindex())("data-id", ctx_r1.node().key);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.isPrevDropPointActive() ? 1 : -1);
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("nodeContent"));
				ɵɵstyleProp("padding-left", ctx_r1.nodeContentPaddingLeft());
				ɵɵproperty("draggable", ctx_r1.tree.draggableNodes())("pBind", ctx_r1.getPTOptions("nodeContent"));
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("nodeToggleButton"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("nodeToggleButton"));
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.tree.togglerIconTemplate() ? 4 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.tree.togglerIconTemplate() ? 5 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.tree.selectionMode() === "checkbox" ? 6 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.hasNodeIcon ? 7 : -1);
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("nodeLabel"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions("nodeLabel"));
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.tree.getTemplateForNode(ctx_r1.node()) ? 9 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.tree.getTemplateForNode(ctx_r1.node()) ? 10 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.isNextDropPointActive() ? 11 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.showChildren ? 12 : -1);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: UITreeNode,
			selectors: [["p-treenode"]],
			inputs: {
				rowNode: [1, "rowNode"],
				node: [1, "node"],
				parentNode: [1, "parentNode"],
				root: [1, "root"],
				index: [1, "index"],
				firstChild: [1, "firstChild"],
				lastChild: [1, "lastChild"],
				level: [1, "level"],
				indentation: [1, "indentation"],
				itemSize: [1, "itemSize"],
				loadingMode: [1, "loadingMode"]
			},
			features: [ɵɵProvidersFeature([
				TreeStyle,
				{
					provide: TREENODE_INSTANCE,
					useExisting: UITreeNode
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: UITreeNode
				}
			]), ɵɵInheritDefinitionFeature],
			decls: 1,
			vars: 1,
			consts: [
				["icon", ""],
				[
					"role",
					"treeitem",
					3,
					"class",
					"height",
					"style",
					"pBind"
				],
				[
					"role",
					"treeitem",
					3,
					"keydown",
					"pBind"
				],
				[
					3,
					"class",
					"pBind"
				],
				[
					3,
					"click",
					"contextmenu",
					"dblclick",
					"touchend",
					"drop",
					"dragstart",
					"dragover",
					"dragleave",
					"dragend",
					"draggable",
					"pBind"
				],
				[
					"type",
					"button",
					"pRipple",
					"",
					"tabindex",
					"-1",
					3,
					"click",
					"pBind"
				],
				[
					3,
					"ngModel",
					"class",
					"binary",
					"indeterminate",
					"disabled",
					"variant",
					"tabindex",
					"pt",
					"unstyled"
				],
				[3, "pBind"],
				[
					"role",
					"group",
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"spinner",
					3,
					"class",
					"spin",
					"pBind"
				],
				[
					"data-p-icon",
					"chevron-right",
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"chevron-down",
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"chevron-right",
					3,
					"pBind"
				],
				[
					"data-p-icon",
					"chevron-down",
					3,
					"pBind"
				],
				[
					"data-p-icon",
					"spinner",
					3,
					"spin",
					"pBind"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				],
				[
					3,
					"click",
					"ngModel",
					"binary",
					"indeterminate",
					"disabled",
					"variant",
					"tabindex",
					"pt",
					"unstyled"
				],
				[
					"role",
					"group",
					3,
					"pBind"
				],
				[
					3,
					"node",
					"parentNode",
					"firstChild",
					"lastChild",
					"index",
					"itemSize",
					"level",
					"loadingMode",
					"pt",
					"unstyled"
				]
			],
			template: function UITreeNode_Template(rf, ctx) {
				if (rf & 1) ɵɵconditionalCreate(0, UITreeNode_Conditional_0_Template, 13, 37, "li", 1);
				if (rf & 2) ɵɵconditional(ctx.node() ? 0 : -1);
			},
			dependencies: [
				UITreeNode,
				NgTemplateOutlet,
				Ripple,
				Checkbox,
				FormsModule,
				NgControlStatus,
				NgModel,
				ChevronRight,
				ChevronDown,
				Spinner,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UITreeNode, [{
		type: Component,
		args: [{
			selector: "p-treenode",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				Ripple,
				Checkbox,
				FormsModule,
				ChevronRight,
				ChevronDown,
				Spinner,
				Bind
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
        @if (node()) {
            <li
                [class]="cn(cx('node'), node()!.styleClass)"
                [style.height.px]="itemSize()"
                [style]="node()!.style"
                [attr.aria-label]="node()!.label"
                [attr.aria-checked]="checked"
                [attr.aria-setsize]="ariaSetSize"
                [attr.aria-selected]="selected"
                [attr.aria-expanded]="ariaExpanded"
                [attr.aria-posinset]="ariaPosInSet()"
                [attr.aria-level]="ariaLevel()"
                [attr.tabindex]="nodeTabindex()"
                [attr.data-id]="node()!.key"
                role="treeitem"
                (keydown)="onKeyDown($event)"
                [pBind]="getPTOptions('node')"
            >
                @if (isPrevDropPointActive()) {
                    <div [class]="cx('dropPoint')" [attr.aria-hidden]="true" [pBind]="getPTOptions('dropPoint')"></div>
                }
                <div
                    [class]="cx('nodeContent')"
                    [style.paddingLeft]="nodeContentPaddingLeft()"
                    (click)="onNodeClick($event)"
                    (contextmenu)="onNodeRightClick($event)"
                    (dblclick)="onNodeDblClick($event)"
                    (touchend)="onNodeTouchEnd()"
                    (drop)="onNodeDrop($event)"
                    (dragstart)="onNodeDragStart($event)"
                    (dragover)="onNodeDragOver($event)"
                    (dragleave)="onNodeDragLeave()"
                    (dragend)="onNodeDragEnd($event)"
                    [draggable]="tree.draggableNodes()"
                    [pBind]="getPTOptions('nodeContent')"
                >
                    <button type="button" [class]="cx('nodeToggleButton')" (click)="toggle($event)" pRipple tabindex="-1" [pBind]="getPTOptions('nodeToggleButton')">
                        @if (!tree.togglerIconTemplate()) {
                            @if (!node()!.loading) {
                                @if (!node()!.expanded) {
                                    <svg data-p-icon="chevron-right" [class]="cx('nodeToggleIcon')" [pBind]="getPTOptions('nodeToggleIcon')" />
                                }
                                @if (node()!.expanded) {
                                    <svg data-p-icon="chevron-down" [class]="cx('nodeToggleIcon')" [pBind]="getPTOptions('nodeToggleIcon')" />
                                }
                            }
                            @if (showLoadingSpinner) {
                                <svg data-p-icon="spinner" [class]="cx('nodeToggleIcon')" [spin]="true" [pBind]="getPTOptions('nodeToggleIcon')" />
                            }
                        }
                        @if (tree.togglerIconTemplate()) {
                            <span [class]="cx('nodeToggleIcon')" [pBind]="getPTOptions('nodeToggleIcon')">
                                <ng-template *ngTemplateOutlet="tree.togglerIconTemplate()!; context: togglerIconContext"></ng-template>
                            </span>
                        }
                    </button>

                    @if (tree.selectionMode() === 'checkbox') {
                        <p-checkbox
                            [ngModel]="isSelected()"
                            [class]="cx('nodeCheckbox')"
                            [binary]="true"
                            [indeterminate]="node()!.partialSelected"
                            [disabled]="node()!.selectable === false"
                            [variant]="checkboxVariant()"
                            [attr.data-p-partialchecked]="node()!.partialSelected"
                            [tabindex]="-1"
                            (click)="$event.preventDefault()"
                            [pt]="getPTOptions('pcNodeCheckbox')"
                            [unstyled]="unstyled()"
                        >
                            @if (tree.checkboxIconTemplate()) {
                                <ng-template #icon>
                                    <ng-template *ngTemplateOutlet="tree.checkboxIconTemplate()!; context: checkboxIconContext"></ng-template>
                                </ng-template>
                            }
                        </p-checkbox>
                    }

                    @if (hasNodeIcon) {
                        <span [class]="getIcon()" [pBind]="getPTOptions('nodeIcon')"></span>
                    }
                    <span [class]="cx('nodeLabel')" [pBind]="getPTOptions('nodeLabel')">
                        @if (!tree.getTemplateForNode(node()!)) {
                            <span>{{ node()!.label }}</span>
                        }
                        @if (tree.getTemplateForNode(node()!)) {
                            <span>
                                <ng-container *ngTemplateOutlet="tree.getTemplateForNode(node()!)!; context: { $implicit: node() }"></ng-container>
                            </span>
                        }
                    </span>
                </div>
                @if (isNextDropPointActive()) {
                    <div [class]="cx('dropPoint', { next: true })" [attr.aria-hidden]="true" [pBind]="getPTOptions('dropPoint')"></div>
                }
                @if (showChildren) {
                    <ul [class]="cx('nodeChildren')" role="group" [pBind]="ptm('nodeChildren')">
                        @for (childNode of node()!.children; track tree.trackBy()($index, childNode); let firstChild = $first; let lastChild = $last; let idx = $index) {
                            <p-treenode
                                [node]="childNode"
                                [parentNode]="node()"
                                [firstChild]="firstChild"
                                [lastChild]="lastChild"
                                [index]="idx"
                                [itemSize]="itemSize()"
                                [level]="level()! + 1"
                                [loadingMode]="loadingMode()"
                                [pt]="pt()"
                                [unstyled]="unstyled()"
                            />
                        }
                    </ul>
                }
            </li>
        }
    `,
			encapsulation: ViewEncapsulation.None,
			providers: [
				TreeStyle,
				{
					provide: TREENODE_INSTANCE,
					useExisting: UITreeNode
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: UITreeNode
				}
			]
		}]
	}], null, {
		rowNode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "rowNode",
				required: false
			}]
		}],
		node: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "node",
				required: false
			}]
		}],
		parentNode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "parentNode",
				required: false
			}]
		}],
		root: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "root",
				required: false
			}]
		}],
		index: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "index",
				required: false
			}]
		}],
		firstChild: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "firstChild",
				required: false
			}]
		}],
		lastChild: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "lastChild",
				required: false
			}]
		}],
		level: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		indentation: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "indentation",
				required: false
			}]
		}],
		itemSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "itemSize",
				required: false
			}]
		}],
		loadingMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loadingMode",
				required: false
			}]
		}]
	});
})();
var Tree = class Tree extends BaseComponent {
	componentName = "Tree";
	_destroyed = false;
	bindDirectiveInstance = inject(Bind, { self: true });
	$pcTree = inject(TREE_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	selectionMode = input(...ngDevMode ? [void 0, { debugName: "selectionMode" }] : /* istanbul ignore next */ []);
	loadingMode = input("mask", ...ngDevMode ? [{ debugName: "loadingMode" }] : /* istanbul ignore next */ []);
	selection = model(null, ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	collapsedKeys = model(null, ...ngDevMode ? [{ debugName: "collapsedKeys" }] : /* istanbul ignore next */ []);
	selectionKeys = model(null, ...ngDevMode ? [{ debugName: "selectionKeys" }] : /* istanbul ignore next */ []);
	contextMenu = input(...ngDevMode ? [void 0, { debugName: "contextMenu" }] : /* istanbul ignore next */ []);
	contextMenuSelection = model(null, ...ngDevMode ? [{ debugName: "contextMenuSelection" }] : /* istanbul ignore next */ []);
	draggableScope = input(...ngDevMode ? [void 0, { debugName: "draggableScope" }] : /* istanbul ignore next */ []);
	droppableScope = input(...ngDevMode ? [void 0, { debugName: "droppableScope" }] : /* istanbul ignore next */ []);
	draggableNodes = input(false, {
		...ngDevMode ? { debugName: "draggableNodes" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	droppableNodes = input(false, {
		...ngDevMode ? { debugName: "droppableNodes" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	metaKeySelection = input(false, {
		...ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	propagateSelectionUp = input(true, {
		...ngDevMode ? { debugName: "propagateSelectionUp" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	propagateSelectionDown = input(true, {
		...ngDevMode ? { debugName: "propagateSelectionDown" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loading = input(false, {
		...ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	loadingIcon = input(...ngDevMode ? [void 0, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []);
	emptyMessage = input("", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	togglerAriaLabel = input(...ngDevMode ? [void 0, { debugName: "togglerAriaLabel" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	validateDrop = input(false, {
		...ngDevMode ? { debugName: "validateDrop" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filter = input(false, {
		...ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filterInputAutoFocus = input(false, {
		...ngDevMode ? { debugName: "filterInputAutoFocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filterBy = input("label", ...ngDevMode ? [{ debugName: "filterBy" }] : /* istanbul ignore next */ []);
	filterMode = input("lenient", ...ngDevMode ? [{ debugName: "filterMode" }] : /* istanbul ignore next */ []);
	filterOptions;
	filterPlaceholder = input(...ngDevMode ? [void 0, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []);
	filteredNodes = model(void 0, ...ngDevMode ? [{ debugName: "filteredNodes" }] : /* istanbul ignore next */ []);
	filterLocale = input(...ngDevMode ? [void 0, { debugName: "filterLocale" }] : /* istanbul ignore next */ []);
	scrollHeight = input(...ngDevMode ? [void 0, { debugName: "scrollHeight" }] : /* istanbul ignore next */ []);
	lazy = input(false, {
		...ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	virtualScroll = input(false, {
		...ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	virtualScrollItemSize = input(...ngDevMode ? [void 0, { debugName: "virtualScrollItemSize" }] : /* istanbul ignore next */ []);
	virtualScrollOptions = input(...ngDevMode ? [void 0, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []);
	indentation = input(1.5, {
		...ngDevMode ? { debugName: "indentation" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	trackBy = input((index, item) => item, ...ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []);
	highlightOnSelect = input(false, {
		...ngDevMode ? { debugName: "highlightOnSelect" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	onNodeSelect = output();
	onNodeUnselect = output();
	onNodeExpand = output();
	onNodeCollapse = output();
	onNodeContextMenuSelect = output();
	onNodeDoubleClick = output();
	onNodeDrop = output();
	onLazyLoad = output();
	onScroll = output();
	onScrollIndexChange = output();
	onFilter = output();
	filterTemplate = contentChild("filter", {
		...ngDevMode ? { debugName: "filterTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	nodeTemplate = contentChild("node", {
		...ngDevMode ? { debugName: "nodeTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	headerTemplate = contentChild("header", {
		...ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	footerTemplate = contentChild("footer", {
		...ngDevMode ? { debugName: "footerTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	loaderTemplate = contentChild("loader", {
		...ngDevMode ? { debugName: "loaderTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	emptyTemplate = contentChild("empty", {
		...ngDevMode ? { debugName: "emptyTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	togglerIconTemplate = contentChild("togglericon", {
		...ngDevMode ? { debugName: "togglerIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	checkboxIconTemplate = contentChild("checkboxicon", {
		...ngDevMode ? { debugName: "checkboxIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	loadingIconTemplate = contentChild("loadingicon", {
		...ngDevMode ? { debugName: "loadingIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	filterIconTemplate = contentChild("filtericon", {
		...ngDevMode ? { debugName: "filterIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	filterViewChild = viewChild("filter", ...ngDevMode ? [{ debugName: "filterViewChild" }] : /* istanbul ignore next */ []);
	scroller = viewChild("scroller", ...ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []);
	wrapperViewChild = viewChild("wrapper", ...ngDevMode ? [{ debugName: "wrapperViewChild" }] : /* istanbul ignore next */ []);
	contentViewChild = viewChild("content", ...ngDevMode ? [{ debugName: "contentViewChild" }] : /* istanbul ignore next */ []);
	serializedValue;
	nodeTouched;
	dragNodeTree;
	dragNode;
	dragNodeSubNodes;
	dragNodeIndex;
	dragNodeScope;
	dragHover;
	_componentStyle = inject(TreeStyle);
	dragDropService = inject(TreeDragDropService, { optional: true });
	destroyRef = inject(DestroyRef);
	constructor() {
		super();
		effect(() => {
			this.value();
			untracked(() => {
				this.updateSerializedValue();
				if (this.hasFilterActive()) this._filter(this.filterViewChild()?.nativeElement?.value);
			});
		});
		effect(() => {
			this.collapsedKeys();
			this.value();
			untracked(() => {
				if (this.collapsedKeys() == null) return;
				this.applyCollapsedKeys();
				this.updateSerializedValue();
			});
		});
		effect(() => {
			this.selectionKeys();
			this.value();
			untracked(() => {
				if (this.selectionKeys() == null) return;
				if (!this.isSameSelectionKeys(this.deriveSelectionKeys(), this.selectionKeys())) this.applySelectionKeys();
			});
		});
		effect(() => {
			this.selection();
			untracked(() => {
				if (this.selectionKeys() == null) return;
				const derived = this.deriveSelectionKeys();
				if (!this.isSameSelectionKeys(derived, this.selectionKeys())) this.selectionKeys.set(derived);
			});
		});
	}
	showLoadingMask = computed(() => this.loading() && this.loadingMode() === "mask", ...ngDevMode ? [{ debugName: "showLoadingMask" }] : /* istanbul ignore next */ []);
	get showEmptyMessage() {
		return !this.loading() && (this.getRootNode() == null || this.getRootNode().length === 0);
	}
	scrollerStyleHeight = computed(() => this.scrollHeight() !== "flex" ? this.scrollHeight() : void 0, ...ngDevMode ? [{ debugName: "scrollerStyleHeight" }] : /* istanbul ignore next */ []);
	scrollerScrollHeight = computed(() => this.scrollHeight() !== "flex" ? void 0 : "100%", ...ngDevMode ? [{ debugName: "scrollerScrollHeight" }] : /* istanbul ignore next */ []);
	get emptyMessageLabel() {
		return this.emptyMessage() || this.translate(TranslationKeys.EMPTY_MESSAGE);
	}
	filteredNodeOrigins = /* @__PURE__ */ new WeakMap();
	onDestroy() {
		this._destroyed = true;
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onInit() {
		if (this.filterBy()) this.filterOptions = {
			filter: (value) => this._filter(value),
			reset: () => this.resetFilter()
		};
		if (this.droppableNodes()) this.dragDropService?.dragStart$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((event) => {
			this.dragNodeTree = event.tree;
			this.dragNode = event.node;
			this.dragNodeSubNodes = event.subNodes;
			this.dragNodeIndex = event.index;
			this.dragNodeScope = event.scope;
		});
		if (this.droppableNodes() || this.draggableNodes()) this.dragDropService?.dragStop$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
			this.dragNodeTree = null;
			this.dragNode = null;
			this.dragNodeSubNodes = null;
			this.dragNodeIndex = null;
			this.dragNodeScope = null;
			this.dragHover = false;
			if (this.hasFilterActive()) {
				this._filter(this.filterViewChild()?.nativeElement?.value);
				this.cd.markForCheck();
			} else if (this.virtualScroll()) {
				this.updateSerializedValue();
				this.cd.markForCheck();
			}
		});
	}
	updateSerializedValue() {
		this.serializedValue = [];
		this.serializeNodes(null, this.getRootNode(), 0, true);
	}
	applyCollapsedKeys() {
		const collapsedKeys = this.collapsedKeys();
		if (collapsedKeys == null) return;
		const walk = (nodes) => {
			if (!nodes) return;
			for (const node of nodes) {
				if (node.key != null) node.expanded = !collapsedKeys[node.key];
				if (node.children) walk(node.children);
			}
		};
		walk(this.getRootNode());
	}
	setNodeCollapsed(node, collapsed) {
		const collapsedKeys = this.collapsedKeys();
		if (collapsedKeys == null || node.key == null) return;
		const next = { ...collapsedKeys };
		if (collapsed) next[node.key] = true;
		else delete next[node.key];
		this.collapsedKeys.set(next);
	}
	collectNodesByKey() {
		const map = /* @__PURE__ */ new Map();
		const walk = (nodes) => {
			if (!nodes) return;
			for (const node of nodes) {
				if (node.key != null) map.set(node.key, node);
				if (node.children) walk(node.children);
			}
		};
		walk(this.getRootNode());
		return map;
	}
	deriveSelectionKeys() {
		const mode = this.selectionMode();
		const map = {};
		if (mode === "checkbox") {
			const selection = this.selection() || [];
			const selectedKeys = new Set(selection.map((node) => node.key));
			const walk = (nodes) => {
				if (!nodes) return;
				for (const node of nodes) {
					if (node.key != null) {
						if (selectedKeys.has(node.key)) map[node.key] = {
							checked: true,
							partialChecked: false
						};
						else if (node.partialSelected) map[node.key] = {
							checked: false,
							partialChecked: true
						};
					}
					if (node.children) walk(node.children);
				}
			};
			walk(this.getRootNode());
		} else if (mode === "single") {
			const selected = this.selection();
			if (selected?.key != null) map[selected.key] = true;
		} else {
			const selection = this.selection() || [];
			for (const node of selection) if (node.key != null) map[node.key] = true;
		}
		return map;
	}
	applySelectionKeys() {
		const keys = this.selectionKeys();
		if (keys == null) return;
		const mode = this.selectionMode();
		const nodesByKey = this.collectNodesByKey();
		const isChecked = (value) => value === true || value?.checked === true;
		if (mode === "single") {
			const key = Object.keys(keys).find((k) => isChecked(keys[k]));
			this.selection.set(key != null ? nodesByKey.get(key) ?? null : null);
			return;
		}
		const selected = [];
		nodesByKey.forEach((node, key) => {
			const value = keys[key];
			if (mode === "checkbox") node.partialSelected = value?.partialChecked === true;
			if (isChecked(value)) selected.push(node);
		});
		this.selection.set(selected);
	}
	isSameSelectionKeys(a, b) {
		const aKeys = Object.keys(a || {});
		const bKeys = Object.keys(b || {});
		if (aKeys.length !== bKeys.length) return false;
		return aKeys.every((key) => {
			const av = a[key];
			const bv = b[key];
			if (av === bv) return true;
			if (av && bv && typeof av === "object" && typeof bv === "object") return av.checked === bv.checked && av.partialChecked === bv.partialChecked;
			return false;
		});
	}
	serializeNodes(parent, nodes, level, visible) {
		if (nodes && nodes.length) for (let node of nodes) {
			node.parent = parent;
			const rowNode = {
				node,
				parent,
				level,
				visible: visible && (parent ? parent.expanded : true)
			};
			this.serializedValue.push(rowNode);
			if (rowNode.visible && node.expanded) this.serializeNodes(node, node.children, level + 1, rowNode.visible);
		}
	}
	onNodeClick(event, node) {
		const section = event.target?.getAttribute?.("data-pc-section");
		if (section === "nodetogglebutton" || section === "nodetoggleicon") return;
		if (this.selectionMode()) {
			if (node.selectable === false) return;
			if (this.hasFilteredNodes()) {
				node = this.getNodeWithKey(node.key, this.filteredNodes());
				if (!node) return;
			}
			let index = this.findIndexInSelection(node);
			let selected = index >= 0;
			const currentSelection = this.selection();
			if (this.isCheckboxSelectionMode()) {
				if (selected) {
					if (this.propagateSelectionDown()) this.propagateDown(node, false);
					else this.selection.set(currentSelection.filter((_val, i) => i != index));
					if (this.propagateSelectionUp() && node.parent) this.propagateUp(node.parent, false);
					this.onNodeUnselect.emit({
						originalEvent: event,
						node
					});
				} else {
					if (this.propagateSelectionDown()) this.propagateDown(node, true);
					else this.selection.set([...currentSelection || [], node]);
					if (this.propagateSelectionUp() && node.parent) this.propagateUp(node.parent, true);
					this.onNodeSelect.emit({
						originalEvent: event,
						node
					});
				}
			} else if (this.nodeTouched ? false : this.metaKeySelection()) {
				let metaKey = event.metaKey || event.ctrlKey;
				if (selected && metaKey) {
					if (this.isSingleSelectionMode()) this.selection.set(null);
					else this.selection.set(currentSelection.filter((_val, i) => i != index));
					this.onNodeUnselect.emit({
						originalEvent: event,
						node
					});
				} else {
					if (this.isSingleSelectionMode()) this.selection.set(node);
					else if (this.isMultipleSelectionMode()) {
						const base = !metaKey ? [] : currentSelection || [];
						this.selection.set([...base, node]);
					}
					this.onNodeSelect.emit({
						originalEvent: event,
						node
					});
				}
			} else if (this.isSingleSelectionMode()) {
				if (selected) {
					this.selection.set(null);
					this.onNodeUnselect.emit({
						originalEvent: event,
						node
					});
				} else {
					this.selection.set(node);
					setTimeout(() => {
						if (this._destroyed) return;
						this.onNodeSelect.emit({
							originalEvent: event,
							node
						});
					});
				}
			} else if (selected) {
				this.selection.set(currentSelection.filter((_val, i) => i != index));
				this.onNodeUnselect.emit({
					originalEvent: event,
					node
				});
			} else {
				this.selection.set([...currentSelection || [], node]);
				setTimeout(() => {
					if (this._destroyed) return;
					this.onNodeSelect.emit({
						originalEvent: event,
						node
					});
				});
			}
		}
		this.nodeTouched = false;
	}
	onNodeTouchEnd() {
		this.nodeTouched = true;
	}
	onNodeRightClick(event, node) {
		if (this.contextMenu()) {
			const section = event.target.getAttribute("data-pc-section");
			if (section === "nodetogglebutton" || section === "nodetoggleicon") return;
			const onContextMenuCallback = () => {
				this.contextMenu().show(event);
				this.contextMenu().hideCallback = () => {
					this.contextMenuSelection.set(null);
				};
				this.onNodeContextMenuSelect.emit({
					originalEvent: event,
					node
				});
			};
			this.contextMenuSelection.set(node);
			onContextMenuCallback();
		}
	}
	onNodeDblClick(event, node) {
		this.onNodeDoubleClick.emit({
			originalEvent: event,
			node
		});
	}
	findIndexInSelection(node) {
		let index = -1;
		const currentSelection = this.selection();
		if (this.selectionMode() && currentSelection) {
			if (this.isSingleSelectionMode()) {
				const sel = currentSelection;
				index = sel.key && sel.key === node.key || sel == node ? 0 : -1;
			} else {
				const selArray = currentSelection;
				for (let i = 0; i < selArray.length; i++) {
					let selectedNode = selArray[i];
					if (selectedNode.key && selectedNode.key === node.key || selectedNode == node) {
						index = i;
						break;
					}
				}
			}
		}
		return index;
	}
	syncNodeOption(node, parentNodes, option, value) {
		const _node = this.hasFilteredNodes() ? this.getNodeWithKey(node.key, parentNodes) : null;
		if (_node) _node[option] = value || node[option];
	}
	hasFilteredNodes() {
		return this.filter() && this.filteredNodes() && this.filteredNodes().length;
	}
	getOriginalNode(node) {
		return this.filteredNodeOrigins.get(node) ?? node;
	}
	hasFilterActive() {
		return this.filter() && this.filterViewChild()?.nativeElement?.value.length > 0;
	}
	getNodeWithKey(key, nodes) {
		for (let node of nodes) {
			if (node.key === key) return node;
			if (node.children) {
				let matchedNode = this.getNodeWithKey(key, node.children);
				if (matchedNode) return matchedNode;
			}
		}
	}
	propagateUp(node, select) {
		if (node.children && node.children.length) {
			let selectedCount = 0;
			let childPartialSelected = false;
			for (let child of node.children) if (this.isSelected(child)) selectedCount++;
			else if (child.partialSelected) childPartialSelected = true;
			const currentSelection = this.selection() || [];
			if (select && selectedCount == node.children.length) {
				this.selection.set([...currentSelection, node]);
				node.partialSelected = false;
			} else {
				if (!select) {
					let index = this.findIndexInSelection(node);
					if (index >= 0) this.selection.set(currentSelection.filter((_val, i) => i != index));
				}
				if (childPartialSelected || selectedCount > 0 && selectedCount != node.children.length) node.partialSelected = true;
				else node.partialSelected = false;
			}
			this.syncNodeOption(node, this.filteredNodes(), "partialSelected");
		}
		let parent = node.parent;
		if (parent) this.propagateUp(parent, select);
	}
	propagateDown(node, select) {
		let index = this.findIndexInSelection(node);
		const currentSelection = this.selection() || [];
		if (select && index == -1) this.selection.set([...currentSelection, node]);
		else if (!select && index > -1) this.selection.set(currentSelection.filter((_val, i) => i != index));
		node.partialSelected = false;
		this.syncNodeOption(node, this.filteredNodes(), "partialSelected");
		if (node.children && node.children.length) for (let child of node.children) this.propagateDown(child, select);
	}
	isSelected(node) {
		return this.findIndexInSelection(node) != -1;
	}
	isSingleSelectionMode() {
		return this.selectionMode() && this.selectionMode() == "single";
	}
	isMultipleSelectionMode() {
		return this.selectionMode() && this.selectionMode() == "multiple";
	}
	isCheckboxSelectionMode() {
		return this.selectionMode() && this.selectionMode() == "checkbox";
	}
	isNodeLeaf(node) {
		return node.leaf == false ? false : !(node.children && node.children.length);
	}
	getRootNode() {
		return this.filteredNodes() ? this.filteredNodes() : this.value();
	}
	getTemplateForNode(node) {
		return this.nodeTemplate() ?? null;
	}
	onDragOver(event) {
		if (this.droppableNodes() && this.allowDrop(this.dragNode, null, this.dragNodeScope)) {
			event.dataTransfer.dropEffect = "copy";
			event.preventDefault();
		}
	}
	onDrop(event) {
		if (this.droppableNodes()) {
			event.preventDefault();
			let dragNode = this.dragNode;
			if (this.isSameTreeScope(this.dragNodeScope)) return;
			if (this.allowDrop(dragNode, null, this.dragNodeScope)) {
				let dragNodeIndex = this.dragNodeIndex;
				if (this.validateDrop()) this.onNodeDrop.emit({
					originalEvent: event,
					dragNode,
					dropNode: null,
					index: dragNodeIndex,
					accept: () => {
						this.processTreeDrop(dragNode, dragNodeIndex);
					}
				});
				else {
					this.onNodeDrop.emit({
						originalEvent: event,
						dragNode,
						dropNode: null,
						index: dragNodeIndex
					});
					this.processTreeDrop(dragNode, dragNodeIndex);
				}
			}
		}
	}
	processTreeDrop(dragNode, dragNodeIndex) {
		const subNodes = this.dragNodeSubNodes;
		const removalIndex = subNodes ? subNodes.indexOf(dragNode) : -1;
		if (removalIndex !== -1) subNodes.splice(removalIndex, 1);
		this.value().push(dragNode);
		this.dragDropService.stopDrag({ node: dragNode });
	}
	onDragEnter() {
		if (this.droppableNodes() && this.allowDrop(this.dragNode, null, this.dragNodeScope)) this.dragHover = true;
	}
	onDragLeave(event) {
		if (this.droppableNodes()) {
			let rect = event.currentTarget.getBoundingClientRect();
			if (event.x > parseInt(rect.left) + rect.width || event.x < parseInt(rect.left) || event.y > parseInt(rect.top) + rect.height || event.y < parseInt(rect.top)) this.dragHover = false;
		}
	}
	allowDrop(dragNode, dropNode, dragNodeScope) {
		if (!dragNode) return false;
		else if (this.isValidDragScope(dragNodeScope)) {
			let allow = true;
			if (dropNode) {
				if (dragNode === this.getOriginalNode(dropNode)) allow = false;
				else {
					let parent = dropNode.parent;
					while (parent != null) {
						if (this.getOriginalNode(parent) === dragNode) {
							allow = false;
							break;
						}
						parent = parent.parent;
					}
				}
			}
			return allow;
		} else return false;
	}
	hasCommonScope(dragScope, dropScope) {
		if (typeof dropScope === "string") {
			if (typeof dragScope === "string") return dropScope === dragScope;
			else if (Array.isArray(dragScope)) return dragScope.indexOf(dropScope) != -1;
		} else if (Array.isArray(dropScope)) {
			if (typeof dragScope === "string") return dropScope.indexOf(dragScope) != -1;
			else if (Array.isArray(dragScope)) {
				for (let s of dropScope) for (let ds of dragScope) if (s === ds) return true;
			}
		}
		return false;
	}
	isSameTreeScope(dragScope) {
		return this.hasCommonScope(dragScope, this.draggableScope());
	}
	isValidDragScope(dragScope) {
		let dropScope = this.droppableScope();
		if (dropScope) return this.hasCommonScope(dragScope, dropScope);
		else return true;
	}
	_filter(value) {
		let filterValue = value;
		if (filterValue === "") this.filteredNodes.set(null);
		else {
			const filteredNodes = [];
			const searchFields = this.filterBy().split(",");
			const filterText = ee(filterValue).toLocaleLowerCase(this.filterLocale());
			const isStrictMode = this.filterMode() === "strict";
			for (let node of this.value()) {
				let copyNode = { ...node };
				this.filteredNodeOrigins.set(copyNode, node);
				let paramsWithoutNode = {
					searchFields,
					filterText,
					isStrictMode
				};
				if (isStrictMode && (this.findFilteredNodes(copyNode, paramsWithoutNode) || this.isFilterMatched(copyNode, paramsWithoutNode)) || !isStrictMode && (this.isFilterMatched(copyNode, paramsWithoutNode) || this.findFilteredNodes(copyNode, paramsWithoutNode))) filteredNodes.push(copyNode);
			}
			this.filteredNodes.set(filteredNodes);
		}
		this.updateSerializedValue();
		this.onFilter.emit({
			filter: filterValue,
			filteredValue: this.filteredNodes()
		});
	}
	resetFilter() {
		this.filteredNodes.set(null);
		const filterEl = this.filterViewChild();
		if (filterEl && filterEl.nativeElement) filterEl.nativeElement.value = "";
	}
	scrollToVirtualIndex(index) {
		if (this.virtualScroll()) this.scroller()?.scrollToIndex(index);
	}
	scrollTo(options) {
		if (this.virtualScroll()) this.scroller()?.scrollTo(options);
		else {
			const wrapper = this.wrapperViewChild();
			if (wrapper && wrapper.nativeElement) {
				if (wrapper.nativeElement.scrollTo) wrapper.nativeElement.scrollTo(options);
				else {
					wrapper.nativeElement.scrollLeft = options.left;
					wrapper.nativeElement.scrollTop = options.top;
				}
			}
		}
	}
	findFilteredNodes(node, paramsWithoutNode) {
		if (node) {
			let matched = false;
			if (node.children) {
				let childNodes = [...node.children];
				node.children = [];
				for (let childNode of childNodes) {
					let copyChildNode = { ...childNode };
					this.filteredNodeOrigins.set(copyChildNode, this.getOriginalNode(childNode));
					if (this.isFilterMatched(copyChildNode, paramsWithoutNode)) {
						matched = true;
						node.children.push(copyChildNode);
					}
				}
			}
			if (matched) {
				node.expanded = true;
				return true;
			}
		}
	}
	isFilterMatched(node, params) {
		let { searchFields, filterText, isStrictMode } = params;
		let matched = false;
		for (let field of searchFields) if (ee(String(d(node, field))).toLocaleLowerCase(this.filterLocale()).indexOf(filterText) > -1) matched = true;
		if (!matched || isStrictMode && !this.isNodeLeaf(node)) matched = this.findFilteredNodes(node, {
			searchFields,
			filterText,
			isStrictMode
		}) || matched;
		return matched;
	}
	getIndex(options, index) {
		const getItemOptions = options["getItemOptions"];
		return getItemOptions ? getItemOptions(index).index : index;
	}
	getBlockableElement() {
		return this.el.nativeElement.children[0];
	}
	get containerDataP() {
		return this.cn({
			loading: this.loading(),
			scrollable: this.scrollHeight() === "flex"
		});
	}
	get wrapperDataP() {
		return this.cn({ scrollable: this.scrollHeight() === "flex" });
	}
	static ɵfac = function Tree_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Tree)();
	};
	static ɵcmp = (function() {
		const _c0 = ["filter"];
		const _c1 = ["node"];
		const _c2 = ["header"];
		const _c3 = ["footer"];
		const _c4 = ["loader"];
		const _c5 = ["empty"];
		const _c6 = ["togglericon"];
		const _c7 = ["checkboxicon"];
		const _c8 = ["loadingicon"];
		const _c9 = ["filtericon"];
		const _c10 = ["scroller"];
		const _c11 = ["wrapper"];
		const _c12 = ["content"];
		const _c13 = (a0) => ({ $implicit: a0 });
		const _c14 = (a0) => ({ height: a0 });
		const _c15 = (a0) => ({ options: a0 });
		function _forTrack0($index, $item) {
			return this.trackBy()($index, $item);
		}
		function _forTrack1($index, $item) {
			return this.trackBy().bind(this)($index, $item);
		}
		function Tree_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "i", 8);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("loadingIcon"), "pi-spin" + ctx_r1.loadingIcon()));
				ɵɵproperty("pBind", ctx_r1.ptm("loadingIcon"));
			}
		}
		function Tree_Conditional_0_Conditional_2_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 10);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("loadingIcon"));
				ɵɵproperty("spin", true)("pBind", ctx_r1.ptm("loadingIcon"));
			}
		}
		function Tree_Conditional_0_Conditional_2_Conditional_1_1_ng_template_0_Template(rf, ctx) {}
		function Tree_Conditional_0_Conditional_2_Conditional_1_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_0_Conditional_2_Conditional_1_1_ng_template_0_Template, 0, 0, "ng-template");
		}
		function Tree_Conditional_0_Conditional_2_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 8);
				ɵɵtemplate(1, Tree_Conditional_0_Conditional_2_Conditional_1_1_Template, 1, 0, null, 7);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("loadingIcon"));
				ɵɵproperty("pBind", ctx_r1.ptm("loadingIcon"));
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.loadingIconTemplate());
			}
		}
		function Tree_Conditional_0_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, Tree_Conditional_0_Conditional_2_Conditional_0_Template, 1, 4, "svg", 9);
				ɵɵconditionalCreate(1, Tree_Conditional_0_Conditional_2_Conditional_1_Template, 2, 4, "span", 6);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵconditional(!ctx_r1.loadingIconTemplate() ? 0 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.loadingIconTemplate() ? 1 : -1);
			}
		}
		function Tree_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "div", 8);
				ɵɵanimateLeave(function Tree_Conditional_0_Template_animateleave_cb() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.pcn("p-overlay-mask-leave-active"));
				});
				ɵɵanimateEnter(function Tree_Conditional_0_Template_animateenter_cb() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.pcn("p-overlay-mask-enter-active"));
				});
				ɵɵconditionalCreate(1, Tree_Conditional_0_Conditional_1_Template, 1, 3, "i", 6);
				ɵɵconditionalCreate(2, Tree_Conditional_0_Conditional_2_Template, 2, 2);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("mask"));
				ɵɵproperty("pBind", ctx_r1.ptm("mask"));
				ɵɵadvance();
				ɵɵconditional(ctx_r1.loadingIcon() ? 1 : -1);
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.loadingIcon() ? 2 : -1);
			}
		}
		function Tree_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Tree_Conditional_2_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Tree_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_2_ng_container_0_Template, 1, 0, "ng-container", 11);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.filterTemplate())("ngTemplateOutletContext", ɵɵpureFunction1(2, _c13, ctx_r1.filterOptions));
			}
		}
		function Tree_Conditional_3_Conditional_0_Conditional_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 16);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("filterIcon"));
				ɵɵproperty("pBind", ctx_r1.ptm("filterIcon"));
			}
		}
		function Tree_Conditional_3_Conditional_0_Conditional_5_1_ng_template_0_Template(rf, ctx) {}
		function Tree_Conditional_3_Conditional_0_Conditional_5_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_3_Conditional_0_Conditional_5_1_ng_template_0_Template, 0, 0, "ng-template");
		}
		function Tree_Conditional_3_Conditional_0_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 8);
				ɵɵtemplate(1, Tree_Conditional_3_Conditional_0_Conditional_5_1_Template, 1, 0, null, 7);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("filterIcon"));
				ɵɵproperty("pBind", ctx_r1.ptm("filterIcon"));
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.filterIconTemplate());
			}
		}
		function Tree_Conditional_3_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r3 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "p-iconfield", 13)(1, "input", 14, 0);
				ɵɵlistener("keydown.enter", function Tree_Conditional_3_Conditional_0_Template_input_keydown_enter_1_listener($event) {
					return $event.preventDefault();
				})("input", function Tree_Conditional_3_Conditional_0_Template_input_input_1_listener($event) {
					ɵɵrestoreView(_r3);
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1._filter($event.target?.value));
				});
				ɵɵelementEnd();
				ɵɵelementStart(3, "p-inputicon", 13);
				ɵɵconditionalCreate(4, Tree_Conditional_3_Conditional_0_Conditional_4_Template, 1, 3, "svg", 15);
				ɵɵconditionalCreate(5, Tree_Conditional_3_Conditional_0_Conditional_5_Template, 2, 4, "span", 6);
				ɵɵelementEnd()();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("pcFilterContainer"));
				ɵɵproperty("pt", ctx_r1.ptm("pcFilterContainer"))("unstyled", ctx_r1.unstyled());
				ɵɵadvance();
				ɵɵclassMap(ctx_r1.cx("pcFilterInput"));
				ɵɵproperty("pAutoFocus", ctx_r1.filterInputAutoFocus())("pt", ctx_r1.ptm("pcFilterInput"))("unstyled", ctx_r1.unstyled());
				ɵɵattribute("placeholder", ctx_r1.filterPlaceholder());
				ɵɵadvance(2);
				ɵɵproperty("pt", ctx_r1.ptm("pcFilterIconContainer"))("unstyled", ctx_r1.unstyled());
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.filterIconTemplate() ? 4 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.filterIconTemplate() ? 5 : -1);
			}
		}
		function Tree_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Tree_Conditional_3_Conditional_0_Template, 6, 14, "p-iconfield", 12);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵconditional(ctx_r1.filter() ? 0 : -1);
			}
		}
		function Tree_Conditional_4_Conditional_0_ng_template_2_Conditional_0_For_3_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-treenode", 22, 3);
			if (rf & 2) {
				const rowNode_r5 = ctx.$implicit;
				const ɵ$index_54_r6 = ctx.$index;
				const ɵ$count_54_r7 = ctx.$count;
				const scrollerOptions_r8 = ɵɵnextContext(2).options;
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵproperty("level", rowNode_r5.level)("rowNode", rowNode_r5)("node", rowNode_r5.node)("parentNode", rowNode_r5.parent)("firstChild", ɵ$index_54_r6 === 0)("lastChild", ɵ$index_54_r6 === ɵ$count_54_r7 - 1)("index", ctx_r1.getIndex(scrollerOptions_r8, ɵ$index_54_r6))("itemSize", scrollerOptions_r8.itemSize)("indentation", ctx_r1.indentation())("loadingMode", ctx_r1.loadingMode())("pt", ctx_r1.pt())("unstyled", ctx_r1.unstyled());
			}
		}
		function Tree_Conditional_4_Conditional_0_ng_template_2_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "ul", 21, 2);
				ɵɵrepeaterCreate(2, Tree_Conditional_4_Conditional_0_ng_template_2_Conditional_0_For_3_Template, 2, 12, "p-treenode", 22, _forTrack0, true);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r8 = ɵɵnextContext();
				const items_r10 = ctx_r8.$implicit;
				const scrollerOptions_r8 = ctx_r8.options;
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵstyleMap(scrollerOptions_r8.contentStyle);
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("rootChildren"), scrollerOptions_r8.contentStyleClass));
				ɵɵproperty("pBind", ctx_r1.ptm("rootChildren"));
				ɵɵattribute("aria-label", ctx_r1.ariaLabel())("aria-labelledby", ctx_r1.ariaLabelledBy());
				ɵɵadvance(2);
				ɵɵrepeater(items_r10);
			}
		}
		function Tree_Conditional_4_Conditional_0_ng_template_2_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, Tree_Conditional_4_Conditional_0_ng_template_2_Conditional_0_Template, 4, 7, "ul", 20);
			if (rf & 2) {
				const items_r10 = ctx.$implicit;
				ɵɵconditional(items_r10 ? 0 : -1);
			}
		}
		function Tree_Conditional_4_Conditional_0_Conditional_4_ng_template_0_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function Tree_Conditional_4_Conditional_0_Conditional_4_ng_template_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_4_Conditional_0_Conditional_4_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 11);
			if (rf & 2) {
				const scrollerOptions_r11 = ctx.options;
				const ctx_r1 = ɵɵnextContext(4);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.loaderTemplate())("ngTemplateOutletContext", ɵɵpureFunction1(2, _c15, scrollerOptions_r11));
			}
		}
		function Tree_Conditional_4_Conditional_0_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_4_Conditional_0_Conditional_4_ng_template_0_Template, 1, 4, "ng-template", null, 4, ɵɵtemplateRefExtractor);
		}
		function Tree_Conditional_4_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r4 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "p-scroller", 19, 1);
				ɵɵlistener("onScroll", function Tree_Conditional_4_Conditional_0_Template_p_scroller_onScroll_0_listener($event) {
					ɵɵrestoreView(_r4);
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.onScroll.emit($event));
				})("onScrollIndexChange", function Tree_Conditional_4_Conditional_0_Template_p_scroller_onScrollIndexChange_0_listener($event) {
					ɵɵrestoreView(_r4);
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.onScrollIndexChange.emit($event));
				})("onLazyLoad", function Tree_Conditional_4_Conditional_0_Template_p_scroller_onLazyLoad_0_listener($event) {
					ɵɵrestoreView(_r4);
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.onLazyLoad.emit($event));
				});
				ɵɵtemplate(2, Tree_Conditional_4_Conditional_0_ng_template_2_Template, 1, 1, "ng-template", null, 2, ɵɵtemplateRefExtractor);
				ɵɵconditionalCreate(4, Tree_Conditional_4_Conditional_0_Conditional_4_Template, 2, 0);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ɵɵpureFunction1(12, _c14, ctx_r1.scrollerStyleHeight()));
				ɵɵproperty("items", ctx_r1.serializedValue)("tabindex", -1)("styleClass", ctx_r1.cx("wrapper"))("scrollHeight", ctx_r1.scrollerScrollHeight())("itemSize", ctx_r1.virtualScrollItemSize())("lazy", ctx_r1.lazy())("options", ctx_r1.virtualScrollOptions())("pt", ctx_r1.ptm("virtualScroller"));
				ɵɵattribute("data-p", ctx_r1.wrapperDataP);
				ɵɵadvance(4);
				ɵɵconditional(ctx_r1.loaderTemplate() ? 4 : -1);
			}
		}
		function Tree_Conditional_4_Conditional_1_Conditional_2_For_3_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "p-treenode", 24);
			if (rf & 2) {
				const node_r12 = ctx.$implicit;
				const ɵ$index_70_r13 = ctx.$index;
				const ɵ$count_70_r14 = ctx.$count;
				const ctx_r1 = ɵɵnextContext(4);
				ɵɵproperty("node", node_r12)("firstChild", ɵ$index_70_r13 === 0)("lastChild", ɵ$index_70_r13 === ɵ$count_70_r14 - 1)("index", ɵ$index_70_r13)("level", 0)("loadingMode", ctx_r1.loadingMode())("pt", ctx_r1.pt())("unstyled", ctx_r1.unstyled());
			}
		}
		function Tree_Conditional_4_Conditional_1_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "ul", 21, 2);
				ɵɵrepeaterCreate(2, Tree_Conditional_4_Conditional_1_Conditional_2_For_3_Template, 1, 8, "p-treenode", 24, _forTrack1, true);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(3);
				ɵɵclassMap(ctx_r1.cx("rootChildren"));
				ɵɵproperty("pBind", ctx_r1.ptm("rootChildren"));
				ɵɵattribute("aria-label", ctx_r1.ariaLabel())("aria-labelledby", ctx_r1.ariaLabelledBy());
				ɵɵadvance(2);
				ɵɵrepeater(ctx_r1.getRootNode());
			}
		}
		function Tree_Conditional_4_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "div", 8, 5);
				ɵɵconditionalCreate(2, Tree_Conditional_4_Conditional_1_Conditional_2_Template, 4, 5, "ul", 23);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("wrapper"));
				ɵɵstyleProp("max-height", ctx_r1.scrollHeight());
				ɵɵproperty("pBind", ctx_r1.ptm("wrapper"));
				ɵɵattribute("data-p", ctx_r1.wrapperDataP);
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.getRootNode() ? 2 : -1);
			}
		}
		function Tree_Conditional_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, Tree_Conditional_4_Conditional_0_Template, 5, 14, "p-scroller", 17);
				ɵɵconditionalCreate(1, Tree_Conditional_4_Conditional_1_Template, 3, 7, "div", 18);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵconditional(ctx_r1.virtualScroll() ? 0 : -1);
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.virtualScroll() ? 1 : -1);
			}
		}
		function Tree_Conditional_5_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵtext(0);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵtextInterpolate1(" ", ctx_r1.emptyMessageLabel, " ");
			}
		}
		function Tree_Conditional_5_Conditional_2_0_ng_template_0_Template(rf, ctx) {}
		function Tree_Conditional_5_Conditional_2_0_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_5_Conditional_2_0_ng_template_0_Template, 0, 0, "ng-template");
		}
		function Tree_Conditional_5_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, Tree_Conditional_5_Conditional_2_0_Template, 1, 0, null, 7);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.emptyTemplate());
			}
		}
		function Tree_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "div", 8);
				ɵɵconditionalCreate(1, Tree_Conditional_5_Conditional_1_Template, 1, 1);
				ɵɵconditionalCreate(2, Tree_Conditional_5_Conditional_2_Template, 1, 1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("emptyMessage"));
				ɵɵproperty("pBind", ctx_r1.ptm("emptyMessage"));
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.emptyTemplate() ? 1 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.emptyTemplate() ? 2 : -1);
			}
		}
		function Tree_ng_container_6_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: Tree,
			selectors: [["p-tree"]],
			contentQueries: function Tree_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.filterTemplate, _c0, 4)(dirIndex, ctx.nodeTemplate, _c1, 4)(dirIndex, ctx.headerTemplate, _c2, 4)(dirIndex, ctx.footerTemplate, _c3, 4)(dirIndex, ctx.loaderTemplate, _c4, 4)(dirIndex, ctx.emptyTemplate, _c5, 4)(dirIndex, ctx.togglerIconTemplate, _c6, 4)(dirIndex, ctx.checkboxIconTemplate, _c7, 4)(dirIndex, ctx.loadingIconTemplate, _c8, 4)(dirIndex, ctx.filterIconTemplate, _c9, 4);
				if (rf & 2) ɵɵqueryAdvance(10);
			},
			viewQuery: function Tree_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.filterViewChild, _c0, 5)(ctx.scroller, _c10, 5)(ctx.wrapperViewChild, _c11, 5)(ctx.contentViewChild, _c12, 5);
				if (rf & 2) ɵɵqueryAdvance(4);
			},
			hostVars: 3,
			hostBindings: function Tree_HostBindings(rf, ctx) {
				if (rf & 1) ɵɵlistener("drop", function Tree_drop_HostBindingHandler($event) {
					return ctx.onDrop($event);
				})("dragover", function Tree_dragover_HostBindingHandler($event) {
					return ctx.onDragOver($event);
				})("dragenter", function Tree_dragenter_HostBindingHandler() {
					return ctx.onDragEnter();
				})("dragleave", function Tree_dragleave_HostBindingHandler($event) {
					return ctx.onDragLeave($event);
				});
				if (rf & 2) {
					ɵɵattribute("data-p", ctx.containerDataP);
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				value: [1, "value"],
				selectionMode: [1, "selectionMode"],
				loadingMode: [1, "loadingMode"],
				selection: [1, "selection"],
				collapsedKeys: [1, "collapsedKeys"],
				selectionKeys: [1, "selectionKeys"],
				contextMenu: [1, "contextMenu"],
				contextMenuSelection: [1, "contextMenuSelection"],
				draggableScope: [1, "draggableScope"],
				droppableScope: [1, "droppableScope"],
				draggableNodes: [1, "draggableNodes"],
				droppableNodes: [1, "droppableNodes"],
				metaKeySelection: [1, "metaKeySelection"],
				propagateSelectionUp: [1, "propagateSelectionUp"],
				propagateSelectionDown: [1, "propagateSelectionDown"],
				loading: [1, "loading"],
				loadingIcon: [1, "loadingIcon"],
				emptyMessage: [1, "emptyMessage"],
				ariaLabel: [1, "ariaLabel"],
				togglerAriaLabel: [1, "togglerAriaLabel"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				validateDrop: [1, "validateDrop"],
				filter: [1, "filter"],
				filterInputAutoFocus: [1, "filterInputAutoFocus"],
				filterBy: [1, "filterBy"],
				filterMode: [1, "filterMode"],
				filterPlaceholder: [1, "filterPlaceholder"],
				filteredNodes: [1, "filteredNodes"],
				filterLocale: [1, "filterLocale"],
				scrollHeight: [1, "scrollHeight"],
				lazy: [1, "lazy"],
				virtualScroll: [1, "virtualScroll"],
				virtualScrollItemSize: [1, "virtualScrollItemSize"],
				virtualScrollOptions: [1, "virtualScrollOptions"],
				indentation: [1, "indentation"],
				trackBy: [1, "trackBy"],
				highlightOnSelect: [1, "highlightOnSelect"]
			},
			outputs: {
				selection: "selectionChange",
				collapsedKeys: "collapsedKeysChange",
				selectionKeys: "selectionKeysChange",
				contextMenuSelection: "contextMenuSelectionChange",
				filteredNodes: "filteredNodesChange",
				onNodeSelect: "onNodeSelect",
				onNodeUnselect: "onNodeUnselect",
				onNodeExpand: "onNodeExpand",
				onNodeCollapse: "onNodeCollapse",
				onNodeContextMenuSelect: "onNodeContextMenuSelect",
				onNodeDoubleClick: "onNodeDoubleClick",
				onNodeDrop: "onNodeDrop",
				onLazyLoad: "onLazyLoad",
				onScroll: "onScroll",
				onScrollIndexChange: "onScrollIndexChange",
				onFilter: "onFilter"
			},
			features: [
				ɵɵProvidersFeature([
					TreeStyle,
					{
						provide: TREE_INSTANCE,
						useExisting: Tree
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: Tree
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 7,
			vars: 6,
			consts: [
				["filter", ""],
				["scroller", ""],
				["content", ""],
				["treeNode", ""],
				["loader", ""],
				["wrapper", ""],
				[
					3,
					"class",
					"pBind"
				],
				[4, "ngTemplateOutlet"],
				[3, "pBind"],
				[
					"data-p-icon",
					"spinner",
					3,
					"class",
					"spin",
					"pBind"
				],
				[
					"data-p-icon",
					"spinner",
					3,
					"spin",
					"pBind"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				],
				[
					3,
					"class",
					"pt",
					"unstyled"
				],
				[
					3,
					"pt",
					"unstyled"
				],
				[
					"pInputText",
					"",
					"type",
					"search",
					"autocomplete",
					"off",
					3,
					"keydown.enter",
					"input",
					"pAutoFocus",
					"pt",
					"unstyled"
				],
				[
					"data-p-icon",
					"search",
					3,
					"class",
					"pBind"
				],
				[
					"data-p-icon",
					"search",
					3,
					"pBind"
				],
				[
					"hostName",
					"tree",
					3,
					"items",
					"tabindex",
					"styleClass",
					"style",
					"scrollHeight",
					"itemSize",
					"lazy",
					"options",
					"pt"
				],
				[
					3,
					"class",
					"max-height",
					"pBind"
				],
				[
					"hostName",
					"tree",
					3,
					"onScroll",
					"onScrollIndexChange",
					"onLazyLoad",
					"items",
					"tabindex",
					"styleClass",
					"scrollHeight",
					"itemSize",
					"lazy",
					"options",
					"pt"
				],
				[
					"role",
					"tree",
					3,
					"class",
					"style",
					"pBind"
				],
				[
					"role",
					"tree",
					3,
					"pBind"
				],
				[
					3,
					"level",
					"rowNode",
					"node",
					"parentNode",
					"firstChild",
					"lastChild",
					"index",
					"itemSize",
					"indentation",
					"loadingMode",
					"pt",
					"unstyled"
				],
				[
					"role",
					"tree",
					3,
					"class",
					"pBind"
				],
				[
					3,
					"node",
					"firstChild",
					"lastChild",
					"index",
					"level",
					"loadingMode",
					"pt",
					"unstyled"
				]
			],
			template: function Tree_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵconditionalCreate(0, Tree_Conditional_0_Template, 3, 5, "div", 6);
					ɵɵtemplate(1, Tree_ng_container_1_Template, 1, 0, "ng-container", 7);
					ɵɵconditionalCreate(2, Tree_Conditional_2_Template, 1, 4, "ng-container")(3, Tree_Conditional_3_Template, 1, 1);
					ɵɵconditionalCreate(4, Tree_Conditional_4_Template, 2, 2);
					ɵɵconditionalCreate(5, Tree_Conditional_5_Template, 3, 5, "div", 6);
					ɵɵtemplate(6, Tree_ng_container_6_Template, 1, 0, "ng-container", 7);
				}
				if (rf & 2) {
					ɵɵconditional(ctx.showLoadingMask() ? 0 : -1);
					ɵɵadvance();
					ɵɵproperty("ngTemplateOutlet", ctx.headerTemplate());
					ɵɵadvance();
					ɵɵconditional(ctx.filterTemplate() ? 2 : 3);
					ɵɵadvance(2);
					ɵɵconditional(ctx.getRootNode()?.length ? 4 : -1);
					ɵɵadvance();
					ɵɵconditional(ctx.showEmptyMessage ? 5 : -1);
					ɵɵadvance();
					ɵɵproperty("ngTemplateOutlet", ctx.footerTemplate());
				}
			},
			dependencies: [
				NgTemplateOutlet,
				Scroller,
				Search,
				Spinner,
				InputText,
				IconField,
				InputIcon,
				UITreeNode,
				AutoFocusModule,
				AutoFocus,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Tree, [{
		type: Component,
		args: [{
			selector: "p-tree",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				Scroller,
				Search,
				Spinner,
				InputText,
				IconField,
				InputIcon,
				UITreeNode,
				AutoFocusModule,
				Bind
			],
			template: `
        @if (showLoadingMask()) {
            <div [class]="cx('mask')" [pBind]="ptm('mask')" [animate.enter]="pcn('p-overlay-mask-enter-active')" [animate.leave]="pcn('p-overlay-mask-leave-active')">
                @if (loadingIcon()) {
                    <i [class]="cn(cx('loadingIcon'), 'pi-spin' + loadingIcon())" [pBind]="ptm('loadingIcon')"></i>
                }
                @if (!loadingIcon()) {
                    @if (!loadingIconTemplate()) {
                        <svg data-p-icon="spinner" [class]="cx('loadingIcon')" [spin]="true" [pBind]="ptm('loadingIcon')" />
                    }
                    @if (loadingIconTemplate()) {
                        <span [class]="cx('loadingIcon')" [pBind]="ptm('loadingIcon')">
                            <ng-template *ngTemplateOutlet="loadingIconTemplate()!"></ng-template>
                        </span>
                    }
                }
            </div>
        }
        <ng-container *ngTemplateOutlet="headerTemplate()"></ng-container>
        @if (filterTemplate()) {
            <ng-container *ngTemplateOutlet="filterTemplate()!; context: { $implicit: filterOptions }"></ng-container>
        } @else {
            @if (filter()) {
                <p-iconfield [class]="cx('pcFilterContainer')" [pt]="ptm('pcFilterContainer')" [unstyled]="unstyled()">
                    <input
                        #filter
                        [pAutoFocus]="filterInputAutoFocus()"
                        pInputText
                        type="search"
                        autocomplete="off"
                        [class]="cx('pcFilterInput')"
                        [attr.placeholder]="filterPlaceholder()"
                        (keydown.enter)="$event.preventDefault()"
                        (input)="_filter($event.target?.value)"
                        [pt]="ptm('pcFilterInput')"
                        [unstyled]="unstyled()"
                    />
                    <p-inputicon [pt]="ptm('pcFilterIconContainer')" [unstyled]="unstyled()">
                        @if (!filterIconTemplate()) {
                            <svg data-p-icon="search" [class]="cx('filterIcon')" [pBind]="ptm('filterIcon')" />
                        }
                        @if (filterIconTemplate()) {
                            <span [class]="cx('filterIcon')" [pBind]="ptm('filterIcon')">
                                <ng-template *ngTemplateOutlet="filterIconTemplate()!"></ng-template>
                            </span>
                        }
                    </p-inputicon>
                </p-iconfield>
            }
        }

        @if (getRootNode()?.length) {
            @if (virtualScroll()) {
                <p-scroller
                    #scroller
                    [items]="serializedValue"
                    [tabindex]="-1"
                    [styleClass]="cx('wrapper')"
                    [style]="{ height: scrollerStyleHeight() }"
                    [scrollHeight]="scrollerScrollHeight()"
                    [itemSize]="virtualScrollItemSize()!"
                    [lazy]="lazy()"
                    (onScroll)="onScroll.emit($event)"
                    (onScrollIndexChange)="onScrollIndexChange.emit($event)"
                    (onLazyLoad)="onLazyLoad.emit($event)"
                    [options]="virtualScrollOptions()"
                    [pt]="ptm('virtualScroller')"
                    hostName="tree"
                    [attr.data-p]="wrapperDataP"
                >
                    <ng-template #content let-items let-scrollerOptions="options">
                        @if (items) {
                            <ul
                                #content
                                [class]="cn(cx('rootChildren'), scrollerOptions.contentStyleClass)"
                                [style]="scrollerOptions.contentStyle"
                                role="tree"
                                [attr.aria-label]="ariaLabel()"
                                [attr.aria-labelledby]="ariaLabelledBy()"
                                [pBind]="ptm('rootChildren')"
                            >
                                @for (rowNode of items; track trackBy()($index, rowNode); let firstChild = $first; let lastChild = $last; let idx = $index) {
                                    <p-treenode
                                        #treeNode
                                        [level]="rowNode.level"
                                        [rowNode]="rowNode"
                                        [node]="rowNode.node"
                                        [parentNode]="rowNode.parent"
                                        [firstChild]="firstChild"
                                        [lastChild]="lastChild"
                                        [index]="getIndex(scrollerOptions, idx)"
                                        [itemSize]="scrollerOptions.itemSize"
                                        [indentation]="indentation()"
                                        [loadingMode]="loadingMode()"
                                        [pt]="pt()"
                                        [unstyled]="unstyled()"
                                    />
                                }
                            </ul>
                        }
                    </ng-template>
                    @if (loaderTemplate()) {
                        <ng-template #loader let-scrollerOptions="options">
                            <ng-container *ngTemplateOutlet="loaderTemplate()!; context: { options: scrollerOptions }"></ng-container>
                        </ng-template>
                    }
                </p-scroller>
            }
            @if (!virtualScroll()) {
                <div #wrapper [class]="cx('wrapper')" [style.max-height]="scrollHeight()" [pBind]="ptm('wrapper')" [attr.data-p]="wrapperDataP">
                    @if (getRootNode()) {
                        <ul #content [class]="cx('rootChildren')" role="tree" [attr.aria-label]="ariaLabel()" [attr.aria-labelledby]="ariaLabelledBy()" [pBind]="ptm('rootChildren')">
                            @for (node of getRootNode(); track trackBy().bind(this)($index, node); let firstChild = $first; let lastChild = $last; let idx = $index) {
                                <p-treenode [node]="node" [firstChild]="firstChild" [lastChild]="lastChild" [index]="idx" [level]="0" [loadingMode]="loadingMode()" [pt]="pt()" [unstyled]="unstyled()" />
                            }
                        </ul>
                    }
                </div>
            }
        }

        @if (showEmptyMessage) {
            <div [class]="cx('emptyMessage')" [pBind]="ptm('emptyMessage')">
                @if (!emptyTemplate()) {
                    {{ emptyMessageLabel }}
                }
                @if (emptyTemplate()) {
                    <ng-template *ngTemplateOutlet="emptyTemplate()!"></ng-template>
                }
            </div>
        }
        <ng-container *ngTemplateOutlet="footerTemplate()"></ng-container>
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				TreeStyle,
				{
					provide: TREE_INSTANCE,
					useExisting: Tree
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: Tree
				}
			],
			host: {
				"[class]": "cx('root')",
				"[attr.data-p]": "containerDataP",
				"(drop)": "onDrop($event)",
				"(dragover)": "onDragOver($event)",
				"(dragenter)": "onDragEnter()",
				"(dragleave)": "onDragLeave($event)"
			},
			hostDirectives: [Bind]
		}]
	}], () => [], {
		value: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		selectionMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "selectionMode",
				required: false
			}]
		}],
		loadingMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loadingMode",
				required: false
			}]
		}],
		selection: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "selection",
				required: false
			}]
		}, {
			type: Output,
			args: ["selectionChange"]
		}],
		collapsedKeys: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "collapsedKeys",
				required: false
			}]
		}, {
			type: Output,
			args: ["collapsedKeysChange"]
		}],
		selectionKeys: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "selectionKeys",
				required: false
			}]
		}, {
			type: Output,
			args: ["selectionKeysChange"]
		}],
		contextMenu: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "contextMenu",
				required: false
			}]
		}],
		contextMenuSelection: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "contextMenuSelection",
				required: false
			}]
		}, {
			type: Output,
			args: ["contextMenuSelectionChange"]
		}],
		draggableScope: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "draggableScope",
				required: false
			}]
		}],
		droppableScope: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "droppableScope",
				required: false
			}]
		}],
		draggableNodes: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "draggableNodes",
				required: false
			}]
		}],
		droppableNodes: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "droppableNodes",
				required: false
			}]
		}],
		metaKeySelection: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "metaKeySelection",
				required: false
			}]
		}],
		propagateSelectionUp: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "propagateSelectionUp",
				required: false
			}]
		}],
		propagateSelectionDown: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "propagateSelectionDown",
				required: false
			}]
		}],
		loading: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loading",
				required: false
			}]
		}],
		loadingIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "loadingIcon",
				required: false
			}]
		}],
		emptyMessage: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "emptyMessage",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		togglerAriaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "togglerAriaLabel",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		validateDrop: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "validateDrop",
				required: false
			}]
		}],
		filter: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}],
		filterInputAutoFocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterInputAutoFocus",
				required: false
			}]
		}],
		filterBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterBy",
				required: false
			}]
		}],
		filterMode: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterMode",
				required: false
			}]
		}],
		filterPlaceholder: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterPlaceholder",
				required: false
			}]
		}],
		filteredNodes: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filteredNodes",
				required: false
			}]
		}, {
			type: Output,
			args: ["filteredNodesChange"]
		}],
		filterLocale: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "filterLocale",
				required: false
			}]
		}],
		scrollHeight: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "scrollHeight",
				required: false
			}]
		}],
		lazy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "lazy",
				required: false
			}]
		}],
		virtualScroll: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "virtualScroll",
				required: false
			}]
		}],
		virtualScrollItemSize: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "virtualScrollItemSize",
				required: false
			}]
		}],
		virtualScrollOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "virtualScrollOptions",
				required: false
			}]
		}],
		indentation: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "indentation",
				required: false
			}]
		}],
		trackBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "trackBy",
				required: false
			}]
		}],
		highlightOnSelect: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "highlightOnSelect",
				required: false
			}]
		}],
		onNodeSelect: [{
			type: Output,
			args: ["onNodeSelect"]
		}],
		onNodeUnselect: [{
			type: Output,
			args: ["onNodeUnselect"]
		}],
		onNodeExpand: [{
			type: Output,
			args: ["onNodeExpand"]
		}],
		onNodeCollapse: [{
			type: Output,
			args: ["onNodeCollapse"]
		}],
		onNodeContextMenuSelect: [{
			type: Output,
			args: ["onNodeContextMenuSelect"]
		}],
		onNodeDoubleClick: [{
			type: Output,
			args: ["onNodeDoubleClick"]
		}],
		onNodeDrop: [{
			type: Output,
			args: ["onNodeDrop"]
		}],
		onLazyLoad: [{
			type: Output,
			args: ["onLazyLoad"]
		}],
		onScroll: [{
			type: Output,
			args: ["onScroll"]
		}],
		onScrollIndexChange: [{
			type: Output,
			args: ["onScrollIndexChange"]
		}],
		onFilter: [{
			type: Output,
			args: ["onFilter"]
		}],
		filterTemplate: [{
			type: ContentChild,
			args: ["filter", {
				descendants: false,
				isSignal: true
			}]
		}],
		nodeTemplate: [{
			type: ContentChild,
			args: ["node", {
				descendants: false,
				isSignal: true
			}]
		}],
		headerTemplate: [{
			type: ContentChild,
			args: ["header", {
				descendants: false,
				isSignal: true
			}]
		}],
		footerTemplate: [{
			type: ContentChild,
			args: ["footer", {
				descendants: false,
				isSignal: true
			}]
		}],
		loaderTemplate: [{
			type: ContentChild,
			args: ["loader", {
				descendants: false,
				isSignal: true
			}]
		}],
		emptyTemplate: [{
			type: ContentChild,
			args: ["empty", {
				descendants: false,
				isSignal: true
			}]
		}],
		togglerIconTemplate: [{
			type: ContentChild,
			args: ["togglericon", {
				descendants: false,
				isSignal: true
			}]
		}],
		checkboxIconTemplate: [{
			type: ContentChild,
			args: ["checkboxicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		loadingIconTemplate: [{
			type: ContentChild,
			args: ["loadingicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		filterIconTemplate: [{
			type: ContentChild,
			args: ["filtericon", {
				descendants: false,
				isSignal: true
			}]
		}],
		filterViewChild: [{
			type: ViewChild,
			args: ["filter", { isSignal: true }]
		}],
		scroller: [{
			type: ViewChild,
			args: ["scroller", { isSignal: true }]
		}],
		wrapperViewChild: [{
			type: ViewChild,
			args: ["wrapper", { isSignal: true }]
		}],
		contentViewChild: [{
			type: ViewChild,
			args: ["content", { isSignal: true }]
		}]
	});
})();
var TreeModule = class TreeModule {
	static ɵfac = function TreeModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TreeModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: TreeModule,
		imports: [Tree],
		exports: [Tree]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [Tree] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TreeModule, [{
		type: NgModule,
		args: [{
			imports: [Tree],
			exports: [Tree]
		}]
	}], null, null);
})();
export { TreeStyle as i, TreeClasses as n, TreeModule as r, Tree as t };
