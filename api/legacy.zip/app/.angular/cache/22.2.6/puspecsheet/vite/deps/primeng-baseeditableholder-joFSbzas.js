import { Ui as signal, c as computed } from "./_resource-chunk-ejDdmnqV.js";
import { Ai as setClassMetadata, Ji as ɵɵInheritDefinitionFeature, O as booleanAttribute, Sn as Input, Wa as ɵɵdefineDirective, X as input, _o as ɵɵgetInheritedFactory, un as Directive } from "./core-BenYQOr3.js";
import { t as BaseModelHolder } from "./primeng-basemodelholder-DPekCZjY.js";
// node_modules/primeng/fesm2022/primeng-baseeditableholder.mjs
var BaseEditableHolder = class BaseEditableHolder extends BaseModelHolder {
	required = input(void 0, {
		...ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	invalid = input(void 0, {
		...ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(void 0, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	_disabled = signal(false, ...ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []);
	$disabled = computed(() => this.disabled() || this._disabled(), ...ngDevMode ? [{ debugName: "$disabled" }] : /* istanbul ignore next */ []);
	onModelChange = () => {};
	onModelTouched = () => {};
	writeDisabledState(value) {
		this._disabled.set(value);
	}
	writeControlValue(value, setModelValue) {}
	writeValue(value) {
		this.writeControlValue(value, this.writeModelValue.bind(this));
	}
	registerOnChange(fn) {
		this.onModelChange = fn;
	}
	registerOnTouched(fn) {
		this.onModelTouched = fn;
	}
	setDisabledState(val) {
		this.writeDisabledState(val);
		this.cd.markForCheck();
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵBaseEditableHolder_BaseFactory = void 0;
		return function BaseEditableHolder_Factory(__ngFactoryType__) {
			return (ɵBaseEditableHolder_BaseFactory || (ɵBaseEditableHolder_BaseFactory = ɵɵgetInheritedFactory(BaseEditableHolder)))(__ngFactoryType__ || BaseEditableHolder);
		};
	})();
	static ɵdir = /*@__PURE__*/ ɵɵdefineDirective({
		type: BaseEditableHolder,
		inputs: {
			required: [1, "required"],
			invalid: [1, "invalid"],
			disabled: [1, "disabled"],
			name: [1, "name"]
		},
		features: [ɵɵInheritDefinitionFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BaseEditableHolder, [{
		type: Directive,
		args: [{ standalone: true }]
	}], null, {
		required: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		invalid: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		name: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}]
	});
})();
export { BaseEditableHolder as t };
