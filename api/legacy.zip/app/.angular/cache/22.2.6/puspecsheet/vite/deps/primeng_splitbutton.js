import { U as InjectionToken, Ui as signal, _a as ɵɵnamespaceSVG, c as computed, la as ɵɵdefineInjectable, ua as ɵɵdefineInjector, va as ɵɵresetView, wr as inject, xn as effect, ya as ɵɵrestoreView } from "./_resource-chunk-ejDdmnqV.js";
import { Y as NgTemplateOutlet, u as isPlatformBrowser } from "./common-D_MNYFJX.js";
import { A as contentChild, Ai as setClassMetadata, Bo as ɵɵnextContext, Ds as ɵɵstyleMap, Fs as ɵɵtextInterpolate1, Ga as ɵɵdefineNgModule, Gt as ChangeDetectionStrategy, Ji as ɵɵInheritDefinitionFeature, Jt as Component, Nn as NgModule, Ns as ɵɵtext, O as booleanAttribute, Ps as ɵɵtextInterpolate, Ro as ɵɵlistener, S as ViewChild, Sn as Input, Ss as ɵɵsanitizeUrl, Ua as ɵɵdefineComponent, X as input, Xi as ɵɵProvidersFeature, Yo as ɵɵproperty, Zi as ɵɵadvance, Zo as ɵɵpureFunction1, Zs as ɵɵviewQuerySignal, _o as ɵɵgetInheritedFactory, aa as ɵɵattribute, ao as ɵɵelementContainer, at as output, ca as ɵɵclassMap, co as ɵɵelementEnd, da as ɵɵconditional, ds as ɵɵrepeaterCreate, fn as ElementRef, go as ɵɵgetCurrentView, gt as viewChild, ha as ɵɵcontentQuerySignal, i as ContentChild, io as ɵɵelement, js as ɵɵtemplate, lo as ɵɵelementStart, os as ɵɵqueryAdvance, pa as ɵɵconditionalCreate, pr as ViewEncapsulation, qi as ɵɵHostDirectivesFeature, rt as numberAttribute, us as ɵɵrepeater, vs as ɵɵsanitizeHtml, xn as Injectable, zn as Output } from "./core-BenYQOr3.js";
import { t as ChevronDown } from "./primeicons-angular-chevron-down-Cxy_idKw.js";
import { t as AutoFocus } from "./primeng-autofocus-C_rkAfz2.js";
import { a as getEventTarget, n as PARENT_INSTANCE, r as ConnectedOverlayScrollHandler, t as BaseComponent } from "./primeng-basecomponent-cJWiv26K.js";
import { Bind, BindModule } from "./primeng_bind.js";
import { o as ButtonDirective } from "./primeng-button-ipRa02IF.js";
import { s as BaseStyle } from "./primeng-config-DLP1OGtv.js";
import { S as p, T as z, b as l, s as J, w as x } from "./dist-BRhwYpCB.js";
import { OverlayService, SharedModule } from "./primeng_api.js";
import { n as MotionDirective, r as MotionModule } from "./primeng-motion-BhkauyGA.js";
import { C as G, G as fe, L as Wt, O as L, Q as nt, W as de, dt as z$1, s as zindexutils_default, v as C, y as Ct } from "./primeng-utils-CHKSviI4.js";
import { f as RouterLink, m as RouterModule, p as RouterLinkActive } from "./router-DFcbkMwa.js";
import { t as AngleRight } from "./primeicons-angular-angle-right-B6uI37x4.js";
import { t as Ripple } from "./primeng-ripple-BUHk2LHf.js";
import { r as TooltipModule, t as Tooltip } from "./primeng-tooltip-DhgMe6wA.js";
// node_modules/@primeuix/styles/dist/tieredmenu/index.mjs
var style$1 = "\n    .p-tieredmenu {\n        background: dt('tieredmenu.background');\n        color: dt('tieredmenu.color');\n        border: 1px solid dt('tieredmenu.border.color');\n        border-radius: dt('tieredmenu.border.radius');\n        min-width: 12.5rem;\n    }\n    \n\n    .p-tieredmenu-root-list,\n    .p-tieredmenu-submenu {\n        margin: 0;\n        padding: dt('tieredmenu.list.padding');\n        list-style: none;\n        outline: 0 none;\n        display: flex;\n        flex-direction: column;\n        gap: dt('tieredmenu.list.gap');\n    }\n\n    .p-tieredmenu-submenu {\n        position: absolute;\n        min-width: 100%;\n        z-index: 1;\n        background: dt('tieredmenu.background');\n        color: dt('tieredmenu.color');\n        border: 1px solid dt('tieredmenu.border.color');\n        border-radius: dt('tieredmenu.border.radius');\n        box-shadow: dt('tieredmenu.shadow');\n        will-change: transform;\n    }\n\n    .p-tieredmenu-item {\n        position: relative;\n    }\n\n    .p-tieredmenu-item-content {\n        transition:\n            background dt('tieredmenu.transition.duration'),\n            color dt('tieredmenu.transition.duration');\n        border-radius: dt('tieredmenu.item.border.radius');\n        color: dt('tieredmenu.item.color');\n    }\n\n    .p-tieredmenu-item-link {\n        cursor: pointer;\n        display: flex;\n        align-items: center;\n        text-decoration: none;\n        overflow: hidden;\n        position: relative;\n        color: inherit;\n        padding: dt('tieredmenu.item.padding');\n        gap: dt('tieredmenu.item.gap');\n        user-select: none;\n        outline: 0 none;\n    }\n\n    .p-tieredmenu-item-label {\n        font-weight: dt('tieredmenu.item.label.font.weight');\n        font-size: dt('tieredmenu.item.label.font.size');\n    }\n\n    .p-tieredmenu-item-icon {\n        color: dt('tieredmenu.item.icon.color');\n        font-size: dt('tieredmenu.item.icon.size');\n        width: dt('tieredmenu.item.icon.size');\n        height: dt('tieredmenu.item.icon.size');\n    }\n\n    .p-tieredmenu-submenu-icon {\n        color: dt('tieredmenu.submenu.icon.color');\n        margin-left: auto;\n        font-size: dt('tieredmenu.submenu.icon.size');\n        width: dt('tieredmenu.submenu.icon.size');\n        height: dt('tieredmenu.submenu.icon.size');\n    }\n\n    .p-tieredmenu-submenu-icon:dir(rtl) {\n        margin-left: 0;\n        margin-right: auto;\n    }\n\n    .p-tieredmenu-item.p-focus > .p-tieredmenu-item-content {\n        color: dt('tieredmenu.item.focus.color');\n        background: dt('tieredmenu.item.focus.background');\n    }\n\n    .p-tieredmenu-item.p-focus > .p-tieredmenu-item-content .p-tieredmenu-item-icon {\n        color: dt('tieredmenu.item.icon.focus.color');\n    }\n\n    .p-tieredmenu-item.p-focus > .p-tieredmenu-item-content .p-tieredmenu-submenu-icon {\n        color: dt('tieredmenu.submenu.icon.focus.color');\n    }\n\n    .p-tieredmenu-item:not(.p-disabled) > .p-tieredmenu-item-content:hover {\n        color: dt('tieredmenu.item.focus.color');\n        background: dt('tieredmenu.item.focus.background');\n    }\n\n    .p-tieredmenu-item:not(.p-disabled) > .p-tieredmenu-item-content:hover .p-tieredmenu-item-icon {\n        color: dt('tieredmenu.item.icon.focus.color');\n    }\n\n    .p-tieredmenu-item:not(.p-disabled) > .p-tieredmenu-item-content:hover .p-tieredmenu-submenu-icon {\n        color: dt('tieredmenu.submenu.icon.focus.color');\n    }\n\n    .p-tieredmenu-item-active > .p-tieredmenu-item-content {\n        color: dt('tieredmenu.item.active.color');\n        background: dt('tieredmenu.item.active.background');\n    }\n\n    .p-tieredmenu-item-active > .p-tieredmenu-item-content .p-tieredmenu-item-icon {\n        color: dt('tieredmenu.item.icon.active.color');\n    }\n\n    .p-tieredmenu-item-active > .p-tieredmenu-item-content .p-tieredmenu-submenu-icon {\n        color: dt('tieredmenu.submenu.icon.active.color');\n    }\n\n    .p-tieredmenu-separator {\n        border-block-start: 1px solid dt('tieredmenu.separator.border.color');\n    }\n\n    .p-tieredmenu-overlay {\n        box-shadow: dt('tieredmenu.shadow');\n        will-change: transform;\n    }\n\n    .p-tieredmenu-mobile .p-tieredmenu-submenu {\n        position: static;\n        box-shadow: none;\n        border: 0 none;\n        padding-inline-start: dt('tieredmenu.submenu.mobile.indent');\n        padding-inline-end: 0;\n    }\n\n    .p-tieredmenu-mobile .p-tieredmenu-submenu:dir(rtl) {\n        padding-inline-start: 0;\n        padding-inline-end: dt('tieredmenu.submenu.mobile.indent');\n    }\n\n    .p-tieredmenu-mobile .p-tieredmenu-submenu-icon {\n        transition: transform 0.2s;\n        transform: rotate(90deg);\n    }\n\n    .p-tieredmenu-mobile .p-tieredmenu-item-active > .p-tieredmenu-item-content .p-tieredmenu-submenu-icon {\n        transform: rotate(-90deg);\n    }\n";
// node_modules/primeng/fesm2022/primeng-tieredmenu.mjs
var inlineStyles = { submenu: ({ instance, processedItem }) => ({ display: instance.isItemActive(processedItem) ? "flex" : "none" }) };
var classes$1 = {
	root: ({ instance }) => ["p-tieredmenu p-component", {
		"p-tieredmenu-overlay": instance.popup(),
		"p-tieredmenu-mobile": instance.queryMatches()
	}],
	start: "p-tieredmenu-start",
	rootList: "p-tieredmenu-root-list",
	item: ({ instance, processedItem }) => ["p-tieredmenu-item", {
		"p-tieredmenu-item-active": instance.isItemActive(processedItem),
		"p-focus": instance.isItemFocused(processedItem),
		"p-disabled": instance.isItemDisabled(processedItem)
	}],
	itemContent: "p-tieredmenu-item-content",
	itemLink: "p-tieredmenu-item-link",
	itemIcon: "p-tieredmenu-item-icon",
	itemLabel: "p-tieredmenu-item-label",
	itemBadge: "p-menuitem-badge",
	submenuIcon: "p-tieredmenu-submenu-icon",
	submenu: "p-tieredmenu-submenu",
	separator: "p-tieredmenu-separator",
	end: "p-tieredmenu-end"
};
var TieredMenuStyle = class TieredMenuStyle extends BaseStyle {
	name = "tieredmenu";
	style = style$1;
	classes = classes$1;
	inlineStyles = inlineStyles;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵTieredMenuStyle_BaseFactory = void 0;
		return function TieredMenuStyle_Factory(__ngFactoryType__) {
			return (ɵTieredMenuStyle_BaseFactory || (ɵTieredMenuStyle_BaseFactory = ɵɵgetInheritedFactory(TieredMenuStyle)))(__ngFactoryType__ || TieredMenuStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: TieredMenuStyle,
		factory: TieredMenuStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TieredMenuStyle, [{ type: Injectable }], null, null);
})();
var TieredMenuClasses;
(function(TieredMenuClasses) {
	TieredMenuClasses["root"] = "p-tieredmenu";
	TieredMenuClasses["start"] = "p-tieredmenu-start";
	TieredMenuClasses["rootList"] = "p-tieredmenu-root-list";
	TieredMenuClasses["item"] = "p-tieredmenu-item";
	TieredMenuClasses["itemContent"] = "p-tieredmenu-item-content";
	TieredMenuClasses["itemLink"] = "p-tieredmenu-item-link";
	TieredMenuClasses["itemIcon"] = "p-tieredmenu-item-icon";
	TieredMenuClasses["itemLabel"] = "p-tieredmenu-item-label";
	TieredMenuClasses["submenuIcon"] = "p-tieredmenu-submenu-icon";
	TieredMenuClasses["submenu"] = "p-tieredmenu-submenu";
	TieredMenuClasses["separator"] = "p-tieredmenu-separator";
	TieredMenuClasses["end"] = "p-tieredmenu-end";
})(TieredMenuClasses || (TieredMenuClasses = {}));
var TIEREDMENU_INSTANCE = new InjectionToken("TIEREDMENU_INSTANCE");
var TIEREDMENUSUB_INSTANCE = new InjectionToken("TIEREDMENUSUB_INSTANCE");
var TieredMenuSub = class TieredMenuSub extends BaseComponent {
	visible = input(false, ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	itemTemplate = input(...ngDevMode ? [void 0, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []);
	root = input(false, {
		...ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	autoDisplay = input(false, {
		...ngDevMode ? { debugName: "autoDisplay" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	autoZIndex = input(true, {
		...ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	baseZIndex = input(0, {
		...ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	popup = input(false, {
		...ngDevMode ? { debugName: "popup" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	menuId = input(...ngDevMode ? [void 0, { debugName: "menuId" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	level = input(0, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	focusedItemId = input(...ngDevMode ? [void 0, { debugName: "focusedItemId" }] : /* istanbul ignore next */ []);
	activeItemPath = input([], ...ngDevMode ? [{ debugName: "activeItemPath" }] : /* istanbul ignore next */ []);
	motionOptions = input(...ngDevMode ? [void 0, { debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	tabindex = input(0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	inlineStyles = input(...ngDevMode ? [void 0, { debugName: "inlineStyles" }] : /* istanbul ignore next */ []);
	itemClick = output();
	itemMouseEnter = output();
	menuFocus = output();
	menuBlur = output();
	menuKeydown = output();
	sublistViewChild = viewChild("sublist", ...ngDevMode ? [{ debugName: "sublistViewChild" }] : /* istanbul ignore next */ []);
	render = signal(false, ...ngDevMode ? [{ debugName: "render" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(TieredMenuStyle);
	bindDirectiveInstance = inject(Bind, { self: true });
	$pcTieredMenu = inject(TIEREDMENU_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	$pcTieredMenuSub = inject(TIEREDMENUSUB_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	tieredMenu = inject(TIEREDMENU_INSTANCE);
	constructor() {
		super();
		effect(() => {
			if (this.visible() || this.root()) this.render.set(true);
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host"]));
	}
	positionSubmenu(sublist) {
		if (isPlatformBrowser(this.tieredMenu.platformId)) {
			if (sublist) de(sublist, this.level());
		}
	}
	getItemProp(processedItem, name, params = null) {
		return processedItem && processedItem.item ? x(processedItem.item[name], params) : void 0;
	}
	getItemId(processedItem) {
		return processedItem.item?.id ?? `${this.menuId()}_${processedItem.key}`;
	}
	getItemKey(processedItem) {
		return this.getItemId(processedItem);
	}
	getItemLabel(processedItem) {
		return this.getItemProp(processedItem, "label");
	}
	getAriaSetSize() {
		return this.items().filter((processedItem) => this.isItemVisible(processedItem) && !this.getItemProp(processedItem, "separator")).length;
	}
	getAriaPosInset(index) {
		return index - this.items().slice(0, index).filter((processedItem) => {
			const isItemVisible = this.isItemVisible(processedItem);
			const isVisibleSeparator = isItemVisible && this.getItemProp(processedItem, "separator");
			return !isItemVisible || isVisibleSeparator;
		}).length + 1;
	}
	isItemVisible(processedItem) {
		return this.getItemProp(processedItem, "visible") !== false;
	}
	isItemActive(processedItem) {
		if (this.activeItemPath()) return this.activeItemPath().some((path) => path.key === processedItem.key);
		return false;
	}
	isItemDisabled(processedItem) {
		return !!this.getItemProp(processedItem, "disabled");
	}
	isItemFocused(processedItem) {
		return this.focusedItemId() === this.getItemId(processedItem);
	}
	isItemGroup(processedItem) {
		return l(processedItem.items);
	}
	hasIcon(processedItem) {
		return !!this.getItemProp(processedItem, "icon");
	}
	hasBadge(processedItem) {
		return !!this.getItemProp(processedItem, "badge");
	}
	shouldEscapeLabel(processedItem) {
		return this.getItemProp(processedItem, "escape") !== false;
	}
	getRouterLinkActiveOptions(processedItem) {
		return this.getItemProp(processedItem, "routerLinkActiveOptions") || { exact: false };
	}
	getItemTemplateContext(processedItem) {
		return {
			$implicit: processedItem.item,
			hasSubmenu: !!this.getItemProp(processedItem, "items")
		};
	}
	getAriaHaspopup(processedItem) {
		return this.isItemGroup(processedItem) && !this.getItemProp(processedItem, "to") ? "menu" : void 0;
	}
	getAriaExpanded(processedItem) {
		return this.isItemGroup(processedItem) ? this.isItemActive(processedItem) : void 0;
	}
	shouldShowSubmenu(processedItem) {
		return this.isItemVisible(processedItem) && this.isItemGroup(processedItem);
	}
	isSubmenuVisible(processedItem) {
		return this.isItemActive(processedItem) && this.isItemGroup(processedItem);
	}
	hasRouterLink(processedItem) {
		return !!this.getItemProp(processedItem, "routerLink");
	}
	isSeparator(processedItem) {
		return this.isItemVisible(processedItem) && !!this.getItemProp(processedItem, "separator");
	}
	isMenuItem(processedItem) {
		return this.isItemVisible(processedItem) && !this.getItemProp(processedItem, "separator");
	}
	getListClass() {
		return this.root() ? this.cx("rootList") : this.cx("submenu");
	}
	getListSection() {
		return this.root() ? "rootList" : "submenu";
	}
	getMotionState() {
		return this.root() ? true : this.visible();
	}
	getAriaDisabled(processedItem) {
		return this.isItemDisabled(processedItem) || void 0;
	}
	_ptm(section, options) {
		return this.$pcTieredMenu ? this.$pcTieredMenu.ptm(section, options) : this.ptm(section, options);
	}
	getPTOptions(processedItem, index, key) {
		return this._ptm(key, { context: {
			item: processedItem.item,
			index,
			active: this.isItemActive(processedItem),
			focused: this.isItemFocused(processedItem),
			disabled: this.isItemDisabled(processedItem)
		} });
	}
	onItemMouseEnter(param) {
		if (this.autoDisplay()) {
			const { originalEvent, processedItem } = param;
			this.itemMouseEnter.emit({
				originalEvent,
				processedItem
			});
		}
	}
	onItemClick(event, processedItem) {
		this.getItemProp(processedItem, "command", {
			originalEvent: event,
			item: processedItem.item
		});
		this.itemClick.emit({
			originalEvent: event,
			processedItem,
			isFocus: true
		});
	}
	onBeforeEnter(event) {
		this.positionSubmenu(event.element);
	}
	onAfterLeave() {
		this.render.set(false);
	}
	static ɵfac = function TieredMenuSub_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TieredMenuSub)();
	};
	static ɵcmp = (function() {
		const _c0 = ["sublist"];
		const _c1 = (a0) => ({ processedItem: a0 });
		const _forTrack0 = ($index, $item) => $item.key;
		function TieredMenuSub_Conditional_0_For_3_Conditional_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "li", 6);
			if (rf & 2) {
				const processedItem_r3 = ɵɵnextContext().$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "style"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("separator"), ctx_r1.getItemProp(processedItem_r3, "class"), ctx_r1.getItemProp(processedItem_r3, "styleClass")));
				ɵɵproperty("pBind", ctx_r1._ptm("separator"));
				ɵɵattribute("id", ctx_r1.getItemId(processedItem_r3));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 16);
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(4);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "iconStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemIcon"), ctx_r1.getItemProp(processedItem_r3, "icon"), ctx_r1.getItemProp(processedItem_r3, "iconClass")));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemIcon"));
				ɵɵattribute("tabindex", -1);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 16);
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(4);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "labelStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemLabel"), ctx_r1.getItemProp(processedItem_r3, "labelClass")));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemLabel"));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1.getItemLabel(processedItem_r3));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 17);
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(4);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "labelStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemLabel"), ctx_r1.getItemProp(processedItem_r3, "labelClass")));
				ɵɵproperty("innerHTML", ctx_r1.getItemLabel(processedItem_r3), ɵɵsanitizeHtml)("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemLabel"));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span");
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const processedItem_r3 = ɵɵnextContext(4).$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemBadge"), ctx_r1.getItemProp(processedItem_r3, "badgeStyleClass")));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1.getItemProp(processedItem_r3, "badge"));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_5_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 20);
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(5);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("submenuIcon"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "submenuIcon"));
				ɵɵattribute("aria-hidden", true);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_5_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_5_Conditional_0_Template, 1, 4, "svg", 18);
				ɵɵtemplate(1, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_5_ng_container_1_Template, 1, 0, "ng-container", 19);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(6);
				ɵɵconditional(!ctx_r1.tieredMenu.submenuIconTemplate() ? 0 : -1);
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.tieredMenu.submenuIconTemplate());
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "a", 12);
				ɵɵconditionalCreate(1, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_1_Template, 1, 6, "span", 13);
				ɵɵconditionalCreate(2, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_2_Template, 2, 6, "span", 13)(3, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_3_Template, 1, 6, "span", 14);
				ɵɵconditionalCreate(4, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_4_Template, 2, 3, "span", 15);
				ɵɵconditionalCreate(5, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Conditional_5_Template, 2, 2);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(3);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "linkStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemLink"), ctx_r1.getItemProp(processedItem_r3, "linkClass")));
				ɵɵproperty("target", ctx_r1.getItemProp(processedItem_r3, "target"))("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemLink"));
				ɵɵattribute("href", ctx_r1.getItemProp(processedItem_r3, "url"), ɵɵsanitizeUrl)("data-automationid", ctx_r1.getItemProp(processedItem_r3, "automationId"))("title", ctx_r1.getItemProp(processedItem_r3, "title"))("tabindex", -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.hasIcon(processedItem_r3) ? 1 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.shouldEscapeLabel(processedItem_r3) ? 2 : 3);
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.hasBadge(processedItem_r3) ? 4 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.isItemGroup(processedItem_r3) ? 5 : -1);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 16);
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(4);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "iconStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemIcon"), ctx_r1.getItemProp(processedItem_r3, "icon"), ctx_r1.getItemProp(processedItem_r3, "iconClass")));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemIcon"));
				ɵɵattribute("aria-hidden", true)("tabindex", -1);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_2_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span", 16);
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(4);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "labelStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemLabel"), ctx_r1.getItemProp(processedItem_r3, "labelClass")));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemLabel"));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1.getItemLabel(processedItem_r3));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "span", 17);
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(4);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "labelStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemLabel"), ctx_r1.getItemProp(processedItem_r3, "labelClass")));
				ɵɵproperty("innerHTML", ctx_r1.getItemLabel(processedItem_r3), ɵɵsanitizeHtml)("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemLabel"));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_4_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "span");
				ɵɵtext(1);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const processedItem_r3 = ɵɵnextContext(4).$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemBadge"), ctx_r1.getItemProp(processedItem_r3, "badgeStyleClass")));
				ɵɵadvance();
				ɵɵtextInterpolate(ctx_r1.getItemProp(processedItem_r3, "badge"));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_5_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 20);
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(5);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.cx("submenuIcon"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "submenuIcon"));
				ɵɵattribute("aria-hidden", true);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_5_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵconditionalCreate(0, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_5_Conditional_0_Template, 1, 4, "svg", 18);
				ɵɵtemplate(1, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_5_ng_container_1_Template, 1, 0, "ng-container", 19);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(6);
				ɵɵconditional(!ctx_r1.tieredMenu.submenuIconTemplate() ? 0 : -1);
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.tieredMenu.submenuIconTemplate());
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵelementStart(0, "a", 21);
				ɵɵconditionalCreate(1, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_1_Template, 1, 7, "span", 13);
				ɵɵconditionalCreate(2, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_2_Template, 2, 6, "span", 13)(3, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_3_Template, 1, 6, "span", 14);
				ɵɵconditionalCreate(4, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_4_Template, 2, 3, "span", 15);
				ɵɵconditionalCreate(5, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Conditional_5_Template, 2, 2);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext(3);
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "linkStyle"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("itemLink"), ctx_r1.getItemProp(processedItem_r3, "linkClass")));
				ɵɵproperty("routerLink", ctx_r1.getItemProp(processedItem_r3, "routerLink"))("queryParams", ctx_r1.getItemProp(processedItem_r3, "queryParams"))("routerLinkActive", "p-tieredmenu-item-link-active")("routerLinkActiveOptions", ctx_r1.getRouterLinkActiveOptions(processedItem_r3))("target", ctx_r1.getItemProp(processedItem_r3, "target"))("fragment", ctx_r1.getItemProp(processedItem_r3, "fragment"))("queryParamsHandling", ctx_r1.getItemProp(processedItem_r3, "queryParamsHandling"))("preserveFragment", ctx_r1.getItemProp(processedItem_r3, "preserveFragment"))("skipLocationChange", ctx_r1.getItemProp(processedItem_r3, "skipLocationChange"))("replaceUrl", ctx_r1.getItemProp(processedItem_r3, "replaceUrl"))("state", ctx_r1.getItemProp(processedItem_r3, "state"))("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemLink"));
				ɵɵattribute("data-automationid", ctx_r1.getItemProp(processedItem_r3, "automationId"))("title", ctx_r1.getItemProp(processedItem_r3, "title"))("tabindex", -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.hasIcon(processedItem_r3) ? 1 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.shouldEscapeLabel(processedItem_r3) ? 2 : 3);
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.hasBadge(processedItem_r3) ? 4 : -1);
				ɵɵadvance();
				ɵɵconditional(ctx_r1.isItemGroup(processedItem_r3) ? 5 : -1);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_0_Template, 6, 14, "a", 10)(1, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Conditional_1_Template, 6, 23, "a", 11);
			if (rf & 2) {
				const processedItem_r3 = ɵɵnextContext(2).$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵconditional(!ctx_r1.hasRouterLink(processedItem_r3) ? 0 : 1);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_4_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_4_ng_container_0_Template, 1, 0, "ng-container", 22);
			if (rf & 2) {
				const processedItem_r3 = ɵɵnextContext(2).$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵproperty("ngTemplateOutlet", ctx_r1.itemTemplate())("ngTemplateOutletContext", ctx_r1.getItemTemplateContext(processedItem_r3));
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				const _r7 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "p-tieredmenusub", 23);
				ɵɵlistener("itemClick", function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_5_Template_p_tieredmenusub_itemClick_0_listener($event) {
					ɵɵrestoreView(_r7);
					const ctx_r1 = ɵɵnextContext(4);
					return ɵɵresetView(ctx_r1.itemClick.emit($event));
				})("itemMouseEnter", function TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_5_Template_p_tieredmenusub_itemMouseEnter_0_listener($event) {
					ɵɵrestoreView(_r7);
					const ctx_r1 = ɵɵnextContext(4);
					return ɵɵresetView(ctx_r1.onItemMouseEnter($event));
				});
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const processedItem_r3 = ɵɵnextContext(2).$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵproperty("items", processedItem_r3.items)("itemTemplate", ctx_r1.itemTemplate())("autoDisplay", ctx_r1.autoDisplay())("menuId", ctx_r1.menuId())("visible", ctx_r1.isSubmenuVisible(processedItem_r3))("activeItemPath", ctx_r1.activeItemPath())("focusedItemId", ctx_r1.focusedItemId())("ariaLabelledBy", ctx_r1.getItemId(processedItem_r3))("level", ctx_r1.level() + 1)("pt", ctx_r1.pt())("motionOptions", ctx_r1.motionOptions())("unstyled", ctx_r1.unstyled());
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r4 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "li", 7, 1)(2, "div", 8);
				ɵɵlistener("click", function TieredMenuSub_Conditional_0_For_3_Conditional_1_Template_div_click_2_listener($event) {
					ɵɵrestoreView(_r4);
					const processedItem_r3 = ɵɵnextContext().$implicit;
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.onItemClick($event, processedItem_r3));
				})("mouseenter", function TieredMenuSub_Conditional_0_For_3_Conditional_1_Template_div_mouseenter_2_listener($event) {
					ɵɵrestoreView(_r4);
					const processedItem_r3 = ɵɵnextContext().$implicit;
					const ctx_r1 = ɵɵnextContext(2);
					return ɵɵresetView(ctx_r1.onItemMouseEnter({
						originalEvent: $event,
						processedItem: processedItem_r3
					}));
				});
				ɵɵconditionalCreate(3, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_3_Template, 2, 1)(4, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_4_Template, 1, 2, "ng-container");
				ɵɵelementEnd();
				ɵɵconditionalCreate(5, TieredMenuSub_Conditional_0_For_3_Conditional_1_Conditional_5_Template, 1, 12, "p-tieredmenusub", 9);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r4 = ɵɵnextContext();
				const processedItem_r3 = ctx_r4.$implicit;
				const ɵ$index_4_r6 = ctx_r4.$index;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵstyleMap(ctx_r1.getItemProp(processedItem_r3, "style"));
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("item", ɵɵpureFunction1(23, _c1, processedItem_r3)), ctx_r1.getItemProp(processedItem_r3, "styleClass")));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "item"))("pTooltip", ctx_r1.getItemProp(processedItem_r3, "tooltip"))("tooltipOptions", ctx_r1.getItemProp(processedItem_r3, "tooltipOptions"))("pTooltipUnstyled", ctx_r1.unstyled());
				ɵɵattribute("id", ctx_r1.getItemId(processedItem_r3))("data-p-highlight", ctx_r1.isItemActive(processedItem_r3))("data-p-focused", ctx_r1.isItemFocused(processedItem_r3))("data-p-disabled", ctx_r1.isItemDisabled(processedItem_r3))("aria-label", ctx_r1.getItemLabel(processedItem_r3))("aria-disabled", ctx_r1.getAriaDisabled(processedItem_r3))("aria-haspopup", ctx_r1.getAriaHaspopup(processedItem_r3))("aria-expanded", ctx_r1.getAriaExpanded(processedItem_r3))("aria-setsize", ctx_r1.getAriaSetSize())("aria-posinset", ctx_r1.getAriaPosInset(ɵ$index_4_r6));
				ɵɵadvance(2);
				ɵɵclassMap(ctx_r1.cx("itemContent"));
				ɵɵproperty("pBind", ctx_r1.getPTOptions(processedItem_r3, ɵ$index_4_r6, "itemContent"));
				ɵɵadvance();
				ɵɵconditional(!ctx_r1.itemTemplate() ? 3 : 4);
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.shouldShowSubmenu(processedItem_r3) ? 5 : -1);
			}
		}
		function TieredMenuSub_Conditional_0_For_3_Template(rf, ctx) {
			if (rf & 1) ɵɵconditionalCreate(0, TieredMenuSub_Conditional_0_For_3_Conditional_0_Template, 1, 6, "li", 4)(1, TieredMenuSub_Conditional_0_For_3_Conditional_1_Template, 6, 25, "li", 5);
			if (rf & 2) {
				const processedItem_r3 = ctx.$implicit;
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵconditional(ctx_r1.isSeparator(processedItem_r3) ? 0 : ctx_r1.isMenuItem(processedItem_r3) ? 1 : -1);
			}
		}
		function TieredMenuSub_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "ul", 3, 0);
				ɵɵlistener("keydown", function TieredMenuSub_Conditional_0_Template_ul_keydown_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.menuKeydown.emit($event));
				})("focus", function TieredMenuSub_Conditional_0_Template_ul_focus_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.menuFocus.emit($event));
				})("blur", function TieredMenuSub_Conditional_0_Template_ul_blur_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.menuBlur.emit($event));
				})("pMotionOnBeforeEnter", function TieredMenuSub_Conditional_0_Template_ul_pMotionOnBeforeEnter_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onBeforeEnter($event));
				})("pMotionOnAfterLeave", function TieredMenuSub_Conditional_0_Template_ul_pMotionOnAfterLeave_0_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onAfterLeave());
				});
				ɵɵrepeaterCreate(2, TieredMenuSub_Conditional_0_For_3_Template, 2, 1, null, null, _forTrack0);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵstyleMap(ctx_r1.inlineStyles());
				ɵɵclassMap(ctx_r1.getListClass());
				ɵɵproperty("id", ctx_r1.menuId() + "_list")("tabindex", ctx_r1.tabindex())("pBind", ctx_r1._ptm(ctx_r1.getListSection()))("pMotion", ctx_r1.getMotionState())("pMotionDisabled", ctx_r1.root() || ctx_r1.tieredMenu.queryMatches())("pMotionAppear", true)("pMotionName", ctx_r1.pcn("p-anchored-overlay"))("pMotionOptions", ctx_r1.motionOptions());
				ɵɵattribute("aria-label", ctx_r1.ariaLabel())("aria-labelledBy", ctx_r1.ariaLabelledBy())("aria-activedescendant", ctx_r1.focusedItemId())("aria-orientation", "vertical");
				ɵɵadvance(2);
				ɵɵrepeater(ctx_r1.items());
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: TieredMenuSub,
			selectors: [["p-tieredmenusub"]],
			viewQuery: function TieredMenuSub_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.sublistViewChild, _c0, 5);
				if (rf & 2) ɵɵqueryAdvance();
			},
			inputs: {
				visible: [1, "visible"],
				items: [1, "items"],
				itemTemplate: [1, "itemTemplate"],
				root: [1, "root"],
				autoDisplay: [1, "autoDisplay"],
				autoZIndex: [1, "autoZIndex"],
				baseZIndex: [1, "baseZIndex"],
				popup: [1, "popup"],
				menuId: [1, "menuId"],
				ariaLabel: [1, "ariaLabel"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				level: [1, "level"],
				focusedItemId: [1, "focusedItemId"],
				activeItemPath: [1, "activeItemPath"],
				motionOptions: [1, "motionOptions"],
				tabindex: [1, "tabindex"],
				inlineStyles: [1, "inlineStyles"]
			},
			outputs: {
				itemClick: "itemClick",
				itemMouseEnter: "itemMouseEnter",
				menuFocus: "menuFocus",
				menuBlur: "menuBlur",
				menuKeydown: "menuKeydown"
			},
			features: [
				ɵɵProvidersFeature([{
					provide: TIEREDMENUSUB_INSTANCE,
					useExisting: TieredMenuSub
				}, {
					provide: PARENT_INSTANCE,
					useExisting: TieredMenuSub
				}]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 1,
			vars: 1,
			consts: [
				["sublist", ""],
				["listItem", ""],
				[
					"role",
					"menu",
					3,
					"class",
					"id",
					"tabindex",
					"pBind",
					"style",
					"pMotion",
					"pMotionDisabled",
					"pMotionAppear",
					"pMotionName",
					"pMotionOptions"
				],
				[
					"role",
					"menu",
					3,
					"keydown",
					"focus",
					"blur",
					"pMotionOnBeforeEnter",
					"pMotionOnAfterLeave",
					"id",
					"tabindex",
					"pBind",
					"pMotion",
					"pMotionDisabled",
					"pMotionAppear",
					"pMotionName",
					"pMotionOptions"
				],
				[
					"role",
					"separator",
					3,
					"style",
					"class",
					"pBind"
				],
				[
					"role",
					"menuitem",
					3,
					"style",
					"class",
					"pBind",
					"pTooltip",
					"tooltipOptions",
					"pTooltipUnstyled"
				],
				[
					"role",
					"separator",
					3,
					"pBind"
				],
				[
					"role",
					"menuitem",
					3,
					"pBind",
					"pTooltip",
					"tooltipOptions",
					"pTooltipUnstyled"
				],
				[
					3,
					"click",
					"mouseenter",
					"pBind"
				],
				[
					3,
					"items",
					"itemTemplate",
					"autoDisplay",
					"menuId",
					"visible",
					"activeItemPath",
					"focusedItemId",
					"ariaLabelledBy",
					"level",
					"pt",
					"motionOptions",
					"unstyled"
				],
				[
					"pRipple",
					"",
					3,
					"target",
					"class",
					"style",
					"pBind"
				],
				[
					"pRipple",
					"",
					3,
					"routerLink",
					"queryParams",
					"routerLinkActive",
					"routerLinkActiveOptions",
					"target",
					"class",
					"style",
					"fragment",
					"queryParamsHandling",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"state",
					"pBind"
				],
				[
					"pRipple",
					"",
					3,
					"target",
					"pBind"
				],
				[
					3,
					"class",
					"style",
					"pBind"
				],
				[
					3,
					"class",
					"style",
					"innerHTML",
					"pBind"
				],
				[3, "class"],
				[3, "pBind"],
				[
					3,
					"innerHTML",
					"pBind"
				],
				[
					"data-p-icon",
					"angle-right",
					3,
					"class",
					"pBind"
				],
				[4, "ngTemplateOutlet"],
				[
					"data-p-icon",
					"angle-right",
					3,
					"pBind"
				],
				[
					"pRipple",
					"",
					3,
					"routerLink",
					"queryParams",
					"routerLinkActive",
					"routerLinkActiveOptions",
					"target",
					"fragment",
					"queryParamsHandling",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"state",
					"pBind"
				],
				[
					4,
					"ngTemplateOutlet",
					"ngTemplateOutletContext"
				],
				[
					3,
					"itemClick",
					"itemMouseEnter",
					"items",
					"itemTemplate",
					"autoDisplay",
					"menuId",
					"visible",
					"activeItemPath",
					"focusedItemId",
					"ariaLabelledBy",
					"level",
					"pt",
					"motionOptions",
					"unstyled"
				]
			],
			template: function TieredMenuSub_Template(rf, ctx) {
				if (rf & 1) ɵɵconditionalCreate(0, TieredMenuSub_Conditional_0_Template, 4, 16, "ul", 2);
				if (rf & 2) ɵɵconditional(ctx.render() ? 0 : -1);
			},
			dependencies: [
				TieredMenuSub,
				NgTemplateOutlet,
				RouterModule,
				RouterLink,
				RouterLinkActive,
				Ripple,
				TooltipModule,
				Tooltip,
				Bind,
				AngleRight,
				SharedModule,
				BindModule,
				MotionModule,
				MotionDirective
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TieredMenuSub, [{
		type: Component,
		args: [{
			selector: "p-tieredmenusub",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				RouterModule,
				Ripple,
				TooltipModule,
				AngleRight,
				SharedModule,
				BindModule,
				MotionModule
			],
			template: `
        @if (render()) {
            <ul
                #sublist
                role="menu"
                [class]="getListClass()"
                [id]="menuId() + '_list'"
                [tabindex]="tabindex()"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledBy]="ariaLabelledBy()"
                [attr.aria-activedescendant]="focusedItemId()"
                [attr.aria-orientation]="'vertical'"
                [pBind]="_ptm(getListSection())"
                (keydown)="menuKeydown.emit($event)"
                (focus)="menuFocus.emit($event)"
                (blur)="menuBlur.emit($event)"
                [style]="inlineStyles()"
                [pMotion]="getMotionState()"
                [pMotionDisabled]="root() || tieredMenu.queryMatches()"
                [pMotionAppear]="true"
                [pMotionName]="pcn('p-anchored-overlay')"
                [pMotionOptions]="motionOptions()"
                (pMotionOnBeforeEnter)="onBeforeEnter($event)"
                (pMotionOnAfterLeave)="onAfterLeave()"
            >
                @for (processedItem of items(); track processedItem.key; let index = $index) {
                    @if (isSeparator(processedItem)) {
                        <li
                            [attr.id]="getItemId(processedItem)"
                            [style]="getItemProp(processedItem, 'style')"
                            [class]="cn(cx('separator'), getItemProp(processedItem, 'class'), getItemProp(processedItem, 'styleClass'))"
                            role="separator"
                            [pBind]="_ptm('separator')"
                        ></li>
                    } @else if (isMenuItem(processedItem)) {
                        <li
                            #listItem
                            role="menuitem"
                            [attr.id]="getItemId(processedItem)"
                            [attr.data-p-highlight]="isItemActive(processedItem)"
                            [attr.data-p-focused]="isItemFocused(processedItem)"
                            [attr.data-p-disabled]="isItemDisabled(processedItem)"
                            [attr.aria-label]="getItemLabel(processedItem)"
                            [attr.aria-disabled]="getAriaDisabled(processedItem)"
                            [attr.aria-haspopup]="getAriaHaspopup(processedItem)"
                            [attr.aria-expanded]="getAriaExpanded(processedItem)"
                            [attr.aria-setsize]="getAriaSetSize()"
                            [attr.aria-posinset]="getAriaPosInset(index)"
                            [style]="getItemProp(processedItem, 'style')"
                            [class]="cn(cx('item', { processedItem }), getItemProp(processedItem, 'styleClass'))"
                            [pBind]="getPTOptions(processedItem, index, 'item')"
                            [pTooltip]="getItemProp(processedItem, 'tooltip')"
                            [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                            [pTooltipUnstyled]="unstyled()"
                        >
                            <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ originalEvent: $event, processedItem })">
                                @if (!itemTemplate()) {
                                    @if (!hasRouterLink(processedItem)) {
                                        <a
                                            [attr.href]="getItemProp(processedItem, 'url')"
                                            [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                            [attr.title]="getItemProp(processedItem, 'title')"
                                            [target]="getItemProp(processedItem, 'target')"
                                            [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                            [style]="getItemProp(processedItem, 'linkStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                            pRipple
                                        >
                                            @if (hasIcon(processedItem)) {
                                                <span
                                                    [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                                    [style]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                                    [attr.tabindex]="-1"
                                                ></span>
                                            }
                                            @if (shouldEscapeLabel(processedItem)) {
                                                <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [style]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                                    getItemLabel(processedItem)
                                                }}</span>
                                            } @else {
                                                <span
                                                    [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                                    [style]="getItemProp(processedItem, 'labelStyle')"
                                                    [innerHTML]="getItemLabel(processedItem)"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                                ></span>
                                            }
                                            @if (hasBadge(processedItem)) {
                                                <span [class]="cn(cx('itemBadge'), getItemProp(processedItem, 'badgeStyleClass'))">{{ getItemProp(processedItem, 'badge') }}</span>
                                            }
                                            @if (isItemGroup(processedItem)) {
                                                @if (!tieredMenu.submenuIconTemplate()) {
                                                    <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                }
                                                <ng-container *ngTemplateOutlet="tieredMenu.submenuIconTemplate()"></ng-container>
                                            }
                                        </a>
                                    } @else {
                                        <a
                                            [routerLink]="getItemProp(processedItem, 'routerLink')"
                                            [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                            [attr.title]="getItemProp(processedItem, 'title')"
                                            [attr.tabindex]="-1"
                                            [queryParams]="getItemProp(processedItem, 'queryParams')"
                                            [routerLinkActive]="'p-tieredmenu-item-link-active'"
                                            [routerLinkActiveOptions]="getRouterLinkActiveOptions(processedItem)"
                                            [target]="getItemProp(processedItem, 'target')"
                                            [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                            [style]="getItemProp(processedItem, 'linkStyle')"
                                            [fragment]="getItemProp(processedItem, 'fragment')"
                                            [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                            [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                            [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                            [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                            [state]="getItemProp(processedItem, 'state')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                            pRipple
                                        >
                                            @if (hasIcon(processedItem)) {
                                                <span
                                                    [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                                    [style]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                                    [attr.aria-hidden]="true"
                                                    [attr.tabindex]="-1"
                                                ></span>
                                            }
                                            @if (shouldEscapeLabel(processedItem)) {
                                                <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [style]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                                    getItemLabel(processedItem)
                                                }}</span>
                                            } @else {
                                                <span
                                                    [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                                    [style]="getItemProp(processedItem, 'labelStyle')"
                                                    [innerHTML]="getItemLabel(processedItem)"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                                ></span>
                                            }
                                            @if (hasBadge(processedItem)) {
                                                <span [class]="cn(cx('itemBadge'), getItemProp(processedItem, 'badgeStyleClass'))">{{ getItemProp(processedItem, 'badge') }}</span>
                                            }
                                            @if (isItemGroup(processedItem)) {
                                                @if (!tieredMenu.submenuIconTemplate()) {
                                                    <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                }
                                                <ng-container *ngTemplateOutlet="tieredMenu.submenuIconTemplate()"></ng-container>
                                            }
                                        </a>
                                    }
                                } @else {
                                    <ng-container *ngTemplateOutlet="itemTemplate(); context: getItemTemplateContext(processedItem)"></ng-container>
                                }
                            </div>

                            @if (shouldShowSubmenu(processedItem)) {
                                <p-tieredmenusub
                                    [items]="processedItem.items"
                                    [itemTemplate]="itemTemplate()"
                                    [autoDisplay]="autoDisplay()"
                                    [menuId]="menuId()"
                                    [visible]="isSubmenuVisible(processedItem)"
                                    [activeItemPath]="activeItemPath()"
                                    [focusedItemId]="focusedItemId()"
                                    [ariaLabelledBy]="getItemId(processedItem)"
                                    [level]="level() + 1"
                                    (itemClick)="itemClick.emit($event)"
                                    (itemMouseEnter)="onItemMouseEnter($event)"
                                    [pt]="pt()"
                                    [motionOptions]="motionOptions()"
                                    [unstyled]="unstyled()"
                                ></p-tieredmenusub>
                            }
                        </li>
                    }
                }
            </ul>
        }
    `,
			encapsulation: ViewEncapsulation.None,
			providers: [{
				provide: TIEREDMENUSUB_INSTANCE,
				useExisting: TieredMenuSub
			}, {
				provide: PARENT_INSTANCE,
				useExisting: TieredMenuSub
			}],
			hostDirectives: [Bind]
		}]
	}], () => [], {
		visible: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}],
		items: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		itemTemplate: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "itemTemplate",
				required: false
			}]
		}],
		root: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "root",
				required: false
			}]
		}],
		autoDisplay: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoDisplay",
				required: false
			}]
		}],
		autoZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoZIndex",
				required: false
			}]
		}],
		baseZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "baseZIndex",
				required: false
			}]
		}],
		popup: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "popup",
				required: false
			}]
		}],
		menuId: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "menuId",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		level: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		focusedItemId: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "focusedItemId",
				required: false
			}]
		}],
		activeItemPath: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "activeItemPath",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		inlineStyles: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "inlineStyles",
				required: false
			}]
		}],
		itemClick: [{
			type: Output,
			args: ["itemClick"]
		}],
		itemMouseEnter: [{
			type: Output,
			args: ["itemMouseEnter"]
		}],
		menuFocus: [{
			type: Output,
			args: ["menuFocus"]
		}],
		menuBlur: [{
			type: Output,
			args: ["menuBlur"]
		}],
		menuKeydown: [{
			type: Output,
			args: ["menuKeydown"]
		}],
		sublistViewChild: [{
			type: ViewChild,
			args: ["sublist", { isSignal: true }]
		}]
	});
})();
var TieredMenu = class TieredMenu extends BaseComponent {
	componentName = "TieredMenu";
	model = input(...ngDevMode ? [void 0, { debugName: "model" }] : /* istanbul ignore next */ []);
	popup = input(false, {
		...ngDevMode ? { debugName: "popup" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	style = input(...ngDevMode ? [void 0, { debugName: "style" }] : /* istanbul ignore next */ []);
	styleClass = input(...ngDevMode ? [void 0, { debugName: "styleClass" }] : /* istanbul ignore next */ []);
	breakpoint = input("960px", ...ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []);
	autoZIndex = input(true, {
		...ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	baseZIndex = input(0, {
		...ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	autoDisplay = input(true, {
		...ngDevMode ? { debugName: "autoDisplay" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	id = input(...ngDevMode ? [void 0, { debugName: "id" }] : /* istanbul ignore next */ []);
	ariaLabel = input(...ngDevMode ? [void 0, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	ariaLabelledBy = input(...ngDevMode ? [void 0, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabindex = input(0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	appendTo = input(...ngDevMode ? [void 0, { debugName: "appendTo" }] : /* istanbul ignore next */ []);
	motionOptions = input(...ngDevMode ? [void 0, { debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	computedMotionOptions = computed(() => ({
		...this.ptm("motion"),
		...this.motionOptions()
	}), ...ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []);
	onShow = output();
	onHide = output();
	rootmenu = viewChild("rootmenu", ...ngDevMode ? [{ debugName: "rootmenu" }] : /* istanbul ignore next */ []);
	containerViewChild = viewChild("container", ...ngDevMode ? [{ debugName: "containerViewChild" }] : /* istanbul ignore next */ []);
	submenuIconTemplate = contentChild("submenuicon", {
		...ngDevMode ? { debugName: "submenuIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	itemTemplate = contentChild("item", {
		...ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	$appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []);
	render = signal(false, ...ngDevMode ? [{ debugName: "render" }] : /* istanbul ignore next */ []);
	container;
	outsideClickListener;
	resizeListener;
	scrollHandler;
	target = null;
	relatedTarget = null;
	visible;
	dirty = false;
	focused = false;
	activeItemPath = signal([], ...ngDevMode ? [{ debugName: "activeItemPath" }] : /* istanbul ignore next */ []);
	focusedItemInfo = signal({
		index: -1,
		level: 0,
		parentKey: "",
		item: null
	}, ...ngDevMode ? [{ debugName: "focusedItemInfo" }] : /* istanbul ignore next */ []);
	searchValue = "";
	searchTimeout;
	_processedItems = [];
	_componentStyle = inject(TieredMenuStyle);
	bindDirectiveInstance = inject(Bind, { self: true });
	overlayService = inject(OverlayService);
	matchMediaListener = null;
	query;
	queryMatches = signal(false, ...ngDevMode ? [{ debugName: "queryMatches" }] : /* istanbul ignore next */ []);
	_internalId = this.$useId.next("pn_id_");
	$id = computed(() => this.id() || this._internalId, ...ngDevMode ? [{ debugName: "$id" }] : /* istanbul ignore next */ []);
	relativeAlign = false;
	shouldRender() {
		return this.render() || !this.popup();
	}
	shouldAnimate() {
		return this.visible || !this.popup();
	}
	getMenuTabindex() {
		return !this.disabled() ? this.tabindex() : -1;
	}
	getFocusedItemIdValue() {
		return this.focused ? this.focusedItemId ?? void 0 : void 0;
	}
	get visibleItems() {
		const processedItem = this.activeItemPath().find((p) => p.key === this.focusedItemInfo().parentKey);
		return processedItem ? processedItem.items : this.processedItems;
	}
	get processedItems() {
		if (!this._processedItems || !this._processedItems.length) this._processedItems = this.createProcessedItems(this.model() || []);
		return this._processedItems;
	}
	get focusedItemId() {
		const focusedItemInfo = this.focusedItemInfo();
		return focusedItemInfo.item?.id ? focusedItemInfo.item.id : focusedItemInfo.index !== -1 ? `${this.$id()}${l(focusedItemInfo.parentKey) ? "_" + focusedItemInfo.parentKey : ""}_${focusedItemInfo.index}` : null;
	}
	constructor() {
		super();
		effect(() => {
			const path = this.activeItemPath();
			if (l(path)) {
				this.bindOutsideClickListener();
				this.bindResizeListener();
			} else {
				this.unbindOutsideClickListener();
				this.unbindResizeListener();
			}
		});
		effect(() => {
			const value = this.model();
			if (value) this._processedItems = this.createProcessedItems(value);
		});
	}
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onInit() {
		this.bindMatchMediaListener();
	}
	bindMatchMediaListener() {
		if (isPlatformBrowser(this.platformId)) {
			if (!this.matchMediaListener) {
				const query = window.matchMedia(`(max-width: ${this.breakpoint()})`);
				this.query = query;
				this.queryMatches.set(query.matches);
				this.matchMediaListener = () => {
					this.queryMatches.set(query.matches);
				};
				query.addEventListener("change", this.matchMediaListener);
			}
		}
	}
	unbindMatchMediaListener() {
		if (this.matchMediaListener) {
			this.query.removeEventListener("change", this.matchMediaListener);
			this.matchMediaListener = null;
		}
	}
	createProcessedItems(items, level = 0, parent = {}, parentKey = "") {
		const processedItems = [];
		if (items) items.forEach((item, index) => {
			const key = (parentKey !== "" ? parentKey + "_" : "") + index;
			const newItem = {
				item,
				index,
				level,
				key,
				parent,
				parentKey,
				items: []
			};
			newItem.items = this.createProcessedItems(item.items, level + 1, newItem, key);
			processedItems.push(newItem);
		});
		return processedItems;
	}
	getItemProp(item, name) {
		return item ? x(item[name]) : void 0;
	}
	getProccessedItemLabel(processedItem) {
		return processedItem ? this.getItemLabel(processedItem.item) : void 0;
	}
	getItemLabel(item) {
		return this.getItemProp(item, "label");
	}
	isProcessedItemGroup(processedItem) {
		return processedItem && l(processedItem.items);
	}
	isSelected(processedItem) {
		return this.activeItemPath().some((p) => p.key === processedItem.key);
	}
	isValidSelectedItem(processedItem) {
		return this.isValidItem(processedItem) && this.isSelected(processedItem);
	}
	isValidItem(processedItem) {
		return !!processedItem && !this.isItemDisabled(processedItem.item) && !this.isItemSeparator(processedItem.item) && this.isItemVisible(processedItem.item);
	}
	isItemDisabled(item) {
		return !!this.getItemProp(item, "disabled");
	}
	isItemVisible(item) {
		return this.getItemProp(item, "visible") !== false;
	}
	isItemSeparator(item) {
		return !!this.getItemProp(item, "separator");
	}
	isItemMatched(processedItem) {
		const label = this.getProccessedItemLabel(processedItem);
		return this.isValidItem(processedItem) && !!label && label.toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase());
	}
	isProccessedItemGroup(processedItem) {
		return processedItem && l(processedItem.items);
	}
	onOverlayClick(event) {
		if (this.popup()) this.overlayService.add({
			originalEvent: event,
			target: this.el.nativeElement
		});
	}
	onItemClick(event) {
		const { originalEvent, processedItem } = event;
		const grouped = this.isProcessedItemGroup(processedItem);
		const root = p(processedItem.parent);
		if (this.isSelected(processedItem)) {
			const { index, key, level, parentKey, item } = processedItem;
			this.activeItemPath.set(this.activeItemPath().filter((p) => key !== p.key && key.startsWith(p.key)));
			this.focusedItemInfo.set({
				index,
				level,
				parentKey,
				item
			});
			this.dirty = true;
			Wt(this.rootmenu()?.sublistViewChild()?.nativeElement);
		} else if (grouped) this.onItemChange(event);
		else {
			const rootProcessedItem = root ? processedItem : this.activeItemPath().find((p) => p.parentKey === "");
			this.hide(originalEvent);
			this.changeFocusedItemIndex(originalEvent, rootProcessedItem?.index ?? -1);
			Wt(this.rootmenu()?.sublistViewChild()?.nativeElement);
		}
	}
	onItemMouseEnter(event) {
		if (!fe()) {
			if (this.dirty) this.onItemChange(event, "hover");
		} else this.onItemChange({
			...event,
			focus: this.autoDisplay()
		}, "hover");
	}
	onKeyDown(event) {
		const metaKey = event.metaKey || event.ctrlKey;
		switch (event.code) {
			case "ArrowDown":
				this.onArrowDownKey(event);
				break;
			case "ArrowUp":
				this.onArrowUpKey(event);
				break;
			case "ArrowLeft":
				this.onArrowLeftKey(event);
				break;
			case "ArrowRight":
				this.onArrowRightKey(event);
				break;
			case "Home":
				this.onHomeKey(event);
				break;
			case "End":
				this.onEndKey(event);
				break;
			case "Space":
				this.onSpaceKey(event);
				break;
			case "Enter":
				this.onEnterKey(event);
				break;
			case "Escape":
				this.onEscapeKey(event);
				break;
			case "Tab":
				this.onTabKey(event);
				break;
			case "PageDown":
			case "PageUp":
			case "Backspace":
			case "ShiftLeft":
			case "ShiftRight": break;
			default: if (!metaKey && J(event.key)) this.searchItems(event, event.key);
		}
	}
	onArrowDownKey(event) {
		const itemIndex = this.focusedItemInfo().index !== -1 ? this.findNextItemIndex(this.focusedItemInfo().index) : this.findFirstFocusedItemIndex();
		this.changeFocusedItemIndex(event, itemIndex);
		event.preventDefault();
	}
	onArrowRightKey(event) {
		const processedItem = this.visibleItems[this.focusedItemInfo().index];
		const grouped = this.isProccessedItemGroup(processedItem);
		const item = processedItem?.item;
		if (grouped) {
			this.onItemChange({
				originalEvent: event,
				processedItem
			});
			this.focusedItemInfo.set({
				index: -1,
				parentKey: processedItem.key,
				item
			});
			this.searchValue = "";
			this.onArrowDownKey(event);
		}
		event.preventDefault();
	}
	onArrowUpKey(event) {
		if (event.altKey) {
			if (this.focusedItemInfo().index !== -1) {
				const processedItem = this.visibleItems[this.focusedItemInfo().index];
				if (!this.isProccessedItemGroup(processedItem)) this.onItemChange({
					originalEvent: event,
					processedItem
				});
			}
			if (this.popup()) this.hide(event, true);
			event.preventDefault();
		} else {
			const itemIndex = this.focusedItemInfo().index !== -1 ? this.findPrevItemIndex(this.focusedItemInfo().index) : this.findLastFocusedItemIndex();
			this.changeFocusedItemIndex(event, itemIndex);
			event.preventDefault();
		}
	}
	onArrowLeftKey(event) {
		const processedItem = this.visibleItems[this.focusedItemInfo().index];
		if (!processedItem) {
			event.preventDefault();
			return;
		}
		const parentItem = this.activeItemPath().find((p) => p.key === processedItem.parentKey);
		if (!p(processedItem.parent)) {
			this.focusedItemInfo.set({
				index: -1,
				parentKey: parentItem ? parentItem.parentKey : "",
				item: processedItem.item
			});
			this.searchValue = "";
			this.onArrowDownKey(event);
		}
		const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== this.focusedItemInfo().parentKey);
		this.activeItemPath.set(activeItemPath);
		event.preventDefault();
	}
	onHomeKey(event) {
		this.changeFocusedItemIndex(event, this.findFirstItemIndex());
		event.preventDefault();
	}
	onEndKey(event) {
		this.changeFocusedItemIndex(event, this.findLastItemIndex());
		event.preventDefault();
	}
	onSpaceKey(event) {
		this.onEnterKey(event);
	}
	onEscapeKey(event) {
		this.hide(event, true);
		this.focusedItemInfo().index = this.findFirstFocusedItemIndex();
		event.preventDefault();
	}
	onTabKey(event) {
		if (this.focusedItemInfo().index !== -1) {
			const processedItem = this.visibleItems[this.focusedItemInfo().index];
			if (!this.isProccessedItemGroup(processedItem)) this.onItemChange({
				originalEvent: event,
				processedItem
			});
		}
		this.hide();
	}
	onEnterKey(event) {
		if (this.focusedItemInfo().index !== -1) {
			const element = nt(this.rootmenu()?.el?.nativeElement, `li[id="${`${this.focusedItemId}`}"]`);
			const anchorElement = element && (nt(element, "[data-pc-section=\"itemlink\"]") || nt(element, "a,button"));
			if (anchorElement) anchorElement.click();
			else element?.click();
			if (!this.popup()) {
				const processedItem = this.visibleItems[this.focusedItemInfo().index];
				if (!this.isProccessedItemGroup(processedItem)) this.focusedItemInfo().index = this.findFirstFocusedItemIndex();
			}
		}
		event.preventDefault();
	}
	onItemChange(event, type) {
		const { processedItem } = event;
		const isFocus = "isFocus" in event ? event.isFocus : "focus" in event ? event.focus : false;
		if (p(processedItem)) return;
		const { index, key, level, parentKey, items, item } = processedItem;
		const grouped = l(items);
		const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== parentKey && p.parentKey !== key);
		if (grouped) activeItemPath.push(processedItem);
		this.focusedItemInfo.set({
			index,
			level,
			parentKey,
			item
		});
		if (grouped) this.dirty = true;
		if (isFocus) Wt(this.rootmenu()?.sublistViewChild()?.nativeElement);
		if (type === "hover" && this.queryMatches()) return;
		this.activeItemPath.set(activeItemPath);
	}
	onMenuFocus(_event) {
		this.focused = true;
		if (this.focusedItemInfo().index === -1 && !this.popup()) {}
	}
	onMenuBlur(_event) {
		this.focused = false;
		this.focusedItemInfo.set({
			index: -1,
			level: 0,
			parentKey: "",
			item: null
		});
		this.searchValue = "";
		this.dirty = false;
	}
	onOverlayBeforeEnter(event) {
		if (this.popup()) {
			this.container = event.element;
			C(this.container, { position: "absolute" });
			this.moveOnTop();
			this.onShow.emit({});
			if (this.$attrSelector) this.$markInstance(this.container);
			this.appendOverlay();
			this.alignOverlay();
		}
	}
	onOverlayAfterEnter() {
		if (this.popup()) {
			this.bindOutsideClickListener();
			this.bindResizeListener();
			this.bindScrollListener();
			this.scrollInView();
		}
		Wt(this.rootmenu()?.sublistViewChild()?.nativeElement);
	}
	onOverlayAfterLeave() {
		this.restoreOverlayAppend();
		this.onOverlayHide();
		this.render.set(false);
		this.onHide.emit({});
	}
	alignOverlay() {
		if (this.container && this.target) {
			if (this.relativeAlign) G(this.container, this.target);
			else z$1(this.container, this.target);
			if (L(this.target) > L(this.container)) this.container.style.minWidth = L(this.target) + "px";
		}
	}
	appendOverlay() {
		if (this.$appendTo() && this.$appendTo() !== "self") {
			if (this.$appendTo() === "body") Ct(this.$overlayParent(this.document.body, this.container), this.container);
			else Ct(this.$overlayParent(this.$appendTo(), this.container), this.container);
		}
	}
	restoreOverlayAppend() {
		if (this.container && this.$appendTo() !== "self") Ct(this.el.nativeElement, this.container);
	}
	moveOnTop() {
		if (this.autoZIndex()) zindexutils_default.set("menu", this.container, this.baseZIndex() + this.config.zIndex.menu);
	}
	hide(_event, isFocus) {
		if (this.popup()) {
			this.onHide.emit({});
			this.visible = false;
		}
		this.activeItemPath.set([]);
		this.focusedItemInfo.set({
			index: -1,
			level: 0,
			parentKey: ""
		});
		if (isFocus) Wt(this.relatedTarget || this.target || this.rootmenu()?.sublistViewChild()?.nativeElement);
		this.dirty = false;
	}
	toggle(event) {
		if (this.visible) this.hide(void 0, true);
		else this.show(event);
	}
	show(event, isFocus) {
		if (this.popup()) {
			this.visible = true;
			this.target = this.target || event.currentTarget || null;
			this.relatedTarget = event.relatedTarget || null;
			this.relativeAlign = event?.relativeAlign || false;
		}
		this.render.set(true);
		this.focusedItemInfo.set({
			index: -1,
			level: 0,
			parentKey: ""
		});
		if (isFocus) Wt(this.rootmenu()?.sublistViewChild()?.nativeElement);
		this.cd.markForCheck();
	}
	searchItems(event, char) {
		this.searchValue = (this.searchValue || "") + char;
		let itemIndex = -1;
		let matched = false;
		if (this.focusedItemInfo().index !== -1) {
			itemIndex = this.visibleItems.slice(this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem));
			itemIndex = itemIndex === -1 ? this.visibleItems.slice(0, this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem)) : itemIndex + this.focusedItemInfo().index;
		} else itemIndex = this.visibleItems.findIndex((processedItem) => this.isItemMatched(processedItem));
		if (itemIndex !== -1) matched = true;
		if (itemIndex === -1 && this.focusedItemInfo().index === -1) itemIndex = this.findFirstFocusedItemIndex();
		if (itemIndex !== -1) this.changeFocusedItemIndex(event, itemIndex);
		if (this.searchTimeout) clearTimeout(this.searchTimeout);
		this.searchTimeout = setTimeout(() => {
			this.searchValue = "";
			this.searchTimeout = void 0;
		}, 500);
		return matched;
	}
	findLastFocusedItemIndex() {
		const selectedIndex = this.findSelectedItemIndex();
		return selectedIndex < 0 ? this.findLastItemIndex() : selectedIndex;
	}
	findLastItemIndex() {
		return z(this.visibleItems, (processedItem) => this.isValidItem(processedItem));
	}
	findPrevItemIndex(index) {
		const matchedItemIndex = index > 0 ? z(this.visibleItems.slice(0, index), (processedItem) => this.isValidItem(processedItem)) : -1;
		return matchedItemIndex > -1 ? matchedItemIndex : index;
	}
	findNextItemIndex(index) {
		const matchedItemIndex = index < this.visibleItems.length - 1 ? this.visibleItems.slice(index + 1).findIndex((processedItem) => this.isValidItem(processedItem)) : -1;
		return matchedItemIndex > -1 ? matchedItemIndex + index + 1 : index;
	}
	findFirstFocusedItemIndex() {
		const selectedIndex = this.findSelectedItemIndex();
		return selectedIndex < 0 ? this.findFirstItemIndex() : selectedIndex;
	}
	findFirstItemIndex() {
		return this.visibleItems.findIndex((processedItem) => this.isValidItem(processedItem));
	}
	findSelectedItemIndex() {
		return this.visibleItems.findIndex((processedItem) => this.isValidSelectedItem(processedItem));
	}
	changeFocusedItemIndex(_event, index) {
		if (this.focusedItemInfo().index !== index) {
			const focusedItemInfo = this.focusedItemInfo();
			this.focusedItemInfo.set({
				...focusedItemInfo,
				item: this.visibleItems[index].item,
				index
			});
			this.scrollInView();
		}
	}
	scrollInView(index = -1) {
		const id = index !== -1 ? `${this.$id()}_${index}` : this.focusedItemId;
		const element = nt(this.rootmenu()?.el?.nativeElement, `li[id="${id}"]`);
		if (element) {
			if (element.scrollIntoView) element.scrollIntoView({
				block: "nearest",
				inline: "nearest"
			});
		}
	}
	bindScrollListener() {
		if (!this.scrollHandler) this.scrollHandler = new ConnectedOverlayScrollHandler(this.target, (event) => {
			if (this.visible) this.hide(event, true);
		});
		this.scrollHandler.bindScrollListener();
	}
	unbindScrollListener() {
		if (this.scrollHandler) {
			this.scrollHandler.unbindScrollListener();
			this.scrollHandler = null;
		}
	}
	bindResizeListener() {
		if (isPlatformBrowser(this.platformId)) {
			if (!this.resizeListener) this.resizeListener = this.renderer.listen(this.document.defaultView, "resize", (event) => {
				if (!fe()) this.hide(event, true);
			});
		}
	}
	bindOutsideClickListener() {
		if (isPlatformBrowser(this.platformId)) {
			if (!this.outsideClickListener) this.outsideClickListener = this.renderer.listen(this.document, "click", (event) => {
				const containerEl = this.containerViewChild();
				const node = getEventTarget(event, this.target);
				const isOutsideContainer = containerEl && !containerEl.nativeElement.contains(getEventTarget(event, containerEl.nativeElement));
				const isOutsideTarget = this.popup() ? !(this.target && (this.target === node || this.target.contains(node))) : true;
				if (isOutsideContainer && isOutsideTarget) this.hide();
			});
		}
	}
	unbindOutsideClickListener() {
		if (this.outsideClickListener) {
			document.removeEventListener("click", this.outsideClickListener);
			this.outsideClickListener = null;
		}
	}
	unbindResizeListener() {
		if (this.resizeListener) {
			this.resizeListener();
			this.resizeListener = null;
		}
	}
	onOverlayHide() {
		this.unbindOutsideClickListener();
		this.unbindResizeListener();
		this.unbindScrollListener();
		if (!this.cd.destroyed) this.target = null;
		if (this.container && this.autoZIndex()) zindexutils_default.clear(this.container);
	}
	onDestroy() {
		if (this.popup()) {
			if (this.scrollHandler) {
				this.scrollHandler.destroy();
				this.scrollHandler = null;
			}
			this.restoreOverlayAppend();
			this.onOverlayHide();
		}
		this.unbindMatchMediaListener();
	}
	static ɵfac = function TieredMenu_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TieredMenu)();
	};
	static ɵcmp = (function() {
		const _c0 = ["submenuicon"];
		const _c1 = ["item"];
		const _c2 = ["rootmenu"];
		const _c3 = ["container"];
		function TieredMenu_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "div", 3, 0);
				ɵɵlistener("click", function TieredMenu_Conditional_0_Template_div_click_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onOverlayClick($event));
				})("pMotionOnBeforeEnter", function TieredMenu_Conditional_0_Template_div_pMotionOnBeforeEnter_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onOverlayBeforeEnter($event));
				})("pMotionOnAfterEnter", function TieredMenu_Conditional_0_Template_div_pMotionOnAfterEnter_0_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onOverlayAfterEnter());
				})("pMotionOnAfterLeave", function TieredMenu_Conditional_0_Template_div_pMotionOnAfterLeave_0_listener() {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onOverlayAfterLeave());
				});
				ɵɵelementStart(2, "p-tieredmenusub", 4, 1);
				ɵɵlistener("itemClick", function TieredMenu_Conditional_0_Template_p_tieredmenusub_itemClick_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onItemClick($event));
				})("menuFocus", function TieredMenu_Conditional_0_Template_p_tieredmenusub_menuFocus_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onMenuFocus($event));
				})("menuBlur", function TieredMenu_Conditional_0_Template_p_tieredmenusub_menuBlur_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onMenuBlur($event));
				})("menuKeydown", function TieredMenu_Conditional_0_Template_p_tieredmenusub_menuKeydown_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onKeyDown($event));
				})("itemMouseEnter", function TieredMenu_Conditional_0_Template_p_tieredmenusub_itemMouseEnter_2_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onItemMouseEnter($event));
				});
				ɵɵelementEnd()();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵstyleMap(ctx_r1.style());
				ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("root"), ctx_r1.styleClass()));
				ɵɵproperty("id", ctx_r1.$id())("pBind", ctx_r1.ptm("root"))("pMotion", ctx_r1.shouldAnimate())("pMotionName", ctx_r1.pcn("p-anchored-overlay"))("pMotionAppear", true)("pMotionDisabled", !ctx_r1.popup())("pMotionOptions", ctx_r1.computedMotionOptions());
				ɵɵadvance(2);
				ɵɵproperty("root", true)("visible", true)("items", ctx_r1.processedItems)("itemTemplate", ctx_r1.itemTemplate())("menuId", ctx_r1.$id())("tabindex", ctx_r1.getMenuTabindex())("ariaLabel", ctx_r1.ariaLabel())("ariaLabelledBy", ctx_r1.ariaLabelledBy())("baseZIndex", ctx_r1.baseZIndex())("autoZIndex", ctx_r1.autoZIndex())("autoDisplay", ctx_r1.autoDisplay())("popup", ctx_r1.popup())("focusedItemId", ctx_r1.getFocusedItemIdValue())("activeItemPath", ctx_r1.activeItemPath())("pt", ctx_r1.pt())("unstyled", ctx_r1.unstyled())("motionOptions", ctx_r1.computedMotionOptions());
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: TieredMenu,
			selectors: [["p-tieredmenu"], ["p-tiered-menu"]],
			contentQueries: function TieredMenu_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.submenuIconTemplate, _c0, 4)(dirIndex, ctx.itemTemplate, _c1, 4);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			viewQuery: function TieredMenu_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.rootmenu, _c2, 5)(ctx.containerViewChild, _c3, 5);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			inputs: {
				model: [1, "model"],
				popup: [1, "popup"],
				style: [1, "style"],
				styleClass: [1, "styleClass"],
				breakpoint: [1, "breakpoint"],
				autoZIndex: [1, "autoZIndex"],
				baseZIndex: [1, "baseZIndex"],
				autoDisplay: [1, "autoDisplay"],
				id: [1, "id"],
				ariaLabel: [1, "ariaLabel"],
				ariaLabelledBy: [1, "ariaLabelledBy"],
				disabled: [1, "disabled"],
				tabindex: [1, "tabindex"],
				appendTo: [1, "appendTo"],
				motionOptions: [1, "motionOptions"]
			},
			outputs: {
				onShow: "onShow",
				onHide: "onHide"
			},
			features: [
				ɵɵProvidersFeature([
					TieredMenuStyle,
					{
						provide: TIEREDMENU_INSTANCE,
						useExisting: TieredMenu
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: TieredMenu
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 1,
			vars: 1,
			consts: [
				["container", ""],
				["rootmenu", ""],
				[
					3,
					"id",
					"class",
					"style",
					"pBind",
					"pMotion",
					"pMotionName",
					"pMotionAppear",
					"pMotionDisabled",
					"pMotionOptions"
				],
				[
					3,
					"click",
					"pMotionOnBeforeEnter",
					"pMotionOnAfterEnter",
					"pMotionOnAfterLeave",
					"id",
					"pBind",
					"pMotion",
					"pMotionName",
					"pMotionAppear",
					"pMotionDisabled",
					"pMotionOptions"
				],
				[
					3,
					"itemClick",
					"menuFocus",
					"menuBlur",
					"menuKeydown",
					"itemMouseEnter",
					"root",
					"visible",
					"items",
					"itemTemplate",
					"menuId",
					"tabindex",
					"ariaLabel",
					"ariaLabelledBy",
					"baseZIndex",
					"autoZIndex",
					"autoDisplay",
					"popup",
					"focusedItemId",
					"activeItemPath",
					"pt",
					"unstyled",
					"motionOptions"
				]
			],
			template: function TieredMenu_Template(rf, ctx) {
				if (rf & 1) ɵɵconditionalCreate(0, TieredMenu_Conditional_0_Template, 4, 28, "div", 2);
				if (rf & 2) ɵɵconditional(ctx.shouldRender() ? 0 : -1);
			},
			dependencies: [
				TieredMenuSub,
				SharedModule,
				BindModule,
				Bind,
				MotionModule,
				MotionDirective
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TieredMenu, [{
		type: Component,
		args: [{
			selector: "p-tieredmenu, p-tiered-menu",
			standalone: true,
			imports: [
				TieredMenuSub,
				SharedModule,
				BindModule,
				MotionModule
			],
			template: `
        @if (shouldRender()) {
            <div
                #container
                [id]="$id()"
                [class]="cn(cx('root'), styleClass())"
                [style]="style()"
                [pBind]="ptm('root')"
                (click)="onOverlayClick($event)"
                [pMotion]="shouldAnimate()"
                [pMotionName]="pcn('p-anchored-overlay')"
                [pMotionAppear]="true"
                [pMotionDisabled]="!popup()"
                [pMotionOptions]="computedMotionOptions()"
                (pMotionOnBeforeEnter)="onOverlayBeforeEnter($event)"
                (pMotionOnAfterEnter)="onOverlayAfterEnter()"
                (pMotionOnAfterLeave)="onOverlayAfterLeave()"
            >
                <p-tieredmenusub
                    #rootmenu
                    [root]="true"
                    [visible]="true"
                    [items]="processedItems"
                    [itemTemplate]="itemTemplate()"
                    [menuId]="$id()"
                    [tabindex]="getMenuTabindex()"
                    [ariaLabel]="ariaLabel()"
                    [ariaLabelledBy]="ariaLabelledBy()"
                    [baseZIndex]="baseZIndex()"
                    [autoZIndex]="autoZIndex()"
                    [autoDisplay]="autoDisplay()"
                    [popup]="popup()"
                    [focusedItemId]="getFocusedItemIdValue()"
                    [activeItemPath]="activeItemPath()"
                    (itemClick)="onItemClick($event)"
                    (menuFocus)="onMenuFocus($event)"
                    (menuBlur)="onMenuBlur($event)"
                    (menuKeydown)="onKeyDown($event)"
                    (itemMouseEnter)="onItemMouseEnter($event)"
                    [pt]="pt()"
                    [unstyled]="unstyled()"
                    [motionOptions]="computedMotionOptions()"
                ></p-tieredmenusub>
            </div>
        }
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			encapsulation: ViewEncapsulation.None,
			providers: [
				TieredMenuStyle,
				{
					provide: TIEREDMENU_INSTANCE,
					useExisting: TieredMenu
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: TieredMenu
				}
			],
			hostDirectives: [Bind]
		}]
	}], () => [], {
		model: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "model",
				required: false
			}]
		}],
		popup: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "popup",
				required: false
			}]
		}],
		style: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "style",
				required: false
			}]
		}],
		styleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "styleClass",
				required: false
			}]
		}],
		breakpoint: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "breakpoint",
				required: false
			}]
		}],
		autoZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoZIndex",
				required: false
			}]
		}],
		baseZIndex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "baseZIndex",
				required: false
			}]
		}],
		autoDisplay: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autoDisplay",
				required: false
			}]
		}],
		id: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		ariaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		ariaLabelledBy: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "ariaLabelledBy",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		appendTo: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "appendTo",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		onShow: [{
			type: Output,
			args: ["onShow"]
		}],
		onHide: [{
			type: Output,
			args: ["onHide"]
		}],
		rootmenu: [{
			type: ViewChild,
			args: ["rootmenu", { isSignal: true }]
		}],
		containerViewChild: [{
			type: ViewChild,
			args: ["container", { isSignal: true }]
		}],
		submenuIconTemplate: [{
			type: ContentChild,
			args: ["submenuicon", {
				descendants: false,
				isSignal: true
			}]
		}],
		itemTemplate: [{
			type: ContentChild,
			args: ["item", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var TieredMenuModule = class TieredMenuModule {
	static ɵfac = function TieredMenuModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TieredMenuModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: TieredMenuModule,
		imports: [TieredMenu, SharedModule],
		exports: [TieredMenu, SharedModule]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [
		TieredMenu,
		SharedModule,
		SharedModule
	] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TieredMenuModule, [{
		type: NgModule,
		args: [{
			imports: [TieredMenu, SharedModule],
			exports: [TieredMenu, SharedModule]
		}]
	}], null, null);
})();
// node_modules/@primeuix/styles/dist/splitbutton/index.mjs
var style = "\n    .p-splitbutton {\n        display: inline-flex;\n        position: relative;\n        border-radius: dt('splitbutton.border.radius');\n    }\n\n    .p-splitbutton-button.p-button {\n        border-start-end-radius: 0;\n        border-end-end-radius: 0;\n        border-inline-end: 0 none;\n    }\n\n    .p-splitbutton-button.p-button:focus-visible,\n    .p-splitbutton-dropdown.p-button:focus-visible {\n        z-index: 1;\n    }\n\n    .p-splitbutton-button.p-button:not(:disabled):hover,\n    .p-splitbutton-button.p-button:not(:disabled):active {\n        border-inline-end: 0 none;\n    }\n\n    .p-splitbutton-dropdown.p-button {\n        border-start-start-radius: 0;\n        border-end-start-radius: 0;\n    }\n\n    .p-splitbutton .p-menu {\n        min-width: 100%;\n    }\n\n    .p-splitbutton-fluid {\n        display: flex;\n    }\n\n    .p-splitbutton-rounded .p-splitbutton-dropdown.p-button {\n        border-start-end-radius: dt('splitbutton.rounded.border.radius');\n        border-end-end-radius: dt('splitbutton.rounded.border.radius');\n    }\n\n    .p-splitbutton-rounded .p-splitbutton-button.p-button {\n        border-start-start-radius: dt('splitbutton.rounded.border.radius');\n        border-end-start-radius: dt('splitbutton.rounded.border.radius');\n    }\n\n    .p-splitbutton-raised {\n        box-shadow: dt('splitbutton.raised.shadow');\n    }\n";
// node_modules/primeng/fesm2022/primeng-splitbutton.mjs
var classes = {
	root: ({ instance }) => {
		const size = instance.size();
		return ["p-splitbutton p-component", {
			"p-splitbutton-raised": instance.raised(),
			"p-splitbutton-rounded": instance.rounded(),
			"p-splitbutton-outlined": instance.outlined(),
			"p-splitbutton-text": instance.text(),
			[`p-splitbutton-${size === "small" ? "sm" : "lg"}`]: size
		}];
	},
	pcButton: "p-splitbutton-button",
	pcDropdown: "p-splitbutton-dropdown p-button-icon-only"
};
var SplitButtonStyle = class SplitButtonStyle extends BaseStyle {
	name = "splitbutton";
	style = style;
	classes = classes;
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵSplitButtonStyle_BaseFactory = void 0;
		return function SplitButtonStyle_Factory(__ngFactoryType__) {
			return (ɵSplitButtonStyle_BaseFactory || (ɵSplitButtonStyle_BaseFactory = ɵɵgetInheritedFactory(SplitButtonStyle)))(__ngFactoryType__ || SplitButtonStyle);
		};
	})();
	static ɵprov = /*@__PURE__*/ ɵɵdefineInjectable({
		token: SplitButtonStyle,
		factory: SplitButtonStyle.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SplitButtonStyle, [{ type: Injectable }], null, null);
})();
var SplitButtonClasses;
(function(SplitButtonClasses) {
	SplitButtonClasses["root"] = "p-splitbutton";
	SplitButtonClasses["pcButton"] = "p-splitbutton-button";
	SplitButtonClasses["pcDropdown"] = "p-splitbutton-dropdown";
})(SplitButtonClasses || (SplitButtonClasses = {}));
var SPLITBUTTON_INSTANCE = new InjectionToken("SPLITBUTTON_INSTANCE");
var SplitButton = class SplitButton extends BaseComponent {
	componentName = "SplitButton";
	$pcSplitButton = inject(SPLITBUTTON_INSTANCE, {
		optional: true,
		skipSelf: true
	}) ?? void 0;
	bindDirectiveInstance = inject(Bind, { self: true });
	model_ = input(void 0, {
		...ngDevMode ? { debugName: "model_" } : /* istanbul ignore next */ {},
		alias: "model"
	});
	severity = input(...ngDevMode ? [void 0, { debugName: "severity" }] : /* istanbul ignore next */ []);
	raised = input(false, {
		...ngDevMode ? { debugName: "raised" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	rounded = input(false, {
		...ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	text = input(false, {
		...ngDevMode ? { debugName: "text" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	outlined = input(false, {
		...ngDevMode ? { debugName: "outlined" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	size = input(...ngDevMode ? [void 0, { debugName: "size" }] : /* istanbul ignore next */ []);
	plain = input(false, {
		...ngDevMode ? { debugName: "plain" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	icon = input(...ngDevMode ? [void 0, { debugName: "icon" }] : /* istanbul ignore next */ []);
	iconPos = input("left", ...ngDevMode ? [{ debugName: "iconPos" }] : /* istanbul ignore next */ []);
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	tooltip = input(...ngDevMode ? [void 0, { debugName: "tooltip" }] : /* istanbul ignore next */ []);
	tooltipOptions = input(...ngDevMode ? [void 0, { debugName: "tooltipOptions" }] : /* istanbul ignore next */ []);
	menuStyle = input(...ngDevMode ? [void 0, { debugName: "menuStyle" }] : /* istanbul ignore next */ []);
	menuStyleClass = input(...ngDevMode ? [void 0, { debugName: "menuStyleClass" }] : /* istanbul ignore next */ []);
	dropdownIcon = input(...ngDevMode ? [void 0, { debugName: "dropdownIcon" }] : /* istanbul ignore next */ []);
	appendTo = input("body", ...ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []);
	dir = input(...ngDevMode ? [void 0, { debugName: "dir" }] : /* istanbul ignore next */ []);
	expandAriaLabel = input(...ngDevMode ? [void 0, { debugName: "expandAriaLabel" }] : /* istanbul ignore next */ []);
	motionOptions = input(void 0, ...ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []);
	computedMotionOptions = computed(() => ({
		...this.ptm("motion"),
		...this.motionOptions()
	}), ...ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []);
	buttonProps = input(...ngDevMode ? [void 0, { debugName: "buttonProps" }] : /* istanbul ignore next */ []);
	menuButtonProps = input(...ngDevMode ? [void 0, { debugName: "menuButtonProps" }] : /* istanbul ignore next */ []);
	autofocus = input(false, {
		...ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	tabindex = input(void 0, {
		...ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	menuButtonDisabled = input(false, {
		...ngDevMode ? { debugName: "menuButtonDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	buttonDisabled = input(false, {
		...ngDevMode ? { debugName: "buttonDisabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	onClick = output();
	onMenuHide = output();
	onMenuShow = output();
	onDropdownClick = output();
	buttonViewChild = viewChild("defaultbtn", {
		...ngDevMode ? { debugName: "buttonViewChild" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	menu = viewChild("menu", ...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	contentTemplate = contentChild("content", {
		...ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	dropdownIconTemplate = contentChild("dropdownicon", {
		...ngDevMode ? { debugName: "dropdownIconTemplate" } : /* istanbul ignore next */ {},
		descendants: false
	});
	ariaId = this.$useId.next("pn_id_");
	isExpanded = signal(false, ...ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []);
	_componentStyle = inject(SplitButtonStyle);
	$appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []);
	$buttonDisabled = computed(() => this.disabled() || this.buttonDisabled(), ...ngDevMode ? [{ debugName: "$buttonDisabled" }] : /* istanbul ignore next */ []);
	$menuButtonDisabled = computed(() => this.disabled() || this.menuButtonDisabled(), ...ngDevMode ? [{ debugName: "$menuButtonDisabled" }] : /* istanbul ignore next */ []);
	onAfterViewChecked() {
		this.bindDirectiveInstance.setAttrs(this.ptms(["host", "root"]));
	}
	onDefaultButtonClick(event) {
		this.onClick.emit(event);
		this.menu()?.hide();
	}
	onDropdownButtonClick(event) {
		this.onDropdownClick.emit(event);
		this.menu()?.toggle({
			currentTarget: this.el?.nativeElement,
			relativeAlign: this.$appendTo() == "self"
		});
	}
	onDropdownButtonKeydown(event) {
		if (event.code === "ArrowDown" || event.code === "ArrowUp") {
			this.onDropdownButtonClick();
			event.preventDefault();
		}
	}
	onHide() {
		this.isExpanded.set(false);
		this.onMenuHide.emit();
	}
	onShow() {
		this.isExpanded.set(true);
		this.onMenuShow.emit();
	}
	static ɵfac = /*@__PURE__*/ (() => {
		let ɵSplitButton_BaseFactory = void 0;
		return function SplitButton_Factory(__ngFactoryType__) {
			return (ɵSplitButton_BaseFactory || (ɵSplitButton_BaseFactory = ɵɵgetInheritedFactory(SplitButton)))(__ngFactoryType__ || SplitButton);
		};
	})();
	static ɵcmp = (function() {
		const _c0 = ["content"];
		const _c1 = ["dropdownicon"];
		const _c2 = ["defaultbtn"];
		const _c3 = ["menu"];
		function SplitButton_Conditional_0_ng_container_1_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function SplitButton_Conditional_0_Template(rf, ctx) {
			if (rf & 1) {
				const _r1 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "button", 7);
				ɵɵlistener("click", function SplitButton_Conditional_0_Template_button_click_0_listener($event) {
					ɵɵrestoreView(_r1);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onDefaultButtonClick($event));
				});
				ɵɵtemplate(1, SplitButton_Conditional_0_ng_container_1_Template, 1, 0, "ng-container", 8);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("pcButton"));
				ɵɵproperty("pButton", ctx_r1.buttonProps())("severity", ctx_r1.severity())("text", ctx_r1.text())("outlined", ctx_r1.outlined())("size", ctx_r1.size())("plain", ctx_r1.plain())("disabled", ctx_r1.disabled())("tabindex", ctx_r1.tabindex())("pButtonPT", ctx_r1.ptm("pcButton"))("pButtonUnstyled", ctx_r1.unstyled())("pAutoFocus", ctx_r1.autofocus())("pTooltip", ctx_r1.tooltip())("pTooltipUnstyled", ctx_r1.unstyled())("tooltipOptions", ctx_r1.tooltipOptions());
				ɵɵattribute("aria-label", ctx_r1.label());
				ɵɵadvance();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.contentTemplate());
			}
		}
		function SplitButton_Conditional_1_Conditional_2_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "i");
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.icon());
			}
		}
		function SplitButton_Conditional_1_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "i");
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext(2);
				ɵɵclassMap(ctx_r1.icon());
			}
		}
		function SplitButton_Conditional_1_Template(rf, ctx) {
			if (rf & 1) {
				const _r3 = ɵɵgetCurrentView();
				ɵɵelementStart(0, "button", 7, 1);
				ɵɵlistener("click", function SplitButton_Conditional_1_Template_button_click_0_listener($event) {
					ɵɵrestoreView(_r3);
					const ctx_r1 = ɵɵnextContext();
					return ɵɵresetView(ctx_r1.onDefaultButtonClick($event));
				});
				ɵɵconditionalCreate(2, SplitButton_Conditional_1_Conditional_2_Template, 1, 2, "i", 4);
				ɵɵtext(3);
				ɵɵconditionalCreate(4, SplitButton_Conditional_1_Conditional_4_Template, 1, 2, "i", 4);
				ɵɵelementEnd();
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.cx("pcButton"));
				ɵɵproperty("pButton", ctx_r1.buttonProps())("severity", ctx_r1.severity())("text", ctx_r1.text())("outlined", ctx_r1.outlined())("size", ctx_r1.size())("plain", ctx_r1.plain())("disabled", ctx_r1.$buttonDisabled())("tabindex", ctx_r1.tabindex())("pButtonPT", ctx_r1.ptm("pcButton"))("pButtonUnstyled", ctx_r1.unstyled())("pAutoFocus", ctx_r1.autofocus())("pTooltip", ctx_r1.tooltip())("pTooltipUnstyled", ctx_r1.unstyled())("tooltipOptions", ctx_r1.tooltipOptions());
				ɵɵattribute("aria-label", ctx_r1.label());
				ɵɵadvance(2);
				ɵɵconditional(ctx_r1.icon() && ctx_r1.iconPos() !== "right" ? 2 : -1);
				ɵɵadvance();
				ɵɵtextInterpolate1(" ", ctx_r1.label(), " ");
				ɵɵadvance();
				ɵɵconditional(ctx_r1.icon() && ctx_r1.iconPos() === "right" ? 4 : -1);
			}
		}
		function SplitButton_Conditional_3_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "i");
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵclassMap(ctx_r1.dropdownIcon());
			}
		}
		function SplitButton_Conditional_4_ng_container_0_Template(rf, ctx) {
			if (rf & 1) ɵɵelementContainer(0);
		}
		function SplitButton_Conditional_4_Template(rf, ctx) {
			if (rf & 1) ɵɵtemplate(0, SplitButton_Conditional_4_ng_container_0_Template, 1, 0, "ng-container", 8);
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵproperty("ngTemplateOutlet", ctx_r1.dropdownIconTemplate());
			}
		}
		function SplitButton_Conditional_5_Template(rf, ctx) {
			if (rf & 1) {
				ɵɵnamespaceSVG();
				ɵɵelement(0, "svg", 5);
			}
			if (rf & 2) {
				const ctx_r1 = ɵɵnextContext();
				ɵɵproperty("pBind", ctx_r1.ptm("pcDropdown")["icon"]);
			}
		}
		return /*@__PURE__*/ ɵɵdefineComponent({
			type: SplitButton,
			selectors: [["p-splitbutton"], ["p-split-button"]],
			contentQueries: function SplitButton_ContentQueries(rf, ctx, dirIndex) {
				if (rf & 1) ɵɵcontentQuerySignal(dirIndex, ctx.contentTemplate, _c0, 4)(dirIndex, ctx.dropdownIconTemplate, _c1, 4);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			viewQuery: function SplitButton_Query(rf, ctx) {
				if (rf & 1) ɵɵviewQuerySignal(ctx.buttonViewChild, _c2, 5, ElementRef)(ctx.menu, _c3, 5);
				if (rf & 2) ɵɵqueryAdvance(2);
			},
			hostVars: 3,
			hostBindings: function SplitButton_HostBindings(rf, ctx) {
				if (rf & 2) {
					ɵɵattribute("data-p-severity", ctx.severity());
					ɵɵclassMap(ctx.cx("root"));
				}
			},
			inputs: {
				model_: [
					1,
					"model",
					"model_"
				],
				severity: [1, "severity"],
				raised: [1, "raised"],
				rounded: [1, "rounded"],
				text: [1, "text"],
				outlined: [1, "outlined"],
				size: [1, "size"],
				plain: [1, "plain"],
				icon: [1, "icon"],
				iconPos: [1, "iconPos"],
				label: [1, "label"],
				tooltip: [1, "tooltip"],
				tooltipOptions: [1, "tooltipOptions"],
				menuStyle: [1, "menuStyle"],
				menuStyleClass: [1, "menuStyleClass"],
				dropdownIcon: [1, "dropdownIcon"],
				appendTo: [1, "appendTo"],
				dir: [1, "dir"],
				expandAriaLabel: [1, "expandAriaLabel"],
				motionOptions: [1, "motionOptions"],
				buttonProps: [1, "buttonProps"],
				menuButtonProps: [1, "menuButtonProps"],
				autofocus: [1, "autofocus"],
				disabled: [1, "disabled"],
				tabindex: [1, "tabindex"],
				menuButtonDisabled: [1, "menuButtonDisabled"],
				buttonDisabled: [1, "buttonDisabled"]
			},
			outputs: {
				onClick: "onClick",
				onMenuHide: "onMenuHide",
				onMenuShow: "onMenuShow",
				onDropdownClick: "onDropdownClick"
			},
			features: [
				ɵɵProvidersFeature([
					SplitButtonStyle,
					{
						provide: SPLITBUTTON_INSTANCE,
						useExisting: SplitButton
					},
					{
						provide: PARENT_INSTANCE,
						useExisting: SplitButton
					}
				]),
				ɵɵHostDirectivesFeature([Bind]),
				ɵɵInheritDefinitionFeature
			],
			decls: 8,
			vars: 27,
			consts: [
				["menu", ""],
				["defaultbtn", ""],
				[
					"type",
					"button",
					3,
					"pButton",
					"severity",
					"text",
					"outlined",
					"size",
					"plain",
					"disabled",
					"tabindex",
					"class",
					"pButtonPT",
					"pButtonUnstyled",
					"pAutoFocus",
					"pTooltip",
					"pTooltipUnstyled",
					"tooltipOptions"
				],
				[
					"type",
					"button",
					"iconOnly",
					"",
					3,
					"click",
					"keydown",
					"pButton",
					"severity",
					"text",
					"outlined",
					"size",
					"plain",
					"disabled",
					"pButtonPT",
					"pButtonUnstyled"
				],
				[3, "class"],
				[
					"data-p-icon",
					"chevron-down",
					3,
					"pBind"
				],
				[
					3,
					"onHide",
					"onShow",
					"id",
					"popup",
					"model",
					"styleClass",
					"appendTo",
					"motionOptions",
					"pt",
					"unstyled"
				],
				[
					"type",
					"button",
					3,
					"click",
					"pButton",
					"severity",
					"text",
					"outlined",
					"size",
					"plain",
					"disabled",
					"tabindex",
					"pButtonPT",
					"pButtonUnstyled",
					"pAutoFocus",
					"pTooltip",
					"pTooltipUnstyled",
					"tooltipOptions"
				],
				[4, "ngTemplateOutlet"]
			],
			template: function SplitButton_Template(rf, ctx) {
				if (rf & 1) {
					ɵɵconditionalCreate(0, SplitButton_Conditional_0_Template, 2, 18, "button", 2)(1, SplitButton_Conditional_1_Template, 5, 20, "button", 2);
					ɵɵelementStart(2, "button", 3);
					ɵɵlistener("click", function SplitButton_Template_button_click_2_listener($event) {
						return ctx.onDropdownButtonClick($event);
					})("keydown", function SplitButton_Template_button_keydown_2_listener($event) {
						return ctx.onDropdownButtonKeydown($event);
					});
					ɵɵconditionalCreate(3, SplitButton_Conditional_3_Template, 1, 2, "i", 4)(4, SplitButton_Conditional_4_Template, 1, 1, "ng-container")(5, SplitButton_Conditional_5_Template, 1, 1, "svg", 5);
					ɵɵelementEnd();
					ɵɵelementStart(6, "p-tieredmenu", 6, 0);
					ɵɵlistener("onHide", function SplitButton_Template_p_tieredmenu_onHide_6_listener() {
						return ctx.onHide();
					})("onShow", function SplitButton_Template_p_tieredmenu_onShow_6_listener() {
						return ctx.onShow();
					});
					ɵɵelementEnd();
				}
				if (rf & 2) {
					ɵɵconditional(ctx.contentTemplate() ? 0 : 1);
					ɵɵadvance(2);
					ɵɵclassMap(ctx.cx("pcDropdown"));
					ɵɵproperty("pButton", ctx.menuButtonProps())("severity", ctx.severity())("text", ctx.text())("outlined", ctx.outlined())("size", ctx.size())("plain", ctx.plain())("disabled", ctx.$menuButtonDisabled())("pButtonPT", ctx.ptm("pcDropdown"))("pButtonUnstyled", ctx.unstyled());
					ɵɵattribute("aria-label", ctx.expandAriaLabel())("aria-haspopup", true)("aria-expanded", ctx.isExpanded())("aria-controls", ctx.ariaId);
					ɵɵadvance();
					ɵɵconditional(ctx.dropdownIcon() ? 3 : ctx.dropdownIconTemplate() ? 4 : 5);
					ɵɵadvance(3);
					ɵɵstyleMap(ctx.menuStyle());
					ɵɵproperty("id", ctx.ariaId)("popup", true)("model", ctx.model_())("styleClass", ctx.menuStyleClass())("appendTo", ctx.$appendTo())("motionOptions", ctx.computedMotionOptions())("pt", ctx.ptm("pcMenu"))("unstyled", ctx.unstyled());
				}
			},
			dependencies: [
				NgTemplateOutlet,
				ButtonDirective,
				AutoFocus,
				TieredMenu,
				ChevronDown,
				TooltipModule,
				Tooltip,
				Bind
			],
			encapsulation: 2
		});
	})();
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SplitButton, [{
		type: Component,
		args: [{
			selector: "p-splitbutton, p-split-button",
			standalone: true,
			imports: [
				NgTemplateOutlet,
				ButtonDirective,
				AutoFocus,
				TieredMenu,
				ChevronDown,
				TooltipModule,
				Bind
			],
			template: `
        @if (contentTemplate()) {
            <button
                type="button"
                [pButton]="buttonProps()"
                [severity]="severity()"
                [text]="text()"
                [outlined]="outlined()"
                [size]="size()"
                [plain]="plain()"
                [disabled]="disabled()"
                [tabindex]="tabindex()"
                [class]="cx('pcButton')"
                [attr.aria-label]="label()"
                [pButtonPT]="ptm('pcButton')"
                [pButtonUnstyled]="unstyled()"
                [pAutoFocus]="autofocus()"
                [pTooltip]="tooltip()"
                [pTooltipUnstyled]="unstyled()"
                [tooltipOptions]="tooltipOptions()"
                (click)="onDefaultButtonClick($event)"
            >
                <ng-container *ngTemplateOutlet="contentTemplate()" />
            </button>
        } @else {
            <button
                #defaultbtn
                type="button"
                [pButton]="buttonProps()"
                [severity]="severity()"
                [text]="text()"
                [outlined]="outlined()"
                [size]="size()"
                [plain]="plain()"
                [disabled]="$buttonDisabled()"
                [tabindex]="tabindex()"
                [class]="cx('pcButton')"
                [attr.aria-label]="label()"
                [pButtonPT]="ptm('pcButton')"
                [pButtonUnstyled]="unstyled()"
                [pAutoFocus]="autofocus()"
                [pTooltip]="tooltip()"
                [pTooltipUnstyled]="unstyled()"
                [tooltipOptions]="tooltipOptions()"
                (click)="onDefaultButtonClick($event)"
            >
                @if (icon() && iconPos() !== 'right') {
                    <i [class]="icon()"></i>
                }
                {{ label() }}
                @if (icon() && iconPos() === 'right') {
                    <i [class]="icon()"></i>
                }
            </button>
        }
        <button
            type="button"
            iconOnly
            [pButton]="menuButtonProps()"
            [severity]="severity()"
            [text]="text()"
            [outlined]="outlined()"
            [size]="size()"
            [plain]="plain()"
            [disabled]="$menuButtonDisabled()"
            [class]="cx('pcDropdown')"
            [attr.aria-label]="expandAriaLabel()"
            [attr.aria-haspopup]="true"
            [attr.aria-expanded]="isExpanded()"
            [attr.aria-controls]="ariaId"
            [pButtonPT]="ptm('pcDropdown')"
            [pButtonUnstyled]="unstyled()"
            (click)="onDropdownButtonClick($event)"
            (keydown)="onDropdownButtonKeydown($event)"
        >
            @if (dropdownIcon()) {
                <i [class]="dropdownIcon()"></i>
            } @else if (dropdownIconTemplate()) {
                <ng-container *ngTemplateOutlet="dropdownIconTemplate()" />
            } @else {
                <svg data-p-icon="chevron-down" [pBind]="ptm('pcDropdown')['icon']" />
            }
        </button>
        <p-tieredmenu
            [id]="ariaId"
            #menu
            [popup]="true"
            [model]="model_()"
            [style]="menuStyle()"
            [styleClass]="menuStyleClass()"
            [appendTo]="$appendTo()"
            [motionOptions]="computedMotionOptions()"
            (onHide)="onHide()"
            (onShow)="onShow()"
            [pt]="ptm('pcMenu')"
            [unstyled]="unstyled()"
        />
    `,
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				SplitButtonStyle,
				{
					provide: SPLITBUTTON_INSTANCE,
					useExisting: SplitButton
				},
				{
					provide: PARENT_INSTANCE,
					useExisting: SplitButton
				}
			],
			encapsulation: ViewEncapsulation.None,
			host: {
				"[class]": "cx('root')",
				"[attr.data-p-severity]": "severity()"
			},
			hostDirectives: [Bind]
		}]
	}], null, {
		model_: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "model",
				required: false
			}]
		}],
		severity: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "severity",
				required: false
			}]
		}],
		raised: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "raised",
				required: false
			}]
		}],
		rounded: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "rounded",
				required: false
			}]
		}],
		text: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		outlined: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "outlined",
				required: false
			}]
		}],
		size: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		plain: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		icon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "icon",
				required: false
			}]
		}],
		iconPos: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "iconPos",
				required: false
			}]
		}],
		label: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		tooltip: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tooltip",
				required: false
			}]
		}],
		tooltipOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tooltipOptions",
				required: false
			}]
		}],
		menuStyle: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "menuStyle",
				required: false
			}]
		}],
		menuStyleClass: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "menuStyleClass",
				required: false
			}]
		}],
		dropdownIcon: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "dropdownIcon",
				required: false
			}]
		}],
		appendTo: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "appendTo",
				required: false
			}]
		}],
		dir: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "dir",
				required: false
			}]
		}],
		expandAriaLabel: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "expandAriaLabel",
				required: false
			}]
		}],
		motionOptions: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "motionOptions",
				required: false
			}]
		}],
		buttonProps: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "buttonProps",
				required: false
			}]
		}],
		menuButtonProps: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "menuButtonProps",
				required: false
			}]
		}],
		autofocus: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "autofocus",
				required: false
			}]
		}],
		disabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		tabindex: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "tabindex",
				required: false
			}]
		}],
		menuButtonDisabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "menuButtonDisabled",
				required: false
			}]
		}],
		buttonDisabled: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "buttonDisabled",
				required: false
			}]
		}],
		onClick: [{
			type: Output,
			args: ["onClick"]
		}],
		onMenuHide: [{
			type: Output,
			args: ["onMenuHide"]
		}],
		onMenuShow: [{
			type: Output,
			args: ["onMenuShow"]
		}],
		onDropdownClick: [{
			type: Output,
			args: ["onDropdownClick"]
		}],
		buttonViewChild: [{
			type: ViewChild,
			args: ["defaultbtn", {
				read: ElementRef,
				isSignal: true
			}]
		}],
		menu: [{
			type: ViewChild,
			args: ["menu", { isSignal: true }]
		}],
		contentTemplate: [{
			type: ContentChild,
			args: ["content", {
				descendants: false,
				isSignal: true
			}]
		}],
		dropdownIconTemplate: [{
			type: ContentChild,
			args: ["dropdownicon", {
				descendants: false,
				isSignal: true
			}]
		}]
	});
})();
var SplitButtonModule = class SplitButtonModule {
	static ɵfac = function SplitButtonModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || SplitButtonModule)();
	};
	static ɵmod = /*@__PURE__*/ ɵɵdefineNgModule({
		type: SplitButtonModule,
		imports: [SplitButton],
		exports: [SplitButton]
	});
	static ɵinj = /*@__PURE__*/ ɵɵdefineInjector({ imports: [SplitButton] });
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SplitButtonModule, [{
		type: NgModule,
		args: [{
			imports: [SplitButton],
			exports: [SplitButton]
		}]
	}], null, null);
})();
export { SplitButton, SplitButtonClasses, SplitButtonModule, SplitButtonStyle };
